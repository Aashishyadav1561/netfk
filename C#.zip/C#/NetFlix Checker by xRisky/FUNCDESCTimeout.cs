﻿using System;

internal delegate object[] FUNCDESCTimeout(object object_0, bool bool_0);
