﻿using System;

internal delegate int CanonPersianCalendar(object object_0, RuntimeMethodHandle runtimeMethodHandle_0);
