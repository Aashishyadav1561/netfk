﻿using System;

internal delegate object SerializationExceptionIDynamicMessageSink();
