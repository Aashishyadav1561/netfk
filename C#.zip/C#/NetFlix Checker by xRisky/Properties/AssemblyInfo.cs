﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.Default | DebuggableAttribute.DebuggingModes.DisableOptimizations | DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints | DebuggableAttribute.DebuggingModes.EnableEditAndContinue)]
[assembly: AssemblyDescription("NetFlix Checker by xRisky")]
[assembly: AssemblyCompany("NetFlix Checker by xRisky")]
[assembly: AssemblyProduct("NetFlix Checker by xRisky")]
[assembly: AssemblyCopyright("Copyright ©  2019")]
[assembly: AssemblyTrademark("NetFlix Checker by xRisky")]
[assembly: ComVisible(false)]
[assembly: Guid("925c15c3-3197-4b71-852d-094b7cd42648")]
[assembly: CompilationRelaxations(8)]
[assembly: AssemblyTitle("NetFlix Checker by xRisky")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[module: NETGuard("KoiVM v0.2.0-custom")]
