﻿using System;

internal delegate object AuditFlags(RuntimeTypeHandle runtimeTypeHandle_0);
