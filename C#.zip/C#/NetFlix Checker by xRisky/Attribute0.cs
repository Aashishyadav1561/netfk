﻿using System;

internal class Attribute0 : Attribute
{
}
