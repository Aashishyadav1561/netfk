﻿using System;

internal delegate byte[] CultureTableDataObsoleteAttribute(object object_0, string string_0);
