﻿using System;

internal class PermissionTokenKeyComparer : Attribute
{
	internal PermissionTokenKeyComparer(int int_0)
	{
		this.DBCSDecoder = -(~(~(~(~(~(-(-(~(int_0 * 1016114441 * -1174025233) * -681947923) - -1794423816)) - 1569999757 - 89449807)))) ^ -69834584);
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
