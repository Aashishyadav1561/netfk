﻿using System;

internal class GetPackagePropertyFlagsQueue : Attribute
{
	internal GetPackagePropertyFlagsQueue(int int_0)
	{
		this.DBCSDecoder = -(-(-(-((((int_0 ^ -594889650) + 932377653 - -1328135107) * 189427777 ^ -2065023150 ^ -1674855835) * 812880561) - -1753915094)) + -464402271);
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
