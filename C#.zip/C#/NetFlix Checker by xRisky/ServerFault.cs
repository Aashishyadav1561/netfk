﻿using System;
using System.Drawing;
using Microsoft.VisualBasic.CompilerServices;

namespace WindowsApp45
{
	[StandardModule]
	internal sealed class ServerFault
	{
		public static Point EncodingInfo(Graphics graphics_0, string string_0, Font font_0, Rectangle rectangle_0)
		{
			ServerFault.DSASignatureFormatter = graphics_0.MeasureString(string_0, font_0);
			Point result = checked(new Point((int)Math.Round(unchecked((double)rectangle_0.Width / 2.0 - (double)(ServerFault.DSASignatureFormatter.Width / 2f))), (int)Math.Round(unchecked((double)rectangle_0.Height / 2.0 - (double)(ServerFault.DSASignatureFormatter.Height / 2f)))));
			return result;
		}

		private static SizeF DSASignatureFormatter;
	}
}
