﻿using System;

internal delegate bool LastCalledTypeExceptionHandlingClauseOptions(int int_0, IntPtr intptr_0, byte[] byte_0, int int_1, ref int int_2);
