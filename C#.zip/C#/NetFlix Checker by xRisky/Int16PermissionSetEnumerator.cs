﻿using System;

internal delegate object Int16PermissionSetEnumerator(RuntimeTypeHandle runtimeTypeHandle_0);
