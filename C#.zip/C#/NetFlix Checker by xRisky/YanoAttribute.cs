﻿using System;

internal class YanoAttribute : Attribute
{
}
