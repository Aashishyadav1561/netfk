﻿using System;

internal class StackOverflowException : Attribute
{
	internal StackOverflowException(int int_0)
	{
		this.DBCSDecoder = -(-((~(-(int_0 ^ -1094249087) * 1678894093 ^ 1810026585) - 607764907 - 90065983) * -269855363)) * 602207659 * 937192765 + 266394094;
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
