﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsApp45
{
	public class CryptoStreamSecurityState : ProgressBar
	{
		public CryptoStreamSecurityState()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
		}

		protected virtual void OnPaint(PaintEventArgs e)
		{
			<Module>.SoapFieldAttribute(160);
			this.SearchDataRealProxyFlags = e.Graphics;
			base.OnPaint(e);
			this.SearchDataRealProxyFlags.Clear(Color.FromArgb(37, 37, 40));
			checked
			{
				using (Pen pen = new Pen(Color.FromArgb(35, 35, 38)))
				{
					this.SearchDataRealProxyFlags.DrawRectangle(pen, new Rectangle(0, 0, base.Width - 1, base.Height - 1));
				}
				using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(0, 122, 204)))
				{
					this.SearchDataRealProxyFlags.FillRectangle(solidBrush, new Rectangle(0, 0, (int)Math.Round(unchecked((double)base.Value / (double)base.Maximum * (double)base.Width - 1.0)), base.Height - 1));
				}
			}
		}

		private Graphics SearchDataRealProxyFlags;
	}
}
