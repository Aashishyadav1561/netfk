﻿using System;

internal delegate uint IWindowClassEntry(uint uint_0, uint uint_1, byte[] byte_0);
