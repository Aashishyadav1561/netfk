﻿using System;

internal delegate int NotSupportedExceptionModuleResolveEventHandler(object object_0);
