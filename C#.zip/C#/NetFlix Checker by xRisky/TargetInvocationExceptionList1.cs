﻿using System;

internal class TargetInvocationExceptionList1 : Attribute
{
	internal TargetInvocationExceptionList1(int int_0)
	{
		this.DBCSDecoder = (~(-1483193768 - -(-1200005168 - ~(int_0 - 1593151588 - 2069995203 - -882728022) ^ -1837687766)) - 1933119801) * -1574345957;
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
