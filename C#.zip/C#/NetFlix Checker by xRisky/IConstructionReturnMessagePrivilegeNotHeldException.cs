﻿using System;

internal delegate int IConstructionReturnMessagePrivilegeNotHeldException(object object_0, string string_0);
