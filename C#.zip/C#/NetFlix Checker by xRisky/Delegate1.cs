﻿using System;
using System.Reflection.Emit;

internal delegate void Delegate1(object object_0, OpCode opCode_0, object object_1);
