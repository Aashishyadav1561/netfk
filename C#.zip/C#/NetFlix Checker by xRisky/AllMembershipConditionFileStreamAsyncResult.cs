﻿using System;

internal delegate void AllMembershipConditionFileStreamAsyncResult(string string_0);
