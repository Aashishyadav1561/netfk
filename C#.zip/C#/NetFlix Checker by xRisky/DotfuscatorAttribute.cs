﻿using System;

internal class DotfuscatorAttribute : Attribute
{
}
