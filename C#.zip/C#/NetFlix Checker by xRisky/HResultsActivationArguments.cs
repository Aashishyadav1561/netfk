﻿using System;

internal class HResultsActivationArguments : Attribute
{
	internal HResultsActivationArguments(int int_0)
	{
		this.DBCSDecoder = (-(int_0 + -686249661 - 688808497) * 939440343 ^ 1812365569 ^ -648852064) * 1926767447 * -930525913;
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
