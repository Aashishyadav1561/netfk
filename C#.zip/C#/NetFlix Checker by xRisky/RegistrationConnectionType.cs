﻿using System;

internal delegate void RegistrationConnectionType(object object_0, byte[] byte_0);
