﻿using System;

internal class Evaluation : Attribute
{
}
