﻿using System;

internal delegate uint INVOKEKIND(byte[] byte_0, int int_0);
