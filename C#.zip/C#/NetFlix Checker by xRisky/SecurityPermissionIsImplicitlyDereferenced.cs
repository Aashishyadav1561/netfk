﻿using System;
using System.Reflection;

internal delegate ParameterInfo[] SecurityPermissionIsImplicitlyDereferenced(object object_0);
