﻿using System;
using System.IO.Compression;

internal delegate object NullTextWriterSecurityTreatAsSafeAttribute(object object_0, CompressionMode compressionMode_0);
