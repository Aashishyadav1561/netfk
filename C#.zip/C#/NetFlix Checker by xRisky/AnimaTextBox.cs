﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace WindowsApp45
{
	[Obfuscation(Exclude = true)]
	[Obfuscation(Exclude = true)]
	public class AnimaTextBox : Control
	{
		private virtual TextBox ConditionalAttributeEraInfo
		{
			[CompilerGenerated]
			[Obfuscation(Exclude = true)]
			[Obfuscation(Exclude = true)]
			get
			{
				return this.TokenType;
			}
			[Obfuscation(Exclude = true)]
			[Obfuscation(Exclude = true)]
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(145);
				EventHandler value2 = delegate(object sender, EventArgs e)
				{
					this.TEnter();
				};
				KeyPressEventHandler value3 = new KeyPressEventHandler(this.TKeyPress);
				EventHandler value4 = delegate(object sender, EventArgs e)
				{
					this.TLeave();
				};
				EventHandler value5 = delegate(object sender, EventArgs e)
				{
					this.TTextChanged();
				};
				TextBox tokenType = this.TokenType;
				if (tokenType != null)
				{
					tokenType.Enter -= value2;
					tokenType.KeyPress -= value3;
					tokenType.Leave -= value4;
					tokenType.TextChanged -= value5;
				}
				this.TokenType = value;
				tokenType = this.TokenType;
				if (tokenType != null)
				{
					tokenType.Enter += value2;
					tokenType.KeyPress += value3;
					tokenType.Leave += value4;
					tokenType.TextChanged += value5;
				}
			}
		}

		public bool PermissionTokenTypeBinaryObjectWithMapTyped { [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] get; [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] set; }

		public bool PolicyRights { [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] get; [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] set; }

		public string MetadataTable
		{
			[Obfuscation(Exclude = true)]
			[Obfuscation(Exclude = true)]
			get
			{
				return this.ConditionalAttributeEraInfo.Text;
			}
			[Obfuscation(Exclude = true)]
			[Obfuscation(Exclude = true)]
			set
			{
				<Module>.SoapFieldAttribute(146);
				base.Text = value;
				this.ConditionalAttributeEraInfo.Text = value;
				base.Invalidate();
			}
		}

		public int IDictionary2IEnumVARIANT
		{
			[Obfuscation(Exclude = true)]
			[Obfuscation(Exclude = true)]
			get
			{
				return this.ConditionalAttributeEraInfo.MaxLength;
			}
			[Obfuscation(Exclude = true)]
			[Obfuscation(Exclude = true)]
			set
			{
				<Module>.SoapFieldAttribute(147);
				this.ConditionalAttributeEraInfo.MaxLength = value;
				base.Invalidate();
			}
		}

		public bool RijndaelManagedTransformMode
		{
			[Obfuscation(Exclude = true)]
			[Obfuscation(Exclude = true)]
			get
			{
				return this.ConditionalAttributeEraInfo.UseSystemPasswordChar;
			}
			[Obfuscation(Exclude = true)]
			[Obfuscation(Exclude = true)]
			set
			{
				<Module>.SoapFieldAttribute(148);
				this.ConditionalAttributeEraInfo.UseSystemPasswordChar = value;
				base.Invalidate();
			}
		}

		public bool SerializationMonkey
		{
			[Obfuscation(Exclude = true)]
			[Obfuscation(Exclude = true)]
			get
			{
				return this.ConditionalAttributeEraInfo.Multiline;
			}
			[Obfuscation(Exclude = true)]
			[Obfuscation(Exclude = true)]
			set
			{
				<Module>.SoapFieldAttribute(149);
				this.ConditionalAttributeEraInfo.Multiline = value;
				base.Size = checked(new Size(this.ConditionalAttributeEraInfo.Width + 2, this.ConditionalAttributeEraInfo.Height + 2));
				base.Invalidate();
			}
		}

		public bool FileLoadExceptionELEMDESC
		{
			[Obfuscation(Exclude = true)]
			[Obfuscation(Exclude = true)]
			get
			{
				return this.ConditionalAttributeEraInfo.ReadOnly;
			}
			[Obfuscation(Exclude = true)]
			[Obfuscation(Exclude = true)]
			set
			{
				<Module>.SoapFieldAttribute(150);
				this.ConditionalAttributeEraInfo.ReadOnly = value;
				base.Invalidate();
			}
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		public AnimaTextBox()
		{
			this.IArraySortHelper1 = new int[]
			{
				45,
				45,
				48
			};
			this.Comparer1SECURITYIMPERSONATIONLEVEL = 45;
			this.DoubleBuffered = true;
			this.ConditionalAttributeEraInfo = new TextBox
			{
				BorderStyle = BorderStyle.None,
				ForeColor = Color.FromArgb(200, 200, 200),
				BackColor = Color.FromArgb(55, 55, 58),
				Location = new Point(6, 5),
				Multiline = false
			};
			base.Controls.Add(this.ConditionalAttributeEraInfo);
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		protected override void CreateHandle()
		{
			<Module>.SoapFieldAttribute(151);
			if (this.PermissionTokenTypeBinaryObjectWithMapTyped)
			{
				this.IArraySortHelper1 = new int[]
				{
					42,
					42,
					45
				};
				this.Comparer1SECURITYIMPERSONATIONLEVEL = 45;
				this.ConditionalAttributeEraInfo.BackColor = Color.FromArgb(45, 45, 48);
			}
			else
			{
				this.IArraySortHelper1 = new int[]
				{
					70,
					70,
					70
				};
				this.Comparer1SECURITYIMPERSONATIONLEVEL = 70;
				this.ConditionalAttributeEraInfo.BackColor = Color.FromArgb(55, 55, 58);
			}
			base.CreateHandle();
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		protected override void OnEnter(EventArgs e)
		{
			<Module>.SoapFieldAttribute(152);
			this.ConditionalAttributeEraInfo.Select();
			base.OnEnter(e);
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		protected override void OnPaint(PaintEventArgs e)
		{
			<Module>.SoapFieldAttribute(153);
			this.IComparer1SafeProvHandle = e.Graphics;
			checked
			{
				if (base.Enabled)
				{
					if (this.PermissionTokenTypeBinaryObjectWithMapTyped)
					{
						this.IComparer1SafeProvHandle.Clear(Color.FromArgb(45, 45, 48));
						using (Pen pen = new Pen(Color.FromArgb(this.IArraySortHelper1[0], this.IArraySortHelper1[1], this.IArraySortHelper1[2])))
						{
							this.IComparer1SafeProvHandle.DrawRectangle(pen, new Rectangle(0, 0, base.Width - 1, base.Height - 1));
							goto IL_2F0;
						}
					}
					this.IComparer1SafeProvHandle.Clear(Color.FromArgb(55, 55, 58));
					using (Pen pen2 = new Pen(Color.FromArgb(42, 42, 45)))
					{
						using (Pen pen3 = new Pen(Color.FromArgb(this.IArraySortHelper1[0], this.IArraySortHelper1[1], this.IArraySortHelper1[2])))
						{
							this.IComparer1SafeProvHandle.DrawRectangle(pen3, new Rectangle(1, 1, base.Width - 3, base.Height - 3));
							this.IComparer1SafeProvHandle.DrawRectangle(pen2, new Rectangle(0, 0, base.Width - 1, base.Height - 1));
						}
						goto IL_2F0;
					}
				}
				this.IComparer1SafeProvHandle.Clear(Color.FromArgb(50, 50, 53));
				this.ConditionalAttributeEraInfo.BackColor = Color.FromArgb(50, 50, 53);
				using (Pen pen4 = new Pen(Color.FromArgb(42, 42, 45)))
				{
					using (Pen pen5 = new Pen(Color.FromArgb(66, 66, 69)))
					{
						e.Graphics.DrawRectangle(pen4, new Rectangle(0, 0, base.Width - 1, base.Height - 1));
						e.Graphics.DrawRectangle(pen5, new Rectangle(1, 1, base.Width - 3, base.Height - 3));
					}
				}
				IL_2F0:
				base.OnPaint(e);
			}
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		private void TEnter()
		{
			<Module>.SoapFieldAttribute(154);
			if (!this.IsConst)
			{
				this.JitHelpersValueFixupEnum = new Thread(new ThreadStart(this.DoAnimation))
				{
					IsBackground = true
				};
				this.JitHelpersValueFixupEnum.Start();
			}
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		private void TKeyPress(object sender, KeyPressEventArgs e)
		{
			<Module>.SoapFieldAttribute(155);
			if (this.PolicyRights && Strings.Asc(e.KeyChar) != 8 && (Strings.Asc(e.KeyChar) < 48 | Strings.Asc(e.KeyChar) > 57))
			{
				e.Handled = true;
			}
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		private void TLeave()
		{
			<Module>.SoapFieldAttribute(156);
			this.IsCopyConstructedInputRecord = new Thread(new ThreadStart(this.UndoAnimation))
			{
				IsBackground = true
			};
			this.IsCopyConstructedInputRecord.Start();
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		protected override void OnResize(EventArgs e)
		{
			<Module>.SoapFieldAttribute(157);
			checked
			{
				if (this.SerializationMonkey)
				{
					this.ConditionalAttributeEraInfo.Size = new Size(base.Width - 7, base.Height - 7);
					base.Invalidate();
				}
				else
				{
					this.ConditionalAttributeEraInfo.Size = new Size(base.Width - 8, base.Height - 15);
					base.Invalidate();
				}
				base.OnResize(e);
			}
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		private void TTextChanged()
		{
			this.OnTextChanged(EventArgs.Empty);
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		private void DoAnimation()
		{
			<Module>.SoapFieldAttribute(158);
			checked
			{
				while (this.IArraySortHelper1[2] < 204 && !this.IsConst)
				{
					int[] iarraySortHelper = this.IArraySortHelper1;
					int num = 1;
					ref int ptr = ref iarraySortHelper[num];
					iarraySortHelper[num] = ptr + 1;
					int[] iarraySortHelper2 = this.IArraySortHelper1;
					int num2 = 2;
					ptr = ref iarraySortHelper2[num2];
					iarraySortHelper2[num2] = ptr + 2;
					base.Invalidate();
					Thread.Sleep(5);
				}
			}
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		private void UndoAnimation()
		{
			<Module>.SoapFieldAttribute(159);
			this.IsConst = true;
			checked
			{
				while (this.IArraySortHelper1[2] > this.Comparer1SECURITYIMPERSONATIONLEVEL)
				{
					int[] iarraySortHelper = this.IArraySortHelper1;
					int num = 1;
					ref int ptr = ref iarraySortHelper[num];
					iarraySortHelper[num] = ptr - 1;
					int[] iarraySortHelper2 = this.IArraySortHelper1;
					int num2 = 2;
					ptr = ref iarraySortHelper2[num2];
					iarraySortHelper2[num2] = ptr - 2;
					base.Invalidate();
					Thread.Sleep(5);
				}
				this.IsConst = false;
			}
		}

		private Graphics IComparer1SafeProvHandle;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("T")]
		private TextBox TokenType;

		private Thread JitHelpersValueFixupEnum;

		private Thread IsCopyConstructedInputRecord;

		private int[] IArraySortHelper1;

		private int Comparer1SECURITYIMPERSONATIONLEVEL;

		private bool IsConst;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private bool DynamicILGenerator;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private bool EventWaitHandleAccessRule;
	}
}
