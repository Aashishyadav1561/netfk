﻿using System;
using System.Reflection;

internal delegate ParameterInfo[] ExceptionInfoSecurityPermissionAttribute(object object_0);
