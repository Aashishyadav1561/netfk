﻿using System;

internal delegate byte[] TaiwanCalendar(uint uint_0);
