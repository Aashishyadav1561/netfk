﻿using System;
using System.Reflection;

internal delegate object UnverifiableCodeAttributeMissingFieldException(string string_0, MethodAttributes methodAttributes_0, CallingConventions callingConventions_0, object object_0, Type[] type_0, object object_1, bool bool_0);
