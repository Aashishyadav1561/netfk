﻿using System;

internal delegate string JapaneseLunisolarCalendarRSAPKCS1SHA1SignatureDescription(string string_0, string string_1);
