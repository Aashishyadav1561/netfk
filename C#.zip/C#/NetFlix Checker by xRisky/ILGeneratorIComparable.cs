﻿using System;

internal delegate object ILGeneratorIComparable(object object_0);
