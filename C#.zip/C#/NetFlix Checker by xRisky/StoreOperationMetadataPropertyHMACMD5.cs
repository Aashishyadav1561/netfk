﻿using System;

internal class StoreOperationMetadataPropertyHMACMD5 : Attribute
{
	internal StoreOperationMetadataPropertyHMACMD5(int int_0)
	{
		this.DBCSDecoder = (-((1476899490 - ~((~(-((int_0 ^ -744639091) * -1740863831 - -1047468149) ^ 1205389691) ^ -1712697011) + -720908381) - -1115830193 ^ -1949466022) - 672730214) - -2087745698) * 1683749551;
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
