﻿using System;
using System.Collections.Generic;

internal delegate uint ActivationAttributeStack(uint[] uint_0, uint uint_1, IList<byte> ilist_0, int int_0, int int_1);
