﻿using System;

internal class RSAOAEPKeyExchangeFormatterTwoLevelFileEnumerator : Attribute
{
	internal RSAOAEPKeyExchangeFormatterTwoLevelFileEnumerator(int int_0)
	{
		this.DBCSDecoder = ~(~(-(int_0 ^ 109849829) + -1990150957) * -1175871879 ^ 465499999);
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
