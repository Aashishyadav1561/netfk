﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic.CompilerServices;

namespace WindowsApp45.My
{
	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "11.0.0.0")]
	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal sealed partial class MySettings : ApplicationSettingsBase
	{
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		[DebuggerNonUserCode]
		private static void IMembershipCondition(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(2);
			if (MyProject.UnicodeDataHeader.SaveMySettingsOnExit)
			{
				LogicalCallContext.STOREASSEMBLYFILESTATUSFLAGS.Save();
			}
		}

		public static MySettings Default
		{
			get
			{
				if (!MySettings.EncodingTable)
				{
					object syncTextReader = MySettings.SyncTextReader;
					ObjectFlowControl.CheckForSyncLockOnValueType(syncTextReader);
					lock (syncTextReader)
					{
						if (!MySettings.EncodingTable)
						{
							MyProject.UnicodeDataHeader.Shutdown += MySettings.IMembershipCondition;
							MySettings.EncodingTable = true;
						}
					}
				}
				return MySettings.PseudoCustomAttribute;
			}
		}

		private static MySettings PseudoCustomAttribute = (MySettings)SettingsBase.Synchronized(new MySettings());

		private static bool EncodingTable;

		private static object SyncTextReader = RuntimeHelpers.GetObjectValue(new object());
	}
}
