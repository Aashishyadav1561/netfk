﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace WindowsApp45.My.Resources
{
	[StandardModule]
	[CompilerGenerated]
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
	[DebuggerNonUserCode]
	[HideModuleName]
	internal sealed class ResolveEventHandlerIListWrapper
	{
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager RemotingConfigInfo
		{
			get
			{
				if (object.ReferenceEquals(ResolveEventHandlerIListWrapper.JapaneseLunisolarCalendar, null))
				{
					ResourceManager japaneseLunisolarCalendar = new ResourceManager("WindowsApp45.Resources", typeof(ResolveEventHandlerIListWrapper).Assembly);
					ResolveEventHandlerIListWrapper.JapaneseLunisolarCalendar = japaneseLunisolarCalendar;
				}
				return ResolveEventHandlerIListWrapper.JapaneseLunisolarCalendar;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo BinaryReader
		{
			get
			{
				return ResolveEventHandlerIListWrapper.LayoutKindRemotingException;
			}
			set
			{
				ResolveEventHandlerIListWrapper.LayoutKindRemotingException = value;
			}
		}

		private static ResourceManager JapaneseLunisolarCalendar;

		private static CultureInfo LayoutKindRemotingException;
	}
}
