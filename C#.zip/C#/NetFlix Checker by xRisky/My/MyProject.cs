﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.ApplicationServices;
using Microsoft.VisualBasic.CompilerServices;

namespace WindowsApp45.My
{
	[StandardModule]
	[HideModuleName]
	[GeneratedCode("MyTemplate", "11.0.0.0")]
	[Obfuscation(Exclude = true)]
	internal sealed class MyProject
	{
		[HelpKeyword("My.Computer")]
		internal static IAppDomainSetup BinderState
		{
			[DebuggerHidden]
			get
			{
				return MyProject.AssemblyCultureAttribute.ISymbolBinder;
			}
		}

		[HelpKeyword("My.Application")]
		internal static ToStringHelperFunc UnicodeDataHeader
		{
			[DebuggerHidden]
			get
			{
				return MyProject.HijriCalendar.ISymbolBinder;
			}
		}

		[HelpKeyword("My.User")]
		internal static User Environment
		{
			[DebuggerHidden]
			get
			{
				return MyProject.IServerChannelSink.ISymbolBinder;
			}
		}

		[HelpKeyword("My.Forms")]
		internal static MyProject.MyForms MemberAccessException
		{
			[DebuggerHidden]
			get
			{
				return MyProject.Number.ISymbolBinder;
			}
		}

		[HelpKeyword("My.WebServices")]
		internal static MyProject.MyWebServices Guid
		{
			[DebuggerHidden]
			get
			{
				return MyProject.AsymmetricKeyExchangeFormatter.ISymbolBinder;
			}
		}

		private static readonly MyProject.ThreadSafeObjectProvider<IAppDomainSetup> AssemblyCultureAttribute = new MyProject.ThreadSafeObjectProvider<IAppDomainSetup>();

		private static readonly MyProject.ThreadSafeObjectProvider<ToStringHelperFunc> HijriCalendar = new MyProject.ThreadSafeObjectProvider<ToStringHelperFunc>();

		private static readonly MyProject.ThreadSafeObjectProvider<User> IServerChannelSink = new MyProject.ThreadSafeObjectProvider<User>();

		private static MyProject.ThreadSafeObjectProvider<MyProject.MyForms> Number = new MyProject.ThreadSafeObjectProvider<MyProject.MyForms>();

		private static readonly MyProject.ThreadSafeObjectProvider<MyProject.MyWebServices> AsymmetricKeyExchangeFormatter = new MyProject.ThreadSafeObjectProvider<MyProject.MyWebServices>();

		[EditorBrowsable(EditorBrowsableState.Never)]
		[MyGroupCollection("System.Windows.Forms.Form", "Create__Instance__", "Dispose__Instance__", "My.MyProject.Forms")]
		[Obfuscation(Exclude = true)]
		internal sealed class MyForms
		{
			[DebuggerHidden]
			private static T Create__Instance__<T>(T Instance) where T : Form, new()
			{
				if (Instance == null || Instance.IsDisposed)
				{
					if (MyProject.MyForms.LayoutKind != null)
					{
						if (MyProject.MyForms.LayoutKind.ContainsKey(typeof(T)))
						{
							throw new InvalidOperationException(Utils.GetResourceString("WinForms_RecursiveFormCreate", new string[0]));
						}
					}
					else
					{
						MyProject.MyForms.LayoutKind = new Hashtable();
					}
					MyProject.MyForms.LayoutKind.Add(typeof(T), null);
					try
					{
						return Activator.CreateInstance<T>();
					}
					catch (TargetInvocationException ex) when (ex.InnerException != null)
					{
						string resourceString = Utils.GetResourceString("WinForms_SeeInnerException", new string[]
						{
							ex.InnerException.Message
						});
						throw new InvalidOperationException(resourceString, ex.InnerException);
					}
					finally
					{
						MyProject.MyForms.LayoutKind.Remove(typeof(T));
					}
				}
				return Instance;
			}

			[DebuggerHidden]
			private void Dispose__Instance__<T>(ref T instance) where T : Form
			{
				instance.Dispose();
				instance = default(T);
			}

			[EditorBrowsable(EditorBrowsableState.Never)]
			[DebuggerHidden]
			public MyForms()
			{
			}

			[EditorBrowsable(EditorBrowsableState.Never)]
			public override bool Equals(object o)
			{
				return base.Equals(RuntimeHelpers.GetObjectValue(o));
			}

			[EditorBrowsable(EditorBrowsableState.Never)]
			public override int GetHashCode()
			{
				return base.GetHashCode();
			}

			[EditorBrowsable(EditorBrowsableState.Never)]
			internal new Type GetType()
			{
				return typeof(MyProject.MyForms);
			}

			[EditorBrowsable(EditorBrowsableState.Never)]
			public override string ToString()
			{
				return base.ToString();
			}

			public ISection StackEnumerator
			{
				[DebuggerHidden]
				get
				{
					this.UnitySerializationHolder = MyProject.MyForms.Create__Instance__<ISection>(this.UnitySerializationHolder);
					return this.UnitySerializationHolder;
				}
				[DebuggerHidden]
				set
				{
					if (value != this.UnitySerializationHolder)
					{
						if (value != null)
						{
							throw new ArgumentException("Property can only be set to Nothing");
						}
						this.Dispose__Instance__<ISection>(ref this.UnitySerializationHolder);
					}
				}
			}

			[ThreadStatic]
			private static Hashtable LayoutKind;

			[EditorBrowsable(EditorBrowsableState.Never)]
			public ISection UnitySerializationHolder;
		}

		[EditorBrowsable(EditorBrowsableState.Never)]
		[MyGroupCollection("System.Web.Services.Protocols.SoapHttpClientProtocol", "Create__Instance__", "Dispose__Instance__", "")]
		[Obfuscation(Exclude = true)]
		internal sealed class MyWebServices
		{
			[EditorBrowsable(EditorBrowsableState.Never)]
			[DebuggerHidden]
			public override bool Equals(object o)
			{
				return base.Equals(RuntimeHelpers.GetObjectValue(o));
			}

			[DebuggerHidden]
			[EditorBrowsable(EditorBrowsableState.Never)]
			public override int GetHashCode()
			{
				return base.GetHashCode();
			}

			[DebuggerHidden]
			[EditorBrowsable(EditorBrowsableState.Never)]
			internal new Type GetType()
			{
				return typeof(MyProject.MyWebServices);
			}

			[DebuggerHidden]
			[EditorBrowsable(EditorBrowsableState.Never)]
			public override string ToString()
			{
				return base.ToString();
			}

			[DebuggerHidden]
			private static T Create__Instance__<T>(T instance) where T : new()
			{
				T result;
				if (instance == null)
				{
					result = Activator.CreateInstance<T>();
				}
				else
				{
					result = instance;
				}
				return result;
			}

			[DebuggerHidden]
			private void Dispose__Instance__<T>(ref T instance)
			{
				instance = default(T);
			}

			[EditorBrowsable(EditorBrowsableState.Never)]
			[DebuggerHidden]
			public MyWebServices()
			{
			}
		}

		[ComVisible(false)]
		[Obfuscation(Exclude = true)]
		[EditorBrowsable(EditorBrowsableState.Never)]
		internal sealed class ThreadSafeObjectProvider<T> where T : new()
		{
			internal T ISymbolBinder
			{
				[DebuggerHidden]
				get
				{
					if (MyProject.ThreadSafeObjectProvider<T>.BinaryCrossAppDomainAssembly == null)
					{
						MyProject.ThreadSafeObjectProvider<T>.BinaryCrossAppDomainAssembly = Activator.CreateInstance<T>();
					}
					return MyProject.ThreadSafeObjectProvider<T>.BinaryCrossAppDomainAssembly;
				}
			}

			[EditorBrowsable(EditorBrowsableState.Never)]
			[DebuggerHidden]
			public ThreadSafeObjectProvider()
			{
			}

			[CompilerGenerated]
			[ThreadStatic]
			private static T BinaryCrossAppDomainAssembly;
		}
	}
}
