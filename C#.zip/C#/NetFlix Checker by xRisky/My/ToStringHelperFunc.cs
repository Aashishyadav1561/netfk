﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.ApplicationServices;

namespace WindowsApp45.My
{
	[GeneratedCode("MyTemplate", "11.0.0.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	internal class ToStringHelperFunc : WindowsFormsApplicationBase
	{
		[DebuggerHidden]
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		[STAThread]
		[MethodImpl(MethodImplOptions.NoOptimization)]
		internal static void SyncArrayList(string[] args)
		{
			<Module>.SoapFieldAttribute(0);
			try
			{
				Application.SetCompatibleTextRenderingDefault(WindowsFormsApplicationBase.UseCompatibleTextRendering);
			}
			finally
			{
			}
			MyProject.UnicodeDataHeader.Run(args);
		}

		[DebuggerStepThrough]
		public ToStringHelperFunc() : base(AuthenticationMode.Windows)
		{
			base.IsSingleInstance = false;
			base.EnableVisualStyles = true;
			base.SaveMySettingsOnExit = true;
			base.ShutdownStyle = ShutdownMode.AfterMainFormCloses;
		}

		[DebuggerStepThrough]
		protected virtual void SpecialPermissionSetFlag()
		{
			<Module>.SoapFieldAttribute(1);
			base.MainForm = MyProject.MemberAccessException.StackEnumerator;
		}

		public static uint[] AssemblyPathLockRankException;
	}
}
