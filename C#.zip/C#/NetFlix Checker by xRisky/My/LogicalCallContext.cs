﻿using System;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace WindowsApp45.My
{
	[StandardModule]
	[HideModuleName]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	internal sealed class LogicalCallContext
	{
		[HelpKeyword("My.Settings")]
		internal static MySettings STOREASSEMBLYFILESTATUSFLAGS
		{
			get
			{
				return MySettings.Default;
			}
		}
	}
}
