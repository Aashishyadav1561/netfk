﻿using System;
using System.Reflection;

internal delegate ConstructorInfo[] EncoderReplacementFallbackBufferLocalBuilder(object object_0);
