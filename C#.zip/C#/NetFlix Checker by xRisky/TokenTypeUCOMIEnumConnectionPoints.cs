﻿using System;

internal class TokenTypeUCOMIEnumConnectionPoints : Attribute
{
	internal TokenTypeUCOMIEnumConnectionPoints(int int_0)
	{
		this.DBCSDecoder = (~(-(-304270853 - (-1849370851 - -(-629758248 - (-(int_0 ^ -1784729249) - 1359813567)) ^ -414823395)) - -1746356536 + -520527936) ^ 1279121058) + -147490771;
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
