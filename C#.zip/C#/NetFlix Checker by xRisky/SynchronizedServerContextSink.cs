﻿using System;

internal class SynchronizedServerContextSink : Attribute
{
	internal SynchronizedServerContextSink(int int_0)
	{
		this.DBCSDecoder = -(-356865526 - (~(1349573687 - ~(-(int_0 - 733991409) - 16629802 ^ 1363837733)) + 257666041) * 697260455 - -312887645) * 839753167;
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
