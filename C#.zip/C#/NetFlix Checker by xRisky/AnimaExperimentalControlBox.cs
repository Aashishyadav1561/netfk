﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace WindowsApp45
{
	[Obfuscation(Exclude = true)]
	[Obfuscation(Exclude = true)]
	public class AnimaExperimentalControlBox : Control
	{
		public int CryptoKeyAuditRule { [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] get; [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] set; }

		public int FormatterAssemblyStyle { [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] get; [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] set; }

		public string[] AssemblyLoadEventArgs { [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] get; [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] set; }

		public int CoClassAttributeReliabilityContractAttribute { [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] get; [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] set; }

		public int EnvoyInfo { [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] get; [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] set; }

		public string PropertyTokenObjectIDGenerator { [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] get; [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] set; }

		public AnimaGroupBox ThreadStateException { [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] get; [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] set; }

		public Point UnknownWrapperExecutionEngineException { [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] get; [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] set; }

		public event AnimaExperimentalControlBox.INormalizeForIsolatedStorage PermissionTokenType
		{
			[CompilerGenerated]
			[Obfuscation(Exclude = true)]
			[Obfuscation(Exclude = true)]
			add
			{
				<Module>.SoapFieldAttribute(217);
				AnimaExperimentalControlBox.INormalizeForIsolatedStorage normalizeForIsolatedStorage = this.CodePageDataItemIsolatedStorageContainment;
				AnimaExperimentalControlBox.INormalizeForIsolatedStorage normalizeForIsolatedStorage2;
				do
				{
					normalizeForIsolatedStorage2 = normalizeForIsolatedStorage;
					AnimaExperimentalControlBox.INormalizeForIsolatedStorage value2 = (AnimaExperimentalControlBox.INormalizeForIsolatedStorage)Delegate.Combine(normalizeForIsolatedStorage2, value);
					normalizeForIsolatedStorage = Interlocked.CompareExchange<AnimaExperimentalControlBox.INormalizeForIsolatedStorage>(ref this.CodePageDataItemIsolatedStorageContainment, value2, normalizeForIsolatedStorage2);
				}
				while (normalizeForIsolatedStorage != normalizeForIsolatedStorage2);
			}
			[Obfuscation(Exclude = true)]
			[Obfuscation(Exclude = true)]
			[CompilerGenerated]
			remove
			{
				<Module>.SoapFieldAttribute(218);
				AnimaExperimentalControlBox.INormalizeForIsolatedStorage normalizeForIsolatedStorage = this.CodePageDataItemIsolatedStorageContainment;
				AnimaExperimentalControlBox.INormalizeForIsolatedStorage normalizeForIsolatedStorage2;
				do
				{
					normalizeForIsolatedStorage2 = normalizeForIsolatedStorage;
					AnimaExperimentalControlBox.INormalizeForIsolatedStorage value2 = (AnimaExperimentalControlBox.INormalizeForIsolatedStorage)Delegate.Remove(normalizeForIsolatedStorage2, value);
					normalizeForIsolatedStorage = Interlocked.CompareExchange<AnimaExperimentalControlBox.INormalizeForIsolatedStorage>(ref this.CodePageDataItemIsolatedStorageContainment, value2, normalizeForIsolatedStorage2);
				}
				while (normalizeForIsolatedStorage != normalizeForIsolatedStorage2);
			}
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		public AnimaExperimentalControlBox()
		{
			this.CryptoKeyAuditRule = 4;
			this.FormatterAssemblyStyle = 24;
			this.CoClassAttributeReliabilityContractAttribute = 0;
			this.EnvoyInfo = 24;
			this.AttributeUsageAttribute = 0;
			this.ServerObjectTerminatorSink = -1;
			this.DoubleBuffered = true;
			this.Font = new Font("Segoe UI", 9f);
			this.ForeColor = Color.FromArgb(200, 200, 200);
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		protected override void OnPaint(PaintEventArgs e)
		{
			<Module>.SoapFieldAttribute(219);
			e.Graphics.Clear(base.Parent.BackColor);
			checked
			{
				if (base.Enabled)
				{
					if (!Information.IsNothing(this.AssemblyLoadEventArgs))
					{
						this.AttributeUsageAttribute = this.AssemblyLoadEventArgs.Count<string>() * this.EnvoyInfo;
					}
					if (!base.DesignMode)
					{
						if (this.KoreanCalendar)
						{
							base.Height = this.AttributeUsageAttribute + this.FormatterAssemblyStyle + 5;
						}
						else
						{
							base.Height = this.FormatterAssemblyStyle + 1;
						}
					}
					using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(55, 55, 58)))
					{
						using (Pen pen = new Pen(Color.FromArgb(42, 42, 45)))
						{
							using (Pen pen2 = new Pen(Color.FromArgb(66, 66, 69)))
							{
								e.Graphics.FillRectangle(solidBrush, new Rectangle(0, 0, base.Width - 1, this.FormatterAssemblyStyle - 1));
								e.Graphics.DrawRectangle(pen, new Rectangle(0, 0, base.Width - 1, this.FormatterAssemblyStyle - 1));
								e.Graphics.DrawRectangle(pen2, new Rectangle(1, 1, base.Width - 3, this.FormatterAssemblyStyle - 3));
							}
						}
					}
					if (Information.IsNothing(this.AssemblyLoadEventArgs))
					{
						this.CoClassAttributeReliabilityContractAttribute = -1;
					}
					else if (this.CoClassAttributeReliabilityContractAttribute != -1)
					{
						using (SolidBrush solidBrush2 = new SolidBrush(this.ForeColor))
						{
							e.Graphics.DrawString(this.AssemblyLoadEventArgs[this.CoClassAttributeReliabilityContractAttribute], this.Font, solidBrush2, new Point(4, 4));
						}
					}
					if (this.KoreanCalendar)
					{
						using (SolidBrush solidBrush3 = new SolidBrush(Color.FromArgb(60, 60, 63)))
						{
							using (Pen pen3 = new Pen(Color.FromArgb(41, 130, 232)))
							{
								e.Graphics.FillRectangle(solidBrush3, new Rectangle(1, this.FormatterAssemblyStyle, base.Width - 3, this.AttributeUsageAttribute));
								e.Graphics.DrawRectangle(pen3, new Rectangle(1, this.FormatterAssemblyStyle, base.Width - 3, this.AttributeUsageAttribute));
							}
						}
						if (this.ServerObjectTerminatorSink != -1)
						{
							using (SolidBrush solidBrush4 = new SolidBrush(Color.FromArgb(41, 130, 232)))
							{
								using (Pen pen4 = new Pen(Color.FromArgb(40, 40, 40)))
								{
									e.Graphics.FillRectangle(solidBrush4, new Rectangle(1, this.FormatterAssemblyStyle + this.ServerObjectTerminatorSink * this.EnvoyInfo, base.Width - 2, this.EnvoyInfo));
									e.Graphics.DrawLine(pen4, 1, this.FormatterAssemblyStyle + this.ServerObjectTerminatorSink * this.EnvoyInfo + this.EnvoyInfo, base.Width - 2, this.FormatterAssemblyStyle + this.ServerObjectTerminatorSink * this.EnvoyInfo + this.EnvoyInfo);
								}
							}
						}
						int num = this.AssemblyLoadEventArgs.Count<string>() - 1;
						int i = 0;
						while (i <= num)
						{
							if (this.ServerObjectTerminatorSink == i)
							{
								using (SolidBrush solidBrush5 = new SolidBrush(Color.FromArgb(15, 15, 15)))
								{
									e.Graphics.DrawString(this.AssemblyLoadEventArgs[i], this.Font, solidBrush5, new Point(4, this.FormatterAssemblyStyle + this.CryptoKeyAuditRule + i * this.EnvoyInfo));
									goto IL_5A7;
								}
								goto IL_535;
							}
							goto IL_535;
							IL_5A7:
							i++;
							continue;
							IL_535:
							using (SolidBrush solidBrush6 = new SolidBrush(this.ForeColor))
							{
								e.Graphics.DrawString(this.AssemblyLoadEventArgs[i], this.Font, solidBrush6, new Point(4, this.FormatterAssemblyStyle + this.CryptoKeyAuditRule + i * this.EnvoyInfo));
							}
							goto IL_5A7;
						}
					}
				}
				else
				{
					using (SolidBrush solidBrush7 = new SolidBrush(Color.FromArgb(50, 50, 53)))
					{
						using (Pen pen5 = new Pen(Color.FromArgb(42, 42, 45)))
						{
							using (Pen pen6 = new Pen(Color.FromArgb(66, 66, 69)))
							{
								e.Graphics.FillRectangle(solidBrush7, new Rectangle(0, 0, base.Width - 1, this.FormatterAssemblyStyle - 1));
								e.Graphics.DrawRectangle(pen5, new Rectangle(0, 0, base.Width - 1, this.FormatterAssemblyStyle - 1));
								e.Graphics.DrawRectangle(pen6, new Rectangle(1, 1, base.Width - 3, this.FormatterAssemblyStyle - 3));
							}
						}
					}
					if (!Information.IsNothing(this.AssemblyLoadEventArgs) && this.CoClassAttributeReliabilityContractAttribute != -1)
					{
						using (SolidBrush solidBrush8 = new SolidBrush(Color.FromArgb(140, 140, 140)))
						{
							e.Graphics.DrawString(this.AssemblyLoadEventArgs[this.CoClassAttributeReliabilityContractAttribute], this.Font, solidBrush8, new Point(4, 4));
						}
					}
				}
				base.OnPaint(e);
			}
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		protected override void OnLostFocus(EventArgs e)
		{
			<Module>.SoapFieldAttribute(220);
			this.KoreanCalendar = false;
			base.Invalidate();
			base.OnLostFocus(e);
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		protected override void OnMouseDown(MouseEventArgs e)
		{
			<Module>.SoapFieldAttribute(221);
			checked
			{
				if (this.KoreanCalendar && this.AttributeUsageAttribute != 0)
				{
					int num = this.AssemblyLoadEventArgs.Count<string>() - 1;
					for (int i = 0; i <= num; i++)
					{
						if (new Rectangle(0, this.FormatterAssemblyStyle + i * this.EnvoyInfo, base.Width - 1, this.EnvoyInfo).Contains(e.Location))
						{
							this.CoClassAttributeReliabilityContractAttribute = i;
							base.Invalidate();
							this.PropertyTokenObjectIDGenerator = this.AssemblyLoadEventArgs[this.CoClassAttributeReliabilityContractAttribute];
							break;
						}
					}
				}
				if (!new Rectangle(0, 0, base.Width - 1, this.FormatterAssemblyStyle + 4).Contains(e.Location) && (this.KoreanCalendar && this.CoClassAttributeReliabilityContractAttribute != -1))
				{
					AnimaExperimentalControlBox.INormalizeForIsolatedStorage codePageDataItemIsolatedStorageContainment = this.CodePageDataItemIsolatedStorageContainment;
					if (codePageDataItemIsolatedStorageContainment != null)
					{
						codePageDataItemIsolatedStorageContainment();
					}
				}
				this.KoreanCalendar = !this.KoreanCalendar;
				base.Invalidate();
				base.Select();
				base.OnMouseDown(e);
			}
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		protected override void OnMouseMove(MouseEventArgs e)
		{
			<Module>.SoapFieldAttribute(222);
			checked
			{
				if (this.KoreanCalendar && this.AttributeUsageAttribute != 0)
				{
					int num = this.AssemblyLoadEventArgs.Count<string>() - 1;
					for (int i = 0; i <= num; i++)
					{
						if (new Rectangle(0, this.FormatterAssemblyStyle + i * this.EnvoyInfo, base.Width - 1, this.EnvoyInfo).Contains(e.Location))
						{
							this.ServerObjectTerminatorSink = i;
							base.Invalidate();
							break;
						}
					}
				}
				base.OnMouseMove(e);
			}
		}

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int BINDPTRIClientResponseChannelSinkStack;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int ApplicationIdBoolean;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private string[] DomainSpecificRemotingData;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int GCHandle;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int Int16;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private string NativeCppClassAttribute;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private AnimaGroupBox FrameSecurityDescriptor;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private Point CodePageHeaderFormat;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private AnimaExperimentalControlBox.INormalizeForIsolatedStorage CodePageDataItemIsolatedStorageContainment;

		private bool KoreanCalendar;

		private int AttributeUsageAttribute;

		private int ServerObjectTerminatorSink;

		public delegate void INormalizeForIsolatedStorage();
	}
}
