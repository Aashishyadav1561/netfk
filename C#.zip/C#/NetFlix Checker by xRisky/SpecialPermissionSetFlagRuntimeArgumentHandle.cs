﻿using System;

internal class SpecialPermissionSetFlagRuntimeArgumentHandle : Attribute
{
	internal SpecialPermissionSetFlagRuntimeArgumentHandle(int int_0)
	{
		this.DBCSDecoder = (-584633357 - ((int_0 - -1466555370) * -1748550161 - 447083192 ^ 211017132) ^ 13933351);
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
