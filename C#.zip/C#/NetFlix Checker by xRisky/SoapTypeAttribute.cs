﻿using System;

internal class SoapTypeAttribute : Attribute
{
	internal SoapTypeAttribute(int int_0)
	{
		this.DBCSDecoder = ~(-((-(-(-273896826 - (1866898996 - (-int_0 + -1827980826 + 475012251))) - -1880219998) ^ 1391192617 ^ -374978966 ^ 728348530 ^ 1988824959) + -958215567 ^ 1873543715));
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
