﻿using System;

internal delegate object DateBufferSymAddressKind(RuntimeFieldHandle runtimeFieldHandle_0);
