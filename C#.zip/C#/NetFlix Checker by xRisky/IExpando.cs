﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace WindowsApp45
{
	public class IExpando : Button
	{
		public Point PrivateImplementationDetails{E61C418B-EF2D-4D3C-A0C2-E7E9B2B2EF81} { get; set; }

		public Size IAsyncResultIDENTITYATTRIBUTE { get; set; }

		public IExpando()
		{
			this.SignatureHelperRijndaelManagedTransform = new int[]
			{
				42,
				42,
				45
			};
			this.CaseInsensitiveComparer = default(Point);
			this.IMetadataSectionEntryCATEGORYINSTANCE = default(Size);
			this.PrivateImplementationDetails{E61C418B-EF2D-4D3C-A0C2-E7E9B2B2EF81} = new Point(checked((int)Math.Round(unchecked((double)base.Width / 2.0 - 7.0))), 6);
			this.IAsyncResultIDENTITYATTRIBUTE = new Size(14, 14);
			this.DoubleBuffered = true;
			this.Font = new Font("Segoe UI", 9f);
			this.ForeColor = Color.FromArgb(200, 200, 200);
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
		}

		protected virtual void IConstructionCallMessage(PaintEventArgs pevent)
		{
			<Module>.SoapFieldAttribute(173);
			this.SearchDataRealProxyFlags = pevent.Graphics;
			this.SearchDataRealProxyFlags.Clear(this.BackColor);
			checked
			{
				using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(55, 55, 58)))
				{
					this.SearchDataRealProxyFlags.FillRectangle(solidBrush, new Rectangle(0, 0, base.Width - 1, base.Height - 1));
				}
				if (this.AsyncCallbackObjectAceFlags)
				{
					using (SolidBrush solidBrush2 = new SolidBrush(Color.FromArgb(66, 66, 69)))
					{
						this.SearchDataRealProxyFlags.FillEllipse(solidBrush2, new Rectangle(this.CaseInsensitiveComparer.X, -30, this.IMetadataSectionEntryCATEGORYINSTANCE.Width, 80));
					}
				}
				using (Pen pen = new Pen(Color.FromArgb(this.SignatureHelperRijndaelManagedTransform[0], this.SignatureHelperRijndaelManagedTransform[1], this.SignatureHelperRijndaelManagedTransform[2])))
				{
					this.SearchDataRealProxyFlags.DrawRectangle(pen, new Rectangle(0, 0, base.Width - 1, base.Height - 1));
				}
				if (!Information.IsNothing(base.Image))
				{
					this.SearchDataRealProxyFlags.DrawImage(base.Image, new Rectangle(this.PrivateImplementationDetails{E61C418B-EF2D-4D3C-A0C2-E7E9B2B2EF81}, this.IAsyncResultIDENTITYATTRIBUTE));
				}
				else
				{
					using (SolidBrush solidBrush3 = new SolidBrush(this.ForeColor))
					{
						this.SearchDataRealProxyFlags.DrawString(this.Text, this.Font, solidBrush3, ServerFault.EncodingInfo(this.SearchDataRealProxyFlags, this.Text, this.Font, new Rectangle(0, 0, base.Width - 1, base.Height - 1)));
					}
				}
			}
		}

		protected virtual void FileIOPermission(EventArgs e)
		{
			<Module>.SoapFieldAttribute(174);
			if (!this.WaitDelegate)
			{
				this.SoapTokenAppDomainLevelActivator = new Thread(new ThreadStart(this.IDENTITYATTRIBUTE))
				{
					IsBackground = true
				};
				this.SoapTokenAppDomainLevelActivator.Start();
			}
			base.OnMouseEnter(e);
		}

		protected virtual void CultureFlags(EventArgs e)
		{
			<Module>.SoapFieldAttribute(175);
			this.IConnectionPointContainer = new Thread(new ThreadStart(this.GregorianCalendar))
			{
				IsBackground = true
			};
			this.IConnectionPointContainer.Start();
			base.OnMouseLeave(e);
		}

		protected virtual void HijriCalendarInt64(MouseEventArgs mevent)
		{
			<Module>.SoapFieldAttribute(176);
			this.ChannelEntryUnicodeEncoding = new Thread(delegate()
			{
				this.CompilationRelaxations(mevent.Location);
			})
			{
				IsBackground = true
			};
			this.ChannelEntryUnicodeEncoding.Start();
			base.OnMouseDown(mevent);
		}

		private void CompilationRelaxations(Point point_0)
		{
			<Module>.SoapFieldAttribute(177);
			this.CaseInsensitiveComparer = point_0;
			this.IMetadataSectionEntryCATEGORYINSTANCE = default(Size);
			this.AsyncCallbackObjectAceFlags = true;
			base.Invalidate();
			checked
			{
				while (this.IMetadataSectionEntryCATEGORYINSTANCE.Width < base.Width * 3)
				{
					ref Point ptr = ref this.CaseInsensitiveComparer;
					this.CaseInsensitiveComparer.X = ptr.X - 1;
					ref Size ptr2 = ref this.IMetadataSectionEntryCATEGORYINSTANCE;
					this.IMetadataSectionEntryCATEGORYINSTANCE.Width = ptr2.Width + 2;
					Thread.Sleep(4);
					base.Invalidate();
				}
				this.AsyncCallbackObjectAceFlags = false;
				base.Invalidate();
			}
		}

		private void IDENTITYATTRIBUTE()
		{
			<Module>.SoapFieldAttribute(178);
			checked
			{
				while (this.SignatureHelperRijndaelManagedTransform[2] < 204 && !this.WaitDelegate)
				{
					int[] signatureHelperRijndaelManagedTransform = this.SignatureHelperRijndaelManagedTransform;
					int num = 1;
					ref int ptr = ref signatureHelperRijndaelManagedTransform[num];
					signatureHelperRijndaelManagedTransform[num] = ptr + 1;
					int[] signatureHelperRijndaelManagedTransform2 = this.SignatureHelperRijndaelManagedTransform;
					int num2 = 2;
					ptr = ref signatureHelperRijndaelManagedTransform2[num2];
					signatureHelperRijndaelManagedTransform2[num2] = ptr + 2;
					base.Invalidate();
					Thread.Sleep(5);
				}
			}
		}

		private void GregorianCalendar()
		{
			<Module>.SoapFieldAttribute(179);
			this.WaitDelegate = true;
			checked
			{
				while (this.SignatureHelperRijndaelManagedTransform[2] > 45)
				{
					int[] signatureHelperRijndaelManagedTransform = this.SignatureHelperRijndaelManagedTransform;
					int num = 1;
					ref int ptr = ref signatureHelperRijndaelManagedTransform[num];
					signatureHelperRijndaelManagedTransform[num] = ptr - 1;
					int[] signatureHelperRijndaelManagedTransform2 = this.SignatureHelperRijndaelManagedTransform;
					int num2 = 2;
					ptr = ref signatureHelperRijndaelManagedTransform2[num2];
					signatureHelperRijndaelManagedTransform2[num2] = ptr - 2;
					base.Invalidate();
					Thread.Sleep(5);
				}
				this.WaitDelegate = false;
			}
		}

		private Graphics SearchDataRealProxyFlags;

		private Thread SoapTokenAppDomainLevelActivator;

		private Thread IConnectionPointContainer;

		private Thread ChannelEntryUnicodeEncoding;

		private int[] SignatureHelperRijndaelManagedTransform;

		private Point CaseInsensitiveComparer;

		private Size IMetadataSectionEntryCATEGORYINSTANCE;

		private bool WaitDelegate;

		private bool AsyncCallbackObjectAceFlags;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private Point KeyContainerPermissionAccessEntryCollectionDeploymentMetadataEntry;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private Size PropertyInfo;

		[CompilerGenerated]
		internal sealed class ReflectionTypeLoadExceptionContextLevelActivator
		{
			internal void _Lambda$__0()
			{
				this.SecurityInfos.CompilationRelaxations(this.Queue.Location);
			}

			public MouseEventArgs Queue;

			public IExpando SecurityInfos;
		}
	}
}
