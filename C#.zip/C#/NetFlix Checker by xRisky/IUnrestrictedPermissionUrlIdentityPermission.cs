﻿using System;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;

namespace WindowsApp45
{
	internal class IUnrestrictedPermissionUrlIdentityPermission
	{
		public static string MLangEncoder(string string_0, string string_1, string string_2, int int_0)
		{
			<Module>.SoapFieldAttribute(137);
			int length = string_1.Length;
			int num = length;
			string result = "";
			int num2 = string_0.IndexOf(string_1, int_0);
			int num3 = num2;
			checked
			{
				int num4 = string_0.IndexOf(string_2, num3 + num);
				int num5 = num4;
				if (num3 != -1 & num5 != -1)
				{
					result = string_0.Substring(num3 + num, num5 - (num3 + num));
				}
				return result;
			}
		}

		public static string ReflectionPermissionAttribute(MD5 md5_0, string string_0)
		{
			<Module>.SoapFieldAttribute(138);
			byte[] array = md5_0.ComputeHash(Encoding.UTF8.GetBytes(string_0));
			StringBuilder stringBuilder = new StringBuilder();
			checked
			{
				int num = array.Length - 1;
				for (int i = 0; i <= num; i++)
				{
					stringBuilder.Append(array[i].ToString("x2"));
				}
				return stringBuilder.ToString();
			}
		}

		public static string EventItfInfoRfc2898DeriveBytes()
		{
			<Module>.SoapFieldAttribute(139);
			return Convert.ToString(HMAC.ObjectAuditRule[IUnrestrictedPermissionUrlIdentityPermission.PolicyManager.Next(0, HMAC.ObjectAuditRule.Count)]);
		}

		public static string IdentityReferenceCollection = DateTime.Now.ToString("HH_mm_ss");

		public static object Decimal = RuntimeHelpers.GetObjectValue(new object());

		public static Random PolicyManager = new Random();
	}
}
