﻿using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 5636)]
internal struct DeploymentMetadataEntryFieldId
{
}
