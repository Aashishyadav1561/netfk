﻿using System;
using System.Reflection;

internal delegate object LeaseManagerMscorlibDictionaryDebugView2(object object_0, string string_0, BindingFlags bindingFlags_0, object object_1, Type[] type_0, ParameterModifier[] parameterModifier_0);
