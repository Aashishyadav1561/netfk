﻿using System;

internal class IsolatedStorageFilePermission : Attribute
{
	internal IsolatedStorageFilePermission(int int_0)
	{
		this.DBCSDecoder = -(~(~(~int_0) + -1746753562 - 1387282318));
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
