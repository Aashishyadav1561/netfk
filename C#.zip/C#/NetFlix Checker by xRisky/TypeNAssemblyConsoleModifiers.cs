﻿using System;

internal delegate void TypeNAssemblyConsoleModifiers(byte[] byte_0, int int_0, IntPtr intptr_0, int int_1);
