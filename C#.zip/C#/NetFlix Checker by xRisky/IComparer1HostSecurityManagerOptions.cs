﻿using System;

internal class IComparer1HostSecurityManagerOptions : Attribute
{
	internal IComparer1HostSecurityManagerOptions(int int_0)
	{
		this.DBCSDecoder = 710175010 - -((1125956185 - (~((~(-((-(int_0 + 2057314371) * 1966596717 - -1152317908) * -1183942377)) + 1943585857) * -2119901527) ^ -610171164) + -589944947) * -106143255);
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
