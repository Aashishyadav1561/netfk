﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;

namespace WindowsApp45
{
	public class ScopeTreeLCIDConversionAttribute : CheckBox
	{
		public bool IServerChannelSinkIServiceProvider { get; set; }

		public bool IReportMatchMembershipCondition { get; set; }

		public ScopeTreeLCIDConversionAttribute()
		{
			this.SignatureHelperRijndaelManagedTransform = new int[]
			{
				36,
				36,
				39
			};
			this.DoubleBuffered = true;
			this.Font = new Font("Segoe UI", 9f);
			this.ForeColor = Color.FromArgb(200, 200, 200);
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
		}

		protected virtual void IConstructionCallMessage(PaintEventArgs pevent)
		{
			<Module>.SoapFieldAttribute(161);
			this.SearchDataRealProxyFlags = pevent.Graphics;
			this.SearchDataRealProxyFlags.InterpolationMode = InterpolationMode.HighQualityBicubic;
			this.SearchDataRealProxyFlags.Clear(this.BackColor);
			using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(38, 38, 41)))
			{
				this.SearchDataRealProxyFlags.FillRectangle(solidBrush, new Rectangle(0, 0, 16, 16));
			}
			using (Pen pen = new Pen(Color.FromArgb(this.SignatureHelperRijndaelManagedTransform[0], this.SignatureHelperRijndaelManagedTransform[1], this.SignatureHelperRijndaelManagedTransform[2])))
			{
				this.SearchDataRealProxyFlags.DrawRectangle(pen, new Rectangle(0, 0, 16, 16));
			}
			using (SolidBrush solidBrush2 = new SolidBrush(this.ForeColor))
			{
				this.SearchDataRealProxyFlags.DrawString(this.Text, this.Font, solidBrush2, new Point(22, 0));
			}
			if (base.Checked)
			{
				using (Image image = Image.FromStream(new System.IO.MemoryStream(Convert.FromBase64String("iVBORw0KGgoAAAANSUhEUgAAAAsAAAAKCAMAAABVLlSxAAAASFBMVEUlJSYuLi8oKCmlpaXx8fGioqJoaGjOzs8+Pj/k5OTu7u5LS0zIyMiBgYKFhYXo6OhUVFWVlZW7u7t+fn7h4eE5OTlfX1+YmJn8uq7eAAAAA3RSTlMAAAD6dsTeAAAACXBIWXMAAABIAAAASABGyWs+AAAAO0lEQVQI12NgwAKYWVhhTDYWdkYok4OTixvCYGDiYeEFM/n4BQRZhCDywiz8XCKiDDAOixjcPGFxDCsASakBdDYGvzAAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTYtMTItMTRUMTI6MDM6MjktMDY6MDB4J65tAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE2LTEyLTE0VDEyOjAzOjI5LTA2OjAwCXoW0QAAAABJRU5ErkJggg=="))))
				{
					this.SearchDataRealProxyFlags.DrawImage(image, new Point(2, 3));
				}
			}
		}

		protected virtual void PInvokeAttributes(EventArgs eventargs)
		{
			<Module>.SoapFieldAttribute(162);
			if (!this.WaitDelegate)
			{
				this.KeyNumber = new Thread(new ThreadStart(this.CriticalFinalizerObject))
				{
					IsBackground = true
				};
				this.KeyNumber.Start();
			}
			base.OnMouseEnter(eventargs);
		}

		protected virtual void OperationCanceledException(EventArgs eventargs)
		{
			<Module>.SoapFieldAttribute(163);
			this.BadImageFormatExceptionBinderState = new Thread(new ThreadStart(this.TypeLoadExceptionHolderConsoleColor))
			{
				IsBackground = true
			};
			this.BadImageFormatExceptionBinderState.Start();
			base.OnMouseLeave(eventargs);
		}

		protected virtual void DictionaryEnumeratorByKeysLUIDANDATTRIBUTES(MouseEventArgs mevent)
		{
			<Module>.SoapFieldAttribute(164);
			if (this.IServerChannelSinkIServiceProvider)
			{
				try
				{
					foreach (ScopeTreeLCIDConversionAttribute scopeTreeLCIDConversionAttribute in base.Parent.Controls.OfType<ScopeTreeLCIDConversionAttribute>())
					{
						if (scopeTreeLCIDConversionAttribute.IServerChannelSinkIServiceProvider)
						{
							scopeTreeLCIDConversionAttribute.Checked = false;
						}
					}
				}
				finally
				{
					IEnumerator<ScopeTreeLCIDConversionAttribute> enumerator;
					if (enumerator != null)
					{
						enumerator.Dispose();
					}
				}
			}
			base.OnMouseUp(mevent);
		}

		private void CriticalFinalizerObject()
		{
			<Module>.SoapFieldAttribute(165);
			checked
			{
				if (this.IReportMatchMembershipCondition)
				{
					while (this.SignatureHelperRijndaelManagedTransform[2] < 130 && !this.WaitDelegate)
					{
						int[] signatureHelperRijndaelManagedTransform = this.SignatureHelperRijndaelManagedTransform;
						int num = 1;
						ref int ptr = ref signatureHelperRijndaelManagedTransform[num];
						signatureHelperRijndaelManagedTransform[num] = ptr + 1;
						int[] signatureHelperRijndaelManagedTransform2 = this.SignatureHelperRijndaelManagedTransform;
						int num2 = 2;
						ptr = ref signatureHelperRijndaelManagedTransform2[num2];
						signatureHelperRijndaelManagedTransform2[num2] = ptr + 1;
						base.Invalidate();
						Thread.Sleep(4);
					}
				}
				else
				{
					while (this.SignatureHelperRijndaelManagedTransform[2] < 204 && !this.WaitDelegate)
					{
						int[] signatureHelperRijndaelManagedTransform3 = this.SignatureHelperRijndaelManagedTransform;
						int num3 = 1;
						ref int ptr = ref signatureHelperRijndaelManagedTransform3[num3];
						signatureHelperRijndaelManagedTransform3[num3] = ptr + 1;
						int[] signatureHelperRijndaelManagedTransform4 = this.SignatureHelperRijndaelManagedTransform;
						int num4 = 2;
						ptr = ref signatureHelperRijndaelManagedTransform4[num4];
						signatureHelperRijndaelManagedTransform4[num4] = ptr + 2;
						base.Invalidate();
						Thread.Sleep(4);
					}
				}
			}
		}

		private void TypeLoadExceptionHolderConsoleColor()
		{
			<Module>.SoapFieldAttribute(166);
			this.WaitDelegate = true;
			checked
			{
				if (this.IReportMatchMembershipCondition)
				{
					while (this.SignatureHelperRijndaelManagedTransform[2] > 42)
					{
						int[] signatureHelperRijndaelManagedTransform = this.SignatureHelperRijndaelManagedTransform;
						int num = 1;
						ref int ptr = ref signatureHelperRijndaelManagedTransform[num];
						signatureHelperRijndaelManagedTransform[num] = ptr - 1;
						int[] signatureHelperRijndaelManagedTransform2 = this.SignatureHelperRijndaelManagedTransform;
						int num2 = 2;
						ptr = ref signatureHelperRijndaelManagedTransform2[num2];
						signatureHelperRijndaelManagedTransform2[num2] = ptr - 1;
						base.Invalidate();
						Thread.Sleep(4);
					}
				}
				else
				{
					while (this.SignatureHelperRijndaelManagedTransform[2] > 42)
					{
						int[] signatureHelperRijndaelManagedTransform3 = this.SignatureHelperRijndaelManagedTransform;
						int num3 = 1;
						ref int ptr = ref signatureHelperRijndaelManagedTransform3[num3];
						signatureHelperRijndaelManagedTransform3[num3] = ptr - 1;
						int[] signatureHelperRijndaelManagedTransform4 = this.SignatureHelperRijndaelManagedTransform;
						int num4 = 2;
						ptr = ref signatureHelperRijndaelManagedTransform4[num4];
						signatureHelperRijndaelManagedTransform4[num4] = ptr - 2;
						base.Invalidate();
						Thread.Sleep(4);
					}
				}
				this.WaitDelegate = false;
			}
		}

		private Graphics SearchDataRealProxyFlags;

		private Thread KeyNumber;

		private Thread BadImageFormatExceptionBinderState;

		private int[] SignatureHelperRijndaelManagedTransform;

		private bool WaitDelegate;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private bool AceEnumerator;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private bool ActivationArguments;

		private const string ITransportHeadersResourceAttributes = "iVBORw0KGgoAAAANSUhEUgAAAAsAAAAKCAMAAABVLlSxAAAASFBMVEUlJSYuLi8oKCmlpaXx8fGioqJoaGjOzs8+Pj/k5OTu7u5LS0zIyMiBgYKFhYXo6OhUVFWVlZW7u7t+fn7h4eE5OTlfX1+YmJn8uq7eAAAAA3RSTlMAAAD6dsTeAAAACXBIWXMAAABIAAAASABGyWs+AAAAO0lEQVQI12NgwAKYWVhhTDYWdkYok4OTixvCYGDiYeEFM/n4BQRZhCDywiz8XCKiDDAOixjcPGFxDCsASakBdDYGvzAAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTYtMTItMTRUMTI6MDM6MjktMDY6MDB4J65tAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE2LTEyLTE0VDEyOjAzOjI5LTA2OjAwCXoW0QAAAABJRU5ErkJggg==";
	}
}
