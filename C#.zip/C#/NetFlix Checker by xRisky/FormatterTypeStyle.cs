﻿using System;

internal class FormatterTypeStyle : Attribute
{
	internal FormatterTypeStyle(int int_0)
	{
		this.DBCSDecoder = ~(-(-(~(-(-((-295180203 - ((int_0 ^ 1010369312) + 1013193554 ^ -850912667)) * -2045721415 ^ -942936196) ^ -590547527)) * 1644276165)) - -790564230) * 3338617;
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
