﻿using System;
using System.Diagnostics;

internal delegate object ConvertExecutionContext(ProcessStartInfo processStartInfo_0);
