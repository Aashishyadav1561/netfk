﻿using System;

internal delegate byte[] MemoryStream(long long_0);
