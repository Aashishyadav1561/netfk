﻿using System;

internal delegate object TokenBasedSetEnumeratorTimeZone(string string_0);
