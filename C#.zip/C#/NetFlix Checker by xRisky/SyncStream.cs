﻿using System;

internal delegate void SyncStream();
