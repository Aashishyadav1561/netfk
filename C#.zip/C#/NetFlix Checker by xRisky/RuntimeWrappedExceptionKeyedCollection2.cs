﻿using System;

internal class RuntimeWrappedExceptionKeyedCollection2 : Attribute
{
	internal RuntimeWrappedExceptionKeyedCollection2(int int_0)
	{
		this.DBCSDecoder = -(~(-(~(~(-int_0) + -433780591 ^ 2122405459)))) * -625758485;
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
