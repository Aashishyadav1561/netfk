﻿using System;

internal class RegionNameOffsetItemTypeInitializationException : Attribute
{
	internal RegionNameOffsetItemTypeInitializationException(int int_0)
	{
		this.DBCSDecoder = (-(-(-(131305981 - int_0) ^ -813570515) ^ 1598611945) * -861293009 ^ 584732974);
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
