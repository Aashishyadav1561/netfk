﻿using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 1486)]
internal struct AsymmetricSignatureFormatterUrl
{
}
