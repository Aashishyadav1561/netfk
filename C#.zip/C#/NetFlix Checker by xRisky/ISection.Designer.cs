﻿namespace WindowsApp45
{
	[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
	public partial class ISection : global::System.Windows.Forms.Form
	{
	}
}
