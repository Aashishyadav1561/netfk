﻿using System;

internal class PackingSize : Attribute
{
	internal PackingSize(int int_0)
	{
		this.DBCSDecoder = ~(~(-((1627013212 - (((int_0 + -930077340) * 1391508733 ^ -72170554) + -793427823 - 1612403079) - 167305861 ^ 714810850) - -1426593816 + 420627117) * -517247683 - 1583158731)) + 1048503055;
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
