﻿using System;

internal class AceQualifier : Attribute
{
	internal AceQualifier(int int_0)
	{
		this.DBCSDecoder = ~(-486546306 - -(-int_0) * -996582199 - 2105835571) * -775097091;
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
