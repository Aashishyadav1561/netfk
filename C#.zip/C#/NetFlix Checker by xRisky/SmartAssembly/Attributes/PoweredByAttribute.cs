﻿using System;

internal class PoweredByAttribute : Attribute
{
}
