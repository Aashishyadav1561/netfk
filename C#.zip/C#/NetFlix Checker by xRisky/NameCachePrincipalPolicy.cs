﻿using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;

namespace WindowsApp45
{
	public class NameCachePrincipalPolicy : ToolStripRenderer
	{
		public event NameCachePrincipalPolicy.MethodOnTypeBuilderInstantiation MutexCleanupInfo
		{
			[CompilerGenerated]
			add
			{
				<Module>.SoapFieldAttribute(180);
				NameCachePrincipalPolicy.MethodOnTypeBuilderInstantiation methodOnTypeBuilderInstantiation = this.RuntimeMethodHandleIEnumSTORECATEGORYSUBCATEGORY;
				NameCachePrincipalPolicy.MethodOnTypeBuilderInstantiation methodOnTypeBuilderInstantiation2;
				do
				{
					methodOnTypeBuilderInstantiation2 = methodOnTypeBuilderInstantiation;
					NameCachePrincipalPolicy.MethodOnTypeBuilderInstantiation value2 = (NameCachePrincipalPolicy.MethodOnTypeBuilderInstantiation)Delegate.Combine(methodOnTypeBuilderInstantiation2, value);
					methodOnTypeBuilderInstantiation = Interlocked.CompareExchange<NameCachePrincipalPolicy.MethodOnTypeBuilderInstantiation>(ref this.RuntimeMethodHandleIEnumSTORECATEGORYSUBCATEGORY, value2, methodOnTypeBuilderInstantiation2);
				}
				while (methodOnTypeBuilderInstantiation != methodOnTypeBuilderInstantiation2);
			}
			[CompilerGenerated]
			remove
			{
				<Module>.SoapFieldAttribute(181);
				NameCachePrincipalPolicy.MethodOnTypeBuilderInstantiation methodOnTypeBuilderInstantiation = this.RuntimeMethodHandleIEnumSTORECATEGORYSUBCATEGORY;
				NameCachePrincipalPolicy.MethodOnTypeBuilderInstantiation methodOnTypeBuilderInstantiation2;
				do
				{
					methodOnTypeBuilderInstantiation2 = methodOnTypeBuilderInstantiation;
					NameCachePrincipalPolicy.MethodOnTypeBuilderInstantiation value2 = (NameCachePrincipalPolicy.MethodOnTypeBuilderInstantiation)Delegate.Remove(methodOnTypeBuilderInstantiation2, value);
					methodOnTypeBuilderInstantiation = Interlocked.CompareExchange<NameCachePrincipalPolicy.MethodOnTypeBuilderInstantiation>(ref this.RuntimeMethodHandleIEnumSTORECATEGORYSUBCATEGORY, value2, methodOnTypeBuilderInstantiation2);
				}
				while (methodOnTypeBuilderInstantiation != methodOnTypeBuilderInstantiation2);
			}
		}

		public event NameCachePrincipalPolicy.RuntimeEventInfoKeyNotFoundException UCOMIBindCtxAF
		{
			[CompilerGenerated]
			add
			{
				<Module>.SoapFieldAttribute(182);
				NameCachePrincipalPolicy.RuntimeEventInfoKeyNotFoundException ex = this.RemotingServices;
				NameCachePrincipalPolicy.RuntimeEventInfoKeyNotFoundException ex2;
				do
				{
					ex2 = ex;
					NameCachePrincipalPolicy.RuntimeEventInfoKeyNotFoundException value2 = (NameCachePrincipalPolicy.RuntimeEventInfoKeyNotFoundException)Delegate.Combine(ex2, value);
					ex = Interlocked.CompareExchange<NameCachePrincipalPolicy.RuntimeEventInfoKeyNotFoundException>(ref this.RemotingServices, value2, ex2);
				}
				while (ex != ex2);
			}
			[CompilerGenerated]
			remove
			{
				<Module>.SoapFieldAttribute(183);
				NameCachePrincipalPolicy.RuntimeEventInfoKeyNotFoundException ex = this.RemotingServices;
				NameCachePrincipalPolicy.RuntimeEventInfoKeyNotFoundException ex2;
				do
				{
					ex2 = ex;
					NameCachePrincipalPolicy.RuntimeEventInfoKeyNotFoundException value2 = (NameCachePrincipalPolicy.RuntimeEventInfoKeyNotFoundException)Delegate.Remove(ex2, value);
					ex = Interlocked.CompareExchange<NameCachePrincipalPolicy.RuntimeEventInfoKeyNotFoundException>(ref this.RemotingServices, value2, ex2);
				}
				while (ex != ex2);
			}
		}

		public event NameCachePrincipalPolicy.SuppressUnmanagedCodeSecurityAttributeReadOnlyList IMuiResourceTypeIdIntEntry
		{
			[CompilerGenerated]
			add
			{
				<Module>.SoapFieldAttribute(184);
				NameCachePrincipalPolicy.SuppressUnmanagedCodeSecurityAttributeReadOnlyList suppressUnmanagedCodeSecurityAttributeReadOnlyList = this.ToBase64Transform;
				NameCachePrincipalPolicy.SuppressUnmanagedCodeSecurityAttributeReadOnlyList suppressUnmanagedCodeSecurityAttributeReadOnlyList2;
				do
				{
					suppressUnmanagedCodeSecurityAttributeReadOnlyList2 = suppressUnmanagedCodeSecurityAttributeReadOnlyList;
					NameCachePrincipalPolicy.SuppressUnmanagedCodeSecurityAttributeReadOnlyList value2 = (NameCachePrincipalPolicy.SuppressUnmanagedCodeSecurityAttributeReadOnlyList)Delegate.Combine(suppressUnmanagedCodeSecurityAttributeReadOnlyList2, value);
					suppressUnmanagedCodeSecurityAttributeReadOnlyList = Interlocked.CompareExchange<NameCachePrincipalPolicy.SuppressUnmanagedCodeSecurityAttributeReadOnlyList>(ref this.ToBase64Transform, value2, suppressUnmanagedCodeSecurityAttributeReadOnlyList2);
				}
				while (suppressUnmanagedCodeSecurityAttributeReadOnlyList != suppressUnmanagedCodeSecurityAttributeReadOnlyList2);
			}
			[CompilerGenerated]
			remove
			{
				<Module>.SoapFieldAttribute(185);
				NameCachePrincipalPolicy.SuppressUnmanagedCodeSecurityAttributeReadOnlyList suppressUnmanagedCodeSecurityAttributeReadOnlyList = this.ToBase64Transform;
				NameCachePrincipalPolicy.SuppressUnmanagedCodeSecurityAttributeReadOnlyList suppressUnmanagedCodeSecurityAttributeReadOnlyList2;
				do
				{
					suppressUnmanagedCodeSecurityAttributeReadOnlyList2 = suppressUnmanagedCodeSecurityAttributeReadOnlyList;
					NameCachePrincipalPolicy.SuppressUnmanagedCodeSecurityAttributeReadOnlyList value2 = (NameCachePrincipalPolicy.SuppressUnmanagedCodeSecurityAttributeReadOnlyList)Delegate.Remove(suppressUnmanagedCodeSecurityAttributeReadOnlyList2, value);
					suppressUnmanagedCodeSecurityAttributeReadOnlyList = Interlocked.CompareExchange<NameCachePrincipalPolicy.SuppressUnmanagedCodeSecurityAttributeReadOnlyList>(ref this.ToBase64Transform, value2, suppressUnmanagedCodeSecurityAttributeReadOnlyList2);
				}
				while (suppressUnmanagedCodeSecurityAttributeReadOnlyList != suppressUnmanagedCodeSecurityAttributeReadOnlyList2);
			}
		}

		public event NameCachePrincipalPolicy.CodePageDataFileHeader RemotingSurrogateSelectorMemberInfoCache1
		{
			[CompilerGenerated]
			add
			{
				<Module>.SoapFieldAttribute(186);
				NameCachePrincipalPolicy.CodePageDataFileHeader codePageDataFileHeader = this.codePageDataFileHeader_0;
				NameCachePrincipalPolicy.CodePageDataFileHeader codePageDataFileHeader2;
				do
				{
					codePageDataFileHeader2 = codePageDataFileHeader;
					NameCachePrincipalPolicy.CodePageDataFileHeader value2 = (NameCachePrincipalPolicy.CodePageDataFileHeader)Delegate.Combine(codePageDataFileHeader2, value);
					codePageDataFileHeader = Interlocked.CompareExchange<NameCachePrincipalPolicy.CodePageDataFileHeader>(ref this.codePageDataFileHeader_0, value2, codePageDataFileHeader2);
				}
				while (codePageDataFileHeader != codePageDataFileHeader2);
			}
			[CompilerGenerated]
			remove
			{
				<Module>.SoapFieldAttribute(187);
				NameCachePrincipalPolicy.CodePageDataFileHeader codePageDataFileHeader = this.codePageDataFileHeader_0;
				NameCachePrincipalPolicy.CodePageDataFileHeader codePageDataFileHeader2;
				do
				{
					codePageDataFileHeader2 = codePageDataFileHeader;
					NameCachePrincipalPolicy.CodePageDataFileHeader value2 = (NameCachePrincipalPolicy.CodePageDataFileHeader)Delegate.Remove(codePageDataFileHeader2, value);
					codePageDataFileHeader = Interlocked.CompareExchange<NameCachePrincipalPolicy.CodePageDataFileHeader>(ref this.codePageDataFileHeader_0, value2, codePageDataFileHeader2);
				}
				while (codePageDataFileHeader != codePageDataFileHeader2);
			}
		}

		public event NameCachePrincipalPolicy.BinaryFormatterISponsor EncoderFallbackBufferAccessControlActions
		{
			[CompilerGenerated]
			add
			{
				<Module>.SoapFieldAttribute(188);
				NameCachePrincipalPolicy.BinaryFormatterISponsor binaryFormatterISponsor = this.StackBasedReturnMessage;
				NameCachePrincipalPolicy.BinaryFormatterISponsor binaryFormatterISponsor2;
				do
				{
					binaryFormatterISponsor2 = binaryFormatterISponsor;
					NameCachePrincipalPolicy.BinaryFormatterISponsor value2 = (NameCachePrincipalPolicy.BinaryFormatterISponsor)Delegate.Combine(binaryFormatterISponsor2, value);
					binaryFormatterISponsor = Interlocked.CompareExchange<NameCachePrincipalPolicy.BinaryFormatterISponsor>(ref this.StackBasedReturnMessage, value2, binaryFormatterISponsor2);
				}
				while (binaryFormatterISponsor != binaryFormatterISponsor2);
			}
			[CompilerGenerated]
			remove
			{
				<Module>.SoapFieldAttribute(189);
				NameCachePrincipalPolicy.BinaryFormatterISponsor binaryFormatterISponsor = this.StackBasedReturnMessage;
				NameCachePrincipalPolicy.BinaryFormatterISponsor binaryFormatterISponsor2;
				do
				{
					binaryFormatterISponsor2 = binaryFormatterISponsor;
					NameCachePrincipalPolicy.BinaryFormatterISponsor value2 = (NameCachePrincipalPolicy.BinaryFormatterISponsor)Delegate.Remove(binaryFormatterISponsor2, value);
					binaryFormatterISponsor = Interlocked.CompareExchange<NameCachePrincipalPolicy.BinaryFormatterISponsor>(ref this.StackBasedReturnMessage, value2, binaryFormatterISponsor2);
				}
				while (binaryFormatterISponsor != binaryFormatterISponsor2);
			}
		}

		public event NameCachePrincipalPolicy.MemberHolder TypeUnloadedExceptionBINDPTR
		{
			[CompilerGenerated]
			add
			{
				<Module>.SoapFieldAttribute(190);
				NameCachePrincipalPolicy.MemberHolder memberHolder = this.memberHolder_0;
				NameCachePrincipalPolicy.MemberHolder memberHolder2;
				do
				{
					memberHolder2 = memberHolder;
					NameCachePrincipalPolicy.MemberHolder value2 = (NameCachePrincipalPolicy.MemberHolder)Delegate.Combine(memberHolder2, value);
					memberHolder = Interlocked.CompareExchange<NameCachePrincipalPolicy.MemberHolder>(ref this.memberHolder_0, value2, memberHolder2);
				}
				while (memberHolder != memberHolder2);
			}
			[CompilerGenerated]
			remove
			{
				<Module>.SoapFieldAttribute(191);
				NameCachePrincipalPolicy.MemberHolder memberHolder = this.memberHolder_0;
				NameCachePrincipalPolicy.MemberHolder memberHolder2;
				do
				{
					memberHolder2 = memberHolder;
					NameCachePrincipalPolicy.MemberHolder value2 = (NameCachePrincipalPolicy.MemberHolder)Delegate.Remove(memberHolder2, value);
					memberHolder = Interlocked.CompareExchange<NameCachePrincipalPolicy.MemberHolder>(ref this.memberHolder_0, value2, memberHolder2);
				}
				while (memberHolder != memberHolder2);
			}
		}

		public event NameCachePrincipalPolicy.IConstructionReturnMessageIEnumerable AssemblyNamePermissionListSet
		{
			[CompilerGenerated]
			add
			{
				<Module>.SoapFieldAttribute(192);
				NameCachePrincipalPolicy.IConstructionReturnMessageIEnumerable constructionReturnMessageIEnumerable = this.InternalMemberValueEErrorMessage;
				NameCachePrincipalPolicy.IConstructionReturnMessageIEnumerable constructionReturnMessageIEnumerable2;
				do
				{
					constructionReturnMessageIEnumerable2 = constructionReturnMessageIEnumerable;
					NameCachePrincipalPolicy.IConstructionReturnMessageIEnumerable value2 = (NameCachePrincipalPolicy.IConstructionReturnMessageIEnumerable)Delegate.Combine(constructionReturnMessageIEnumerable2, value);
					constructionReturnMessageIEnumerable = Interlocked.CompareExchange<NameCachePrincipalPolicy.IConstructionReturnMessageIEnumerable>(ref this.InternalMemberValueEErrorMessage, value2, constructionReturnMessageIEnumerable2);
				}
				while (constructionReturnMessageIEnumerable != constructionReturnMessageIEnumerable2);
			}
			[CompilerGenerated]
			remove
			{
				<Module>.SoapFieldAttribute(193);
				NameCachePrincipalPolicy.IConstructionReturnMessageIEnumerable constructionReturnMessageIEnumerable = this.InternalMemberValueEErrorMessage;
				NameCachePrincipalPolicy.IConstructionReturnMessageIEnumerable constructionReturnMessageIEnumerable2;
				do
				{
					constructionReturnMessageIEnumerable2 = constructionReturnMessageIEnumerable;
					NameCachePrincipalPolicy.IConstructionReturnMessageIEnumerable value2 = (NameCachePrincipalPolicy.IConstructionReturnMessageIEnumerable)Delegate.Remove(constructionReturnMessageIEnumerable2, value);
					constructionReturnMessageIEnumerable = Interlocked.CompareExchange<NameCachePrincipalPolicy.IConstructionReturnMessageIEnumerable>(ref this.InternalMemberValueEErrorMessage, value2, constructionReturnMessageIEnumerable2);
				}
				while (constructionReturnMessageIEnumerable != constructionReturnMessageIEnumerable2);
			}
		}

		public event NameCachePrincipalPolicy.ComparisonResultICDF StateManagerRunningStateWellKnownClientTypeEntry
		{
			[CompilerGenerated]
			add
			{
				<Module>.SoapFieldAttribute(194);
				NameCachePrincipalPolicy.ComparisonResultICDF comparisonResultICDF = this.InternalParseStateEMessage;
				NameCachePrincipalPolicy.ComparisonResultICDF comparisonResultICDF2;
				do
				{
					comparisonResultICDF2 = comparisonResultICDF;
					NameCachePrincipalPolicy.ComparisonResultICDF value2 = (NameCachePrincipalPolicy.ComparisonResultICDF)Delegate.Combine(comparisonResultICDF2, value);
					comparisonResultICDF = Interlocked.CompareExchange<NameCachePrincipalPolicy.ComparisonResultICDF>(ref this.InternalParseStateEMessage, value2, comparisonResultICDF2);
				}
				while (comparisonResultICDF != comparisonResultICDF2);
			}
			[CompilerGenerated]
			remove
			{
				<Module>.SoapFieldAttribute(195);
				NameCachePrincipalPolicy.ComparisonResultICDF comparisonResultICDF = this.InternalParseStateEMessage;
				NameCachePrincipalPolicy.ComparisonResultICDF comparisonResultICDF2;
				do
				{
					comparisonResultICDF2 = comparisonResultICDF;
					NameCachePrincipalPolicy.ComparisonResultICDF value2 = (NameCachePrincipalPolicy.ComparisonResultICDF)Delegate.Remove(comparisonResultICDF2, value);
					comparisonResultICDF = Interlocked.CompareExchange<NameCachePrincipalPolicy.ComparisonResultICDF>(ref this.InternalParseStateEMessage, value2, comparisonResultICDF2);
				}
				while (comparisonResultICDF != comparisonResultICDF2);
			}
		}

		public event NameCachePrincipalPolicy.PropertyToken SyncArrayListFormat
		{
			[CompilerGenerated]
			add
			{
				<Module>.SoapFieldAttribute(196);
				NameCachePrincipalPolicy.PropertyToken propertyToken = this.AgileSafeNativeMemoryHandle;
				NameCachePrincipalPolicy.PropertyToken propertyToken2;
				do
				{
					propertyToken2 = propertyToken;
					NameCachePrincipalPolicy.PropertyToken value2 = (NameCachePrincipalPolicy.PropertyToken)Delegate.Combine(propertyToken2, value);
					propertyToken = Interlocked.CompareExchange<NameCachePrincipalPolicy.PropertyToken>(ref this.AgileSafeNativeMemoryHandle, value2, propertyToken2);
				}
				while (propertyToken != propertyToken2);
			}
			[CompilerGenerated]
			remove
			{
				<Module>.SoapFieldAttribute(197);
				NameCachePrincipalPolicy.PropertyToken propertyToken = this.AgileSafeNativeMemoryHandle;
				NameCachePrincipalPolicy.PropertyToken propertyToken2;
				do
				{
					propertyToken2 = propertyToken;
					NameCachePrincipalPolicy.PropertyToken value2 = (NameCachePrincipalPolicy.PropertyToken)Delegate.Remove(propertyToken2, value);
					propertyToken = Interlocked.CompareExchange<NameCachePrincipalPolicy.PropertyToken>(ref this.AgileSafeNativeMemoryHandle, value2, propertyToken2);
				}
				while (propertyToken != propertyToken2);
			}
		}

		protected virtual void CMSASSEMBLYREFERENCEDEPENDENTASSEMBLYFLAG(ToolStripRenderEventArgs e)
		{
			<Module>.SoapFieldAttribute(198);
			NameCachePrincipalPolicy.MethodOnTypeBuilderInstantiation runtimeMethodHandleIEnumSTORECATEGORYSUBCATEGORY = this.RuntimeMethodHandleIEnumSTORECATEGORYSUBCATEGORY;
			if (runtimeMethodHandleIEnumSTORECATEGORYSUBCATEGORY != null)
			{
				runtimeMethodHandleIEnumSTORECATEGORYSUBCATEGORY(this, e);
			}
		}

		protected virtual void PInvokeAttributesGregorianCalendarHelper(ToolStripRenderEventArgs e)
		{
			<Module>.SoapFieldAttribute(199);
			NameCachePrincipalPolicy.SuppressUnmanagedCodeSecurityAttributeReadOnlyList toBase64Transform = this.ToBase64Transform;
			if (toBase64Transform != null)
			{
				toBase64Transform(this, e);
			}
		}

		protected virtual void IFormatterConverterFieldInfo(ToolStripRenderEventArgs e)
		{
			<Module>.SoapFieldAttribute(200);
			NameCachePrincipalPolicy.RuntimeEventInfoKeyNotFoundException remotingServices = this.RemotingServices;
			if (remotingServices != null)
			{
				remotingServices(this, e);
			}
		}

		protected virtual void SoapDateTimeIChannelSender(ToolStripItemImageRenderEventArgs e)
		{
			<Module>.SoapFieldAttribute(201);
			NameCachePrincipalPolicy.CodePageDataFileHeader codePageDataFileHeader = this.codePageDataFileHeader_0;
			if (codePageDataFileHeader != null)
			{
				codePageDataFileHeader(this, e);
			}
		}

		protected virtual void StoreOperationStageComponentNodeEnumerator(ToolStripItemImageRenderEventArgs e)
		{
			<Module>.SoapFieldAttribute(202);
			NameCachePrincipalPolicy.BinaryFormatterISponsor stackBasedReturnMessage = this.StackBasedReturnMessage;
			if (stackBasedReturnMessage != null)
			{
				stackBasedReturnMessage(this, e);
			}
		}

		protected virtual void SecurityTransparentAttribute(ToolStripItemTextRenderEventArgs e)
		{
			<Module>.SoapFieldAttribute(203);
			NameCachePrincipalPolicy.MemberHolder memberHolder = this.memberHolder_0;
			if (memberHolder != null)
			{
				memberHolder(this, e);
			}
		}

		protected virtual void CompressedStackRunDataOutOfMemoryException(ToolStripItemRenderEventArgs e)
		{
			<Module>.SoapFieldAttribute(204);
			NameCachePrincipalPolicy.IConstructionReturnMessageIEnumerable internalMemberValueEErrorMessage = this.InternalMemberValueEErrorMessage;
			if (internalMemberValueEErrorMessage != null)
			{
				internalMemberValueEErrorMessage(this, e);
			}
		}

		protected virtual void InternalRM(ToolStripArrowRenderEventArgs e)
		{
			<Module>.SoapFieldAttribute(205);
			NameCachePrincipalPolicy.ComparisonResultICDF internalParseStateEMessage = this.InternalParseStateEMessage;
			if (internalParseStateEMessage != null)
			{
				internalParseStateEMessage(this, e);
			}
		}

		protected virtual void AssertFiltersIMethodMessage(ToolStripSeparatorRenderEventArgs e)
		{
			<Module>.SoapFieldAttribute(206);
			NameCachePrincipalPolicy.PropertyToken agileSafeNativeMemoryHandle = this.AgileSafeNativeMemoryHandle;
			if (agileSafeNativeMemoryHandle != null)
			{
				agileSafeNativeMemoryHandle(this, e);
			}
		}

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private NameCachePrincipalPolicy.MethodOnTypeBuilderInstantiation RuntimeMethodHandleIEnumSTORECATEGORYSUBCATEGORY;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private NameCachePrincipalPolicy.RuntimeEventInfoKeyNotFoundException RemotingServices;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private NameCachePrincipalPolicy.SuppressUnmanagedCodeSecurityAttributeReadOnlyList ToBase64Transform;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private NameCachePrincipalPolicy.CodePageDataFileHeader codePageDataFileHeader_0;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private NameCachePrincipalPolicy.BinaryFormatterISponsor StackBasedReturnMessage;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private NameCachePrincipalPolicy.MemberHolder memberHolder_0;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private NameCachePrincipalPolicy.IConstructionReturnMessageIEnumerable InternalMemberValueEErrorMessage;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private NameCachePrincipalPolicy.ComparisonResultICDF InternalParseStateEMessage;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private NameCachePrincipalPolicy.PropertyToken AgileSafeNativeMemoryHandle;

		public delegate void MethodOnTypeBuilderInstantiation(object sender, ToolStripRenderEventArgs e);

		public delegate void RuntimeEventInfoKeyNotFoundException(object sender, ToolStripRenderEventArgs e);

		public delegate void SuppressUnmanagedCodeSecurityAttributeReadOnlyList(object sender, ToolStripRenderEventArgs e);

		public delegate void CodePageDataFileHeader(object sender, ToolStripItemImageRenderEventArgs e);

		public delegate void BinaryFormatterISponsor(object sender, ToolStripItemImageRenderEventArgs e);

		public delegate void MemberHolder(object sender, ToolStripItemTextRenderEventArgs e);

		public delegate void IConstructionReturnMessageIEnumerable(object sender, ToolStripItemRenderEventArgs e);

		public delegate void ComparisonResultICDF(object sender, ToolStripArrowRenderEventArgs e);

		public delegate void PropertyToken(object sender, ToolStripSeparatorRenderEventArgs e);
	}
}
