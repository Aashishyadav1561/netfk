﻿using System;
using System.Reflection;

internal delegate IntPtr TypeAttributesLocalDataStoreSlot(Module module_0);
