﻿using System;
using System.Reflection;

internal delegate MethodInfo[] InvalidCastExceptionSHA1(object object_0, BindingFlags bindingFlags_0);
