﻿using System;

internal delegate void ApplicationTrustEnumeratorLogSwitch(object object_0);
