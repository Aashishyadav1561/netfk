﻿using System;

internal delegate Type[] GCSafeFindHandle(object object_0);
