﻿using System;

internal delegate void AssemblyKeyFileAttributePublisherIdentityPermission(int int_0);
