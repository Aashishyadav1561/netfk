﻿using System;
using System.Reflection.Emit;

internal delegate void IArraySortHelper1TypeEntry(object object_0, OpCode opCode_0, int int_0);
