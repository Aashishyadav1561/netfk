﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using MetroSuite;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.ApplicationServices;
using Microsoft.VisualBasic.CompilerServices;
using Microsoft.VisualBasic.Devices;
using xNet;

internal class <Module>
{
	static <Module>()
	{
		<Module>.smethod_3();
	}

	[DllImport("kernel32.dll")]
	internal unsafe static extern bool VirtualProtect(byte* pByte_0, int int_0, uint uint_0, ref uint uint_1);

	internal unsafe static void smethod_0()
	{
		Module module = typeof(<Module>).Module;
		byte* ptr = (byte*)((void*)Marshal.GetHINSTANCE(module));
		byte* ptr2 = ptr + 60;
		ptr2 = ptr + *(uint*)ptr2;
		ptr2 += 6;
		ushort num = *(ushort*)ptr2;
		ptr2 += 10;
		uint num2 = *(uint*)ptr2;
		ptr2 += 4;
		ushort num3 = *(ushort*)ptr2;
		ptr2 = ptr2 + 4 + num3;
		byte* ptr3 = stackalloc byte[(UIntPtr)11];
		uint num5;
		if (module.FullyQualifiedName[0] != '<')
		{
			uint num4 = *(uint*)(ptr2 - 16);
			if (num4 == 0u)
			{
				num4 ^= (num2 ^ 4116064373u);
			}
			byte* ptr4 = ptr + num4;
			if (*(uint*)(ptr2 - 120) != 0u)
			{
				byte* ptr5 = ptr + *(uint*)(ptr2 - 120);
				byte* ptr6 = ptr + *(uint*)ptr5;
				byte* ptr7 = ptr + *(uint*)(ptr5 + 12);
				byte* ptr8 = ptr + *(uint*)ptr6 + 2;
				<Module>.VirtualProtect(ptr7, 11, 64u, ref num5);
				*(int*)ptr3 = 1818522734;
				*(int*)(ptr3 + 4) = 1818504812;
				*(short*)(ptr3 + (IntPtr)4 * 2) = 108;
				ptr3[10] = 0;
				for (int i = 0; i < 11; i++)
				{
					ptr7[i] = ptr3[i];
				}
				<Module>.VirtualProtect(ptr8, 11, 64u, ref num5);
				*(int*)ptr3 = 1866691662;
				*(int*)(ptr3 + 4) = 1852404846;
				*(short*)(ptr3 + (IntPtr)4 * 2) = 25973;
				ptr3[10] = 0;
				for (int j = 0; j < 11; j++)
				{
					ptr8[j] = ptr3[j];
				}
			}
			for (int k = 0; k < (int)num; k++)
			{
				<Module>.VirtualProtect(ptr2, 8, 64u, ref num5);
				Marshal.Copy(new byte[8], 0, (IntPtr)((void*)ptr2), 8);
				ptr2 += 40;
			}
			<Module>.VirtualProtect(ptr4, 72, 64u, ref num5);
			byte* ptr9 = ptr + *(uint*)(ptr4 + 8);
			*(int*)ptr4 = 0;
			*(int*)(ptr4 + 4) = 0;
			*(int*)(ptr4 + (IntPtr)2 * 4) = 0;
			*(int*)(ptr4 + (IntPtr)3 * 4) = 0;
			<Module>.VirtualProtect(ptr9, 4, 64u, ref num5);
			*(int*)ptr9 = 0;
			ptr9 += 12;
			ptr9 += *(uint*)ptr9;
			ptr9 = (ptr9 + 7L & -4L);
			ptr9 += 2;
			ushort num6 = (ushort)(*ptr9);
			ptr9 += 2;
			for (int l = 0; l < (int)num6; l++)
			{
				<Module>.VirtualProtect(ptr9, 8, 64u, ref num5);
				ptr9 += 4;
				ptr9 += 4;
				for (int m = 0; m < 8; m++)
				{
					<Module>.VirtualProtect(ptr9, 4, 64u, ref num5);
					*ptr9 = 0;
					ptr9++;
					if (*ptr9 == 0)
					{
						ptr9 += 3;
						break;
					}
					*ptr9 = 0;
					ptr9++;
					if (*ptr9 == 0)
					{
						ptr9 += 2;
						break;
					}
					*ptr9 = 0;
					ptr9++;
					if (*ptr9 == 0)
					{
						ptr9++;
						break;
					}
					*ptr9 = 0;
					ptr9++;
				}
			}
			return;
		}
		uint num7 = *(uint*)(ptr2 - 16);
		uint num8 = *(uint*)(ptr2 - 120);
		uint[] array = new uint[(int)num];
		uint[] array2 = new uint[(int)num];
		uint[] array3 = new uint[(int)num];
		for (int n = 0; n < (int)num; n++)
		{
			<Module>.VirtualProtect(ptr2, 8, 64u, ref num5);
			Marshal.Copy(new byte[8], 0, (IntPtr)((void*)ptr2), 8);
			array[n] = *(uint*)(ptr2 + 12);
			array2[n] = *(uint*)(ptr2 + 8);
			array3[n] = *(uint*)(ptr2 + 20);
			ptr2 += 40;
		}
		if (num8 != 0u)
		{
			for (int num9 = 0; num9 < (int)num; num9++)
			{
				if (array[num9] <= num8 && num8 < array[num9] + array2[num9])
				{
					num8 = num8 - array[num9] + array3[num9];
					break;
				}
			}
			byte* ptr10 = ptr + num8;
			uint num10 = *(uint*)ptr10;
			for (int num11 = 0; num11 < (int)num; num11++)
			{
				if (array[num11] <= num10 && num10 < array[num11] + array2[num11])
				{
					num10 = num10 - array[num11] + array3[num11];
					break;
				}
			}
			byte* ptr11 = ptr + num10;
			uint num12 = *(uint*)(ptr10 + 12);
			for (int num13 = 0; num13 < (int)num; num13++)
			{
				if (array[num13] <= num12 && num12 < array[num13] + array2[num13])
				{
					num12 = num12 - array[num13] + array3[num13];
					IL_55F:
					uint num14 = *(uint*)ptr11 + 2u;
					for (int num15 = 0; num15 < (int)num; num15++)
					{
						if (array[num15] <= num14 && num14 < array[num15] + array2[num15])
						{
							num14 = num14 - array[num15] + array3[num15];
							break;
						}
					}
					<Module>.VirtualProtect(ptr + num12, 11, 64u, ref num5);
					*(int*)ptr3 = 1818522734;
					*(int*)(ptr3 + 4) = 1818504812;
					*(short*)(ptr3 + (IntPtr)4 * 2) = 108;
					ptr3[10] = 0;
					for (int num16 = 0; num16 < 11; num16++)
					{
						(ptr + num12)[num16] = ptr3[num16];
					}
					<Module>.VirtualProtect(ptr + num14, 11, 64u, ref num5);
					*(int*)ptr3 = 1866691662;
					*(int*)(ptr3 + 4) = 1852404846;
					*(short*)(ptr3 + (IntPtr)4 * 2) = 25973;
					ptr3[10] = 0;
					for (int num17 = 0; num17 < 11; num17++)
					{
						(ptr + num14)[num17] = ptr3[num17];
					}
					goto IL_6A2;
				}
			}
			goto IL_55F;
		}
		IL_6A2:
		for (int num18 = 0; num18 < (int)num; num18++)
		{
			if (array[num18] <= num7 && num7 < array[num18] + array2[num18])
			{
				num7 = num7 - array[num18] + array3[num18];
				break;
			}
		}
		byte* ptr12 = ptr + num7;
		<Module>.VirtualProtect(ptr12, 72, 64u, ref num5);
		uint num19 = *(uint*)(ptr12 + 8);
		for (int num20 = 0; num20 < (int)num; num20++)
		{
			if (array[num20] <= num19 && num19 < array[num20] + array2[num20])
			{
				num19 = num19 - array[num20] + array3[num20];
				IL_74C:
				*(int*)ptr12 = 0;
				*(int*)(ptr12 + 4) = 0;
				*(int*)(ptr12 + (IntPtr)2 * 4) = 0;
				*(int*)(ptr12 + (IntPtr)3 * 4) = 0;
				byte* ptr13 = ptr + num19;
				<Module>.VirtualProtect(ptr13, 4, 64u, ref num5);
				*(int*)ptr13 = 0;
				ptr13 += 12;
				ptr13 += *(uint*)ptr13;
				ptr13 = (ptr13 + 7L & -4L);
				ptr13 += 2;
				ushort num21 = (ushort)(*ptr13);
				ptr13 += 2;
				for (int num22 = 0; num22 < (int)num21; num22++)
				{
					<Module>.VirtualProtect(ptr13, 8, 64u, ref num5);
					ptr13 += 4;
					ptr13 += 4;
					for (int num23 = 0; num23 < 8; num23++)
					{
						<Module>.VirtualProtect(ptr13, 4, 64u, ref num5);
						*ptr13 = 0;
						ptr13++;
						if (*ptr13 == 0)
						{
							ptr13 += 3;
							break;
						}
						*ptr13 = 0;
						ptr13++;
						if (*ptr13 == 0)
						{
							ptr13 += 2;
							break;
						}
						*ptr13 = 0;
						ptr13++;
						if (*ptr13 == 0)
						{
							ptr13++;
							break;
						}
						*ptr13 = 0;
						ptr13++;
					}
				}
				return;
			}
		}
		goto IL_74C;
	}

	internal static void smethod_1()
	{
		new Thread(new ThreadStart(<Module>.RSACryptoServiceProvider))
		{
			IsBackground = true
		}.Start();
	}

	internal static void RSACryptoServiceProvider()
	{
		IntPtr handle = Process.GetCurrentProcess().Handle;
		for (;;)
		{
			Thread.Sleep(16384);
			GC.Collect();
			GC.WaitForPendingFinalizers();
			if (Environment.OSVersion.Platform == PlatformID.Win32NT)
			{
				<Module>.SetProcessWorkingSetSize(handle, -1, -1);
			}
		}
	}

	[DllImport("kernel32")]
	internal static extern int SetProcessWorkingSetSize(IntPtr intptr_0, int int_0, int int_1);

	public static string GetPath()
	{
		return Process.GetCurrentProcess().MainModule.FileName;
	}

	public static string ProductVersion()
	{
		if (<Module>.GCCollectionMode == null)
		{
			<Module>.GCCollectionMode = FileVersionInfo.GetVersionInfo(<Module>.GetPath());
		}
		return <Module>.GCCollectionMode.ProductVersion;
	}

	public static string ProductName()
	{
		if (<Module>.GCCollectionMode == null)
		{
			<Module>.GCCollectionMode = FileVersionInfo.GetVersionInfo(<Module>.GetPath());
		}
		return <Module>.GCCollectionMode.ProductName;
	}

	internal static void ISerializableSidNameUse()
	{
		try
		{
			<Module>.CreateActContextParametersSource createActContextParametersSource = new <Module>.CreateActContextParametersSource();
			createActContextParametersSource.SecurityLogonTypeFileSystemSecurity(typeof(Assembly).GetMethod("GetEntryAssembly"));
			createActContextParametersSource.DelegateBindingFlags(typeof(Assembly).GetMethod("GetExecutingAssembly"));
			Type type = Type.GetType("System.Reflection.RuntimeAssembly");
			if (type != null)
			{
				createActContextParametersSource.SecurityLogonTypeFileSystemSecurity(type.GetProperty("Location").GetGetMethod());
				createActContextParametersSource.DelegateBindingFlags(typeof(<Module>).GetMethod("GetPath"));
			}
		}
		catch
		{
		}
	}

	internal static byte[] CallConvStdcall(byte[] byte_0)
	{
		System.IO.MemoryStream memoryStream = new System.IO.MemoryStream(byte_0);
		<Module>.ConfigServerDictionaryBase configServerDictionaryBase = new <Module>.ConfigServerDictionaryBase();
		byte[] array = new byte[5];
		memoryStream.Read(array, 0, 5);
		configServerDictionaryBase.MonthNameStylesISymbolScope(array);
		long num = 0L;
		for (int i = 0; i < 8; i++)
		{
			int num2 = memoryStream.ReadByte();
			num |= (long)((long)((ulong)((byte)num2)) << 8 * i);
		}
		byte[] array2 = new byte[(int)num];
		System.IO.MemoryStream stream_ = new System.IO.MemoryStream(array2, true);
		long long_ = memoryStream.Length - 13L;
		configServerDictionaryBase.DirectoryInfoUTF8Decoder(memoryStream, stream_, long_, num);
		return array2;
	}

	private static byte[] TYPELIBATTRDirectoryInfo(byte[] byte_0)
	{
		byte[] result;
		using (GZipStream gzipStream = new GZipStream(new System.IO.MemoryStream(byte_0), CompressionMode.Decompress))
		{
			byte[] buffer = new byte[4096];
			using (System.IO.MemoryStream memoryStream = new System.IO.MemoryStream())
			{
				int num;
				do
				{
					num = gzipStream.Read(buffer, 0, 4096);
					if (num > 0)
					{
						memoryStream.Write(buffer, 0, num);
					}
				}
				while (num > 0);
				result = memoryStream.ToArray();
			}
		}
		return result;
	}

	public static string UInt64COMServerEntry(string string_0)
	{
		int num = string_0.IndexOf("mscorlib");
		if (num == -1)
		{
			return string_0;
		}
		int num2 = string_0.IndexOf("]", num);
		if (num2 == -1)
		{
			return string_0;
		}
		if (num <= num2)
		{
			return string_0.Remove(num, num2 - num);
		}
		return string_0;
	}

	public static void PropertyInfoIActContext()
	{
		<Module>.GenericArraySortHelper2();
		List<IntPtr> list = new List<IntPtr>();
		list.Add(ldftn(set_PropertyTokenObjectIDGenerator));
		list.Add(ldftn(get_CryptoKeyAuditRule));
		list.Add(ldftn(get_CoClassAttributeReliabilityContractAttribute));
		list.Add(ldftn(get_FormatterAssemblyStyle));
		list.Add(ldftn(get_EnvoyInfo));
		list.Add(ldftn(get_AssemblyLoadEventArgs));
		list.Add(ldftn(set_EnvoyInfo));
		list.Add(ldftn(set_CoClassAttributeReliabilityContractAttribute));
		list.Add(ldftn(set_FormatterAssemblyStyle));
		list.Add(ldftn(set_CryptoKeyAuditRule));
		list.Add(ldftn(get_LogMessageEventHandler));
		list.Add(ldftn(add_StateManagerRunningStateWellKnownClientTypeEntry));
		list.Add(ldftn(add_AssemblyNamePermissionListSet));
		list.Add(ldftn(add_TypeUnloadedExceptionBINDPTR));
		list.Add(ldftn(add_EncoderFallbackBufferAccessControlActions));
		list.Add(ldftn(add_UCOMIBindCtxAF));
		list.Add(ldftn(add_MutexCleanupInfo));
		list.Add(ldftn(get_IAsyncResultIDENTITYATTRIBUTE));
		list.Add(ldftn(get_PrivateImplementationDetails{E61C418B-EF2D-4D3C-A0C2-E7E9B2B2EF81}));
		list.Add(ldftn(get_IReportMatchMembershipCondition));
		list.Add(ldftn(get_IServerChannelSinkIServiceProvider));
		list.Add(ldftn(get_SerializationMonkey));
		list.Add(ldftn(get_PolicyRights));
		list.Add(ldftn(get_PermissionTokenTypeBinaryObjectWithMapTyped));
		list.Add(ldftn(get_SurrogateHashtable));
		list.Add(ldftn(get_RegistryPermissionAccess));
		list.Add(ldftn(get_TextInfo));
		list.Add(ldftn(get_EventWaitHandleAuditRule));
		list.Add(ldftn(get_CodePageDataItemStringReader));
		list.Add(ldftn(get_Int32_0));
		list.Add(ldftn(get_ObjectCreationDelegateCleanupCode));
		list.Add(ldftn(get_CustomErrorsModes));
		list.Add(ldftn(set_EventWaitHandleAuditRule));
		list.Add(ldftn(set_TextInfo));
		list.Add(ldftn(set_CodePageEncodingManifestResourceAttributes));
		list.Add(ldftn(set_SurrogateHashtable));
		list.Add(ldftn(set_Int32_0));
		list.Add(ldftn(set_InterlockedThreadAbortException));
		list.Add(ldftn(get_InterlockedThreadAbortException));
		list.Add(ldftn(set_IServerChannelSinkIServiceProvider));
		list.Add(ldftn(set_IReportMatchMembershipCondition));
		list.Add(ldftn(set_IAsyncResultIDENTITYATTRIBUTE));
		list.Add(ldftn(set_PrivateImplementationDetails{E61C418B-EF2D-4D3C-A0C2-E7E9B2B2EF81}));
		IntPtr item = (IntPtr)null;
		int num = 308;
		byte[] array = <Module>.MuiResourceTypeIdStringEntryFieldId;
		for (int i = 0; i < array.Length; i++)
		{
			byte[] array2 = array;
			int num2 = i;
			array2[num2] ^= (byte)i;
		}
		array = <Module>.TYPELIBATTRDirectoryInfo(array);
		BinaryReader binaryReader = new BinaryReader(new System.IO.MemoryStream(array));
		for (int j = 0; j < num; j++)
		{
			int num3 = j * 20;
			binaryReader.BaseStream.Position = (long)num3;
			int num4 = binaryReader.ReadInt32();
			int num5 = binaryReader.ReadInt32();
			int startIndex = binaryReader.ReadInt32();
			uint num6 = binaryReader.ReadUInt32();
			int num7 = binaryReader.ReadInt32();
			uint num8 = 0u;
			if (num4 > 0)
			{
				num8 = BitConverter.ToUInt32(array, startIndex);
			}
			binaryReader.BaseStream.Position = (long)num7;
			uint num9 = binaryReader.ReadUInt32();
			binaryReader.BaseStream.Position = (long)num5;
			uint num10 = binaryReader.ReadUInt32();
			Type type = null;
			foreach (FieldInfo fieldInfo in typeof(<Module>).GetFields())
			{
				if (<Module>.ConstructorBuilderSecurityCriticalScope.CompoundAce(fieldInfo.Name) == num6)
				{
					type = fieldInfo.FieldType;
					break;
				}
			}
			MethodInfo methodInfo = null;
			foreach (MethodInfo methodInfo2 in type.GetMethods(BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic))
			{
				ParameterInfo[] parameters = methodInfo2.GetParameters();
				if (parameters.Length == num4 && <Module>.ConstructorBuilderSecurityCriticalScope.CompoundAce(methodInfo2.Name) == num10 && <Module>.ConstructorBuilderSecurityCriticalScope.CompoundAce(methodInfo2.ReturnType.FullName) == num9)
				{
					List<string> list2 = new List<string>();
					for (int l = 0; l < parameters.Length; l++)
					{
						string text = parameters[l].ParameterType.FullName;
						try
						{
							if (text.Contains("mscorlib"))
							{
								text = <Module>.UInt64COMServerEntry(text);
							}
							list2.Add(text);
							goto IL_465;
						}
						catch
						{
							goto IL_465;
						}
						break;
						IL_465:;
					}
					if (<Module>.ConstructorBuilderSecurityCriticalScope.CompoundAce(string.Join(new string(new char[0]), list2.ToArray())) == num8)
					{
						methodInfo = methodInfo2;
						break;
					}
				}
			}
			item = methodInfo.MethodHandle.GetFunctionPointer();
			list.Add(item);
		}
		<Module>.EventSinkHelperWriterIAssemblyRequestEntry = list.ToArray();
		Array.Clear(array, 0, array.Length);
	}

	private static void GenericArraySortHelper2()
	{
		string name = "EditAndContinueHelperMissingManifestResourceException";
		MethodAttributes attributes = MethodAttributes.FamANDAssem | MethodAttributes.Family | MethodAttributes.Static;
		CallingConventions callingConvention = CallingConventions.Standard;
		Type typeFromHandle = typeof(void);
		Type[] array = new Type[0];
		DynamicMethod dynamicMethod = new DynamicMethod(name, attributes, callingConvention, typeFromHandle, array, typeof(<Module>), false);
		MethodInfo methodInfo = <Module>.RtFieldInfo(dynamicMethod, array);
		if (methodInfo == null)
		{
			ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
			ilgenerator.Emit(OpCodes.Ldc_I4, 4065);
			ilgenerator.Emit(OpCodes.Newarr, typeof(byte));
			ilgenerator.Emit(OpCodes.Dup);
			ilgenerator.Emit(OpCodes.Ldtoken, typeof(<Module>).GetField("IsolatedStoragePermission", BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic));
			ilgenerator.EmitCall(OpCodes.Call, <Module>.CryptographicExceptionWin32(typeof(RuntimeHelpers), "InitializeArray", false, new Type[0], new object[]
			{
				typeof(Array),
				typeof(RuntimeFieldHandle)
			}), null);
			ilgenerator.Emit(OpCodes.Stsfld, typeof(<Module>).GetField("MuiResourceTypeIdStringEntryFieldId", BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic));
			ilgenerator.Emit(OpCodes.Ret);
			methodInfo = dynamicMethod.GetBaseDefinition();
			<Module>.SafeProcessHandleEnvironmentPermissionAttribute(methodInfo, array);
		}
		methodInfo.Invoke(null, new object[0]);
	}

	private static bool TransparentProxy(ParameterInfo[] parameterInfo_0, object[] object_0)
	{
		bool result = true;
		for (int i = 0; i < parameterInfo_0.Length; i++)
		{
			if (object_0[i] is Type)
			{
				if (parameterInfo_0[i].ParameterType != object_0[i])
				{
					result = false;
					break;
				}
			}
			else
			{
				string b = ((int)object_0[i] == 0) ? "T" : string.Format("T{0}", object_0[i]);
				if (parameterInfo_0[i].ParameterType.Name != b)
				{
					result = false;
					break;
				}
			}
		}
		return result;
	}

	public static MethodInfo CryptographicExceptionWin32(Type type_0, string string_0, bool bool_0, Type[] type_1, object[] object_0)
	{
		<Module>.CMSTIMEUNITTYPE = (<Module>.CMSTIMEUNITTYPE ?? new Dictionary<Type, List<MethodInfo>>());
		List<MethodInfo> list = null;
		if (!<Module>.CMSTIMEUNITTYPE.ContainsKey(type_0))
		{
			<Module>.CMSTIMEUNITTYPE[type_0] = new List<MethodInfo>(type_0.GetMethods(BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic));
		}
		list = <Module>.CMSTIMEUNITTYPE[type_0];
		MethodInfo methodInfo = null;
		try
		{
			methodInfo = type_0.GetMethod(string_0, BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
		}
		catch
		{
			try
			{
				methodInfo = type_0.GetMethod(string_0, BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic, null, (Type[])object_0, null);
			}
			catch
			{
				methodInfo = null;
			}
		}
		if (methodInfo == null)
		{
			foreach (MethodInfo methodInfo2 in list)
			{
				if (!(methodInfo2.Name != string_0) && (!bool_0 || methodInfo2.ContainsGenericParameters))
				{
					ParameterInfo[] parameters = methodInfo2.GetParameters();
					if (parameters.Length == object_0.Length)
					{
						bool flag = true;
						if (<Module>.TransparentProxy(parameters, object_0))
						{
							if (bool_0)
							{
								flag = (methodInfo2.GetGenericArguments().Length == type_1.Length);
							}
							if (flag)
							{
								methodInfo = methodInfo2;
								break;
							}
						}
					}
				}
			}
		}
		if (methodInfo.ContainsGenericParameters)
		{
			methodInfo = methodInfo.MakeGenericMethod(type_1);
		}
		return methodInfo;
	}

	public static ConstructorInfo TimerBase(Type type_0, bool bool_0, Type[] type_1, object[] object_0)
	{
		<Module>.EncoderFallback = (<Module>.EncoderFallback ?? new Dictionary<Type, List<ConstructorInfo>>());
		if (!<Module>.EncoderFallback.ContainsKey(type_0))
		{
			<Module>.EncoderFallback[type_0] = new List<ConstructorInfo>(type_0.GetConstructors());
		}
		List<ConstructorInfo> list = <Module>.EncoderFallback[type_0];
		ConstructorInfo result = null;
		foreach (ConstructorInfo constructorInfo in list)
		{
			if (!bool_0 || constructorInfo.ContainsGenericParameters)
			{
				ParameterInfo[] parameters = constructorInfo.GetParameters();
				if (parameters.Length == object_0.Length)
				{
					bool flag = true;
					if (<Module>.TransparentProxy(parameters, object_0))
					{
						if (bool_0)
						{
							flag = (constructorInfo.GetGenericArguments().Length == type_1.Length);
						}
						if (flag)
						{
							result = constructorInfo;
							break;
						}
					}
				}
			}
		}
		return result;
	}

	private static string ResourceReaderPolicyLevel(string string_0, Type[] type_0)
	{
		string text = "";
		foreach (Type type in type_0)
		{
			text += type.Name;
		}
		return BitConverter.ToString(MD5.Create().ComputeHash(System.Text.Encoding.UTF8.GetBytes(string_0 + text))).Replace("-", "");
	}

	public static MethodInfo RtFieldInfo(DynamicMethod dynamicMethod_0, Type[] type_0)
	{
		if (<Module>.IIDENTITYAUTHORITYDOESDEFINITIONMATCHREFERENCEFLAGS == null)
		{
			<Module>.IIDENTITYAUTHORITYDOESDEFINITIONMATCHREFERENCEFLAGS = new Dictionary<string, MethodInfo>();
		}
		string key = <Module>.ResourceReaderPolicyLevel(dynamicMethod_0.Name, type_0);
		if (!<Module>.IIDENTITYAUTHORITYDOESDEFINITIONMATCHREFERENCEFLAGS.ContainsKey(key))
		{
			return null;
		}
		return <Module>.IIDENTITYAUTHORITYDOESDEFINITIONMATCHREFERENCEFLAGS[key];
	}

	public static void SafeProcessHandleEnvironmentPermissionAttribute(MethodInfo methodInfo_0, Type[] type_0)
	{
		string key = <Module>.ResourceReaderPolicyLevel(methodInfo_0.Name, type_0);
		<Module>.IIDENTITYAUTHORITYDOESDEFINITIONMATCHREFERENCEFLAGS[key] = methodInfo_0;
	}

	static void IObjectReference(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[--num]) << 0) + (int)((int)(fieldFromHandle.Name[1] ^ (char)array[--num]) << 16) + (int)((int)(fieldFromHandle.Name[3] ^ (char)array[--num]) << 8);
		num--;
		int num3 = (num2 + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[num - 1]) << 24)) * -2049080135;
		num3 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num3);
		Type fieldType = fieldFromHandle.FieldType;
		if (!methodBase.IsStatic)
		{
			DynamicMethod dynamicMethod = null;
			Type[] array2 = null;
			foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
			{
				if (methodInfo.DeclaringType == fieldType)
				{
					ParameterInfo[] parameters = methodInfo.GetParameters();
					array2 = new Type[parameters.Length];
					for (int j = 0; j < array2.Length; j++)
					{
						array2[j] = parameters[j].ParameterType;
					}
					Type declaringType = methodBase.DeclaringType;
					dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
					break;
				}
			}
			DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
			DynamicILInfo dynamicILInfo2 = dynamicILInfo;
			byte[] array3 = new byte[2];
			array3[0] = 7;
			dynamicILInfo2.SetLocalSignature(array3);
			byte[] array4 = new byte[2 * array2.Length + 6];
			int num4 = 0;
			for (int k = 0; k < array2.Length; k++)
			{
				array4[num4++] = 14;
				array4[num4++] = (byte)k;
			}
			array4[num4++] = ((byte)fieldFromHandle.Name[4] ^ byte_0);
			int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
			array4[num4++] = (byte)tokenFor;
			array4[num4++] = (byte)(tokenFor >> 8);
			array4[num4++] = (byte)(tokenFor >> 16);
			array4[num4++] = (byte)(tokenFor >> 24);
			array4[num4] = 42;
			dynamicILInfo.SetCode(array4, array2.Length + 1);
			fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
			return;
		}
		fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
	}

	static void SidNameUseIConnectionPointContainer(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[3] ^ (char)array[--num]) << 0) + (int)((int)(fieldFromHandle.Name[1] ^ (char)array[--num]) << 16) + (int)((int)(fieldFromHandle.Name[4] ^ (char)array[--num]) << 8);
		num--;
		int num3 = (num2 + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[num - 1]) << 24)) * -890902253;
		num3 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num3);
		Type fieldType = fieldFromHandle.FieldType;
		if (!methodBase.IsStatic)
		{
			DynamicMethod dynamicMethod = null;
			Type[] array2 = null;
			foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
			{
				if (methodInfo.DeclaringType == fieldType)
				{
					ParameterInfo[] parameters = methodInfo.GetParameters();
					array2 = new Type[parameters.Length];
					for (int j = 0; j < array2.Length; j++)
					{
						array2[j] = parameters[j].ParameterType;
					}
					Type declaringType = methodBase.DeclaringType;
					dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
					break;
				}
			}
			DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
			DynamicILInfo dynamicILInfo2 = dynamicILInfo;
			byte[] array3 = new byte[2];
			array3[0] = 7;
			dynamicILInfo2.SetLocalSignature(array3);
			byte[] array4 = new byte[2 * array2.Length + 6];
			int num4 = 0;
			for (int k = 0; k < array2.Length; k++)
			{
				array4[num4++] = 14;
				array4[num4++] = (byte)k;
			}
			array4[num4++] = ((byte)fieldFromHandle.Name[0] ^ byte_0);
			int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
			array4[num4++] = (byte)tokenFor;
			array4[num4++] = (byte)(tokenFor >> 8);
			array4[num4++] = (byte)(tokenFor >> 16);
			array4[num4++] = (byte)(tokenFor >> 24);
			array4[num4] = 42;
			dynamicILInfo.SetCode(array4, array2.Length + 1);
			fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
			return;
		}
		fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
	}

	static void UnSafeCharBuffer(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = -1580697267;
		int num3 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[--num]) << 0) + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[--num]) << 8) + (int)((int)(fieldFromHandle.Name[1] ^ (char)array[--num]) << 24);
		num--;
		int num4 = num2 * (num3 + (int)((int)(fieldFromHandle.Name[4] ^ (char)array[num - 1]) << 16));
		num4 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num4);
		Type fieldType = fieldFromHandle.FieldType;
		if (!methodBase.IsStatic)
		{
			DynamicMethod dynamicMethod = null;
			Type[] array2 = null;
			foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
			{
				if (methodInfo.DeclaringType == fieldType)
				{
					ParameterInfo[] parameters = methodInfo.GetParameters();
					array2 = new Type[parameters.Length];
					for (int j = 0; j < array2.Length; j++)
					{
						array2[j] = parameters[j].ParameterType;
					}
					Type declaringType = methodBase.DeclaringType;
					dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
					break;
				}
			}
			DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
			DynamicILInfo dynamicILInfo2 = dynamicILInfo;
			byte[] array3 = new byte[2];
			array3[0] = 7;
			dynamicILInfo2.SetLocalSignature(array3);
			byte[] array4 = new byte[2 * array2.Length + 6];
			int num5 = 0;
			for (int k = 0; k < array2.Length; k++)
			{
				array4[num5++] = 14;
				array4[num5++] = (byte)k;
			}
			array4[num5++] = ((byte)fieldFromHandle.Name[3] ^ byte_0);
			int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
			array4[num5++] = (byte)tokenFor;
			array4[num5++] = (byte)(tokenFor >> 8);
			array4[num5++] = (byte)(tokenFor >> 16);
			array4[num5++] = (byte)(tokenFor >> 24);
			array4[num5] = 42;
			dynamicILInfo.SetCode(array4, array2.Length + 1);
			fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
			return;
		}
		fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
	}

	static void FUNCFLAGS(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = -774437063;
		int num3 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[--num]) << 16) + (int)((int)(fieldFromHandle.Name[1] ^ (char)array[--num]) << 8) + (int)((int)(fieldFromHandle.Name[3] ^ (char)array[--num]) << 24);
		num--;
		int num4 = num2 * (num3 + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[num - 1]) << 0));
		num4 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num4);
		Type fieldType = fieldFromHandle.FieldType;
		if (!methodBase.IsStatic)
		{
			DynamicMethod dynamicMethod = null;
			Type[] array2 = null;
			foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
			{
				if (methodInfo.DeclaringType == fieldType)
				{
					ParameterInfo[] parameters = methodInfo.GetParameters();
					array2 = new Type[parameters.Length];
					for (int j = 0; j < array2.Length; j++)
					{
						array2[j] = parameters[j].ParameterType;
					}
					Type declaringType = methodBase.DeclaringType;
					dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
					break;
				}
			}
			DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
			DynamicILInfo dynamicILInfo2 = dynamicILInfo;
			byte[] array3 = new byte[2];
			array3[0] = 7;
			dynamicILInfo2.SetLocalSignature(array3);
			byte[] array4 = new byte[2 * array2.Length + 6];
			int num5 = 0;
			for (int k = 0; k < array2.Length; k++)
			{
				array4[num5++] = 14;
				array4[num5++] = (byte)k;
			}
			array4[num5++] = ((byte)fieldFromHandle.Name[4] ^ byte_0);
			int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
			array4[num5++] = (byte)tokenFor;
			array4[num5++] = (byte)(tokenFor >> 8);
			array4[num5++] = (byte)(tokenFor >> 16);
			array4[num5++] = (byte)(tokenFor >> 24);
			array4[num5] = 42;
			dynamicILInfo.SetCode(array4, array2.Length + 1);
			fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
			return;
		}
		fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
	}

	static void BinaryConverterFileStream(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = -389333767;
		int num3 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[3] ^ (char)array[--num]) << 16) + (int)((int)(fieldFromHandle.Name[1] ^ (char)array[--num]) << 8) + (int)((int)(fieldFromHandle.Name[4] ^ (char)array[--num]) << 0);
		num--;
		int num4 = num2 * (num3 + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[num - 1]) << 24));
		num4 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num4);
		Type fieldType = fieldFromHandle.FieldType;
		if (!methodBase.IsStatic)
		{
			DynamicMethod dynamicMethod = null;
			Type[] array2 = null;
			foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
			{
				if (methodInfo.DeclaringType == fieldType)
				{
					ParameterInfo[] parameters = methodInfo.GetParameters();
					array2 = new Type[parameters.Length];
					for (int j = 0; j < array2.Length; j++)
					{
						array2[j] = parameters[j].ParameterType;
					}
					Type declaringType = methodBase.DeclaringType;
					dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
					break;
				}
			}
			DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
			DynamicILInfo dynamicILInfo2 = dynamicILInfo;
			byte[] array3 = new byte[2];
			array3[0] = 7;
			dynamicILInfo2.SetLocalSignature(array3);
			byte[] array4 = new byte[2 * array2.Length + 6];
			int num5 = 0;
			for (int k = 0; k < array2.Length; k++)
			{
				array4[num5++] = 14;
				array4[num5++] = (byte)k;
			}
			array4[num5++] = ((byte)fieldFromHandle.Name[2] ^ byte_0);
			int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
			array4[num5++] = (byte)tokenFor;
			array4[num5++] = (byte)(tokenFor >> 8);
			array4[num5++] = (byte)(tokenFor >> 16);
			array4[num5++] = (byte)(tokenFor >> 24);
			array4[num5] = 42;
			dynamicILInfo.SetCode(array4, array2.Length + 1);
			fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
			return;
		}
		fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
	}

	static void LeaseSinkManualResetEvent(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[--num]) << 24) + (int)((int)(fieldFromHandle.Name[1] ^ (char)array[--num]) << 16) + (int)((int)(fieldFromHandle.Name[3] ^ (char)array[--num]) << 8);
		num--;
		int num3 = (num2 + (int)((int)(fieldFromHandle.Name[4] ^ (char)array[num - 1]) << 0)) * 648558195;
		num3 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num3);
		Type fieldType = fieldFromHandle.FieldType;
		if (methodBase.IsStatic)
		{
			fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
			return;
		}
		DynamicMethod dynamicMethod = null;
		Type[] array2 = null;
		foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
		{
			if (methodInfo.DeclaringType == fieldType)
			{
				ParameterInfo[] parameters = methodInfo.GetParameters();
				array2 = new Type[parameters.Length];
				for (int j = 0; j < array2.Length; j++)
				{
					array2[j] = parameters[j].ParameterType;
				}
				Type declaringType = methodBase.DeclaringType;
				dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
				IL_16D:
				DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
				DynamicILInfo dynamicILInfo2 = dynamicILInfo;
				byte[] array3 = new byte[2];
				array3[0] = 7;
				dynamicILInfo2.SetLocalSignature(array3);
				byte[] array4 = new byte[2 * array2.Length + 6];
				int num4 = 0;
				for (int k = 0; k < array2.Length; k++)
				{
					array4[num4++] = 14;
					array4[num4++] = (byte)k;
				}
				array4[num4++] = ((byte)fieldFromHandle.Name[2] ^ byte_0);
				int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
				array4[num4++] = (byte)tokenFor;
				array4[num4++] = (byte)(tokenFor >> 8);
				array4[num4++] = (byte)(tokenFor >> 16);
				array4[num4++] = (byte)(tokenFor >> 24);
				array4[num4] = 42;
				dynamicILInfo.SetCode(array4, array2.Length + 1);
				fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
				return;
			}
		}
		goto IL_16D;
	}

	static void DSAParameters(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = -18507705;
		int num3 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[3] ^ (char)array[--num]) << 0) + (int)((int)(fieldFromHandle.Name[1] ^ (char)array[--num]) << 16) + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[--num]) << 24);
		num--;
		int num4 = num2 * (num3 + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[num - 1]) << 8));
		num4 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num4);
		Type fieldType = fieldFromHandle.FieldType;
		if (methodBase.IsStatic)
		{
			fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
			return;
		}
		DynamicMethod dynamicMethod = null;
		Type[] array2 = null;
		foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
		{
			if (methodInfo.DeclaringType == fieldType)
			{
				ParameterInfo[] parameters = methodInfo.GetParameters();
				array2 = new Type[parameters.Length];
				for (int j = 0; j < array2.Length; j++)
				{
					array2[j] = parameters[j].ParameterType;
				}
				Type declaringType = methodBase.DeclaringType;
				dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
				break;
			}
		}
		DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
		DynamicILInfo dynamicILInfo2 = dynamicILInfo;
		byte[] array3 = new byte[2];
		array3[0] = 7;
		dynamicILInfo2.SetLocalSignature(array3);
		byte[] array4 = new byte[2 * array2.Length + 6];
		int num5 = 0;
		for (int k = 0; k < array2.Length; k++)
		{
			array4[num5++] = 14;
			array4[num5++] = (byte)k;
		}
		array4[num5++] = ((byte)fieldFromHandle.Name[4] ^ byte_0);
		int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
		array4[num5++] = (byte)tokenFor;
		array4[num5++] = (byte)(tokenFor >> 8);
		array4[num5++] = (byte)(tokenFor >> 16);
		array4[num5++] = (byte)(tokenFor >> 24);
		array4[num5] = 42;
		dynamicILInfo.SetCode(array4, array2.Length + 1);
		fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
	}

	static void IsCopyConstructedSetWin32ContextInIDispatchAttribute(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = -697394707;
		int num3 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[3] ^ (char)array[--num]) << 16) + (int)((int)(fieldFromHandle.Name[1] ^ (char)array[--num]) << 24) + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[--num]) << 0);
		num--;
		int num4 = num2 * (num3 + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[num - 1]) << 8));
		num4 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num4);
		Type fieldType = fieldFromHandle.FieldType;
		if (!methodBase.IsStatic)
		{
			DynamicMethod dynamicMethod = null;
			Type[] array2 = null;
			foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
			{
				if (methodInfo.DeclaringType == fieldType)
				{
					ParameterInfo[] parameters = methodInfo.GetParameters();
					array2 = new Type[parameters.Length];
					for (int j = 0; j < array2.Length; j++)
					{
						array2[j] = parameters[j].ParameterType;
					}
					Type declaringType = methodBase.DeclaringType;
					dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
					break;
				}
			}
			DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
			DynamicILInfo dynamicILInfo2 = dynamicILInfo;
			byte[] array3 = new byte[2];
			array3[0] = 7;
			dynamicILInfo2.SetLocalSignature(array3);
			byte[] array4 = new byte[2 * array2.Length + 6];
			int num5 = 0;
			for (int k = 0; k < array2.Length; k++)
			{
				array4[num5++] = 14;
				array4[num5++] = (byte)k;
			}
			array4[num5++] = ((byte)fieldFromHandle.Name[4] ^ byte_0);
			int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
			array4[num5++] = (byte)tokenFor;
			array4[num5++] = (byte)(tokenFor >> 8);
			array4[num5++] = (byte)(tokenFor >> 16);
			array4[num5++] = (byte)(tokenFor >> 24);
			array4[num5] = 42;
			dynamicILInfo.SetCode(array4, array2.Length + 1);
			fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
			return;
		}
		fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
	}

	static void ArrayEnumeratorFileAssociationEntryFieldId(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = -310238929;
		int num3 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[--num]) << 24) + (int)((int)(fieldFromHandle.Name[3] ^ (char)array[--num]) << 8) + (int)((int)(fieldFromHandle.Name[4] ^ (char)array[--num]) << 16);
		num--;
		int num4 = num2 * (num3 + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[num - 1]) << 0));
		num4 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num4);
		Type fieldType = fieldFromHandle.FieldType;
		if (methodBase.IsStatic)
		{
			fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
			return;
		}
		DynamicMethod dynamicMethod = null;
		Type[] array2 = null;
		foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
		{
			if (methodInfo.DeclaringType == fieldType)
			{
				ParameterInfo[] parameters = methodInfo.GetParameters();
				array2 = new Type[parameters.Length];
				for (int j = 0; j < array2.Length; j++)
				{
					array2[j] = parameters[j].ParameterType;
				}
				Type declaringType = methodBase.DeclaringType;
				dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
				break;
			}
		}
		DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
		DynamicILInfo dynamicILInfo2 = dynamicILInfo;
		byte[] array3 = new byte[2];
		array3[0] = 7;
		dynamicILInfo2.SetLocalSignature(array3);
		byte[] array4 = new byte[2 * array2.Length + 6];
		int num5 = 0;
		for (int k = 0; k < array2.Length; k++)
		{
			array4[num5++] = 14;
			array4[num5++] = (byte)k;
		}
		array4[num5++] = ((byte)fieldFromHandle.Name[1] ^ byte_0);
		int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
		array4[num5++] = (byte)tokenFor;
		array4[num5++] = (byte)(tokenFor >> 8);
		array4[num5++] = (byte)(tokenFor >> 16);
		array4[num5++] = (byte)(tokenFor >> 24);
		array4[num5] = 42;
		dynamicILInfo.SetCode(array4, array2.Length + 1);
		fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
	}

	static void MuiResourceIdLookupMapEntry(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[3] ^ (char)array[--num]) << 24) + (int)((int)(fieldFromHandle.Name[4] ^ (char)array[--num]) << 8) + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[--num]) << 0);
		num--;
		int num3 = (num2 + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[num - 1]) << 16)) * 1287679913;
		num3 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num3);
		Type fieldType = fieldFromHandle.FieldType;
		if (methodBase.IsStatic)
		{
			fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
			return;
		}
		DynamicMethod dynamicMethod = null;
		Type[] array2 = null;
		foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
		{
			if (methodInfo.DeclaringType == fieldType)
			{
				ParameterInfo[] parameters = methodInfo.GetParameters();
				array2 = new Type[parameters.Length];
				for (int j = 0; j < array2.Length; j++)
				{
					array2[j] = parameters[j].ParameterType;
				}
				Type declaringType = methodBase.DeclaringType;
				dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
				IL_16B:
				DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
				DynamicILInfo dynamicILInfo2 = dynamicILInfo;
				byte[] array3 = new byte[2];
				array3[0] = 7;
				dynamicILInfo2.SetLocalSignature(array3);
				byte[] array4 = new byte[2 * array2.Length + 6];
				int num4 = 0;
				for (int k = 0; k < array2.Length; k++)
				{
					array4[num4++] = 14;
					array4[num4++] = (byte)k;
				}
				array4[num4++] = ((byte)fieldFromHandle.Name[1] ^ byte_0);
				int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
				array4[num4++] = (byte)tokenFor;
				array4[num4++] = (byte)(tokenFor >> 8);
				array4[num4++] = (byte)(tokenFor >> 16);
				array4[num4++] = (byte)(tokenFor >> 24);
				array4[num4] = 42;
				dynamicILInfo.SetCode(array4, array2.Length + 1);
				fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
				return;
			}
		}
		goto IL_16B;
	}

	static void TargetParameterCountExceptionCompoundAce(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = 1026884267;
		int num3 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[--num]) << 0) + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[--num]) << 24) + (int)((int)(fieldFromHandle.Name[1] ^ (char)array[--num]) << 8);
		num--;
		int num4 = num2 * (num3 + (int)((int)(fieldFromHandle.Name[3] ^ (char)array[num - 1]) << 16));
		num4 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num4);
		Type fieldType = fieldFromHandle.FieldType;
		if (methodBase.IsStatic)
		{
			fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
			return;
		}
		DynamicMethod dynamicMethod = null;
		Type[] array2 = null;
		foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
		{
			if (methodInfo.DeclaringType == fieldType)
			{
				ParameterInfo[] parameters = methodInfo.GetParameters();
				array2 = new Type[parameters.Length];
				for (int j = 0; j < array2.Length; j++)
				{
					array2[j] = parameters[j].ParameterType;
				}
				Type declaringType = methodBase.DeclaringType;
				dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
				IL_16D:
				DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
				DynamicILInfo dynamicILInfo2 = dynamicILInfo;
				byte[] array3 = new byte[2];
				array3[0] = 7;
				dynamicILInfo2.SetLocalSignature(array3);
				byte[] array4 = new byte[2 * array2.Length + 6];
				int num5 = 0;
				for (int k = 0; k < array2.Length; k++)
				{
					array4[num5++] = 14;
					array4[num5++] = (byte)k;
				}
				array4[num5++] = ((byte)fieldFromHandle.Name[4] ^ byte_0);
				int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
				array4[num5++] = (byte)tokenFor;
				array4[num5++] = (byte)(tokenFor >> 8);
				array4[num5++] = (byte)(tokenFor >> 16);
				array4[num5++] = (byte)(tokenFor >> 24);
				array4[num5] = 42;
				dynamicILInfo.SetCode(array4, array2.Length + 1);
				fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
				return;
			}
		}
		goto IL_16D;
	}

	static void SecurityContextRunDataRuntimeEventInfo(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = 1149300225;
		int num3 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[--num]) << 0) + (int)((int)(fieldFromHandle.Name[4] ^ (char)array[--num]) << 24) + (int)((int)(fieldFromHandle.Name[1] ^ (char)array[--num]) << 16);
		num--;
		int num4 = num2 * (num3 + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[num - 1]) << 8));
		num4 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num4);
		Type fieldType = fieldFromHandle.FieldType;
		if (!methodBase.IsStatic)
		{
			DynamicMethod dynamicMethod = null;
			Type[] array2 = null;
			foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
			{
				if (methodInfo.DeclaringType == fieldType)
				{
					ParameterInfo[] parameters = methodInfo.GetParameters();
					array2 = new Type[parameters.Length];
					for (int j = 0; j < array2.Length; j++)
					{
						array2[j] = parameters[j].ParameterType;
					}
					Type declaringType = methodBase.DeclaringType;
					dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
					break;
				}
			}
			DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
			DynamicILInfo dynamicILInfo2 = dynamicILInfo;
			byte[] array3 = new byte[2];
			array3[0] = 7;
			dynamicILInfo2.SetLocalSignature(array3);
			byte[] array4 = new byte[2 * array2.Length + 6];
			int num5 = 0;
			for (int k = 0; k < array2.Length; k++)
			{
				array4[num5++] = 14;
				array4[num5++] = (byte)k;
			}
			array4[num5++] = ((byte)fieldFromHandle.Name[3] ^ byte_0);
			int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
			array4[num5++] = (byte)tokenFor;
			array4[num5++] = (byte)(tokenFor >> 8);
			array4[num5++] = (byte)(tokenFor >> 16);
			array4[num5++] = (byte)(tokenFor >> 24);
			array4[num5] = 42;
			dynamicILInfo.SetCode(array4, array2.Length + 1);
			fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
			return;
		}
		fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
	}

	static void DelayLoadClientChannelEntry(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = 2084515223;
		int num3 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[--num]) << 0) + (int)((int)(fieldFromHandle.Name[4] ^ (char)array[--num]) << 8) + (int)((int)(fieldFromHandle.Name[1] ^ (char)array[--num]) << 16);
		num--;
		int num4 = num2 * (num3 + (int)((int)(fieldFromHandle.Name[3] ^ (char)array[num - 1]) << 24));
		num4 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num4);
		Type fieldType = fieldFromHandle.FieldType;
		if (methodBase.IsStatic)
		{
			fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
			return;
		}
		DynamicMethod dynamicMethod = null;
		Type[] array2 = null;
		foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
		{
			if (methodInfo.DeclaringType == fieldType)
			{
				ParameterInfo[] parameters = methodInfo.GetParameters();
				array2 = new Type[parameters.Length];
				for (int j = 0; j < array2.Length; j++)
				{
					array2[j] = parameters[j].ParameterType;
				}
				Type declaringType = methodBase.DeclaringType;
				dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
				break;
			}
		}
		DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
		DynamicILInfo dynamicILInfo2 = dynamicILInfo;
		byte[] array3 = new byte[2];
		array3[0] = 7;
		dynamicILInfo2.SetLocalSignature(array3);
		byte[] array4 = new byte[2 * array2.Length + 6];
		int num5 = 0;
		for (int k = 0; k < array2.Length; k++)
		{
			array4[num5++] = 14;
			array4[num5++] = (byte)k;
		}
		array4[num5++] = ((byte)fieldFromHandle.Name[2] ^ byte_0);
		int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
		array4[num5++] = (byte)tokenFor;
		array4[num5++] = (byte)(tokenFor >> 8);
		array4[num5++] = (byte)(tokenFor >> 16);
		array4[num5++] = (byte)(tokenFor >> 24);
		array4[num5] = 42;
		dynamicILInfo.SetCode(array4, array2.Length + 1);
		fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
	}

	static void ParamArrayAttribute(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = -209276913;
		int num3 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[--num]) << 16) + (int)((int)(fieldFromHandle.Name[3] ^ (char)array[--num]) << 8) + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[--num]) << 24);
		num--;
		int num4 = num2 * (num3 + (int)((int)(fieldFromHandle.Name[4] ^ (char)array[num - 1]) << 0));
		num4 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num4);
		Type fieldType = fieldFromHandle.FieldType;
		if (!methodBase.IsStatic)
		{
			DynamicMethod dynamicMethod = null;
			Type[] array2 = null;
			foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
			{
				if (methodInfo.DeclaringType == fieldType)
				{
					ParameterInfo[] parameters = methodInfo.GetParameters();
					array2 = new Type[parameters.Length];
					for (int j = 0; j < array2.Length; j++)
					{
						array2[j] = parameters[j].ParameterType;
					}
					Type declaringType = methodBase.DeclaringType;
					dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
					break;
				}
			}
			DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
			DynamicILInfo dynamicILInfo2 = dynamicILInfo;
			byte[] array3 = new byte[2];
			array3[0] = 7;
			dynamicILInfo2.SetLocalSignature(array3);
			byte[] array4 = new byte[2 * array2.Length + 6];
			int num5 = 0;
			for (int k = 0; k < array2.Length; k++)
			{
				array4[num5++] = 14;
				array4[num5++] = (byte)k;
			}
			array4[num5++] = ((byte)fieldFromHandle.Name[1] ^ byte_0);
			int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
			array4[num5++] = (byte)tokenFor;
			array4[num5++] = (byte)(tokenFor >> 8);
			array4[num5++] = (byte)(tokenFor >> 16);
			array4[num5++] = (byte)(tokenFor >> 24);
			array4[num5] = 42;
			dynamicILInfo.SetCode(array4, array2.Length + 1);
			fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
			return;
		}
		fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
	}

	static void SpecialNameAttributeOnSerializingAttribute(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[3] ^ (char)array[--num]) << 0) + (int)((int)(fieldFromHandle.Name[4] ^ (char)array[--num]) << 24) + (int)((int)(fieldFromHandle.Name[1] ^ (char)array[--num]) << 8);
		num--;
		int num3 = (num2 + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[num - 1]) << 16)) * 1182070983;
		num3 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num3);
		Type fieldType = fieldFromHandle.FieldType;
		if (methodBase.IsStatic)
		{
			fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
			return;
		}
		DynamicMethod dynamicMethod = null;
		Type[] array2 = null;
		foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
		{
			if (methodInfo.DeclaringType == fieldType)
			{
				ParameterInfo[] parameters = methodInfo.GetParameters();
				array2 = new Type[parameters.Length];
				for (int j = 0; j < array2.Length; j++)
				{
					array2[j] = parameters[j].ParameterType;
				}
				Type declaringType = methodBase.DeclaringType;
				dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
				break;
			}
		}
		DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
		DynamicILInfo dynamicILInfo2 = dynamicILInfo;
		byte[] array3 = new byte[2];
		array3[0] = 7;
		dynamicILInfo2.SetLocalSignature(array3);
		byte[] array4 = new byte[2 * array2.Length + 6];
		int num4 = 0;
		for (int k = 0; k < array2.Length; k++)
		{
			array4[num4++] = 14;
			array4[num4++] = (byte)k;
		}
		array4[num4++] = ((byte)fieldFromHandle.Name[2] ^ byte_0);
		int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
		array4[num4++] = (byte)tokenFor;
		array4[num4++] = (byte)(tokenFor >> 8);
		array4[num4++] = (byte)(tokenFor >> 16);
		array4[num4++] = (byte)(tokenFor >> 24);
		array4[num4] = 42;
		dynamicILInfo.SetCode(array4, array2.Length + 1);
		fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
	}

	static void COMExceptionUCOMIEnumString(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[--num]) << 16) + (int)((int)(fieldFromHandle.Name[1] ^ (char)array[--num]) << 8) + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[--num]) << 0);
		num--;
		int num3 = (num2 + (int)((int)(fieldFromHandle.Name[4] ^ (char)array[num - 1]) << 24)) * 489970657;
		num3 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num3);
		Type fieldType = fieldFromHandle.FieldType;
		if (methodBase.IsStatic)
		{
			fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
			return;
		}
		DynamicMethod dynamicMethod = null;
		Type[] array2 = null;
		foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
		{
			if (methodInfo.DeclaringType == fieldType)
			{
				ParameterInfo[] parameters = methodInfo.GetParameters();
				array2 = new Type[parameters.Length];
				for (int j = 0; j < array2.Length; j++)
				{
					array2[j] = parameters[j].ParameterType;
				}
				Type declaringType = methodBase.DeclaringType;
				dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
				IL_16D:
				DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
				DynamicILInfo dynamicILInfo2 = dynamicILInfo;
				byte[] array3 = new byte[2];
				array3[0] = 7;
				dynamicILInfo2.SetLocalSignature(array3);
				byte[] array4 = new byte[2 * array2.Length + 6];
				int num4 = 0;
				for (int k = 0; k < array2.Length; k++)
				{
					array4[num4++] = 14;
					array4[num4++] = (byte)k;
				}
				array4[num4++] = ((byte)fieldFromHandle.Name[3] ^ byte_0);
				int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
				array4[num4++] = (byte)tokenFor;
				array4[num4++] = (byte)(tokenFor >> 8);
				array4[num4++] = (byte)(tokenFor >> 16);
				array4[num4++] = (byte)(tokenFor >> 24);
				array4[num4] = 42;
				dynamicILInfo.SetCode(array4, array2.Length + 1);
				fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
				return;
			}
		}
		goto IL_16D;
	}

	private static byte[] SendOrPostCallbackWaitDelegate(byte[] byte_0)
	{
		byte[] result;
		using (GZipStream gzipStream = new GZipStream(new System.IO.MemoryStream(byte_0), CompressionMode.Decompress))
		{
			byte[] buffer = new byte[4096];
			using (System.IO.MemoryStream memoryStream = new System.IO.MemoryStream())
			{
				int num;
				do
				{
					num = gzipStream.Read(buffer, 0, 4096);
					if (num > 0)
					{
						memoryStream.Write(buffer, 0, num);
					}
				}
				while (num > 0);
				result = memoryStream.ToArray();
			}
		}
		return result;
	}

	public static string PermissionSetTripleMuiResourceTypeIdStringEntryFieldId(string string_0)
	{
		int num = string_0.IndexOf("mscorlib");
		if (num == -1)
		{
			return string_0;
		}
		int num2 = string_0.IndexOf("]", num);
		if (num2 == -1)
		{
			return string_0;
		}
		if (num > num2)
		{
			return string_0;
		}
		return string_0.Remove(num, num2 - num);
	}

	public static void IDENTITYATTRIBUTEIContributeObjectSink()
	{
		<Module>.InternalNameSpaceE();
		List<IntPtr> list = new List<IntPtr>();
		list.Add(ldftn(set_PropertyTokenObjectIDGenerator));
		list.Add(ldftn(get_CryptoKeyAuditRule));
		list.Add(ldftn(get_CoClassAttributeReliabilityContractAttribute));
		list.Add(ldftn(get_FormatterAssemblyStyle));
		list.Add(ldftn(get_EnvoyInfo));
		list.Add(ldftn(get_AssemblyLoadEventArgs));
		list.Add(ldftn(set_EnvoyInfo));
		list.Add(ldftn(set_CoClassAttributeReliabilityContractAttribute));
		list.Add(ldftn(set_FormatterAssemblyStyle));
		list.Add(ldftn(set_CryptoKeyAuditRule));
		list.Add(ldftn(get_LogMessageEventHandler));
		list.Add(ldftn(get_SerializationMonkey));
		list.Add(ldftn(get_PolicyRights));
		list.Add(ldftn(get_PermissionTokenTypeBinaryObjectWithMapTyped));
		list.Add(ldftn(get_SurrogateHashtable));
		list.Add(ldftn(get_RegistryPermissionAccess));
		list.Add(ldftn(get_TextInfo));
		list.Add(ldftn(get_EventWaitHandleAuditRule));
		list.Add(ldftn(get_CodePageDataItemStringReader));
		list.Add(ldftn(get_Int32_0));
		list.Add(ldftn(get_ObjectCreationDelegateCleanupCode));
		list.Add(ldftn(get_CustomErrorsModes));
		list.Add(ldftn(set_EventWaitHandleAuditRule));
		list.Add(ldftn(set_TextInfo));
		list.Add(ldftn(set_CodePageEncodingManifestResourceAttributes));
		list.Add(ldftn(set_SurrogateHashtable));
		list.Add(ldftn(set_Int32_0));
		list.Add(ldftn(set_InterlockedThreadAbortException));
		list.Add(ldftn(get_InterlockedThreadAbortException));
		IntPtr item = (IntPtr)null;
		int num = 90;
		byte[] array = <Module>.RegistryAccessRuleDecoderFallbackException;
		for (int i = 0; i < array.Length; i++)
		{
			byte[] array2 = array;
			int num2 = i;
			array2[num2] ^= (byte)i;
		}
		array = <Module>.SendOrPostCallbackWaitDelegate(array);
		BinaryReader binaryReader = new BinaryReader(new System.IO.MemoryStream(array));
		int j = 0;
		IL_1C4:
		while (j < num)
		{
			int num3 = j * 20;
			binaryReader.BaseStream.Position = (long)num3;
			int num4 = binaryReader.ReadInt32();
			int num5 = binaryReader.ReadInt32();
			int startIndex = binaryReader.ReadInt32();
			uint num6 = binaryReader.ReadUInt32();
			int num7 = binaryReader.ReadInt32();
			uint num8 = 0u;
			if (num4 > 0)
			{
				num8 = BitConverter.ToUInt32(array, startIndex);
			}
			binaryReader.BaseStream.Position = (long)num7;
			uint num9 = binaryReader.ReadUInt32();
			binaryReader.BaseStream.Position = (long)num5;
			uint num10 = binaryReader.ReadUInt32();
			Type type = null;
			FieldInfo[] fields = typeof(<Module>).GetFields();
			for (int k = 0; k < fields.Length; k++)
			{
				FieldInfo fieldInfo = fields[k];
				if (<Module>.Disposition.MulticastDelegate(fieldInfo.Name) == num6)
				{
					type = fieldInfo.FieldType;
					IL_2AD:
					MethodInfo methodInfo = null;
					foreach (MethodInfo methodInfo2 in type.GetMethods(BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic))
					{
						ParameterInfo[] parameters = methodInfo2.GetParameters();
						if (parameters.Length == num4 && <Module>.Disposition.MulticastDelegate(methodInfo2.Name) == num10 && <Module>.Disposition.MulticastDelegate(methodInfo2.ReturnType.FullName) == num9)
						{
							List<string> list2 = new List<string>();
							for (int l = 0; l < parameters.Length; l++)
							{
								string text = parameters[l].ParameterType.FullName;
								try
								{
									if (text.Contains("mscorlib"))
									{
										text = <Module>.PermissionSetTripleMuiResourceTypeIdStringEntryFieldId(text);
									}
									list2.Add(text);
									goto IL_3BD;
								}
								catch
								{
									goto IL_3BD;
								}
								break;
								IL_3BD:;
							}
							if (<Module>.Disposition.MulticastDelegate(string.Join(new string(new char[0]), list2.ToArray())) == num8)
							{
								methodInfo = methodInfo2;
								break;
							}
						}
					}
					item = methodInfo.MethodHandle.GetFunctionPointer();
					list.Add(item);
					j++;
					goto IL_1C4;
				}
			}
			goto IL_2AD;
		}
		<Module>.ConstructorOnTypeBuilderInstantiationManifestResourceInfo = list.ToArray();
		Array.Clear(array, 0, array.Length);
	}

	private static void InternalNameSpaceE()
	{
		string name = "AsyncWorkItem";
		MethodAttributes attributes = MethodAttributes.FamANDAssem | MethodAttributes.Family | MethodAttributes.Static;
		CallingConventions callingConvention = CallingConventions.Standard;
		Type typeFromHandle = typeof(void);
		Type[] array = new Type[0];
		DynamicMethod dynamicMethod = new DynamicMethod(name, attributes, callingConvention, typeFromHandle, array, typeof(<Module>), false);
		MethodInfo methodInfo = <Module>.RtFieldInfo(dynamicMethod, array);
		if (methodInfo == null)
		{
			ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
			ilgenerator.Emit(OpCodes.Ldc_I4, 1486);
			ilgenerator.Emit(OpCodes.Newarr, typeof(byte));
			ilgenerator.Emit(OpCodes.Dup);
			ilgenerator.Emit(OpCodes.Ldtoken, typeof(<Module>).GetField("EastAsianLunisolarCalendarThrowHelper", BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic));
			ilgenerator.EmitCall(OpCodes.Call, <Module>.CryptographicExceptionWin32(typeof(RuntimeHelpers), "InitializeArray", false, new Type[0], new object[]
			{
				typeof(Array),
				typeof(RuntimeFieldHandle)
			}), null);
			ilgenerator.Emit(OpCodes.Stsfld, typeof(<Module>).GetField("RegistryAccessRuleDecoderFallbackException", BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic));
			ilgenerator.Emit(OpCodes.Ret);
			methodInfo = dynamicMethod.GetBaseDefinition();
			<Module>.SafeProcessHandleEnvironmentPermissionAttribute(methodInfo, array);
		}
		methodInfo.Invoke(null, new object[0]);
	}

	static void LockCookieResourceWriter(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[--num]) << 24) + (int)((int)(fieldFromHandle.Name[1] ^ (char)array[--num]) << 16) + (int)((int)(fieldFromHandle.Name[3] ^ (char)array[--num]) << 8);
		num--;
		int num3 = (num2 + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[num - 1]) << 0)) * 363475603;
		num3 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num3);
		Type fieldType = fieldFromHandle.FieldType;
		if (methodBase.IsStatic)
		{
			fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
			return;
		}
		DynamicMethod dynamicMethod = null;
		Type[] array2 = null;
		foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
		{
			if (methodInfo.DeclaringType == fieldType)
			{
				ParameterInfo[] parameters = methodInfo.GetParameters();
				array2 = new Type[parameters.Length];
				for (int j = 0; j < array2.Length; j++)
				{
					array2[j] = parameters[j].ParameterType;
				}
				Type declaringType = methodBase.DeclaringType;
				dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
				IL_16D:
				DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
				DynamicILInfo dynamicILInfo2 = dynamicILInfo;
				byte[] array3 = new byte[2];
				array3[0] = 7;
				dynamicILInfo2.SetLocalSignature(array3);
				byte[] array4 = new byte[2 * array2.Length + 6];
				int num4 = 0;
				for (int k = 0; k < array2.Length; k++)
				{
					array4[num4++] = 14;
					array4[num4++] = (byte)k;
				}
				array4[num4++] = ((byte)fieldFromHandle.Name[4] ^ byte_0);
				int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
				array4[num4++] = (byte)tokenFor;
				array4[num4++] = (byte)(tokenFor >> 8);
				array4[num4++] = (byte)(tokenFor >> 16);
				array4[num4++] = (byte)(tokenFor >> 24);
				array4[num4] = 42;
				dynamicILInfo.SetCode(array4, array2.Length + 1);
				fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
				return;
			}
		}
		goto IL_16D;
	}

	static void IRemotingTypeInfo(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = 1328526141;
		int num3 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[--num]) << 0) + (int)((int)(fieldFromHandle.Name[1] ^ (char)array[--num]) << 24) + (int)((int)(fieldFromHandle.Name[4] ^ (char)array[--num]) << 8);
		num--;
		int num4 = num2 * (num3 + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[num - 1]) << 16));
		num4 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num4);
		Type fieldType = fieldFromHandle.FieldType;
		if (!methodBase.IsStatic)
		{
			DynamicMethod dynamicMethod = null;
			Type[] array2 = null;
			foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
			{
				if (methodInfo.DeclaringType == fieldType)
				{
					ParameterInfo[] parameters = methodInfo.GetParameters();
					array2 = new Type[parameters.Length];
					for (int j = 0; j < array2.Length; j++)
					{
						array2[j] = parameters[j].ParameterType;
					}
					Type declaringType = methodBase.DeclaringType;
					dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
					IL_15A:
					DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
					DynamicILInfo dynamicILInfo2 = dynamicILInfo;
					byte[] array3 = new byte[2];
					array3[0] = 7;
					dynamicILInfo2.SetLocalSignature(array3);
					byte[] array4 = new byte[2 * array2.Length + 6];
					int num5 = 0;
					for (int k = 0; k < array2.Length; k++)
					{
						array4[num5++] = 14;
						array4[num5++] = (byte)k;
					}
					array4[num5++] = ((byte)fieldFromHandle.Name[3] ^ byte_0);
					int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
					array4[num5++] = (byte)tokenFor;
					array4[num5++] = (byte)(tokenFor >> 8);
					array4[num5++] = (byte)(tokenFor >> 16);
					array4[num5++] = (byte)(tokenFor >> 24);
					array4[num5] = 42;
					dynamicILInfo.SetCode(array4, array2.Length + 1);
					fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
					return;
				}
			}
			goto IL_15A;
		}
		fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
	}

	static void RuntimeEnvironmentBinaryMethodReturn(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = 1181582197;
		int num3 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[--num]) << 0) + (int)((int)(fieldFromHandle.Name[4] ^ (char)array[--num]) << 8) + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[--num]) << 16);
		num--;
		int num4 = num2 * (num3 + (int)((int)(fieldFromHandle.Name[1] ^ (char)array[num - 1]) << 24));
		num4 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num4);
		Type fieldType = fieldFromHandle.FieldType;
		if (methodBase.IsStatic)
		{
			fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
			return;
		}
		DynamicMethod dynamicMethod = null;
		Type[] array2 = null;
		foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
		{
			if (methodInfo.DeclaringType == fieldType)
			{
				ParameterInfo[] parameters = methodInfo.GetParameters();
				array2 = new Type[parameters.Length];
				for (int j = 0; j < array2.Length; j++)
				{
					array2[j] = parameters[j].ParameterType;
				}
				Type declaringType = methodBase.DeclaringType;
				dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
				break;
			}
		}
		DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
		DynamicILInfo dynamicILInfo2 = dynamicILInfo;
		byte[] array3 = new byte[2];
		array3[0] = 7;
		dynamicILInfo2.SetLocalSignature(array3);
		byte[] array4 = new byte[2 * array2.Length + 6];
		int num5 = 0;
		for (int k = 0; k < array2.Length; k++)
		{
			array4[num5++] = 14;
			array4[num5++] = (byte)k;
		}
		array4[num5++] = ((byte)fieldFromHandle.Name[3] ^ byte_0);
		int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
		array4[num5++] = (byte)tokenFor;
		array4[num5++] = (byte)(tokenFor >> 8);
		array4[num5++] = (byte)(tokenFor >> 16);
		array4[num5++] = (byte)(tokenFor >> 24);
		array4[num5] = 42;
		dynamicILInfo.SetCode(array4, array2.Length + 1);
		fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
	}

	static void STATSTG(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = -1852808291;
		int num3 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[3] ^ (char)array[--num]) << 24) + (int)((int)(fieldFromHandle.Name[1] ^ (char)array[--num]) << 8) + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[--num]) << 16);
		num--;
		int num4 = num2 * (num3 + (int)((int)(fieldFromHandle.Name[4] ^ (char)array[num - 1]) << 0));
		num4 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num4);
		Type fieldType = fieldFromHandle.FieldType;
		if (methodBase.IsStatic)
		{
			fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
			return;
		}
		DynamicMethod dynamicMethod = null;
		Type[] array2 = null;
		foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
		{
			if (methodInfo.DeclaringType == fieldType)
			{
				ParameterInfo[] parameters = methodInfo.GetParameters();
				array2 = new Type[parameters.Length];
				for (int j = 0; j < array2.Length; j++)
				{
					array2[j] = parameters[j].ParameterType;
				}
				Type declaringType = methodBase.DeclaringType;
				dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
				IL_16D:
				DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
				DynamicILInfo dynamicILInfo2 = dynamicILInfo;
				byte[] array3 = new byte[2];
				array3[0] = 7;
				dynamicILInfo2.SetLocalSignature(array3);
				byte[] array4 = new byte[2 * array2.Length + 6];
				int num5 = 0;
				for (int k = 0; k < array2.Length; k++)
				{
					array4[num5++] = 14;
					array4[num5++] = (byte)k;
				}
				array4[num5++] = ((byte)fieldFromHandle.Name[0] ^ byte_0);
				int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
				array4[num5++] = (byte)tokenFor;
				array4[num5++] = (byte)(tokenFor >> 8);
				array4[num5++] = (byte)(tokenFor >> 16);
				array4[num5++] = (byte)(tokenFor >> 24);
				array4[num5] = 42;
				dynamicILInfo.SetCode(array4, array2.Length + 1);
				fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
				return;
			}
		}
		goto IL_16D;
	}

	static void smethod_2(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[--num]) << 0) + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[--num]) << 16) + (int)((int)(fieldFromHandle.Name[3] ^ (char)array[--num]) << 24);
		num--;
		int num3 = (num2 + (int)((int)(fieldFromHandle.Name[4] ^ (char)array[num - 1]) << 8)) * -1061376157;
		num3 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num3);
		Type fieldType = fieldFromHandle.FieldType;
		if (!methodBase.IsStatic)
		{
			DynamicMethod dynamicMethod = null;
			Type[] array2 = null;
			foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
			{
				if (methodInfo.DeclaringType == fieldType)
				{
					ParameterInfo[] parameters = methodInfo.GetParameters();
					array2 = new Type[parameters.Length];
					for (int j = 0; j < array2.Length; j++)
					{
						array2[j] = parameters[j].ParameterType;
					}
					Type declaringType = methodBase.DeclaringType;
					dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
					break;
				}
			}
			DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
			DynamicILInfo dynamicILInfo2 = dynamicILInfo;
			byte[] array3 = new byte[2];
			array3[0] = 7;
			dynamicILInfo2.SetLocalSignature(array3);
			byte[] array4 = new byte[2 * array2.Length + 6];
			int num4 = 0;
			for (int k = 0; k < array2.Length; k++)
			{
				array4[num4++] = 14;
				array4[num4++] = (byte)k;
			}
			array4[num4++] = ((byte)fieldFromHandle.Name[1] ^ byte_0);
			int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
			array4[num4++] = (byte)tokenFor;
			array4[num4++] = (byte)(tokenFor >> 8);
			array4[num4++] = (byte)(tokenFor >> 16);
			array4[num4++] = (byte)(tokenFor >> 24);
			array4[num4] = 42;
			dynamicILInfo.SetCode(array4, array2.Length + 1);
			fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
			return;
		}
		fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
	}

	static void MLangDecoder(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[--num]) << 16) + (int)((int)(fieldFromHandle.Name[4] ^ (char)array[--num]) << 8) + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[--num]) << 24);
		num--;
		int num3 = (num2 + (int)((int)(fieldFromHandle.Name[3] ^ (char)array[num - 1]) << 0)) * -2125228171;
		num3 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num3);
		Type fieldType = fieldFromHandle.FieldType;
		if (!methodBase.IsStatic)
		{
			DynamicMethod dynamicMethod = null;
			Type[] array2 = null;
			foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
			{
				if (methodInfo.DeclaringType == fieldType)
				{
					ParameterInfo[] parameters = methodInfo.GetParameters();
					array2 = new Type[parameters.Length];
					for (int j = 0; j < array2.Length; j++)
					{
						array2[j] = parameters[j].ParameterType;
					}
					Type declaringType = methodBase.DeclaringType;
					dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
					IL_158:
					DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
					DynamicILInfo dynamicILInfo2 = dynamicILInfo;
					byte[] array3 = new byte[2];
					array3[0] = 7;
					dynamicILInfo2.SetLocalSignature(array3);
					byte[] array4 = new byte[2 * array2.Length + 6];
					int num4 = 0;
					for (int k = 0; k < array2.Length; k++)
					{
						array4[num4++] = 14;
						array4[num4++] = (byte)k;
					}
					array4[num4++] = ((byte)fieldFromHandle.Name[1] ^ byte_0);
					int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
					array4[num4++] = (byte)tokenFor;
					array4[num4++] = (byte)(tokenFor >> 8);
					array4[num4++] = (byte)(tokenFor >> 16);
					array4[num4++] = (byte)(tokenFor >> 24);
					array4[num4] = 42;
					dynamicILInfo.SetCode(array4, array2.Length + 1);
					fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
					return;
				}
			}
			goto IL_158;
		}
		fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
	}

	static void SHA1CryptoServiceProviderIServerChannelSinkProvider(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[--num]) << 16) + (int)((int)(fieldFromHandle.Name[1] ^ (char)array[--num]) << 24) + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[--num]) << 0);
		num--;
		int num3 = (num2 + (int)((int)(fieldFromHandle.Name[4] ^ (char)array[num - 1]) << 8)) * 577857921;
		num3 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num3);
		Type fieldType = fieldFromHandle.FieldType;
		if (!methodBase.IsStatic)
		{
			DynamicMethod dynamicMethod = null;
			Type[] array2 = null;
			foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
			{
				if (methodInfo.DeclaringType == fieldType)
				{
					ParameterInfo[] parameters = methodInfo.GetParameters();
					array2 = new Type[parameters.Length];
					for (int j = 0; j < array2.Length; j++)
					{
						array2[j] = parameters[j].ParameterType;
					}
					Type declaringType = methodBase.DeclaringType;
					dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
					break;
				}
			}
			DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
			DynamicILInfo dynamicILInfo2 = dynamicILInfo;
			byte[] array3 = new byte[2];
			array3[0] = 7;
			dynamicILInfo2.SetLocalSignature(array3);
			byte[] array4 = new byte[2 * array2.Length + 6];
			int num4 = 0;
			for (int k = 0; k < array2.Length; k++)
			{
				array4[num4++] = 14;
				array4[num4++] = (byte)k;
			}
			array4[num4++] = ((byte)fieldFromHandle.Name[3] ^ byte_0);
			int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
			array4[num4++] = (byte)tokenFor;
			array4[num4++] = (byte)(tokenFor >> 8);
			array4[num4++] = (byte)(tokenFor >> 16);
			array4[num4++] = (byte)(tokenFor >> 24);
			array4[num4] = 42;
			dynamicILInfo.SetCode(array4, array2.Length + 1);
			fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
			return;
		}
		fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
	}

	static void QuickCacheEntryType(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = 1681136587;
		int num3 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[--num]) << 0) + (int)((int)(fieldFromHandle.Name[4] ^ (char)array[--num]) << 24) + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[--num]) << 8);
		num--;
		int num4 = num2 * (num3 + (int)((int)(fieldFromHandle.Name[3] ^ (char)array[num - 1]) << 16));
		num4 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num4);
		Type fieldType = fieldFromHandle.FieldType;
		if (methodBase.IsStatic)
		{
			fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
			return;
		}
		DynamicMethod dynamicMethod = null;
		Type[] array2 = null;
		foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
		{
			if (methodInfo.DeclaringType == fieldType)
			{
				ParameterInfo[] parameters = methodInfo.GetParameters();
				array2 = new Type[parameters.Length];
				for (int j = 0; j < array2.Length; j++)
				{
					array2[j] = parameters[j].ParameterType;
				}
				Type declaringType = methodBase.DeclaringType;
				dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
				IL_16D:
				DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
				DynamicILInfo dynamicILInfo2 = dynamicILInfo;
				byte[] array3 = new byte[2];
				array3[0] = 7;
				dynamicILInfo2.SetLocalSignature(array3);
				byte[] array4 = new byte[2 * array2.Length + 6];
				int num5 = 0;
				for (int k = 0; k < array2.Length; k++)
				{
					array4[num5++] = 14;
					array4[num5++] = (byte)k;
				}
				array4[num5++] = ((byte)fieldFromHandle.Name[1] ^ byte_0);
				int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
				array4[num5++] = (byte)tokenFor;
				array4[num5++] = (byte)(tokenFor >> 8);
				array4[num5++] = (byte)(tokenFor >> 16);
				array4[num5++] = (byte)(tokenFor >> 24);
				array4[num5] = 42;
				dynamicILInfo.SetCode(array4, array2.Length + 1);
				fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
				return;
			}
		}
		goto IL_16D;
	}

	static void MemoryStreamIStore(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = 675280535;
		int num3 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[--num]) << 24) + (int)((int)(fieldFromHandle.Name[1] ^ (char)array[--num]) << 8) + (int)((int)(fieldFromHandle.Name[3] ^ (char)array[--num]) << 16);
		num--;
		int num4 = num2 * (num3 + (int)((int)(fieldFromHandle.Name[4] ^ (char)array[num - 1]) << 0));
		num4 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num4);
		Type fieldType = fieldFromHandle.FieldType;
		if (methodBase.IsStatic)
		{
			fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
			return;
		}
		DynamicMethod dynamicMethod = null;
		Type[] array2 = null;
		foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
		{
			if (methodInfo.DeclaringType == fieldType)
			{
				ParameterInfo[] parameters = methodInfo.GetParameters();
				array2 = new Type[parameters.Length];
				for (int j = 0; j < array2.Length; j++)
				{
					array2[j] = parameters[j].ParameterType;
				}
				Type declaringType = methodBase.DeclaringType;
				dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
				break;
			}
		}
		DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
		DynamicILInfo dynamicILInfo2 = dynamicILInfo;
		byte[] array3 = new byte[2];
		array3[0] = 7;
		dynamicILInfo2.SetLocalSignature(array3);
		byte[] array4 = new byte[2 * array2.Length + 6];
		int num5 = 0;
		for (int k = 0; k < array2.Length; k++)
		{
			array4[num5++] = 14;
			array4[num5++] = (byte)k;
		}
		array4[num5++] = ((byte)fieldFromHandle.Name[0] ^ byte_0);
		int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
		array4[num5++] = (byte)tokenFor;
		array4[num5++] = (byte)(tokenFor >> 8);
		array4[num5++] = (byte)(tokenFor >> 16);
		array4[num5++] = (byte)(tokenFor >> 24);
		array4[num5] = 42;
		dynamicILInfo.SetCode(array4, array2.Length + 1);
		fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
	}

	static void IEnumString(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = -79186261;
		int num3 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[--num]) << 16) + (int)((int)(fieldFromHandle.Name[3] ^ (char)array[--num]) << 24) + (int)((int)(fieldFromHandle.Name[1] ^ (char)array[--num]) << 0);
		num--;
		int num4 = num2 * (num3 + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[num - 1]) << 8));
		num4 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num4);
		Type fieldType = fieldFromHandle.FieldType;
		if (methodBase.IsStatic)
		{
			fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
			return;
		}
		DynamicMethod dynamicMethod = null;
		Type[] array2 = null;
		foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
		{
			if (methodInfo.DeclaringType == fieldType)
			{
				ParameterInfo[] parameters = methodInfo.GetParameters();
				array2 = new Type[parameters.Length];
				for (int j = 0; j < array2.Length; j++)
				{
					array2[j] = parameters[j].ParameterType;
				}
				Type declaringType = methodBase.DeclaringType;
				dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
				IL_16B:
				DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
				DynamicILInfo dynamicILInfo2 = dynamicILInfo;
				byte[] array3 = new byte[2];
				array3[0] = 7;
				dynamicILInfo2.SetLocalSignature(array3);
				byte[] array4 = new byte[2 * array2.Length + 6];
				int num5 = 0;
				for (int k = 0; k < array2.Length; k++)
				{
					array4[num5++] = 14;
					array4[num5++] = (byte)k;
				}
				array4[num5++] = ((byte)fieldFromHandle.Name[4] ^ byte_0);
				int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
				array4[num5++] = (byte)tokenFor;
				array4[num5++] = (byte)(tokenFor >> 8);
				array4[num5++] = (byte)(tokenFor >> 16);
				array4[num5++] = (byte)(tokenFor >> 24);
				array4[num5] = 42;
				dynamicILInfo.SetCode(array4, array2.Length + 1);
				fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
				return;
			}
		}
		goto IL_16B;
	}

	static void EventInfoDefaultDependencyAttribute(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[--num]) << 24) + (int)((int)(fieldFromHandle.Name[3] ^ (char)array[--num]) << 16) + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[--num]) << 8);
		num--;
		int num3 = (num2 + (int)((int)(fieldFromHandle.Name[4] ^ (char)array[num - 1]) << 0)) * 1153325829;
		num3 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num3);
		Type fieldType = fieldFromHandle.FieldType;
		if (!methodBase.IsStatic)
		{
			DynamicMethod dynamicMethod = null;
			Type[] array2 = null;
			foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
			{
				if (methodInfo.DeclaringType == fieldType)
				{
					ParameterInfo[] parameters = methodInfo.GetParameters();
					array2 = new Type[parameters.Length];
					for (int j = 0; j < array2.Length; j++)
					{
						array2[j] = parameters[j].ParameterType;
					}
					Type declaringType = methodBase.DeclaringType;
					dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
					IL_15A:
					DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
					DynamicILInfo dynamicILInfo2 = dynamicILInfo;
					byte[] array3 = new byte[2];
					array3[0] = 7;
					dynamicILInfo2.SetLocalSignature(array3);
					byte[] array4 = new byte[2 * array2.Length + 6];
					int num4 = 0;
					for (int k = 0; k < array2.Length; k++)
					{
						array4[num4++] = 14;
						array4[num4++] = (byte)k;
					}
					array4[num4++] = ((byte)fieldFromHandle.Name[1] ^ byte_0);
					int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
					array4[num4++] = (byte)tokenFor;
					array4[num4++] = (byte)(tokenFor >> 8);
					array4[num4++] = (byte)(tokenFor >> 16);
					array4[num4++] = (byte)(tokenFor >> 24);
					array4[num4] = 42;
					dynamicILInfo.SetCode(array4, array2.Length + 1);
					fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
					return;
				}
			}
			goto IL_15A;
		}
		fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
	}

	static void SafeLsaPolicyHandle(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[--num]) << 24) + (int)((int)(fieldFromHandle.Name[3] ^ (char)array[--num]) << 16) + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[--num]) << 8);
		num--;
		int num3 = (num2 + (int)((int)(fieldFromHandle.Name[4] ^ (char)array[num - 1]) << 0)) * -818353771;
		num3 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num3);
		Type fieldType = fieldFromHandle.FieldType;
		if (!methodBase.IsStatic)
		{
			DynamicMethod dynamicMethod = null;
			Type[] array2 = null;
			foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
			{
				if (methodInfo.DeclaringType == fieldType)
				{
					ParameterInfo[] parameters = methodInfo.GetParameters();
					array2 = new Type[parameters.Length];
					for (int j = 0; j < array2.Length; j++)
					{
						array2[j] = parameters[j].ParameterType;
					}
					Type declaringType = methodBase.DeclaringType;
					dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
					IL_158:
					DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
					DynamicILInfo dynamicILInfo2 = dynamicILInfo;
					byte[] array3 = new byte[2];
					array3[0] = 7;
					dynamicILInfo2.SetLocalSignature(array3);
					byte[] array4 = new byte[2 * array2.Length + 6];
					int num4 = 0;
					for (int k = 0; k < array2.Length; k++)
					{
						array4[num4++] = 14;
						array4[num4++] = (byte)k;
					}
					array4[num4++] = ((byte)fieldFromHandle.Name[1] ^ byte_0);
					int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
					array4[num4++] = (byte)tokenFor;
					array4[num4++] = (byte)(tokenFor >> 8);
					array4[num4++] = (byte)(tokenFor >> 16);
					array4[num4++] = (byte)(tokenFor >> 24);
					array4[num4] = 42;
					dynamicILInfo.SetCode(array4, array2.Length + 1);
					fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
					return;
				}
			}
			goto IL_158;
		}
		fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
	}

	static void ParseError(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[3] ^ (char)array[--num]) << 16) + (int)((int)(fieldFromHandle.Name[1] ^ (char)array[--num]) << 8) + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[--num]) << 0);
		num--;
		int num3 = (num2 + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[num - 1]) << 24)) * 1400432503;
		num3 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num3);
		Type fieldType = fieldFromHandle.FieldType;
		if (!methodBase.IsStatic)
		{
			DynamicMethod dynamicMethod = null;
			Type[] array2 = null;
			foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
			{
				if (methodInfo.DeclaringType == fieldType)
				{
					ParameterInfo[] parameters = methodInfo.GetParameters();
					array2 = new Type[parameters.Length];
					for (int j = 0; j < array2.Length; j++)
					{
						array2[j] = parameters[j].ParameterType;
					}
					Type declaringType = methodBase.DeclaringType;
					dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
					IL_158:
					DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
					DynamicILInfo dynamicILInfo2 = dynamicILInfo;
					byte[] array3 = new byte[2];
					array3[0] = 7;
					dynamicILInfo2.SetLocalSignature(array3);
					byte[] array4 = new byte[2 * array2.Length + 6];
					int num4 = 0;
					for (int k = 0; k < array2.Length; k++)
					{
						array4[num4++] = 14;
						array4[num4++] = (byte)k;
					}
					array4[num4++] = ((byte)fieldFromHandle.Name[4] ^ byte_0);
					int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
					array4[num4++] = (byte)tokenFor;
					array4[num4++] = (byte)(tokenFor >> 8);
					array4[num4++] = (byte)(tokenFor >> 16);
					array4[num4++] = (byte)(tokenFor >> 24);
					array4[num4] = 42;
					dynamicILInfo.SetCode(array4, array2.Length + 1);
					fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
					return;
				}
			}
			goto IL_158;
		}
		fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
	}

	static void BitArray(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[--num]) << 16) + (int)((int)(fieldFromHandle.Name[4] ^ (char)array[--num]) << 8) + (int)((int)(fieldFromHandle.Name[3] ^ (char)array[--num]) << 24);
		num--;
		int num3 = (num2 + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[num - 1]) << 0)) * 12377787;
		num3 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num3);
		Type fieldType = fieldFromHandle.FieldType;
		if (!methodBase.IsStatic)
		{
			DynamicMethod dynamicMethod = null;
			Type[] array2 = null;
			foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
			{
				if (methodInfo.DeclaringType == fieldType)
				{
					ParameterInfo[] parameters = methodInfo.GetParameters();
					array2 = new Type[parameters.Length];
					for (int j = 0; j < array2.Length; j++)
					{
						array2[j] = parameters[j].ParameterType;
					}
					Type declaringType = methodBase.DeclaringType;
					dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
					break;
				}
			}
			DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
			DynamicILInfo dynamicILInfo2 = dynamicILInfo;
			byte[] array3 = new byte[2];
			array3[0] = 7;
			dynamicILInfo2.SetLocalSignature(array3);
			byte[] array4 = new byte[2 * array2.Length + 6];
			int num4 = 0;
			for (int k = 0; k < array2.Length; k++)
			{
				array4[num4++] = 14;
				array4[num4++] = (byte)k;
			}
			array4[num4++] = ((byte)fieldFromHandle.Name[1] ^ byte_0);
			int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
			array4[num4++] = (byte)tokenFor;
			array4[num4++] = (byte)(tokenFor >> 8);
			array4[num4++] = (byte)(tokenFor >> 16);
			array4[num4++] = (byte)(tokenFor >> 24);
			array4[num4] = 42;
			dynamicILInfo.SetCode(array4, array2.Length + 1);
			fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
			return;
		}
		fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
	}

	static void CspAlgorithmTypeSignatureToken(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = -1178328691;
		int num3 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[--num]) << 16) + (int)((int)(fieldFromHandle.Name[1] ^ (char)array[--num]) << 8) + (int)((int)(fieldFromHandle.Name[4] ^ (char)array[--num]) << 24);
		num--;
		int num4 = num2 * (num3 + (int)((int)(fieldFromHandle.Name[3] ^ (char)array[num - 1]) << 0));
		num4 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num4);
		Type fieldType = fieldFromHandle.FieldType;
		if (methodBase.IsStatic)
		{
			fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
			return;
		}
		DynamicMethod dynamicMethod = null;
		Type[] array2 = null;
		foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
		{
			if (methodInfo.DeclaringType == fieldType)
			{
				ParameterInfo[] parameters = methodInfo.GetParameters();
				array2 = new Type[parameters.Length];
				for (int j = 0; j < array2.Length; j++)
				{
					array2[j] = parameters[j].ParameterType;
				}
				Type declaringType = methodBase.DeclaringType;
				dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
				IL_16D:
				DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
				DynamicILInfo dynamicILInfo2 = dynamicILInfo;
				byte[] array3 = new byte[2];
				array3[0] = 7;
				dynamicILInfo2.SetLocalSignature(array3);
				byte[] array4 = new byte[2 * array2.Length + 6];
				int num5 = 0;
				for (int k = 0; k < array2.Length; k++)
				{
					array4[num5++] = 14;
					array4[num5++] = (byte)k;
				}
				array4[num5++] = ((byte)fieldFromHandle.Name[2] ^ byte_0);
				int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
				array4[num5++] = (byte)tokenFor;
				array4[num5++] = (byte)(tokenFor >> 8);
				array4[num5++] = (byte)(tokenFor >> 16);
				array4[num5++] = (byte)(tokenFor >> 24);
				array4[num5] = 42;
				dynamicILInfo.SetCode(array4, array2.Length + 1);
				fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
				return;
			}
		}
		goto IL_16D;
	}

	static void CategoryMembershipDataEntryFieldIdStoreAssemblyEnumeration(RuntimeFieldHandle runtimeFieldHandle_0, byte byte_0)
	{
		FieldInfo fieldFromHandle = FieldInfo.GetFieldFromHandle(runtimeFieldHandle_0);
		byte[] array = fieldFromHandle.Module.ResolveSignature(fieldFromHandle.MetadataToken);
		int num = array.Length;
		int num2 = -736381425;
		int num3 = fieldFromHandle.GetOptionalCustomModifiers()[0].MetadataToken + (int)((int)(fieldFromHandle.Name[4] ^ (char)array[--num]) << 0) + (int)((int)(fieldFromHandle.Name[1] ^ (char)array[--num]) << 16) + (int)((int)(fieldFromHandle.Name[0] ^ (char)array[--num]) << 8);
		num--;
		int num4 = num2 * (num3 + (int)((int)(fieldFromHandle.Name[2] ^ (char)array[num - 1]) << 24));
		num4 *= fieldFromHandle.GetCustomAttributes(false)[0].GetHashCode();
		MethodBase methodBase = fieldFromHandle.Module.ResolveMethod(num4);
		Type fieldType = fieldFromHandle.FieldType;
		if (!methodBase.IsStatic)
		{
			DynamicMethod dynamicMethod = null;
			Type[] array2 = null;
			foreach (MethodInfo methodInfo in fieldFromHandle.FieldType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic))
			{
				if (methodInfo.DeclaringType == fieldType)
				{
					ParameterInfo[] parameters = methodInfo.GetParameters();
					array2 = new Type[parameters.Length];
					for (int j = 0; j < array2.Length; j++)
					{
						array2[j] = parameters[j].ParameterType;
					}
					Type declaringType = methodBase.DeclaringType;
					dynamicMethod = new DynamicMethod("", methodInfo.ReturnType, array2, fieldType, true);
					IL_15A:
					DynamicILInfo dynamicILInfo = dynamicMethod.GetDynamicILInfo();
					DynamicILInfo dynamicILInfo2 = dynamicILInfo;
					byte[] array3 = new byte[2];
					array3[0] = 7;
					dynamicILInfo2.SetLocalSignature(array3);
					byte[] array4 = new byte[2 * array2.Length + 6];
					int num5 = 0;
					for (int k = 0; k < array2.Length; k++)
					{
						array4[num5++] = 14;
						array4[num5++] = (byte)k;
					}
					array4[num5++] = ((byte)fieldFromHandle.Name[3] ^ byte_0);
					int tokenFor = dynamicILInfo.GetTokenFor(methodBase.MethodHandle);
					array4[num5++] = (byte)tokenFor;
					array4[num5++] = (byte)(tokenFor >> 8);
					array4[num5++] = (byte)(tokenFor >> 16);
					array4[num5++] = (byte)(tokenFor >> 24);
					array4[num5] = 42;
					dynamicILInfo.SetCode(array4, array2.Length + 1);
					fieldFromHandle.SetValue(null, dynamicMethod.CreateDelegate(fieldType));
					return;
				}
			}
			goto IL_15A;
		}
		fieldFromHandle.SetValue(null, Delegate.CreateDelegate(fieldType, (MethodInfo)methodBase));
	}

	internal static void smethod_3()
	{
		uint[] array = new uint[]
		{
			4007356196u,
			3278656527u,
			3949955357u,
			1463668609u,
			3542984667u,
			185944738u,
			2502347805u,
			1093608800u,
			2876715712u,
			1268437285u,
			112426822u,
			1934159732u,
			813061195u,
			1997504646u,
			2647583932u,
			2684470422u,
			3968121440u,
			2416546767u,
			3403142730u,
			2876813213u,
			1203299131u,
			2606892626u,
			746013570u,
			3491736869u,
			1348632356u,
			3315486091u,
			31849818u,
			2689886182u,
			3841746749u,
			3423612165u,
			2515355205u,
			1590968296u,
			1217501281u,
			3146521926u,
			850678153u,
			2501587986u,
			1456386039u,
			3425074137u,
			157840403u,
			1774715905u,
			2256795346u,
			454435171u,
			2392593064u,
			2014122184u,
			2319813521u,
			630062373u,
			420044640u,
			1477736280u,
			1260897042u,
			1077329479u,
			2083212151u,
			3616658182u,
			3117577131u,
			3823114975u,
			2784683632u,
			3700749212u,
			3985134307u,
			3114083408u,
			1545174015u,
			4059141283u,
			2553982069u,
			744069474u,
			1680985733u,
			4041039974u,
			3771694844u,
			1327727292u,
			54094422u,
			1654197297u,
			2427828699u,
			3757381246u,
			3121337813u,
			4162447776u,
			40334341u,
			542285301u,
			3727884623u,
			2289264934u,
			3493115996u,
			2407694353u,
			1598071392u,
			221734114u,
			1998420210u,
			2499647336u,
			566593332u,
			3552470486u,
			3482186489u,
			1064013082u,
			2412910408u,
			3615974503u,
			810390512u,
			3676926602u,
			2538404083u,
			3476644896u,
			3821369560u,
			2967123542u,
			2475145201u,
			908499976u,
			986494447u,
			1930527324u,
			2534676159u,
			1850516221u,
			2966328760u,
			1004555586u,
			1142244513u,
			1187191766u,
			2261928360u,
			1249989715u,
			673966614u,
			2747647633u,
			1728151939u,
			2542440185u,
			3490920849u,
			546008198u,
			2829115607u,
			3757959816u,
			3524542398u,
			1530642323u,
			2576707343u,
			1358538369u,
			3019830734u,
			330921943u,
			4128059541u,
			1032327885u,
			2852138520u,
			2368966438u,
			758747254u,
			4098389638u,
			3903800287u,
			1768446989u,
			1544053831u,
			983722411u,
			2861525033u,
			3861704195u,
			403814946u,
			1044324764u,
			2639550016u,
			3858997250u,
			2166990412u,
			554035899u,
			4163629842u,
			3816220540u,
			1525410950u,
			1951165024u,
			3684179154u,
			3081760598u,
			390047359u,
			1609628299u,
			994984071u,
			3961961153u,
			2139823055u,
			756783025u,
			1822795578u,
			1359748140u,
			3995208132u,
			1371312351u,
			68368922u,
			2146298158u,
			2695418186u,
			1517213325u,
			4150643333u,
			1703336201u,
			3214154814u,
			2275373447u,
			1282182308u,
			1786570069u,
			3132998326u,
			671210488u,
			2674962249u,
			484393532u,
			3354524949u,
			1322410756u,
			349201810u,
			55198373u,
			2953500192u,
			1124381390u,
			4269223392u,
			3198665083u,
			4024649207u,
			1507036938u,
			669783143u,
			3048605660u,
			491550823u,
			227988362u,
			3264820026u,
			236172990u,
			3785954008u,
			4280199137u,
			4246769763u,
			2975233935u,
			469972073u,
			3481767168u,
			529150267u,
			975532978u,
			2999592236u,
			641208156u,
			2674653703u,
			2897094177u,
			2779044272u,
			2768775895u,
			2435224260u,
			2038670743u,
			2104207135u,
			2903061292u,
			2429991035u,
			131653408u,
			3628918898u,
			2521241624u,
			1122517289u,
			3511827084u,
			3628991173u,
			1808012554u,
			2486377077u,
			1499175834u,
			3698708955u,
			3025308973u,
			2534710379u,
			1934152330u,
			2496360562u,
			4182426248u,
			3134004616u,
			2563310120u,
			441037733u,
			2396227926u,
			3838492599u,
			263065557u,
			3149588949u,
			3588094093u,
			1686443762u,
			2323991929u,
			2665883298u,
			2417600465u,
			4165381876u,
			3470864435u,
			4139138440u,
			1846850257u,
			4207233019u,
			1443902828u,
			2377674952u,
			2580245468u,
			1915743796u,
			703320420u,
			4156270162u,
			104678005u,
			3540898398u,
			2306144418u,
			1593100797u,
			2185383796u,
			963979838u,
			2870771120u,
			2677636224u,
			2030832850u,
			604366291u,
			871799289u,
			3236240407u,
			2330431818u,
			2530418605u,
			1506033744u,
			1067321412u,
			3854435760u,
			3304580443u,
			3211489048u,
			3791235753u,
			1415471648u,
			716338185u,
			3840283570u,
			4250113579u,
			2729367687u,
			3748237827u,
			1688858465u,
			2132878374u,
			636421429u,
			2797711973u,
			1276842502u,
			1593420851u,
			1363570345u,
			1189497439u,
			1915253114u,
			2959256884u,
			2752004946u,
			2990251317u,
			3737101688u,
			2316223748u,
			3297435779u,
			352712648u,
			3947767388u,
			3231074886u,
			1470750230u,
			3541023202u,
			2518741791u,
			2946080367u,
			306027856u,
			2477504058u,
			2576784221u,
			2805716242u,
			1672266243u,
			2303658549u,
			2715083080u,
			2995005176u,
			2983538894u,
			2748227617u,
			3933279643u,
			3223996409u,
			3977606089u,
			1910376587u,
			4145115614u,
			4276752574u,
			2776600181u,
			3647753532u,
			1772517045u,
			2721381884u,
			196777676u,
			4247792302u,
			2098075485u,
			3808722108u,
			2458216019u,
			3438688720u,
			2517766498u,
			2914068645u,
			1526012286u,
			3328334443u,
			521312163u,
			3513425051u,
			1877707725u,
			60382732u,
			4282942096u,
			2875263893u,
			3816418574u,
			2790719401u,
			2864013923u,
			3562113504u,
			4217007667u,
			1866986412u,
			1610801299u,
			4251733268u,
			3160635116u,
			1455633938u,
			2355766270u,
			986462340u,
			3647696115u,
			2469107414u,
			495974598u,
			1980980358u,
			1749250319u,
			4247895441u,
			1876320920u,
			1435287053u,
			1230246877u,
			809372221u,
			733332656u,
			2267548427u,
			3629330657u,
			2287221712u,
			1832746169u,
			3621871609u,
			821773580u,
			3047379401u,
			2129098655u,
			1473784268u,
			422106696u,
			290028921u,
			2978106474u,
			1969982458u,
			297681857u,
			1195606970u,
			3411996199u,
			4175802400u,
			2770697701u,
			2731945543u,
			934077943u,
			381984690u,
			86383979u,
			2484540637u,
			2073999943u,
			1043748103u,
			967680134u,
			2246296953u,
			158592660u,
			2732859424u,
			3979935000u,
			1739244276u,
			2456536161u,
			751307718u,
			631485535u,
			1506158255u,
			3790107922u,
			1592191948u,
			2670061699u,
			1146311559u,
			1721728944u,
			3871582578u,
			1443569504u,
			1174610859u,
			218305209u,
			2083676792u,
			58101206u,
			2228360336u,
			916617241u,
			1202154832u,
			2953405586u,
			2985873382u,
			366839717u,
			1841754693u,
			3640723318u,
			4159789797u,
			1768256665u,
			1054018037u,
			3518484025u,
			2788790495u,
			3693004146u,
			823333319u,
			3725430921u,
			3550904759u,
			2225406818u,
			2044108853u,
			634604797u,
			3926561531u,
			1346607527u,
			1986734707u,
			1363475375u,
			2915978772u,
			1419326579u,
			3910180297u,
			4218873380u,
			3057203890u,
			1191639712u,
			685617660u,
			4045327598u,
			1774600222u,
			2459330367u,
			691417686u,
			2297814105u,
			3529152334u,
			3403762706u,
			1863069869u,
			1280210592u,
			1331430490u,
			2036497627u,
			2529798700u,
			2765042601u,
			3503612566u,
			1921504894u,
			1774772179u,
			904309316u,
			2630662537u,
			2695877044u,
			1910509852u,
			1752098524u,
			2118218725u,
			3315557818u,
			4190258457u,
			1277092813u,
			2338490181u,
			3620785062u,
			3276757549u,
			220648049u,
			3778763534u,
			4079735192u,
			657747309u,
			1134039379u,
			236015583u,
			4238968220u,
			1689127809u,
			1459585325u,
			1552597787u,
			411713305u,
			3031168760u,
			4281581182u,
			2291175444u,
			2735531991u,
			859529986u,
			2110633776u,
			1896729206u,
			2340906330u,
			3300374457u,
			2288250546u,
			2693046896u,
			2155304069u,
			3268123768u,
			354413724u,
			2320751918u,
			1337795612u,
			3094703116u,
			1160225846u,
			2398697236u,
			4239759221u,
			3648356529u,
			3183090598u,
			1613821452u,
			1254728726u,
			335303354u,
			4111794468u,
			426740711u,
			2535583050u,
			3211674289u,
			783746705u,
			195678932u,
			3485314651u,
			463958636u,
			2730615512u,
			398863522u,
			660038912u,
			3321213951u,
			2978748011u,
			1485506047u,
			3216633472u,
			3958924985u,
			429139619u,
			3011422450u,
			838312614u,
			4011846533u,
			2279782982u,
			2809883694u,
			3572328336u,
			1197882178u,
			4090886834u,
			313328017u,
			2802127333u,
			1626925989u,
			3458477149u,
			957544053u,
			4137763373u,
			3813608905u,
			3381571484u,
			2064213408u,
			1447198993u,
			100688127u,
			2972393727u,
			1896603348u,
			1806190549u,
			1314572707u,
			3086289931u,
			1093113512u,
			1690480318u,
			3689292709u,
			2863671130u,
			696312452u,
			2039916594u,
			3216217999u,
			1567901028u,
			600094274u,
			3979488343u,
			3907955830u,
			1516511167u,
			2742572174u,
			105080012u,
			2078234211u,
			3130090527u,
			4102735512u,
			50472530u,
			1457409551u,
			1563999752u,
			2153309400u,
			2336696663u,
			1397883020u,
			2646082048u,
			3453805866u,
			1182702022u,
			3763721063u,
			1447850990u,
			4238753460u,
			56775375u,
			4080841812u,
			2407436732u,
			389341407u,
			3824124926u,
			1172408769u,
			764769102u,
			1722332755u,
			536935074u,
			1621295467u,
			4051370044u,
			310545179u,
			3059067847u,
			456079798u,
			3050360777u,
			2618760073u,
			3060575818u,
			4112856803u,
			2553802778u,
			240163649u,
			981578549u,
			2690221450u,
			2943072161u,
			394414016u,
			2877744489u,
			3508917190u,
			2703345077u,
			937729164u,
			2719320076u,
			3951222843u,
			1321950968u,
			2562744733u,
			421758450u,
			90400194u,
			1661614198u,
			1413231945u,
			281521752u,
			1749937024u,
			705576423u,
			3249622124u,
			3203849117u,
			1992630999u,
			1247960571u,
			1110188664u,
			2824695662u,
			762478470u,
			2169649306u,
			3582499115u,
			612108174u,
			3558820205u,
			3507517355u,
			2686411601u,
			3175171159u,
			608364062u,
			3136604712u,
			692463429u,
			1007749486u,
			4029278396u,
			3979470799u,
			2367665892u,
			4144166049u,
			746928791u,
			3479427807u,
			1478858581u,
			1988183796u,
			1793386194u,
			2806760629u,
			1042433585u,
			2634402512u,
			3375822875u,
			1968866586u,
			541007768u,
			317657411u,
			1338140075u,
			3440940045u,
			763016597u,
			2961208531u,
			4062194146u,
			1513651624u,
			2452509289u,
			2489277343u,
			2809871999u,
			3855524549u,
			2459424705u,
			822926932u,
			3194761764u,
			1986152074u,
			1020628210u,
			1824544579u,
			3663926378u,
			65090432u,
			2885871509u,
			2999515891u,
			2940877132u,
			921453315u,
			61025057u,
			2957777886u,
			3988302397u,
			2708897212u,
			2698472187u,
			3176213527u,
			625338682u,
			2540272072u,
			3384307849u,
			3161437630u,
			3872234875u,
			3172518464u,
			2427610684u,
			3955053658u,
			2630426350u,
			2186862959u,
			500451919u,
			3787248290u,
			3814772466u,
			1957661814u,
			4256916140u,
			920362617u,
			618973465u,
			3375503397u,
			2787422409u,
			4019868432u,
			3434338891u,
			4219771015u,
			3341044273u,
			4050004880u,
			741084542u,
			2366310629u,
			3021928391u,
			1425768838u,
			1532682399u,
			3056469917u,
			922984073u,
			2089164323u,
			4015718202u,
			3382746137u,
			3319197009u,
			681684873u,
			1790033218u,
			3741055392u,
			252678991u,
			3800470226u,
			3049185941u,
			1789893853u,
			3956508784u,
			4283856418u,
			3299677838u,
			1195390498u,
			1771265486u,
			1354212660u,
			731859460u,
			2783204787u,
			3022170165u,
			2387492167u,
			231649706u,
			2207810823u,
			1204806144u,
			3533474526u,
			2914019896u,
			2753165543u,
			1622157154u,
			3422388322u,
			239086399u,
			1043991853u,
			1088398586u,
			3221560720u,
			3081953821u,
			3606985013u,
			3084756438u,
			3230622890u,
			717154762u,
			2344707910u,
			225095042u,
			1978245916u,
			838748644u,
			1981896855u,
			1564921263u,
			1333199043u,
			3985160505u,
			1814472308u,
			1106344092u,
			2638703825u,
			1723222288u,
			1172344217u,
			917304753u,
			274451826u,
			2536009372u,
			20645663u,
			2033986368u,
			2966269247u,
			3539626855u,
			1788054462u,
			3023282475u,
			2102716718u,
			1957654684u,
			1722373174u,
			4205041926u,
			2114677540u,
			3680210581u,
			2029265545u,
			2845139752u,
			1905300487u,
			88041419u,
			2506009468u,
			2939371249u,
			109110651u,
			2197457822u,
			3992886681u,
			329433166u,
			3005807635u,
			1940875212u,
			722687706u,
			2096628690u,
			2855581982u,
			3578376451u,
			583609717u,
			3675137315u,
			2239167876u,
			670733543u,
			2780749962u,
			2490027813u,
			2442860016u,
			1371821460u,
			1720911850u,
			438566842u,
			1757543565u,
			2548602780u,
			301318532u,
			2435020506u,
			2465120865u,
			1833837394u,
			3412166683u,
			592381954u,
			490841894u,
			331952226u,
			534310882u,
			2030295607u,
			1468589159u,
			1845149974u,
			1632431432u,
			2062502112u,
			804355806u,
			2066684885u,
			880023902u,
			4168953958u,
			3432570475u,
			3224906007u,
			276907635u,
			3618395366u,
			487678627u,
			280608466u,
			1431568297u,
			1763934317u,
			4216411393u,
			1492148219u,
			1505108424u,
			3128954922u,
			2781866915u,
			1074574949u,
			2436819878u,
			2866572695u,
			3335860918u,
			3476855743u,
			822771254u,
			521580331u,
			873883765u,
			529198363u,
			784337711u,
			1556128545u,
			996548032u,
			3180734139u,
			2240806591u,
			317846971u,
			1561358108u,
			41471329u,
			1923585118u,
			2829086900u,
			4033093938u,
			2029687535u,
			3141862576u,
			1826488614u,
			2831431642u,
			2190242279u,
			1225879476u,
			3819907206u,
			2379749824u,
			3005388001u,
			3154482438u,
			1671708196u,
			2611391810u,
			4094129430u,
			158139369u,
			2016994580u,
			2370866951u,
			2543026431u,
			893795423u,
			3156173222u,
			3068092508u,
			4209186271u,
			3253401789u,
			200038918u,
			345783770u,
			3138032603u,
			2862108104u,
			2434423982u,
			4209592645u,
			2975333712u,
			3349274480u,
			2670629822u,
			1646247859u,
			1362798135u,
			3686615849u,
			761953283u,
			1270137018u,
			3338670411u,
			1926687318u,
			4264717382u,
			2917383767u,
			3227866840u,
			2637170108u,
			432741390u,
			1436235634u,
			1631416995u,
			3059598248u,
			2080726471u,
			286949683u,
			1192058660u,
			3139151197u,
			466390795u,
			3015381846u,
			2704462531u,
			891671689u,
			2604283006u,
			4095897689u,
			274933373u,
			2502344041u,
			1802564882u,
			884681527u,
			1964842353u,
			2098339261u,
			3843876148u,
			1136562324u,
			901964925u,
			2652371620u,
			2829581803u,
			3174661402u,
			885560913u,
			2904626920u,
			397255208u,
			2106696388u,
			1871774472u,
			2333505662u,
			1679475635u,
			2664950322u,
			811219188u,
			3431244899u,
			3127420465u,
			1562126289u,
			2273718302u,
			3439084213u,
			2745850247u,
			1901657568u,
			1025262415u,
			895995650u,
			3779476359u,
			1868690381u,
			760145832u,
			440233664u,
			887635644u,
			3526006754u,
			2156932670u,
			347835673u,
			1248862463u,
			2669265632u,
			1332871252u,
			3666976278u,
			2224808808u,
			1718301023u,
			1431622933u,
			3839714496u,
			2043936395u,
			3182494558u,
			1909459750u,
			2890928156u,
			720102416u,
			249142753u,
			346550218u,
			3369938338u,
			572797052u,
			1578688196u,
			3872202365u,
			3869039103u,
			2670735734u,
			856497798u,
			2757884748u,
			220188471u,
			1659467230u,
			2145849095u,
			1077655250u,
			3898138076u,
			3845467556u,
			1071931434u,
			316835877u,
			1170613593u,
			2116142233u,
			1500675881u,
			3402461896u,
			2961289527u,
			2117414873u,
			3781646582u,
			3131560885u,
			368601733u,
			3154962940u,
			2482294491u,
			3791850226u,
			1293402519u,
			2459367870u,
			1473608065u,
			1210835794u,
			1591198318u,
			2564469758u,
			673688949u,
			2753486776u,
			1207033051u,
			2285373546u,
			3861588186u,
			2935345380u,
			972761237u,
			4032248161u,
			1003827513u,
			1774341077u,
			1017419112u,
			2317676660u,
			3701833532u,
			2974666872u,
			873051947u,
			1118077010u,
			4173626021u,
			3904092491u,
			3623886858u,
			814143871u,
			1453307641u,
			3772885830u,
			3322905771u,
			3123281348u,
			1227541722u,
			3706371538u,
			3377414258u,
			1914430720u,
			1882779351u,
			1634370481u,
			2553113441u,
			464538621u,
			2925449324u,
			609003219u,
			4151152954u,
			152377954u,
			632908438u,
			3359301840u,
			3482697891u,
			627493826u,
			49332570u,
			1352803323u,
			2526387529u,
			2062151408u,
			2773433884u,
			2387570395u,
			4257690901u,
			2798326494u,
			1387182463u,
			1537038499u,
			1366859445u,
			2133875038u,
			2592752312u,
			2546098547u,
			9383174u,
			81670257u,
			213662592u,
			4176280144u,
			898888886u,
			2385567592u,
			1071242882u,
			2542448516u,
			2289144085u,
			3045072237u,
			2883879541u,
			424036731u,
			1601465070u,
			2621673975u,
			2038433097u,
			422511526u,
			2428508915u,
			164291536u,
			485794513u,
			2705165116u,
			2598837372u,
			770083870u,
			1966103027u,
			3544892189u,
			99717763u,
			303466828u,
			3365301997u,
			1031331003u,
			574109654u,
			2127687996u,
			1785499966u,
			3686652720u,
			4054087532u,
			748369305u,
			2820725864u,
			877637226u,
			282794942u,
			3467422457u,
			2809515272u,
			301631441u,
			1498010355u,
			3929209011u,
			18113550u,
			810927315u,
			2217930308u,
			1608936219u,
			1798018261u,
			2899378257u,
			2181464968u,
			3750968888u,
			2090993374u,
			2038341551u,
			2128312544u,
			3954480030u,
			1166041919u,
			1553346970u,
			272850676u,
			2284808877u,
			3622160600u,
			2174644983u,
			2546230842u,
			4147161586u,
			1927765555u,
			3980174093u,
			3033346811u,
			133479292u,
			1622603125u,
			978882641u,
			1555152569u,
			2051293253u,
			3687506197u,
			3430611148u,
			1520105340u,
			2457125931u,
			3193950739u,
			3819963623u,
			3630126863u,
			258832575u,
			1318659510u,
			927288911u,
			1143799072u,
			3088413529u,
			3426316201u,
			732704404u,
			3076494670u,
			1433477601u,
			697742225u,
			4230556347u,
			984919943u,
			1903869648u,
			1871065753u,
			1789964387u,
			2758369498u,
			104070968u,
			2220777881u,
			3737870377u,
			154801703u,
			652208613u,
			228668564u,
			3337352299u,
			3438958644u,
			407581807u,
			4171292021u,
			824218554u,
			3318959756u,
			2286621337u,
			731797208u,
			3405978920u,
			877833161u,
			18996510u,
			1770803006u,
			853114924u,
			787399966u,
			3471183249u,
			2358689281u,
			2687526057u,
			3680205346u,
			362635928u,
			764967462u,
			2863260992u,
			1640416997u,
			1216845936u,
			1392895174u,
			2408687169u,
			1450519673u,
			2618059563u,
			3162266967u,
			3738086381u,
			4166505697u,
			3600664441u,
			3971003947u,
			3352294660u,
			1593221973u,
			1743791193u,
			2167430859u,
			3467291576u,
			860639985u,
			3730323345u,
			2963168863u,
			3376935392u,
			3354316778u,
			2315358012u,
			2780401881u,
			3996699993u,
			868392979u,
			110331509u,
			476783982u,
			2924840628u,
			3897489185u,
			47647058u,
			3629894064u,
			826242788u,
			709639379u,
			1868998424u,
			1132580006u,
			1728673559u,
			3749523767u,
			1368862156u,
			1487999089u,
			285958241u,
			1752385801u,
			614495572u,
			1995755734u,
			3422238268u,
			312947820u,
			1547079592u,
			2543077109u,
			474864106u,
			2205454780u,
			3033160202u,
			579103329u,
			2855940057u,
			2228828590u,
			410169544u,
			709469354u,
			3462430445u,
			3877935194u,
			763459600u,
			1111431222u,
			285435565u,
			3578721207u,
			1910875967u,
			3363605342u,
			3717953071u,
			1766906638u,
			3477831704u,
			1174831732u,
			3636545720u,
			639054025u,
			1951474959u,
			3602327706u,
			1269113216u,
			965381517u,
			283668168u,
			1075053424u,
			592368630u,
			2265257124u,
			1344429311u,
			2564427824u,
			2980868878u,
			2539355669u,
			1895620063u,
			3265121534u,
			3479044069u,
			3012390885u,
			340866600u,
			2704585481u,
			3630625185u,
			214073707u,
			31888551u,
			1786505207u,
			4115223630u,
			3897179153u,
			3767706629u,
			74044704u,
			2344596829u,
			1142291829u,
			797640403u,
			1121907860u,
			4227559694u,
			3976609241u,
			3164308433u,
			2817663831u,
			3641113448u,
			2700913006u,
			3884279097u,
			3047209267u,
			4059440336u,
			3230988827u,
			2578403225u,
			95327354u,
			3538131324u,
			545619851u,
			2959334025u,
			1658702177u,
			1106220877u,
			3848709378u,
			4122013474u,
			2235129010u,
			3210519760u,
			1124300910u,
			2286288526u,
			3266613385u,
			26638186u,
			3091642879u,
			1579480178u,
			2706110909u,
			2591559544u,
			3793850192u,
			671558039u,
			1930212264u,
			2192630395u,
			3309754164u,
			3267200409u,
			1340289798u,
			1588927694u,
			18561894u,
			1645095827u,
			2788902085u,
			198176215u,
			310070936u,
			3520281541u,
			1411489231u,
			3302879282u,
			3272040897u,
			548066567u,
			748190746u,
			4254515207u,
			126808005u,
			2355901055u,
			2432349894u,
			4041848607u,
			2251720166u,
			2063342044u,
			3609226939u,
			2573151191u,
			4294334717u,
			2586454844u,
			1517870831u,
			1464049444u,
			3248558644u,
			2926764927u,
			3299654823u,
			3826187879u,
			3030595444u,
			1250264013u,
			1540241883u,
			785795368u,
			1554206207u,
			955615434u,
			2526674379u,
			440415265u,
			4254007162u,
			870135274u,
			3476946167u,
			495128797u,
			3527130423u,
			2935311274u,
			787229017u,
			2728539504u,
			32122199u,
			3858135351u,
			2717587438u,
			3492455886u,
			1224177752u,
			3374149223u,
			2982047729u,
			1468595468u,
			2461710755u,
			31884765u,
			2842132224u,
			2604492893u,
			2755245066u,
			3284330580u,
			4278409123u,
			1420570718u,
			932969541u,
			4020639837u,
			3328272875u,
			2549146730u,
			3686764959u,
			4010619533u,
			2054841240u,
			3481851660u,
			3268557473u,
			3101792710u,
			3283404010u,
			348940604u,
			2333821582u,
			80906937u,
			2556329802u,
			2556786384u,
			2573140146u,
			3620028829u,
			990350565u,
			2030601278u,
			3850600309u,
			4125392669u,
			1838829569u,
			3293892396u,
			712647392u,
			2974339859u,
			176954673u,
			233144344u,
			3252281734u,
			1816918969u,
			2934270563u,
			1665144899u,
			1574100493u,
			3386196790u,
			3396238217u,
			234372703u,
			2162618658u,
			3604517426u,
			2052519937u,
			3355367135u,
			4133608474u,
			2779748627u,
			2287154u,
			820967179u,
			1207781640u,
			957401473u,
			1737558259u,
			3328863556u,
			3772022328u,
			3000130287u,
			4022690305u,
			2975313169u,
			4227189773u,
			2727210019u,
			2146407141u,
			3511588581u,
			1450139051u,
			1128942839u,
			2734350852u,
			4086895648u,
			37557957u,
			3043524335u,
			577261786u,
			1162897923u,
			491989529u,
			3676312413u,
			1804042067u,
			97781001u,
			427143106u,
			3808187472u,
			633828062u,
			2079102552u,
			3062129671u,
			3571899510u,
			485030178u,
			4145567206u,
			2308350118u,
			3438120489u,
			265673348u,
			714865097u,
			963048187u,
			874230953u,
			1070080435u,
			2008931050u,
			360547444u,
			501925507u,
			2560695277u,
			2692121458u,
			1126511974u,
			3494729703u,
			1558151357u,
			1622119590u,
			3530873859u,
			1497682608u,
			3604804267u,
			3162977609u,
			1407135181u,
			2597401629u,
			1478575560u,
			3869334984u,
			1784672059u,
			2855301320u,
			1214798595u,
			573942125u,
			1971589300u,
			2477887848u,
			4279347668u,
			659431043u,
			1190690531u,
			2226219296u,
			2871328587u,
			2043061604u,
			2533674975u,
			2141003508u,
			578504692u,
			3166826678u,
			4216190913u,
			1062739246u,
			3204659122u,
			575718604u,
			3773215647u,
			1102545329u,
			1879146581u,
			388340696u,
			2422415759u,
			307578272u,
			2066294023u,
			3221285196u,
			2066314134u,
			3577543519u,
			54751975u,
			3118778070u,
			3452044390u,
			2175812692u,
			601034150u,
			470656548u,
			2698235236u,
			4206628752u,
			3114371535u,
			3730474546u,
			88324846u,
			1258712126u,
			3769998121u,
			2603525532u,
			1203256822u,
			3472331337u,
			4211281936u,
			2774587761u,
			745184975u,
			3434366386u,
			2191026639u,
			2910320090u,
			3760024392u,
			20220686u,
			4060733651u,
			1704280937u,
			3017016578u,
			2254925308u,
			4278586535u,
			4230579046u,
			987114697u,
			1365269345u,
			2161875359u,
			2759982518u,
			1788773625u,
			2297448479u,
			2902665705u,
			3566494775u,
			1428572159u,
			2174762575u,
			3765822138u,
			899841020u,
			1391185677u,
			2315267210u,
			1986546510u,
			4023944439u,
			3237737876u,
			3401138767u,
			63081333u,
			4044718356u,
			3070253183u,
			1434441081u,
			819343271u,
			502625727u,
			3801242282u,
			1982892976u,
			1787943775u,
			1576703437u,
			2656456286u,
			3692680388u,
			404284730u,
			3551831286u,
			3520664054u,
			1429422166u,
			1386610570u,
			2797514585u,
			3433301715u,
			2612379415u,
			904853499u,
			540306052u,
			910666449u,
			2769486174u,
			3930932711u,
			31335204u,
			94350167u,
			3317729664u,
			2134314900u,
			3398315429u,
			3922818446u,
			4032428666u,
			3772928970u,
			3018244041u,
			1437221337u,
			2669221268u,
			462219416u,
			1321684805u,
			3243519199u,
			3537313978u,
			1027590196u,
			1326603293u,
			1352656262u,
			1415042492u,
			2921815539u,
			988821060u,
			4048034291u,
			4182849074u,
			4013692988u,
			3814604325u,
			1276677075u,
			1763709805u,
			404060389u,
			765670180u,
			3489046519u,
			2253774154u,
			444634020u,
			1152004281u,
			329297179u,
			1160132142u,
			42122521u,
			383526453u,
			4225628821u,
			4225378089u,
			3197085816u,
			967818907u,
			2253844714u,
			2745278293u,
			1473860878u,
			3834993413u,
			3029069954u,
			1728554595u,
			335201762u,
			3868567460u,
			4271814719u,
			2305458529u,
			1178549418u,
			1929783828u,
			4125186142u,
			1459401587u,
			3606259014u,
			1979759096u,
			3687832342u,
			533784854u,
			3911354215u,
			2601459890u,
			115436319u,
			191388789u,
			130884164u,
			4194290784u,
			2154570978u,
			3107735205u,
			175563033u,
			887810231u,
			1507101286u,
			1375610716u,
			1345344690u,
			3639282594u,
			968439756u,
			4292382935u,
			654218806u,
			3140598206u,
			833767088u,
			3224507246u,
			4102154626u,
			3373682531u,
			2205248856u,
			3685638638u,
			3052661620u,
			2890752357u,
			993439168u,
			1032519257u,
			1485947514u,
			4028796719u,
			3009014338u,
			3175313929u,
			427715425u,
			3219500960u,
			1537400182u,
			1358746718u,
			473393424u,
			912762037u,
			2089733012u,
			1692521155u,
			593724935u,
			3179647391u,
			3019862246u,
			73957802u,
			1738602507u,
			1775566535u,
			2194149508u,
			2945251511u,
			2608897351u,
			2395857993u,
			1097057067u,
			4095487809u,
			2271509812u,
			2485559473u,
			4268102658u,
			1170771451u,
			3153809199u,
			3949458361u,
			4256151573u,
			952414047u,
			1572344554u,
			1233434714u,
			1589211155u,
			2546355907u,
			4117168569u,
			299143357u,
			631585583u,
			239940885u,
			3412107687u,
			955741350u,
			1041183125u,
			1327569031u,
			815668741u,
			851315259u,
			2165554362u,
			1723247464u,
			3989530733u,
			490976748u,
			3035921670u,
			1529454575u,
			4063667611u,
			335354199u,
			4001879000u,
			1551373093u,
			825323373u,
			563083436u,
			531443666u,
			3514964451u,
			811378970u,
			2656152941u,
			66721541u,
			579980875u,
			2997213526u,
			4072249069u,
			1074120416u,
			2510421251u,
			1225522362u,
			2057077500u,
			3021405531u,
			3665250608u,
			975045613u,
			1916900489u,
			2553071026u,
			4204896007u,
			1289139446u,
			3597274848u,
			560500386u,
			4041543695u,
			866111725u,
			407172801u,
			1814228850u,
			3743037944u,
			2394095366u,
			2541192367u,
			1410730362u,
			3314186650u,
			1470710581u,
			1763022329u,
			673536918u,
			152982203u,
			3280014461u,
			1999244640u,
			2375152917u,
			3208040253u,
			2868711013u,
			1773005473u,
			3976683963u,
			3362641584u,
			1896072594u,
			569522113u,
			298117831u,
			3762521502u,
			3927727649u,
			103810043u,
			2754414415u,
			2687090127u,
			3447114390u,
			3819628235u,
			153010614u,
			614780119u,
			137047166u,
			4164287970u,
			3379198928u,
			4051607381u,
			786129227u,
			3817919822u,
			705015429u,
			4285552370u,
			1584091532u,
			1213147452u,
			1149572638u,
			1112384675u,
			2372037398u,
			4044923045u,
			1828320970u,
			3334767255u,
			3330033161u,
			736612369u,
			2160527835u,
			332292341u,
			976162185u,
			1595325801u,
			2900277610u,
			878671567u,
			1853522396u,
			2292237157u,
			1982405807u,
			3589655061u,
			4171417128u,
			3160460061u,
			2525769172u,
			71436816u,
			732702970u,
			878625298u,
			1141573127u,
			3060061450u,
			1362600020u,
			3913299520u,
			2573738971u,
			2275245240u,
			2580906416u,
			1951510395u,
			3949237291u,
			2656423758u,
			1723072501u,
			3463835366u,
			1439547563u,
			249346401u,
			2704513449u,
			1652613092u,
			3560873766u,
			1650000995u,
			1124269488u,
			3626511523u,
			1903970213u,
			2940579137u,
			3367207078u,
			388888048u,
			3013964577u,
			2427809509u,
			2426635115u,
			1326849238u,
			1098913047u,
			3678013244u,
			2298446474u,
			1634045356u,
			715274924u,
			86447076u,
			316738093u,
			510768922u,
			3584176754u,
			199105022u,
			2191919320u,
			3943596738u,
			3221401790u,
			2881880708u,
			2554535281u,
			3216924519u,
			100716127u,
			1819124166u,
			4071832554u,
			1670504069u,
			4007005084u,
			369112879u,
			1517999444u,
			1307575235u,
			1336554673u,
			4259314042u,
			2498213836u,
			3716495211u,
			3417788916u,
			3286836192u,
			1353880025u,
			3319351226u,
			2493447795u,
			2177966655u,
			3581099450u,
			2868043951u,
			392309829u,
			4170066801u,
			3178040916u,
			1992219575u,
			2125776490u,
			1465521091u,
			1437864347u,
			1523822174u,
			3208609169u,
			3652504111u,
			647916219u,
			4008652244u,
			2816933926u,
			1979569044u,
			1314281681u,
			1966959328u,
			3101019317u,
			2099682194u,
			1073107959u,
			4164995951u,
			3856376425u,
			801637325u,
			1132627530u,
			4232261999u,
			1279714207u,
			925498833u,
			1062853015u,
			1341442116u,
			3922755531u,
			2084215636u,
			1250459818u,
			463636329u,
			1405062203u,
			2526299677u,
			338480238u,
			2675647005u,
			3584731123u,
			3823951257u,
			2877352709u,
			1761188513u,
			2643165691u,
			2982741u,
			2972145596u,
			3015908293u,
			2668451666u,
			4019726335u,
			2275087601u,
			1653757521u,
			1528207133u,
			2735425548u,
			2418725419u,
			3360479556u,
			2949567466u,
			1405470540u,
			2202771280u,
			3796704439u,
			2778838792u,
			1955675866u,
			2624997956u,
			2241819431u,
			2485765726u,
			1808801866u,
			3702125174u,
			1336106473u,
			1609765481u,
			3656434789u,
			1601363481u,
			555484788u,
			1964273702u,
			2221730659u,
			3230204714u,
			1703547370u,
			2864101623u,
			633291217u,
			3542181543u,
			15343910u,
			928711388u,
			3619543185u,
			3415559510u,
			4080448221u,
			1524381191u,
			1619390231u,
			3112236222u,
			3322125574u,
			722762525u,
			1709619249u,
			1928602582u,
			3059368166u,
			3572106677u,
			2307039273u,
			1625518628u,
			807727587u,
			2367677388u,
			1126752073u,
			3507781122u,
			2693141135u,
			2445168960u,
			2000519864u,
			47113350u,
			3784004627u,
			2821216754u,
			2804464251u,
			40478671u,
			3533951244u,
			3764409555u,
			2561589343u,
			3363005274u,
			2972404760u,
			2226556206u,
			4056669658u,
			244480943u,
			1420985361u,
			315275403u,
			3450392090u,
			1583630285u,
			331508566u,
			336945435u,
			1332086897u,
			2037015791u,
			680246634u,
			1931557135u,
			3257524556u,
			4108672317u,
			1262894557u,
			304970640u,
			3571154851u,
			4134363304u,
			3792333609u,
			3945694331u,
			3872886413u,
			787813572u,
			2432908576u,
			2094742611u,
			3269505702u,
			3717861129u,
			3510470891u,
			359229917u,
			1974333359u,
			2348106479u,
			2761046581u,
			1122480004u,
			3015084676u,
			2011549369u,
			1245108105u,
			525888381u,
			2962435949u,
			2499721615u,
			2069927564u,
			2263673184u,
			2452285138u,
			4152550668u,
			94761634u,
			3798482620u,
			3968259776u,
			3375672385u,
			3140521533u,
			1583203069u,
			4212576585u,
			2299073471u,
			1902517579u,
			3833021932u,
			1613617016u,
			4101799736u,
			1584342740u,
			1587176954u,
			3288002796u,
			821140176u,
			2787885783u,
			3144573837u,
			1111771003u,
			1197339414u,
			336899432u,
			1673102124u,
			3013860639u,
			2261842400u,
			641023630u,
			1848063387u,
			2129263630u,
			1445668490u,
			1051234263u,
			1152817725u,
			1623448172u,
			3582579990u,
			1715675032u,
			4090398952u,
			3404408135u,
			3116823591u,
			2340163077u,
			3956103798u,
			1258638757u,
			3468454666u,
			179468364u,
			328969097u,
			1410434577u,
			2401480114u,
			3295156570u,
			2148121918u,
			3783762467u,
			3873403046u,
			2444354255u,
			2061319158u,
			1991675326u,
			1573568504u,
			2629093593u,
			1253379942u,
			3876355516u,
			2811336615u,
			365820320u,
			1143868026u,
			1971105351u,
			3544412839u,
			1982450884u,
			3048578860u,
			3776441507u,
			250116508u,
			3104836467u,
			2026600304u,
			3405110431u,
			4082588738u,
			1102461023u,
			1356037710u,
			2117595970u,
			639203593u,
			1503437132u,
			3035022785u,
			3168937615u,
			1646109599u,
			2845911340u,
			2354788132u,
			3254565831u,
			373668373u,
			2995189816u,
			4161359657u,
			3551233340u,
			1664843103u,
			582191686u,
			329406108u,
			2554417243u,
			2512234867u,
			1530218389u,
			3574176034u,
			2098383941u,
			3301579049u,
			1873514841u,
			2393320977u,
			463155044u,
			222235025u,
			3943931499u,
			3967136436u,
			2311965942u,
			2233853748u,
			3397961336u,
			2464244858u,
			2713921913u,
			1500172552u,
			2263254856u,
			936741220u,
			2032589339u,
			2949703240u,
			4250836172u,
			2326331642u,
			2201686711u,
			4103764698u,
			1644501717u,
			4091734929u,
			3252662374u,
			4003480349u,
			3886729506u,
			428296683u,
			178395406u,
			3050233584u,
			3041576078u,
			1692699417u,
			1411595682u,
			2072152535u,
			90934612u,
			4197435373u,
			2315773292u,
			1054239364u,
			2675587255u,
			2988900569u,
			198305660u,
			3669662528u,
			66873365u,
			634861772u,
			3312601696u,
			2089425605u,
			4246238558u,
			1765198974u,
			1357472561u,
			3265395467u,
			1517980870u,
			2208668565u,
			1194559194u,
			450325132u,
			4281653880u,
			3698260771u,
			3588916410u,
			2554365289u,
			261546132u,
			2097559906u,
			532343442u,
			123453797u,
			1177478322u,
			2698929838u,
			2860798673u,
			706797401u,
			3952971251u,
			4244060043u,
			3856803028u,
			115865867u,
			2721396986u,
			176558787u,
			3275499001u,
			2810519266u,
			2568810732u,
			3395814812u,
			2810963911u,
			566593813u,
			4187762119u,
			2525783332u,
			2536057288u,
			152162907u,
			2650837530u,
			2079892690u,
			363158326u,
			750342456u,
			3227997374u,
			2076055904u,
			3411655836u,
			4148092919u,
			4211939108u,
			62090827u,
			688349114u,
			4192782853u,
			2357499815u,
			3698567920u,
			3981140885u,
			368055391u,
			739485690u,
			957773708u,
			191996007u,
			751611995u,
			3171838455u,
			4086493788u,
			86715519u,
			20683569u,
			2116812252u,
			432586975u,
			568561039u,
			3751217175u,
			1813049295u,
			893225543u,
			340887208u,
			392861246u,
			1503929040u,
			4090459661u,
			2086634906u,
			3066433782u,
			512676769u,
			330789239u,
			190506081u,
			3511510018u,
			1003637444u,
			4212467291u,
			3048438100u,
			2893522446u,
			1431972524u,
			262231661u,
			3706809959u,
			1659705326u,
			1154957942u,
			1701616514u,
			2468840584u,
			2667908877u,
			352596124u,
			3515663726u,
			1469678314u,
			1140865762u,
			1866770133u,
			3913823413u,
			3909108862u,
			95404550u,
			1646018013u,
			2487650904u,
			2553219653u,
			3080889703u,
			4011540424u,
			943435582u,
			1435451795u,
			3923318936u,
			453946819u,
			1004994886u,
			364580901u,
			653678107u,
			390191843u,
			3496284390u,
			3904122794u,
			1463870491u,
			2702293061u,
			2657464291u,
			1755016392u,
			267464954u,
			4119349759u,
			3438635575u,
			875390938u,
			2568261912u,
			4130792683u,
			1634073686u,
			1674245116u,
			690905293u,
			367711270u,
			2599019726u,
			1985188110u,
			20763780u,
			1150258884u,
			3357443167u,
			365737345u,
			1860459336u,
			1388026837u,
			3659422106u,
			262103606u,
			2959066997u,
			1440898174u,
			3135636349u,
			479715984u,
			1312343715u,
			3023389590u,
			918700959u,
			3499316183u,
			1928577701u,
			1969187898u,
			2850719422u,
			2705406572u,
			2923392330u,
			3105802393u,
			3358858140u,
			1567812928u,
			1820868970u,
			226011675u,
			132821126u,
			3143640767u,
			2722197456u,
			4070162719u,
			3195822070u,
			4062987069u,
			30941124u,
			432798096u,
			3852443008u,
			70500495u,
			3817521716u,
			2836940855u,
			651969867u,
			1543019180u,
			1608549821u,
			2940967025u,
			2201674945u,
			417932634u,
			660527071u,
			2999636602u,
			3433332726u,
			1308172182u,
			1722530144u,
			2768895333u,
			756924483u,
			2474570241u,
			587973193u,
			711257714u,
			3960839930u,
			3104904505u,
			3771502050u,
			2729471315u,
			1400598500u,
			144101427u,
			4048180864u,
			1143175989u,
			707666443u,
			169525718u,
			1118764162u,
			3996555172u,
			4269701183u,
			3346907852u,
			2580584352u,
			1355051002u,
			1616189965u,
			540606761u,
			3759523986u,
			1758499891u,
			4253607536u,
			20081863u,
			991376605u,
			844743893u,
			1927820406u,
			1061922230u,
			575362966u,
			2131084850u,
			3133296249u,
			3621435526u,
			2079774683u,
			2705621394u,
			2716696689u,
			299651200u,
			2173488886u,
			798265177u,
			1582262186u,
			2846760414u,
			1465477949u,
			198145495u,
			3648537253u,
			2083305978u,
			2213166668u,
			1893004783u,
			516014552u,
			2055772838u,
			3711335928u,
			172415701u,
			1747707024u,
			972837261u,
			1048948788u,
			3094246454u,
			1982580969u,
			3884067526u,
			2555701031u,
			75448626u,
			2837245855u,
			2967742338u,
			4234257844u,
			325289646u,
			2902047443u,
			1393456806u,
			2385175057u,
			3420563422u,
			3465917095u,
			4157920491u,
			3699079305u,
			1661808965u,
			813283790u,
			3222059190u,
			3517823456u,
			1411608967u,
			978697306u,
			778976310u,
			2056665402u,
			338626430u,
			2415484090u,
			1738780875u,
			2950949265u,
			1988634854u,
			3215386182u,
			3167009909u,
			972901231u,
			1106470593u,
			3131726787u,
			4089071709u,
			2456903650u,
			3317261050u,
			1096403294u,
			4091296744u,
			2634702753u,
			4000577188u,
			2410993335u,
			214944681u,
			4135369514u,
			352638814u,
			327855374u,
			980424580u,
			3802493071u,
			1072603923u,
			2697670613u,
			1021700785u,
			1930481926u,
			3083594197u,
			558750616u,
			118244377u,
			3325864767u,
			3133489923u,
			2878697609u,
			3728316190u,
			2357287114u,
			1938009772u,
			3416546193u,
			871872674u,
			2925538262u,
			1439173391u,
			4176241306u,
			4132725463u,
			3127932759u,
			3316503583u,
			3213972864u,
			4062133146u,
			4168659255u,
			945392234u,
			1427544429u,
			2420341856u,
			813092319u,
			567645072u,
			2624029921u,
			2668430112u,
			2296515515u,
			1507404575u,
			2088356000u,
			2787512051u,
			392241464u,
			436756092u,
			347458117u,
			1576324955u,
			1705262239u,
			592911808u,
			34051286u,
			393150144u,
			3087713684u,
			3396794604u,
			460255432u,
			1903563228u,
			288691358u,
			560695079u,
			4065093094u,
			1370183757u,
			3834617841u,
			1702491042u,
			3031894248u,
			1928339009u,
			2595198160u,
			2922501280u,
			2592386394u,
			9111857u,
			3301986656u,
			3375180772u,
			3236380641u,
			881113439u,
			1582495296u,
			101794677u,
			1891870662u,
			2978145900u,
			793299486u,
			2255705224u,
			2434232214u,
			3761546650u,
			327181279u,
			3433668686u,
			340295126u,
			484009104u,
			2064447351u,
			4259252353u,
			805120272u,
			4242176920u,
			1939522050u,
			2938745609u,
			3233621821u,
			1850717266u,
			1433948382u,
			2241981196u,
			3701354699u,
			2259805033u,
			1183092062u,
			2126226595u,
			1617586468u,
			897578077u,
			2005817305u,
			4203400870u,
			4123369525u,
			162667981u,
			3930579889u,
			897200169u,
			1648230313u,
			1201249187u,
			1965840646u,
			3796939038u,
			3586880751u,
			1161145333u,
			918073992u,
			430499807u,
			1489062527u,
			2850043910u,
			3203186803u,
			2356624831u,
			687250376u,
			2889163831u,
			1577881727u,
			3181412325u,
			919064452u,
			3513202585u,
			2779455585u,
			1615437170u,
			4166569280u,
			3396249622u,
			1755640668u,
			3826347213u,
			3089412161u,
			2698118084u,
			3045800736u,
			2280724130u,
			2659253047u,
			3521494025u,
			504486234u,
			1204082801u,
			4147674460u,
			1584280719u,
			4089087681u,
			1922216786u,
			3132108904u,
			674721014u,
			752205915u,
			2850613857u,
			1558262136u,
			3473984274u,
			3914204720u,
			312581053u,
			2721715732u,
			4145078449u,
			3488839556u,
			1965824512u,
			3162450460u,
			2296628985u,
			4095677557u,
			1601585689u,
			4285179670u,
			1296861683u,
			866989744u,
			153450884u,
			2925258223u,
			2690873047u,
			4172271403u,
			771782966u,
			256905820u,
			3564475323u,
			2288178847u,
			2544115662u,
			476628540u,
			681020701u,
			3174253672u,
			556639926u,
			2711801749u,
			681603533u,
			1760862389u,
			3227063449u,
			2740688190u,
			128465418u,
			3615506486u,
			3132808690u,
			2029175988u,
			3207206219u,
			2484905081u,
			2338566038u,
			3435237422u,
			2504313753u,
			403253395u,
			1679954037u,
			3979998194u,
			458640034u,
			3691424044u,
			2684612856u,
			107486451u,
			1658412693u,
			3750591975u,
			1474068278u,
			1530670904u,
			1620801297u,
			2344179089u,
			1184542341u,
			632048524u,
			2099970581u,
			4285803912u,
			2781136142u,
			3586461970u,
			142141721u,
			825018415u,
			3925015751u,
			394501794u,
			2008297787u,
			2592929764u,
			2577257174u,
			2538806294u,
			1747673058u,
			3034122101u,
			2223765964u,
			1877223292u,
			3912021986u,
			448805332u,
			3549751952u,
			3975710410u,
			2055157870u,
			918249812u,
			4195150782u,
			2257067012u,
			928083534u,
			2594185198u,
			4113136395u,
			2285759417u,
			3077128235u,
			840070046u,
			3467094347u,
			104497084u,
			1007008859u,
			2495728320u,
			347472101u,
			3780669172u,
			3385630085u,
			2001967244u,
			1400055082u,
			770247164u,
			330203504u,
			3484067781u,
			798297222u,
			2796681515u,
			5622742u,
			802718508u,
			1178321824u,
			1098244851u,
			2906873593u,
			1212464454u,
			3069119232u,
			3647931459u,
			3982106889u,
			1522444604u,
			435391313u,
			2769460444u,
			1778348312u,
			2046263904u,
			484198682u,
			3787254271u,
			2002483846u,
			1903857871u,
			3892910664u,
			3158008782u,
			2582460703u,
			410995565u,
			3415539367u,
			3577646698u,
			2595827718u,
			3269357966u,
			4053608016u,
			2631946684u,
			1799624169u,
			1264301978u,
			1294083359u,
			1287446695u,
			144365305u,
			2969193062u,
			1175731003u,
			455037633u,
			1443194010u,
			2046135165u,
			3975765751u,
			3659074575u,
			2100240831u,
			1240535462u,
			1696281989u,
			69330270u,
			2955021539u,
			3832836956u,
			1631336992u,
			4060758625u,
			781318233u,
			2268279364u,
			1001320289u,
			879792030u,
			60297786u,
			2243962493u,
			2893323398u,
			810466413u,
			3044255194u,
			3245007196u,
			1500704585u,
			3772471381u,
			3799615457u,
			1415943776u,
			2600508054u,
			3636327659u,
			2098792270u,
			1196515893u,
			3542478853u,
			3733284767u,
			893732015u,
			3636722690u,
			3876846427u,
			1774949609u,
			1733121323u,
			3453851904u,
			38938598u,
			1056847437u,
			2702980805u,
			4052762330u,
			924118292u,
			410942791u,
			1654769501u,
			1878280546u,
			1294590773u,
			1381664314u,
			2424967877u,
			401853193u,
			3146793137u,
			845119234u,
			1627790327u,
			2671917899u,
			73653377u,
			3856896930u,
			2466095556u,
			3886499494u,
			1479882210u,
			184515979u,
			1315167542u,
			1649850505u,
			1014760434u,
			3022346130u,
			2012772498u,
			2697577478u,
			3249494384u,
			3911582078u,
			3812642111u,
			3059045630u,
			4196756111u,
			1078352653u,
			3127189266u,
			874260924u,
			3828593882u,
			2875182297u,
			306960189u,
			2202309266u,
			1802555971u,
			4244362492u,
			778017794u,
			604577501u,
			3378742183u,
			3115446521u,
			3364408623u,
			2717927561u,
			432246896u,
			1266809234u,
			1064538259u,
			1573159432u,
			2080894217u,
			1990024022u,
			1820339781u,
			1089830810u,
			961716114u,
			1097615865u,
			62612122u,
			2300502612u,
			2703443998u,
			2135256384u,
			2507074414u,
			4130533806u,
			735989544u,
			3671036681u,
			4152389637u,
			3538144483u,
			1216303158u,
			1206829094u,
			315455558u,
			3183493629u,
			2707629974u,
			1206752789u,
			418144696u,
			204632401u,
			4222635266u,
			3410370232u,
			310767906u,
			887602111u,
			1722435779u,
			1211403459u,
			152754645u,
			2839839617u,
			74014216u,
			506480188u,
			3222528754u,
			787214455u,
			3591446386u,
			411347703u,
			1644531790u,
			2475899481u,
			1924892520u,
			672290421u,
			138050745u,
			1825170776u,
			3020242649u,
			2207090844u,
			239255938u,
			808794547u,
			3001098334u,
			707167323u,
			1898994460u,
			472516672u,
			4043434372u,
			1174037117u,
			258553841u,
			383210918u,
			4237363315u,
			3642172178u,
			2775325866u,
			4078969661u,
			3206492459u,
			1941154375u,
			2324823348u,
			55712472u,
			3426791655u,
			2941756490u,
			110847064u,
			2359414580u,
			3574850942u,
			84224109u,
			3126876022u,
			3779906165u,
			4034561972u,
			3042551836u,
			3736173448u,
			288243897u,
			2706274941u,
			2839813088u,
			3579273371u,
			3989614890u,
			2051050807u,
			565097881u,
			186460714u,
			3501880530u,
			3757665596u,
			1678735766u,
			776893749u,
			205161577u,
			2625439196u,
			2715100134u,
			1040875069u,
			96344384u,
			2474760301u,
			903878456u,
			1805342106u,
			369695090u,
			4125611449u,
			3199536608u,
			114371005u,
			2699280956u,
			10241726u,
			3869095415u,
			1318904711u,
			1461957791u,
			1846204755u,
			1765209509u,
			3822154557u,
			2214486330u,
			1649782288u,
			603186964u,
			3321409818u,
			3000395112u,
			2818331627u,
			2529723799u,
			4294367804u,
			1730109091u,
			3531975162u,
			3446373955u,
			1604026882u,
			501176939u,
			2171974970u,
			491687744u,
			1749723832u,
			2381519786u,
			500958110u,
			3010267602u,
			2629369078u,
			1242207770u,
			3996305460u,
			183816003u,
			536221310u,
			1993913213u,
			2571590482u,
			1217097175u,
			816004578u,
			522941333u,
			2071525635u,
			2777306261u,
			2100852915u,
			3493536398u,
			425722574u,
			168260919u,
			2587830178u,
			515697061u,
			1298610740u,
			3620226527u,
			1845153044u,
			3629970870u,
			2324711122u,
			1876728679u,
			776249375u,
			4221509536u,
			3345883297u,
			1470203812u,
			2666378057u,
			4185650505u,
			2806520011u,
			1221785107u,
			4066291675u,
			3460882141u,
			3471877008u,
			492482329u,
			3072873403u,
			912214324u,
			32327677u,
			2746803596u,
			2083260487u,
			3414340061u,
			565140042u,
			3782089662u,
			1595236815u,
			1759889957u,
			2548350452u,
			4173344962u,
			3590142025u,
			1305296330u,
			416415779u,
			2464836565u,
			4141376529u,
			3593837963u,
			1120826940u,
			529114254u,
			103157535u,
			3305692557u,
			1518536485u,
			2610606798u,
			1464285472u,
			1713458082u,
			580594656u,
			327333571u,
			2853860612u,
			2022356495u,
			4106933874u,
			930124674u,
			125944449u,
			3728366382u,
			618260168u,
			2983083712u,
			432751844u,
			1110422413u,
			3702475950u,
			288488086u,
			3106173470u,
			1375025978u,
			1463466363u,
			2912595374u,
			4222249586u,
			3771827798u,
			3047489472u,
			2116720222u,
			4242475710u,
			2274722735u,
			737694959u,
			3766452591u,
			1645049233u,
			903647913u,
			2069303877u,
			3249823116u,
			1922936046u,
			4152076799u,
			1683324239u,
			1670166286u,
			1283710035u,
			3802481503u,
			729677905u,
			2012705604u,
			3011416637u,
			4030974894u,
			1559761857u,
			3208057196u,
			924851915u,
			2004406384u,
			2054082024u,
			1775863719u,
			2890752927u,
			3470913387u,
			1988016744u,
			1261107422u,
			1014167165u,
			2924062232u,
			3529361641u,
			4044393776u,
			3738118109u,
			3643642823u,
			969174111u,
			985306999u,
			3962688707u,
			1381992482u,
			3751601528u,
			2011679618u,
			3098420576u,
			3091762422u,
			1659431976u,
			1690411548u,
			622962817u,
			424538441u,
			2906390287u,
			3034940769u,
			3140673891u,
			4196752016u,
			975590744u,
			2860549856u,
			503453413u,
			4231540630u,
			1367219740u,
			114531370u,
			1885074950u,
			384493242u,
			1570727597u,
			2638616861u,
			1435172308u,
			603002812u,
			3972836171u,
			2739190860u,
			3811169610u,
			2130213100u,
			3525032683u,
			1672549952u,
			250346784u,
			3884266644u,
			412401118u,
			2064468303u,
			3124081679u,
			181215424u,
			2388242868u,
			1711715626u,
			3789704151u,
			297924447u,
			3697041106u,
			106535031u,
			1769419034u,
			1168090478u,
			259742347u,
			160740286u,
			3242589311u,
			3995763066u,
			77802320u,
			4134586075u,
			1035725841u,
			1244363155u,
			2232953718u,
			2053597282u,
			3887460368u,
			2540504931u,
			545979454u,
			2684566484u,
			484773648u,
			600920422u,
			4129838608u,
			2123283010u,
			2094927129u,
			2724199187u,
			1167289736u,
			2993399809u,
			3788954814u,
			1763528356u,
			71147967u,
			2981709044u,
			770128086u,
			2838541274u,
			2248457838u,
			998441643u,
			146040575u,
			1368419728u,
			3817117972u,
			2042517864u,
			3383724471u,
			1084715655u,
			1455728078u,
			1281191789u,
			1028022935u,
			3106628784u,
			2894343334u,
			238427157u,
			3942331708u,
			231803163u,
			2907630886u,
			2837491006u,
			652538378u,
			4170043076u,
			1046574420u,
			1263077013u,
			3064367875u,
			287345250u,
			126746637u,
			3287385268u,
			1097009410u,
			680157370u,
			3335856088u,
			3041052400u,
			1702143088u,
			1663947929u,
			404711804u,
			1360377382u,
			2480094387u,
			1986937893u,
			3280574005u,
			3960853990u,
			3158322233u,
			1927774033u,
			2323071266u,
			2526251155u,
			1729436626u,
			1127836430u,
			3017854027u,
			1679192931u,
			3814423982u,
			1304023023u,
			910587421u,
			887970218u,
			3395667044u,
			2753665507u,
			1684251816u,
			1592127856u,
			2259663281u,
			232394920u,
			3952893323u,
			722065342u,
			4242631325u,
			1086049875u,
			2892688276u,
			3705881710u,
			2730156967u,
			2330719314u,
			3428034085u,
			1448059683u,
			3864617943u,
			2629702642u,
			1554434129u,
			1880310646u,
			3003078073u,
			2071106130u,
			759474157u,
			1912466806u,
			4228019128u,
			1225137211u,
			1345692204u,
			369190986u,
			1306219617u,
			3709498493u,
			2788531819u,
			785488182u,
			4255127043u,
			106507588u,
			2995437149u,
			1344085720u,
			3065314916u,
			4293851053u,
			1306653671u,
			3546878754u,
			2388492697u,
			664633865u,
			2364976431u,
			3855520745u,
			1769583340u,
			4091226591u,
			904623737u,
			2773647892u,
			1296442028u,
			3462131060u,
			279900018u,
			1755964696u,
			1583512435u,
			1381959838u,
			847305556u,
			3037511793u,
			2195676470u,
			2946077279u,
			2326807700u,
			1603718403u,
			1010013722u,
			2495065320u,
			2513216745u,
			3200113767u,
			2045458387u,
			749000070u,
			1837786953u,
			2624683743u,
			2803604907u,
			2603175935u,
			1410759631u,
			2019111522u,
			3493344838u,
			522333345u,
			2313528385u,
			2295903310u,
			82993808u,
			3097422578u,
			2959646697u,
			357394519u,
			983718987u,
			3011087419u,
			3074760774u,
			1247867287u,
			1579912806u,
			2722654411u,
			2112186004u,
			1312072388u,
			1464090625u,
			758100446u,
			4120585491u,
			1192152919u,
			862359725u,
			4144645345u,
			3981059102u,
			2784314284u,
			3055059353u,
			4045285117u,
			375176937u,
			2536737545u,
			541746810u,
			2770066741u,
			2612718425u,
			3674967349u,
			1296666575u,
			1545679183u,
			1832153700u,
			3661117704u,
			2763291323u,
			2461242552u,
			3650798184u,
			1604157482u,
			850778640u,
			605982790u,
			2556761370u,
			2489935282u,
			3783428961u,
			1172168418u,
			1061269505u,
			3750774647u,
			1713814825u,
			3471254889u,
			2692953032u,
			587862352u,
			2767102963u,
			2138523760u,
			3355590882u,
			3944771323u,
			1465672932u,
			1857048861u,
			2173367391u,
			2343233766u,
			1714082751u,
			2398189175u,
			3607879143u,
			3623432437u,
			853090278u,
			2383234923u,
			3049820307u,
			1904844276u,
			865826727u,
			1906574961u,
			3192392487u,
			1833937849u,
			1449477565u,
			2860840037u,
			2857832313u,
			1928996499u,
			2264435729u,
			1306774430u,
			1518805731u,
			3741974987u,
			708162590u,
			179557447u,
			1178453618u,
			824730112u,
			3598767756u,
			4000206932u,
			2984500111u,
			2320320857u,
			3052103899u,
			2916312000u,
			997959405u,
			4022879100u,
			3674221205u,
			4049287615u,
			3552706276u,
			2424737803u,
			3654176516u,
			1320424032u,
			260696293u,
			3080692499u,
			1109901498u,
			813711290u,
			121557621u,
			1693955596u,
			1484484926u,
			4080113148u,
			4273342796u,
			644071661u,
			3082248322u,
			907737281u,
			217294825u,
			1760216864u,
			1744345065u,
			1137040638u,
			422840399u,
			2848288146u,
			1612456784u,
			1108309290u,
			3205785822u,
			3916103253u,
			1294768300u,
			2796765862u,
			2241335600u,
			318518159u,
			3736571767u,
			700583212u,
			2885541625u,
			2122127008u,
			753490591u,
			872395831u,
			3649041570u,
			577707227u,
			3134670834u,
			2158643538u,
			1131318342u,
			44853137u,
			342291911u,
			2359677080u,
			2967002370u,
			3318329991u,
			2546178746u,
			1170429121u,
			412663186u,
			691885856u,
			217686620u,
			157486205u,
			3536355788u,
			474480831u,
			810119765u,
			286356845u,
			1621151643u,
			841340565u,
			1685883131u,
			1046227821u,
			3294476571u,
			3606169105u,
			3491129010u,
			2378354432u,
			126965954u,
			3260268814u,
			628442094u,
			708341547u,
			2961317274u,
			1515465830u,
			1641612888u,
			1860470115u,
			3627805960u,
			2454136126u,
			1177318241u,
			1846418653u,
			854783041u,
			1305121852u,
			3961949076u,
			3327846578u,
			3416251245u,
			2402136855u,
			4294550942u,
			4229620960u,
			660989440u,
			3780358587u,
			763737135u,
			66556124u,
			1859001267u,
			3424560257u,
			788721493u,
			1541269764u,
			1629955696u,
			3670680489u,
			96005873u,
			4268835274u,
			2184482512u,
			2891719902u,
			149950887u,
			910852174u,
			506128528u,
			1391372920u,
			3187359208u,
			2921766229u,
			1910360596u,
			3525528629u,
			3051487643u,
			521122890u,
			3159851746u,
			2610243248u,
			2700643071u,
			1224253692u,
			403346263u,
			1112476297u,
			666965507u,
			3001367115u,
			86638158u,
			2653644769u,
			3016871694u,
			3915330297u,
			4284943865u,
			4271253831u,
			2217637050u,
			2165250048u,
			1208583968u,
			177459357u,
			2699188303u,
			2350540036u,
			3706281892u,
			1724452422u,
			1105164968u,
			520773756u,
			3094924053u,
			3220205379u,
			2589790498u,
			3968432085u,
			774269534u,
			2143665795u,
			2926933174u,
			2514509387u,
			976773670u,
			2104058001u,
			112792596u,
			786973530u,
			2493409883u,
			893746384u,
			391221610u,
			3723848059u,
			3084228310u,
			1491277703u,
			2029270887u,
			222192778u,
			2467789400u,
			2802254077u,
			227827065u,
			2989615611u,
			23081083u,
			2400642698u,
			2177874625u,
			3552399647u,
			3282629007u,
			3651171982u,
			2558961110u,
			788863213u,
			3508479408u,
			495025113u,
			83113513u,
			3143724282u,
			3783426522u,
			3629420032u,
			662825793u,
			1704299821u,
			1296266951u,
			635071918u,
			155852651u,
			2888118234u,
			1266042276u,
			1228272055u,
			4167277830u,
			4038401423u,
			3817008462u,
			1230989588u,
			4205314847u,
			284471464u,
			1533278111u,
			2449334291u,
			2958422579u,
			2663469172u,
			3439986246u,
			876481812u,
			2464905240u,
			891684982u,
			2608084215u,
			4280460300u,
			34801800u,
			1627804215u,
			1001823915u,
			2609270566u,
			426036u,
			4031293005u,
			879385659u,
			670478664u,
			4190171425u,
			3978360736u,
			2264759159u,
			335965683u,
			2060055430u,
			4201638888u,
			3981229204u,
			2665060274u,
			1240613512u,
			1358603302u,
			2123957346u,
			2183063441u,
			921444054u,
			2936405148u,
			2647712680u,
			332086065u,
			188899718u,
			2281912344u,
			2200991777u,
			2534707596u,
			1578798610u,
			515828083u,
			3214335547u,
			2301205578u,
			3235664376u,
			1833787346u,
			2157104522u,
			1087748114u,
			3961463511u,
			1396252078u,
			1477840847u,
			3699440406u,
			1144854761u,
			1826911529u,
			1515698679u,
			730297720u,
			640876877u,
			2324797587u,
			2313557510u,
			1517970665u,
			3667330405u,
			2047972373u,
			2021425028u,
			1675698781u,
			2028258935u,
			1773199648u,
			3198488177u,
			2862524754u,
			2071038880u,
			3038031145u,
			2450825837u,
			3211296506u,
			3867060256u,
			3550885400u,
			444713884u,
			1779540500u,
			1708948894u,
			2631617587u,
			3936937323u,
			3594543100u,
			1412516427u,
			2882799374u,
			3791391048u,
			805682670u,
			2749017037u,
			4098423737u,
			83232762u,
			3948539255u,
			2474207938u,
			3591783878u,
			3318073685u,
			419761482u,
			3477705450u,
			610850835u,
			2397507831u,
			727545761u,
			1158330745u,
			134736516u,
			144216429u,
			2767256661u,
			933242288u,
			658482064u,
			3802158861u,
			2377035896u,
			3213987668u,
			1365978941u,
			1868694298u,
			1228132639u,
			2681187399u,
			1365086032u,
			249369720u,
			2220392013u,
			1372394729u,
			1703847638u,
			656135108u,
			4135190635u,
			3015336009u,
			2735862108u,
			497504721u,
			763147112u,
			1986041401u,
			4084898228u,
			706348935u,
			1588639430u,
			569767340u,
			1301931805u,
			3531082042u,
			3093898154u,
			3683811338u,
			832972239u,
			2293848630u,
			2701453937u,
			272521844u,
			2162930037u,
			3232758861u,
			3741655237u,
			1858246529u,
			2058469003u,
			202953659u,
			2004284674u,
			824394014u,
			114431026u,
			122341831u,
			1911591708u,
			3504593394u,
			3692206173u,
			1118313546u,
			2882633188u,
			876646586u,
			1772577631u,
			2774871423u,
			3452778464u,
			1251620427u,
			1575261376u,
			264461311u,
			3942211067u,
			252316164u,
			1383022835u,
			1557206080u,
			276098428u,
			2286585432u,
			1626178625u,
			1422832884u,
			507381643u,
			3855675959u,
			40238594u,
			993012980u,
			2994413262u,
			3982869670u,
			291969346u,
			586651700u,
			2842620676u,
			1531807295u,
			3110304782u,
			2547984787u,
			1561712717u,
			265451768u,
			67853478u,
			2161033508u,
			1670208185u,
			155503592u,
			3630622092u,
			2737685638u,
			768274776u,
			1264635832u,
			2606217298u,
			626801043u,
			844028007u,
			797165069u,
			4076348858u,
			1264767878u,
			1502345682u,
			2075326192u,
			1930104899u,
			3026972476u,
			1147923807u,
			828745679u,
			856679870u,
			1120871721u,
			2220535713u,
			4234295694u,
			154469845u,
			1091944819u,
			1340071667u,
			1445973298u,
			187906976u,
			1549811483u,
			902274479u,
			1751502115u,
			895666630u,
			1313236519u,
			1876268006u,
			4143148879u,
			1036601830u,
			3290706272u,
			857277719u,
			1206157381u,
			951102516u,
			3324442413u,
			3451092589u,
			3721837310u,
			318664740u,
			1960918744u,
			2111681895u,
			1362707773u,
			1842948150u,
			2091149291u,
			566784966u,
			455752271u,
			778692297u,
			1106712468u,
			1520981650u,
			2493694514u,
			3701461792u,
			258592871u,
			4157862131u,
			3767163398u,
			3443116692u,
			1449399511u,
			3719988840u,
			265461336u,
			2610240035u,
			3636572373u,
			4250793134u,
			3208904320u,
			4067979597u,
			2482920817u,
			1007639548u,
			390229762u,
			3090438415u,
			2645969110u,
			3591635289u,
			2957200066u,
			810031906u,
			1323881776u,
			1733420015u,
			1166516093u,
			4166378621u,
			2784347511u,
			174963650u,
			447471012u,
			4252569259u,
			1518723858u,
			304763715u,
			986379310u,
			3422123470u,
			1387313881u,
			3460320382u,
			1451378802u,
			2223040031u,
			2577883312u,
			590261022u,
			1348479070u,
			190692093u,
			2281528795u,
			3600211447u,
			1316145441u,
			731859833u,
			2748251338u,
			1267259147u,
			956520005u,
			3914257940u,
			1671684878u,
			2232669737u,
			3204597270u,
			1608866586u,
			1693597618u,
			567213064u,
			3529620834u,
			3274085775u,
			911015905u,
			2076906892u,
			328840656u,
			3073541630u,
			3451157747u,
			2807725134u,
			3603254457u,
			1364398145u,
			2601573192u,
			2054146723u,
			388764935u,
			760988828u,
			2989431595u,
			2653236696u,
			1788035248u,
			2399499354u,
			2963234979u,
			1486983625u,
			4045061950u,
			3537081213u,
			3128513636u,
			1826777228u,
			2868556279u,
			2972645881u,
			804258401u,
			4241159791u,
			941816720u,
			547896104u,
			1180183873u,
			3999632833u,
			2508924708u,
			3883362319u,
			1614233858u,
			165643910u,
			3700223697u,
			202149960u,
			1506237199u,
			1291220379u,
			1651876914u,
			2115582523u,
			2175833035u,
			1128747608u,
			211584100u,
			4236102903u,
			2086362107u,
			1507973861u,
			1076770876u,
			2563613730u,
			1681324611u,
			3880889721u,
			3055742216u,
			1497481058u,
			2711493119u,
			3455240607u,
			345076079u,
			2667616146u,
			3512376724u,
			1928564504u,
			3637409855u,
			3740448803u,
			1741931215u,
			2297765013u,
			3461735140u,
			2698965795u,
			396319296u,
			1888943397u,
			3416490626u,
			4028930781u,
			1231186560u,
			2334352209u,
			2452435057u,
			1116693188u,
			3708540079u,
			3210218654u,
			1188360407u,
			246371417u,
			1729938465u,
			766264956u,
			3634685230u,
			944689420u,
			4179072569u,
			1604244444u,
			1605531127u,
			198489344u,
			675747852u,
			2860452473u,
			2652516693u,
			3090213056u,
			837401224u,
			2717407639u,
			1967581883u,
			2117638259u,
			3546553970u,
			2289208250u,
			2798856346u,
			2516460554u,
			582245392u,
			3095771285u,
			2569999898u,
			686783291u,
			3205026453u,
			3438892339u,
			3348180605u,
			2349266478u,
			1380733160u,
			892012827u,
			2466112644u,
			2493110278u,
			1488586880u,
			4069456235u,
			1637766005u,
			908523013u,
			645394956u,
			650362112u,
			702435591u,
			3010303041u,
			3035551398u,
			4044047846u,
			1031680608u,
			573828936u,
			2347197184u,
			125679596u,
			2680815802u,
			814190285u,
			3209341813u,
			1375985877u,
			2400340370u,
			2673362605u,
			3117367794u,
			634356300u,
			927353205u,
			2680995015u,
			486599396u,
			2092256301u,
			4064336728u,
			3984963374u,
			1437171458u,
			1665101312u,
			4274123817u,
			1618679531u,
			1847572276u,
			1601526835u,
			576496789u,
			4175242252u,
			3513078571u,
			858643577u,
			160066586u,
			2930476707u,
			1587207279u,
			2715305815u,
			318351689u,
			2787251855u,
			2447002127u,
			490205088u,
			2742428544u,
			3534383272u,
			165025188u,
			289627394u,
			2816058161u,
			542994730u,
			3010275656u,
			3383168168u,
			2001710559u,
			1382375098u,
			3566064575u,
			1737658344u,
			1084253626u,
			101348455u,
			3548893937u,
			520678117u,
			312919135u,
			2415348427u,
			1252179379u,
			2442102749u,
			348746914u,
			597119557u,
			2366334852u,
			2341286425u,
			1205738892u,
			804141327u,
			2479161273u,
			587282149u,
			4263330554u,
			3936774723u,
			3217559966u,
			248409827u,
			1397450762u,
			3993624955u,
			150570363u,
			2737444708u,
			1713303426u,
			2831254924u,
			3170391546u,
			580612038u,
			385981832u,
			1985693682u,
			2097226369u,
			1682504967u,
			3858684390u,
			2039233143u,
			1045273830u,
			4136963740u,
			3739715954u,
			3799611554u,
			1409835211u,
			3401044693u,
			502502184u,
			2161419298u,
			2623415375u,
			491433005u,
			3319048634u,
			772155482u,
			1502494099u,
			3829540491u,
			2957742175u,
			2964232246u,
			883083887u,
			2105104811u,
			2287660240u,
			3817033644u,
			4083957030u,
			1216869862u,
			3809253142u,
			2341558556u,
			2877013636u,
			3979072325u,
			3996576461u,
			1292564350u,
			1302740352u,
			267621943u,
			3791448700u,
			3697598974u,
			33986903u,
			2467449223u,
			977977859u,
			3503798114u,
			1400905492u,
			803219344u,
			3599593289u,
			4106881861u,
			837103172u,
			2677288598u,
			1357483673u,
			2915405177u,
			979317370u,
			2166838039u,
			1309353447u,
			4236376785u,
			2596879288u,
			2104826543u,
			2926133824u,
			2303039082u,
			2630877489u,
			2835618406u,
			72308042u,
			119496330u,
			1779095484u,
			3730776275u,
			1826590831u,
			2841863885u,
			2008375807u,
			339735371u,
			2974396962u,
			45323172u,
			985564483u,
			2269303923u,
			2454094420u,
			3427559265u,
			1451544502u,
			2307614071u,
			219685914u,
			1958894775u,
			927775514u,
			2192463653u,
			3037108077u,
			2917609965u,
			3009689088u,
			2263101006u,
			752920298u,
			804512u,
			2358253613u,
			3004635718u,
			2781318717u,
			3646766570u,
			1917130337u,
			3869067579u,
			3360720960u,
			4136965831u,
			2408934542u,
			721361876u,
			3155666142u,
			3084961165u,
			4271304890u,
			1181051977u,
			4288914549u,
			3517799426u,
			3674015911u,
			3729413228u,
			3698326796u,
			2002546707u,
			2438324395u,
			1478189435u,
			124839412u,
			542396253u,
			1227092907u,
			3560838701u,
			1177944847u,
			3895980885u,
			35482354u,
			1023853194u,
			1294639973u,
			1049600189u,
			3094153786u,
			3007600161u,
			3074571881u,
			1428213089u,
			2250266515u,
			1588137378u,
			3518078828u,
			2604832070u,
			4158261447u,
			234630083u,
			2185214377u,
			3360814809u,
			3396251476u,
			2194980273u,
			3580255836u,
			1708812723u,
			1111401244u,
			1298222290u,
			855218356u,
			2431991067u,
			318621061u,
			2509260929u,
			1039280468u,
			3681616972u,
			4224396482u,
			2329770341u,
			891765759u,
			4044571959u,
			4056563431u,
			4092250933u,
			592484720u,
			48349802u,
			1593170767u,
			3784788616u,
			2384400187u,
			3720497074u,
			1899197141u,
			657404139u,
			3984864279u,
			704175023u,
			1836385012u,
			3276489946u,
			671405561u,
			1089855090u,
			1968495222u,
			3202166587u,
			3614499629u,
			1110574643u,
			1251601969u,
			3072444374u,
			900701033u,
			3352191475u,
			3213314267u,
			2972245620u,
			729406526u,
			1137743994u,
			1307786007u,
			3664537675u,
			894289469u,
			3583494768u,
			2406918404u,
			1854849615u,
			947458989u,
			2570690902u,
			1994934408u,
			1458715679u,
			3457220782u,
			737500156u,
			280861348u,
			1264472641u,
			1579057066u,
			4196642303u,
			2053708608u,
			534589031u,
			3974742350u,
			4210653756u,
			305821654u,
			2583376966u,
			1270956479u,
			3786839516u,
			3176981250u,
			3919853517u,
			7210073u,
			271205016u,
			882818768u,
			4151387627u,
			4000909433u,
			1498103176u,
			3367512114u,
			2606864455u,
			912801222u,
			3026621149u,
			3092348938u,
			241942460u,
			1958132363u,
			3450618020u,
			2544586245u,
			2627392558u,
			4200043669u,
			1027263677u,
			3746658093u,
			989950093u,
			2801063287u,
			2133385301u,
			1755680326u,
			2880571645u,
			4171814409u,
			1896986043u,
			1233268352u,
			1433133505u,
			3665939679u,
			3384583437u,
			2426848043u,
			64987843u,
			979871313u,
			4068856520u,
			2511528096u,
			3099252128u,
			2031658758u,
			1149371726u,
			910017701u,
			2679233901u,
			1985592690u,
			4189172322u,
			2907277560u,
			2409848132u,
			169090498u,
			692124581u,
			1445720297u,
			1652995311u,
			1358208496u,
			3068832343u,
			1503312606u,
			412305925u,
			2017498276u,
			3882630840u,
			1078628402u,
			189782449u,
			2281372111u,
			1274004205u,
			696999455u,
			844409108u,
			3815195664u,
			2234359769u,
			1674627878u,
			4107597573u,
			595658459u,
			1068931473u,
			1684500380u,
			4029712354u,
			2434439241u,
			3824194670u,
			2063317757u,
			923159848u,
			2764069385u,
			2272449981u,
			1397486930u,
			1227311174u,
			2998690186u,
			1114255556u,
			3965682154u,
			3641637008u,
			3992012407u,
			2591384843u,
			592121876u,
			725264419u,
			1562514632u,
			3056960368u,
			3576272250u,
			1988162824u,
			910361490u,
			3953804705u,
			1651105464u,
			931000602u,
			1842671082u,
			2972413905u,
			1802677649u,
			3702961561u,
			660232488u,
			2678502011u,
			1259352519u,
			3290305634u,
			2234627779u,
			3896241807u,
			1010544936u,
			1889819054u,
			1218403563u,
			1301000462u,
			2015036047u,
			2134096906u,
			4191497057u,
			461807198u,
			1744609934u,
			1285018553u,
			472619110u,
			1870343655u,
			2701634824u,
			3589452835u,
			1722353092u,
			93731892u,
			2105801167u,
			3307242916u,
			2887530722u,
			15683894u,
			678191155u,
			2802209561u,
			1737040471u,
			2120713521u,
			235971663u,
			1088121386u,
			1486517676u,
			2788482117u,
			831879587u,
			834359286u,
			3209508795u,
			3301535636u,
			3623683178u,
			3992586643u,
			1321256358u,
			1555480130u,
			3822469147u,
			2966975016u,
			778258948u,
			2698067001u,
			1461255388u,
			1785066502u,
			2659925649u,
			1215233385u,
			1215221427u,
			2687757318u,
			2355882433u,
			2217945397u,
			3762393221u,
			3091104270u,
			1595331273u,
			688742336u,
			460368375u,
			2063829682u,
			1735320087u,
			2502728041u,
			842888019u,
			3059683046u,
			2402118777u,
			3385159499u,
			1443659427u,
			2065811593u,
			676742888u,
			2265341680u,
			2355037498u,
			2006659491u,
			1592429957u,
			907707337u,
			1010631082u,
			2195381721u,
			3984052733u,
			418795183u,
			2052193421u,
			2314399213u,
			3296947733u,
			2333996513u,
			1943953717u,
			3212320986u,
			1457245406u,
			4126111448u,
			3031762212u,
			3255062267u,
			1710879899u,
			3304615110u,
			1945580363u,
			132640118u,
			1541268945u,
			3693129092u,
			3451739716u,
			436822894u,
			675165779u,
			3974867575u,
			534104785u,
			3165857056u,
			1661932049u,
			1743008216u,
			2032011054u,
			2941522748u,
			657581821u,
			1949738041u,
			1549037605u,
			2718766517u,
			2697646433u,
			3360032545u,
			1308367295u,
			2403573832u,
			3213117126u,
			1779424432u,
			3644008933u,
			3853284220u,
			3555101096u,
			297309607u,
			2824021919u,
			3290912651u,
			3827121996u,
			107247490u,
			2129811064u,
			1501028037u,
			934725315u,
			3236415492u,
			707068299u,
			2973017032u,
			775862237u,
			1707660244u,
			4202504145u,
			245971556u,
			1004440890u,
			1078662597u,
			139424639u,
			4077706132u,
			807818825u,
			2027185907u,
			765479889u,
			3616992926u,
			1221617165u,
			715495728u,
			3565335621u,
			105436596u,
			1142651457u,
			2034160882u,
			4255331371u,
			1516315694u,
			4108038390u,
			2172084885u,
			75222976u,
			1907482204u,
			281100128u,
			24315017u,
			671904176u,
			1860660717u,
			1875186594u,
			2441085280u,
			399062868u,
			2799767966u,
			1862908139u,
			576467685u,
			3805741060u,
			4127874605u,
			4056214263u,
			4267595743u,
			3741685581u,
			3799950615u,
			4229460382u,
			3078417944u,
			2207233166u,
			1983900813u,
			3556684966u,
			1510958111u,
			1588754238u,
			876966004u,
			3067002171u,
			403602536u,
			856688423u,
			1638836214u,
			3406716260u,
			2748763069u,
			1386506580u,
			2593272783u,
			1334754223u,
			3052041323u,
			3181097606u,
			3977263076u,
			2524114927u,
			1949299443u,
			3499764214u,
			1661122016u,
			4238613191u,
			1594294877u,
			2665979365u,
			2246068757u,
			2786333185u,
			1705732686u,
			3834733059u,
			2019922319u,
			3891591194u,
			2202023896u,
			2339140738u,
			1485803557u,
			634930347u,
			112647383u,
			448213182u,
			150616114u,
			1241715691u,
			3847265614u,
			1633920153u,
			4262213110u,
			1638013160u,
			1836259084u,
			1672643389u,
			4198596374u,
			3902859082u,
			4070194882u,
			3689693043u,
			474377448u,
			2998877123u,
			1743329844u,
			3220962752u,
			555885885u,
			1554497920u,
			4228515255u,
			2068458033u,
			3397227192u,
			2934722570u,
			317969340u,
			1261484130u,
			757805474u,
			3684887048u,
			1801211829u,
			2205002226u,
			10360349u,
			2528853923u,
			1418641483u,
			1568468879u,
			2966495265u,
			398334852u,
			2208283963u,
			3274110693u,
			1998719627u,
			4068329473u,
			4184177181u,
			3848119411u,
			626682721u,
			2011603224u,
			4039415750u,
			1496324759u,
			2057213339u,
			2762331669u,
			3386146442u,
			3621235923u,
			3914106858u,
			2089343255u,
			1914998868u,
			159291751u,
			3885400011u,
			3377225964u,
			962608872u,
			2482805457u,
			1788462844u,
			3358423759u,
			2299318796u,
			399013783u,
			3386287245u,
			2232317653u,
			2286599819u,
			2297686856u,
			833264002u,
			3849932584u,
			3867514857u,
			1707090462u,
			979889376u,
			465275516u,
			1722661861u,
			2502881246u,
			3241900852u,
			2745574316u,
			1562250367u,
			1608105563u,
			1729534990u,
			3837494434u,
			825695942u,
			2595484067u,
			968208119u,
			2822735232u,
			1899904779u,
			4248167523u,
			101715014u,
			1382498863u,
			3248310999u,
			837882989u,
			4104828622u,
			1035445603u,
			3933643186u,
			3910576714u,
			22890022u,
			701881588u,
			1630378253u,
			2001273963u,
			2837146367u,
			3379572493u,
			1129651508u,
			2842368474u,
			3249816444u,
			883971582u,
			514316085u,
			837017543u,
			2350539646u,
			1752536113u,
			2258566075u,
			1391833873u,
			1104268209u,
			966804726u,
			3388165302u,
			108111799u,
			1931140094u,
			621871778u,
			200019141u,
			3957990509u,
			3189899730u,
			3847256851u,
			1629042522u,
			2666431744u,
			1372954780u,
			2906001387u,
			2290575406u,
			2982801553u,
			1192694391u,
			4004280730u,
			3697991273u,
			2668087681u,
			1017691619u,
			3056036828u,
			409441579u,
			3862549457u,
			1022449738u,
			173813952u,
			2552461066u,
			4264973954u,
			1636601139u,
			1854254587u,
			4105696282u,
			924957378u,
			2744642080u,
			1407026052u,
			4053805703u,
			768890793u,
			3972625552u,
			2238228883u,
			3767169654u,
			2486598426u,
			2024642765u,
			2854756840u,
			4222353536u,
			3400368837u,
			3539551474u,
			4135456644u,
			3904722808u,
			1503111475u,
			2050361039u,
			3311935227u,
			3159868473u,
			585670818u,
			2577218111u,
			4103673322u,
			220297143u,
			3564914551u,
			2703188205u,
			1816380068u,
			814336449u,
			3890980799u,
			2104918963u,
			3534324077u,
			3760255621u,
			3114249495u,
			3127047713u,
			3104015622u,
			1371622707u,
			2034551676u,
			2715657963u,
			833359355u,
			1057896038u,
			1877773525u,
			25466845u,
			396960638u,
			50445042u,
			803202796u,
			188975665u,
			3107238140u,
			171381087u,
			1649854442u,
			2096717901u,
			2622008910u,
			1568459849u,
			1344138419u,
			3300539377u,
			2450024719u,
			2586170622u,
			2404409653u,
			1550212088u,
			935318125u,
			16510551u,
			2700874355u,
			1807375785u,
			3689068878u,
			946179641u,
			271268599u,
			3587353383u,
			2409474523u,
			108545326u,
			3885419170u,
			4074633532u,
			3691339921u,
			528510532u,
			3298169435u,
			4184586355u,
			287647720u,
			1874392405u,
			1777409518u,
			2525589503u,
			1828655876u,
			1947821100u,
			4021005687u,
			1101243796u,
			3314800445u,
			4143175713u,
			1834986441u,
			2449376462u,
			2412163338u,
			3546515391u,
			3281808498u,
			3933089156u,
			2588683795u,
			29804390u,
			1531619521u,
			1511844647u,
			3739846216u,
			3113902443u,
			1064845657u,
			1789018189u,
			1680487585u,
			2224308866u,
			2785151508u,
			3050838821u,
			3810117151u,
			4048570214u,
			2810861557u,
			75800105u,
			928111150u,
			1119331905u,
			2839840776u,
			1268120551u,
			482716625u,
			3412285010u,
			1517316130u,
			3767349000u,
			3128980069u,
			2247971757u,
			1013254402u,
			485871844u,
			1687852098u,
			3404789506u,
			4211258744u,
			3203241169u,
			3896947181u,
			3717650856u,
			1125171268u,
			2507084865u,
			2367224946u,
			411926451u,
			2596281660u,
			3088239749u,
			1394468115u,
			3435033689u,
			2873438178u,
			4114530951u,
			2104318916u,
			1457848168u,
			2226861074u,
			2606158341u,
			2146891386u,
			3392837589u,
			1059711278u,
			3258916187u,
			479206596u,
			2529202034u,
			793514981u,
			2622966761u,
			423281380u,
			501586014u,
			3144986586u,
			4107007348u,
			3932140857u,
			605692173u,
			1822051083u,
			1626916199u,
			1445772204u,
			132041691u,
			3324909941u,
			3306274860u,
			963231671u,
			2062085744u,
			539276079u,
			317537599u,
			3874587401u,
			3333812347u,
			3636804885u,
			2369890982u,
			2990824539u,
			3704534182u,
			3378828041u,
			3236397185u,
			583295773u,
			1693013997u,
			3854817966u,
			2657398862u,
			2256627664u,
			1825042446u,
			1970199669u,
			1862680591u,
			1360212794u,
			3987317751u,
			3620273730u,
			3474479292u,
			2949923019u,
			1243610136u,
			588633182u,
			1444263649u,
			3563296250u,
			3491933686u,
			4029535570u,
			4099571724u,
			474086876u,
			2628452250u,
			404856285u,
			247194816u,
			262378220u,
			1564782160u,
			2347181272u,
			2107355336u,
			445684009u,
			663088847u,
			787095049u,
			2418761441u,
			781026282u,
			1099330372u,
			1193786413u,
			1982558047u,
			615404580u,
			1071423847u,
			3073951242u,
			2765974963u,
			3516907692u,
			2805376987u,
			3095166084u,
			4165202784u,
			3276693637u,
			696431903u,
			2577566457u,
			2983322847u,
			3114108191u,
			2923115097u,
			1097225728u,
			575607489u,
			116924463u,
			3347042667u,
			2670857999u,
			118340001u,
			1135038594u,
			268753551u,
			3750991657u,
			21685211u,
			1975395565u,
			3745610242u,
			3383345404u,
			3018531146u,
			3252497036u,
			1762741559u,
			2283455995u,
			3232688675u,
			123765235u,
			1247142465u,
			4209770492u,
			427631582u,
			2950194310u,
			3686971124u,
			393958502u,
			3141417240u,
			846091917u,
			1887356490u,
			1506420177u,
			2478730944u,
			831723u,
			3773257254u,
			3942533563u,
			1920653533u,
			2922373773u,
			2611049027u,
			870549593u,
			2063843674u,
			1782629866u,
			888091892u,
			1488232793u,
			3657027316u,
			1365703811u,
			3524420354u,
			2048884701u,
			605001816u,
			1853078806u,
			3721923199u,
			2333972843u,
			3743829348u,
			2670682740u,
			2650505972u,
			3520156496u,
			3212992926u,
			1403497595u,
			712746389u,
			1079069140u,
			4239216379u,
			4005882159u,
			4222203162u,
			3864937258u,
			96063622u,
			1499696421u,
			2192380725u,
			1302464568u,
			3549220889u,
			411234160u,
			1973151976u,
			1191053833u,
			1660770670u,
			2462094284u,
			180974630u,
			343118389u,
			1160778759u,
			3805384601u,
			1938597041u,
			950271776u,
			678507679u,
			1259267168u,
			638023615u,
			3675233578u,
			3159289457u,
			1221768598u,
			450177153u,
			535695512u,
			3139137962u,
			276474846u,
			528605201u,
			4036757790u,
			4171974376u,
			3186240235u,
			1188682604u,
			3864600137u,
			2780592438u,
			159815468u,
			1525393822u,
			2006165261u,
			1826251148u,
			1056868904u,
			4136546172u,
			1407550460u,
			3335105757u,
			92271994u,
			4280658540u,
			3801554239u,
			1226643619u,
			2629631568u,
			1612150596u,
			1761233440u,
			3134216751u,
			574822320u,
			2780669053u,
			1156194864u,
			3292413428u,
			3236689088u,
			1456755783u,
			3453906803u,
			656863332u,
			1423769661u,
			1616467444u,
			1131922400u,
			442045242u,
			2822242674u,
			861631567u,
			1807481456u,
			2135792232u,
			2030263709u,
			1781839014u,
			1210686928u,
			1753866167u,
			411152164u,
			1232281211u,
			3724087596u,
			3306044722u,
			2866165194u,
			4068609300u,
			2471405576u,
			3770248631u,
			3194949247u,
			1385110572u,
			3392225893u,
			26039240u,
			2793873638u,
			2798495512u,
			1730359926u,
			1830886783u,
			1228967606u,
			3527619154u,
			513458381u,
			4014176270u,
			1364357671u,
			3240146783u,
			3036849234u,
			2271029858u,
			2588374696u,
			2062604280u,
			864880091u,
			137262749u,
			2583717079u,
			2756427613u,
			2862299269u,
			3945968254u,
			2105721569u,
			126216293u,
			3087343977u,
			1435184059u,
			1518131411u,
			1601570390u,
			2918563183u,
			1526063880u,
			542936965u,
			1107818168u,
			3547661418u,
			1846793449u,
			1957527554u,
			3394863965u,
			1732973406u,
			146371591u,
			1262687216u,
			2326869593u,
			1932615623u,
			2297999198u,
			1179896981u,
			2096939973u,
			3152018226u,
			1050183138u,
			3830122572u,
			3514940911u,
			451903263u,
			2060706787u,
			4101336527u,
			248130801u,
			4232386657u,
			4203162604u,
			2611364404u,
			1785858859u,
			1520788095u,
			3697408603u,
			1536272834u,
			233009859u,
			1601420970u,
			597258617u,
			361392145u,
			1785338178u,
			1992851565u,
			3208112991u,
			2680228113u,
			1035399060u,
			3591600609u,
			157432841u,
			3716082063u,
			1498411724u,
			3109023473u,
			2453747292u,
			2733809048u,
			2619068200u,
			2589666181u,
			2100028156u,
			501796149u,
			3198682984u,
			333448810u,
			1517574336u,
			1318096050u,
			1078316283u,
			2582711921u,
			481158392u,
			3463028491u,
			2523789233u,
			1782088565u,
			558030160u,
			3731548764u,
			3525254191u,
			1598502115u,
			2689784261u,
			4292937802u,
			1272542116u,
			2841926611u,
			2513435070u,
			3932138440u,
			124088244u,
			1969395310u,
			1734796659u,
			3637138718u,
			810446114u,
			1802172623u,
			3995660881u,
			1497381464u,
			312701444u,
			2177103161u,
			2860419216u,
			3217851778u,
			3327968623u,
			2517621454u,
			1176065236u,
			377064533u,
			2772678442u,
			3105635279u,
			3185488u,
			2485851857u,
			3036982574u,
			4227289872u,
			2929519143u,
			2488310396u,
			3403351975u,
			2235873402u,
			2252879846u,
			3292354259u,
			1799239138u,
			256541577u,
			1108246281u,
			2887183600u,
			3860385958u,
			76360632u,
			4233244498u,
			3560453420u,
			1895750899u,
			3496194450u,
			831685093u,
			4147278786u,
			1061115381u,
			3531037478u,
			3390157226u,
			123776034u,
			897815530u,
			1533586956u,
			4046758810u,
			1372945006u,
			1727460547u,
			4200500770u,
			2319135u,
			1137189818u,
			1625962934u,
			4239935928u,
			3572204654u,
			231947596u,
			3387064012u,
			2042628712u,
			1806096806u,
			3533543847u,
			4070624084u,
			4006233198u,
			4243221075u,
			2083981841u,
			3800511451u,
			3180659912u,
			3076623117u,
			2819880735u,
			1763901849u,
			2381271797u,
			1881706569u,
			900996957u,
			1728760745u,
			3151521018u,
			1831189272u,
			363516714u,
			2659738556u,
			4071076506u,
			1302001462u,
			919131118u,
			3024826142u,
			1971880300u,
			3899680050u,
			277112506u,
			834858856u,
			3817640805u,
			4275423999u,
			1128798002u,
			4265851331u,
			2347034379u,
			4265493561u,
			1943018950u,
			2447799518u,
			4166782767u,
			2145102655u,
			1522078482u,
			2779740383u,
			3791288046u,
			3457629715u,
			3280324321u,
			2355698272u,
			2356488911u,
			1511356613u,
			3212440152u,
			1041676347u,
			1569145051u,
			2358689064u,
			2012114997u,
			2419384896u,
			3548771290u,
			708621614u,
			1626727269u,
			2114511032u,
			1414052831u,
			2624567441u,
			4145166740u,
			2259334709u,
			288220486u,
			2262790499u,
			1117698567u,
			3983009011u,
			3529891212u,
			4020173968u,
			2483428755u,
			1799194669u,
			2797529030u,
			3982469814u,
			2231504721u,
			3379037433u,
			1337974145u,
			1701519240u,
			3448525709u,
			3369933339u,
			391886914u,
			1043939479u,
			2206271432u,
			2189101044u,
			1815428841u,
			2961649269u,
			363788664u,
			2368085u,
			3667193276u,
			3370248068u,
			3831234087u,
			2124038110u,
			2241605114u,
			3323897817u,
			931416317u,
			3970474481u,
			1636514902u,
			2603760244u,
			3434608469u,
			2348120047u,
			2215084132u,
			2414345628u,
			2739268108u,
			3461719351u,
			2230836815u,
			871781769u,
			2312637353u,
			1010564812u,
			819931758u,
			2181404775u,
			1379680023u,
			4154624153u,
			2878190374u,
			2097474969u,
			495770804u,
			854215645u,
			3676272932u,
			4133620499u,
			1082127383u,
			2375266323u,
			4097621132u,
			1770320451u,
			2147625937u,
			1498345691u,
			3437078018u,
			2750112954u,
			100055301u,
			3986525790u,
			3431649964u,
			2582005097u,
			1315981313u,
			3919736521u,
			529381557u,
			2946710002u,
			155549835u,
			1852005577u,
			2021750338u,
			218732200u,
			2482813907u,
			1039093417u,
			358346069u,
			2010693413u,
			490836223u,
			3590236268u,
			3899775037u,
			3200297209u,
			223847364u,
			2657450996u,
			4199492141u,
			2017277377u,
			3875748693u,
			1180677922u,
			2618619330u,
			1233247274u,
			4163611721u,
			213479850u,
			1244346068u,
			3786785020u,
			2630519895u,
			2992374979u,
			2830831475u,
			2793160730u,
			1009550625u,
			2045400190u,
			2308142345u,
			2519009099u,
			3595593157u,
			2730285262u,
			92329097u,
			3456229344u,
			2661319532u,
			1050676090u,
			989293911u,
			3034284966u,
			2943601468u,
			3326333570u,
			286633847u,
			564370101u,
			3163063740u,
			102995800u,
			3346881825u,
			204195536u,
			3000854501u,
			3356329995u,
			1746600382u,
			527598721u,
			2069319630u,
			2907106569u,
			923100972u,
			2790999693u,
			1820766107u,
			2672066139u,
			2244091203u,
			2099919844u,
			936057553u,
			3815091172u,
			2335287847u,
			1635908999u,
			1752284705u,
			3968552460u,
			3832209433u,
			866926795u,
			2045434473u,
			3157530045u,
			1582311098u,
			4289090998u,
			3628359199u,
			207249645u,
			1366960085u,
			2332347000u,
			2015722538u,
			1805703456u,
			2397937352u,
			384996355u,
			1402188394u,
			2472409553u,
			2278525923u,
			634488374u,
			2069164205u,
			2120240510u,
			1224139370u,
			444574420u,
			1550448457u,
			1506965402u,
			755454188u,
			2208638687u,
			1472696682u,
			625338355u,
			3516674223u,
			1684199676u,
			2608472171u,
			986051273u,
			1542662019u,
			1733306320u,
			3960313954u,
			2148890098u,
			35367405u,
			228656047u,
			1856873364u,
			63699462u,
			823876914u,
			3845980452u,
			3956873096u,
			1225226738u,
			267830872u,
			4264089558u,
			1258908541u,
			57793414u,
			4149159769u,
			3852448815u,
			61924597u,
			885614309u,
			1960459259u,
			3699933415u,
			495458263u,
			2199196158u,
			1545083474u,
			970298505u,
			4119020060u,
			975527455u,
			2574184300u,
			2971716661u,
			2609306043u,
			1829269047u,
			3047655100u,
			2893472991u,
			1898968108u,
			289080811u,
			2752720793u,
			1706705469u,
			1712776421u,
			4030217555u,
			3172803319u,
			284822169u,
			2260844756u,
			1678028512u,
			3518615857u,
			449192359u,
			1037166280u,
			1439195239u,
			3878043176u,
			2582730689u,
			1251822098u,
			4193047047u,
			4191747037u,
			1615485406u,
			548044353u,
			3643651280u,
			4172575053u,
			646755401u,
			4014735988u,
			3329648068u,
			2823670318u,
			3828108796u,
			1568929280u,
			2409478925u,
			4128475127u,
			1982081192u,
			839000782u,
			3019900465u,
			2758910607u,
			2755099950u,
			1542377774u,
			469757178u,
			240098823u,
			398158542u,
			4230801086u,
			2513259439u,
			1670199084u,
			1230145853u,
			3479519331u,
			1765108677u,
			101733460u,
			3867997173u,
			821056863u,
			952151981u,
			3988860499u,
			3060642546u,
			1178196601u,
			1947141382u,
			711129785u,
			2342663817u,
			483469815u,
			4054302194u,
			157199124u,
			3287381268u,
			3329966976u,
			3007645964u,
			1508577301u,
			2486626415u,
			3184163299u,
			2175287252u,
			2447338593u,
			2693669578u,
			1058806429u,
			1471139770u,
			3969728973u,
			2429441597u,
			223852307u,
			802634010u,
			3546365068u,
			866226268u,
			336029911u,
			95994554u,
			2408040412u,
			1627728054u,
			2191568095u,
			2779901523u,
			3566278776u,
			765119470u,
			115353344u,
			3706651929u,
			1718332234u,
			4000421646u,
			2399707316u,
			198010368u,
			684241860u,
			2458277137u,
			738131245u,
			324284478u,
			1826604312u,
			2755377728u,
			2694704295u,
			2416300480u,
			892236040u,
			3725179941u,
			1651540957u,
			2951679725u,
			1284982887u,
			2092505831u,
			2967227811u,
			3612437005u,
			2152980159u,
			2476601150u,
			490044474u,
			1294602208u,
			3992845126u,
			3851082087u,
			2555786725u,
			3056505085u,
			1041145044u,
			1470404370u,
			1043758172u,
			672322525u,
			2337374534u,
			2911545006u,
			4185455819u,
			4259195823u,
			3452931717u,
			1676633771u,
			1588919000u,
			338235465u,
			2170697036u,
			1246192267u,
			1938752080u,
			2362095309u,
			1000437687u,
			2511545393u,
			2717886278u,
			956797589u,
			1822894853u,
			2883811281u,
			1304678663u,
			2837687701u,
			1917286321u,
			1087682522u,
			2065787472u,
			1391998012u,
			307823115u,
			367382220u,
			411709112u,
			1371062392u,
			1023479396u,
			759789367u,
			2930568335u,
			3823861496u,
			4097384432u,
			4040022994u,
			207359608u,
			44259088u,
			3792401167u,
			3849814007u,
			756035008u,
			1090855383u,
			3965328014u,
			464768197u,
			3487640919u,
			458360644u,
			1764822073u,
			298758288u,
			892045663u,
			4271342158u,
			255367473u,
			2576208080u,
			2903716302u,
			603940646u,
			3585342878u,
			2398477424u,
			2663359871u,
			1508571091u,
			3190097217u,
			1550973186u,
			415743135u,
			853091605u,
			3622412532u,
			3347631529u,
			3099413996u,
			3950625831u,
			2062542979u,
			3771651791u,
			3839114838u,
			1658782665u,
			2531633134u,
			4094953870u,
			2301431366u,
			1819378870u,
			1510673036u,
			312905236u,
			2950113267u,
			3390503998u,
			3768544859u,
			1321142030u,
			2507025557u,
			3830422574u,
			3924589491u,
			3942028884u,
			405674698u,
			3330500154u,
			449104026u,
			3986984053u,
			249774572u,
			3334707868u,
			3400034437u,
			2702510038u,
			2163967659u,
			1109497921u,
			991697003u,
			294669018u,
			399432546u,
			4072895622u,
			4165019426u,
			1110149194u,
			838409320u,
			1426212749u,
			323841219u,
			3965999901u,
			3995419750u,
			250576335u,
			3174300074u,
			1004917988u,
			2943411068u,
			167793999u,
			267467370u,
			512883356u,
			945025913u,
			2338525967u,
			2814214800u,
			4169774109u,
			1418725254u,
			3152148775u,
			3511289914u,
			3552097243u,
			1537071496u,
			4051201520u,
			3846616539u,
			296207213u,
			2133423706u,
			292267515u,
			2463120751u,
			3413007995u,
			2094162805u,
			33271038u,
			4123209840u,
			2841833513u,
			4097065921u,
			2282211223u,
			177112029u,
			2565272208u,
			1971395962u,
			2135730164u,
			2236468792u,
			2197161301u,
			3248116447u,
			479107321u,
			2552766545u,
			215913919u,
			54525665u,
			2336732178u,
			2472994612u,
			3784922874u,
			3655681407u,
			4247963356u,
			3209854407u,
			2935704653u,
			1988804571u,
			1409461159u,
			911717426u,
			4256886748u,
			2085770508u,
			1253231967u,
			2230380259u,
			4006739232u,
			2108564935u,
			544985599u,
			371902928u,
			1596997294u,
			3490758598u,
			660369942u,
			1065762523u,
			847528002u,
			1038490831u,
			1682371471u,
			3213089767u,
			3708398201u,
			49227708u,
			3756814630u,
			343322320u,
			3700384023u,
			3501106161u,
			2311529930u,
			2961757542u,
			2925500396u,
			1262521975u,
			3909867841u,
			1545348716u,
			214636082u,
			1281983356u,
			585347732u,
			987505528u,
			89347840u,
			305699933u,
			1519578560u,
			4239845675u,
			3136700213u,
			1522879510u,
			4192780507u,
			2045770558u,
			3902772578u,
			3337339589u,
			3861641516u,
			1348768788u,
			3212831883u,
			2449623505u,
			412142574u,
			809901017u,
			764227085u,
			3018868149u,
			2667411014u,
			3039152054u,
			999728420u,
			451246612u,
			753418529u,
			1087733087u,
			2916815540u,
			1892597615u,
			2500068313u,
			1801586373u,
			538607560u,
			1586912158u,
			2346363607u,
			2521989685u,
			177479070u,
			672416688u,
			3648632942u,
			1961791139u,
			2356466267u,
			2283459771u,
			498495562u,
			2310234348u,
			1354089443u,
			1660474887u,
			795906110u,
			66467654u,
			621731721u,
			3900591153u,
			1311323169u,
			4401661u,
			1923805375u,
			2366687088u,
			2197834886u,
			3908139533u,
			2139134711u,
			1271505826u,
			2041064665u,
			1813310835u,
			1528854558u,
			2615663463u,
			3768511535u,
			2842089308u,
			4141054100u,
			1990145775u,
			1336724665u,
			2530211841u,
			2637391104u,
			4193081844u,
			1454241146u,
			4036332515u,
			1164611852u,
			2945405995u,
			3505759151u,
			1166036571u,
			2223049324u,
			4187734781u,
			2364042788u,
			329350267u,
			388221678u,
			922247217u,
			104280329u,
			790534u,
			4156795375u,
			2141837913u,
			1081022951u,
			2385223755u,
			2210901276u,
			2319747593u,
			22691171u,
			2365447879u,
			522217816u,
			3414735152u,
			624597043u,
			4206716992u,
			1813468006u,
			3816748062u,
			2361114371u,
			2726795722u,
			836740518u,
			234285995u,
			1950165971u,
			3473966296u,
			1282619487u,
			4291529943u,
			765861690u,
			4270118067u,
			1712266505u,
			233804900u,
			4235500975u,
			3939536470u,
			425342386u,
			3565534621u,
			1590457242u,
			2182679556u,
			1145839404u,
			463732943u,
			1526410312u,
			2417131482u,
			3372671800u,
			3029360340u,
			3197270845u,
			3703582690u,
			3234134612u,
			2675498957u,
			1238613473u,
			2409255553u,
			2127518310u,
			3814262830u,
			1842210311u,
			578093365u,
			1755355219u,
			3749974031u,
			4070837365u,
			47241722u,
			1287167261u,
			4203914647u,
			3367496022u,
			450865352u,
			3939255234u,
			2033895505u,
			564330774u,
			1472314818u,
			4277204499u,
			3041711213u,
			2825230530u,
			1410971784u,
			3014064520u,
			170585452u,
			3499504849u,
			226510539u,
			3753575844u,
			717953669u,
			1029649770u,
			3666017000u,
			3046330938u,
			2300728670u,
			2241951304u,
			1687583282u,
			2100964652u,
			3612246562u,
			1113879438u,
			1820920329u,
			1885344910u,
			2804234281u,
			2642112950u,
			2501123799u,
			848374547u,
			307514609u,
			2783913572u,
			994027660u,
			656961875u,
			2455788413u,
			52393257u,
			336419185u,
			3699791772u,
			3050309342u,
			2693223821u,
			1332387522u,
			121383809u,
			1273198996u,
			88121803u,
			3193957985u,
			3891461491u,
			3862893802u,
			666637873u,
			686618078u,
			1150409817u,
			1098013643u,
			3707919999u,
			3073484621u,
			1935326028u,
			3606158111u,
			3387369454u,
			3323694765u,
			3959839127u,
			890414223u,
			2022900811u,
			280152043u,
			1715632405u,
			3787948608u,
			3140387030u,
			512322776u,
			3767091382u,
			505264476u,
			4217877670u,
			3281320183u,
			3656763858u,
			555826792u,
			3752888690u,
			1420270317u,
			4269696405u,
			2262088767u,
			1697683335u,
			1379562927u,
			2861064825u,
			695651542u,
			2581301374u,
			817943947u,
			575121116u,
			4001362343u,
			2463492698u,
			2244967917u,
			594568118u,
			3703981622u,
			2870907718u,
			372295133u,
			406036893u,
			1114733077u,
			2857798636u,
			1008396229u,
			4163130711u,
			661283772u,
			305361708u,
			4137663573u,
			3782610938u,
			1301327547u,
			1327390699u,
			3202344327u,
			2492627095u,
			1248911480u,
			2071866456u,
			322614968u,
			3623634942u,
			234110598u,
			4267207310u,
			2206060521u,
			1972204390u,
			3082701596u,
			1529040884u,
			1240865985u,
			2269786345u,
			2144213412u,
			3299423993u,
			2817901889u,
			1023889662u,
			3009128755u,
			1567697423u,
			3229692591u,
			1325011189u,
			1212940457u,
			2004552639u,
			4234071030u,
			2893432372u,
			1809853597u,
			4154478551u,
			1864323450u,
			56678031u,
			489648157u,
			3292749115u,
			824176960u,
			2270904046u,
			2219591350u,
			823844416u,
			3623190260u,
			2685609213u,
			3117851000u,
			2637610024u,
			2229995122u,
			2954912520u,
			2004574233u,
			354781464u,
			2810138176u,
			1576446595u,
			810435364u,
			2167449825u,
			4036153167u,
			213737044u,
			2485901862u,
			1458159579u,
			2563463023u,
			2167959054u,
			139745476u,
			451341517u,
			2901603823u,
			1641298608u,
			544505469u,
			1196768948u,
			635965886u,
			3637419482u,
			553927863u,
			2840154159u,
			3640283431u,
			3883723305u,
			1533469492u,
			3524883610u,
			3906075582u,
			1183687232u,
			946742451u,
			3302669640u,
			682722123u,
			4172917647u,
			1994136437u,
			2871436551u,
			421407020u,
			497019723u,
			3885430854u,
			3995995900u,
			4273047132u,
			1592102625u,
			2791207912u,
			1094952766u,
			4010358244u,
			1851637329u,
			1663203029u,
			3451934739u,
			1176221752u,
			1742512651u,
			3925795351u,
			1794762453u,
			2507089581u,
			1562014078u,
			4154301003u,
			3714426823u,
			523946857u,
			2431233259u,
			4188010u,
			1101594745u,
			2795211592u,
			1036990240u,
			959153324u,
			3982850450u,
			1143978381u,
			3151500613u,
			1284305319u,
			3702694587u,
			2127106183u,
			1236125813u,
			3991116898u,
			1223933343u,
			2798215087u,
			3710074901u,
			1730880703u,
			3911525353u,
			2492829963u,
			289628056u,
			3929294935u,
			100556429u,
			1979387342u,
			3502472266u,
			902543522u,
			4137314512u,
			820853930u,
			3446732627u,
			471333541u,
			1497830513u,
			3201890031u,
			1562074686u,
			3963276995u,
			199905850u,
			2556364461u,
			1877060488u,
			607650338u,
			3063103535u,
			2190395669u,
			3968888798u,
			2795938394u,
			231211898u,
			2354047765u,
			3883999812u,
			494404247u,
			864816503u,
			2514103624u,
			266424497u,
			2307246646u,
			1408100811u,
			207477218u,
			2181293291u,
			3489800112u,
			2563812580u,
			1216495168u,
			1550722101u,
			3108204111u,
			3988897169u,
			1882348198u,
			3630639747u,
			240046543u,
			375247851u,
			2505406086u,
			3331321586u,
			3112794837u,
			1751647995u,
			2498312143u,
			2870789001u,
			2419887432u,
			2243110174u,
			3644259290u,
			1513858569u,
			374541231u,
			2632574454u,
			3998668681u,
			2334013855u,
			1112500410u,
			58352676u,
			3421796069u,
			2791364030u,
			1831874714u,
			4078419693u,
			463460010u,
			2782786923u,
			3938981499u,
			3794444006u,
			3331989902u,
			261427512u,
			4118012532u,
			1981282347u,
			538061816u,
			3198336010u,
			2283887222u,
			291502092u,
			1459540637u,
			219135067u,
			4127974914u,
			1035523204u,
			2096570376u,
			1192168094u,
			1236284726u,
			1533893253u,
			1985797882u,
			1404979200u,
			1005896970u,
			2274957303u,
			2607201163u,
			391663815u,
			3780312886u,
			4141728633u,
			4187604025u,
			3871453394u,
			830278076u,
			3213342432u,
			3052244338u,
			3666889313u,
			3618083036u,
			198774300u,
			2538966066u,
			2710429569u,
			1445462401u,
			2072659147u,
			3487371842u,
			4197909271u,
			2189648102u,
			279260671u,
			872706894u,
			1534195324u,
			2115146015u,
			3571562199u,
			2699938905u,
			1160127126u,
			3944114957u,
			1164690951u,
			520314162u,
			2114476735u,
			3794516630u,
			1280872718u,
			924867724u,
			1109364992u,
			1899867626u,
			2482894791u,
			1994471278u,
			2848444857u,
			1331146030u,
			3800182919u,
			1459254909u,
			1628756319u,
			2773953444u,
			3804143296u,
			3635351904u,
			3501856930u,
			3300566519u,
			1056734024u,
			3879433971u,
			722817863u,
			1358513704u,
			878492586u,
			1653035205u,
			1918098072u,
			667701618u,
			3319247754u,
			3848228954u,
			304148800u,
			1909260386u,
			1267542760u,
			1939990075u,
			1189137817u,
			3330578661u,
			3539080806u,
			1013551599u,
			1812487605u,
			1024038410u,
			431201856u,
			495197853u,
			2094504366u,
			4135528389u,
			2333360863u,
			2399770108u,
			81025272u,
			2353069737u,
			2912354659u,
			1350378135u,
			2996376093u,
			3692588395u,
			95527586u,
			3710443750u,
			1006652404u,
			492864002u,
			2482709795u,
			1480695306u,
			1683290709u,
			2052832463u,
			3736073209u,
			1744534316u,
			795485606u,
			2028211060u,
			161885509u,
			68454101u,
			1637786078u,
			58315151u,
			2235172408u,
			4183998692u,
			3546553745u,
			4185400822u,
			663230944u,
			886411386u,
			552619746u,
			1347663353u,
			3752965009u,
			3795692343u,
			2555039808u,
			1959737235u,
			3282846877u,
			3673582493u,
			475653327u,
			3936857053u,
			1590383191u,
			4280346436u,
			3191138617u,
			606904861u,
			3484561736u,
			1136586930u,
			1035869595u,
			1655513609u,
			3403253843u,
			439248962u,
			2769904666u,
			2986024876u,
			4126820033u,
			1846108791u,
			279183876u,
			1186899261u,
			3460951346u,
			3350039310u,
			2664257557u,
			62146050u,
			2872199334u,
			3989918589u,
			2692815521u,
			3852166803u,
			3156172145u,
			470760206u,
			1992115195u,
			1844482340u,
			832616056u,
			2343386771u,
			2975995543u,
			3524602823u,
			980546324u,
			1204272085u,
			64908532u,
			4232773483u,
			437926354u,
			3953592676u,
			1616428119u,
			1320593075u,
			1992285739u,
			3928655141u,
			1269546596u,
			3498595848u,
			806219758u,
			891088378u,
			4053698054u,
			1956007968u,
			2646900153u,
			4244688916u,
			3955747882u,
			219809804u,
			956282632u,
			3565165173u,
			1580995223u,
			2420852413u,
			652096207u,
			2716844945u,
			1042930517u,
			4009519396u,
			3631710329u,
			722320132u,
			2010748236u,
			2582280265u,
			3595721394u,
			2531337812u,
			200636887u,
			2168304270u,
			3431206082u,
			2150945481u,
			3218377428u,
			2439648419u,
			1642307359u,
			1961688071u,
			2039214337u,
			662366521u,
			1443315139u,
			1656786799u,
			1964050543u,
			199870044u,
			1082292319u,
			884672124u,
			2746951659u,
			3497424847u,
			1717491123u,
			113362492u,
			2009546348u,
			2086343696u,
			3403743682u,
			3759672967u,
			4171284256u,
			1161069179u,
			417155783u,
			2083750062u,
			3768275613u,
			1737176770u,
			2575441043u,
			902967243u,
			858955798u,
			1250953584u,
			569763481u,
			1984283440u,
			1829560263u,
			2631620775u,
			3453118815u,
			475726648u,
			3566259073u,
			3814531636u,
			3610109060u,
			2080109889u,
			3387559512u,
			3677081289u,
			3192138812u,
			2493797877u,
			2846503309u,
			1495014863u,
			1589682573u,
			3961562096u,
			2967591306u,
			4124355452u,
			3405234484u,
			98071603u,
			1460274020u,
			3711256902u,
			4180911517u,
			1424053887u,
			3714393012u,
			2416792957u,
			1564205540u,
			1750792506u,
			745778213u,
			2521852823u,
			3609749418u,
			1128070770u,
			2612324208u,
			3914569759u,
			21193905u,
			3246792690u,
			3454121299u,
			1004736028u,
			2618612155u,
			1592250166u,
			3879463090u,
			695308156u,
			909408933u,
			1827958750u,
			2106031807u,
			1312601338u,
			1594072938u,
			3705156248u,
			3688804733u,
			1688970691u,
			927888309u,
			888415291u,
			3884214537u,
			2654279688u,
			109904561u,
			3612256006u,
			1188238496u,
			1646922489u,
			1847192593u,
			1258778744u,
			1453267914u,
			2294798644u,
			2274724306u,
			4260431388u,
			3275062243u,
			3160119600u,
			1891589884u,
			352891311u,
			333443616u,
			3945708137u,
			2620570150u,
			3065384513u,
			1615140087u,
			35084240u,
			3339386074u,
			3610491814u,
			607800275u,
			2583182271u,
			3614242998u,
			106005617u,
			608640536u,
			2796792914u,
			3051171013u,
			1752977119u,
			2825459043u,
			653478828u,
			325880447u,
			1095865941u,
			4230488457u,
			2058193830u,
			890360034u,
			1024070852u,
			880963927u,
			1800373288u,
			1434040059u,
			2706306101u,
			2997049678u,
			779279565u,
			1594819407u,
			3094711992u,
			309192903u,
			218928044u,
			3841591955u,
			3349343366u,
			1638682944u,
			2241213259u,
			2888776755u,
			2803627610u,
			2099249594u,
			1727168538u,
			376158647u,
			2985121492u,
			3218359279u,
			3198869763u,
			133733669u,
			469901166u,
			2398545713u,
			2931287755u,
			2654455957u,
			3941545141u,
			1506202697u,
			1783123973u,
			2130340698u,
			4027359106u,
			4072075154u,
			3258537714u,
			3307820870u,
			3717386025u,
			3610748624u,
			1821335909u,
			1922013521u,
			3690195580u,
			2078456751u,
			1477577360u,
			4225708824u,
			3240429881u,
			2739868366u,
			4119982940u,
			1282744094u,
			1182917768u,
			687464538u,
			3388984566u,
			4280163299u,
			3383635335u,
			1570972453u,
			300557771u,
			3137033316u,
			877362554u,
			1000677368u,
			585063137u,
			2256008810u,
			1476611225u,
			2486312282u,
			1650125897u,
			1166236105u,
			4193484502u,
			1268085533u,
			3553326578u,
			2861831511u,
			391536025u,
			1727113705u,
			103934405u,
			4184243757u,
			2440862721u,
			488866551u,
			262329566u,
			4160199188u,
			737518911u,
			634294066u,
			3394035017u,
			343207518u,
			3437774500u,
			734595299u,
			468914972u,
			2924954212u,
			2834137189u,
			2265716849u,
			3740286757u,
			3950647407u,
			2219160707u,
			1140709053u,
			974108357u,
			262647559u,
			3926883004u,
			1669982876u,
			3696287938u,
			1635960148u,
			1778183481u,
			4053927639u,
			3712052477u,
			2727826516u,
			1579374770u,
			3971824533u,
			1441459516u,
			710268245u,
			186002016u,
			3544132875u,
			3925679553u,
			225184353u,
			739994997u,
			3794533894u,
			407701765u,
			3149391641u,
			4063613403u,
			936460397u,
			567699326u,
			720133383u,
			3685417677u,
			1339154859u,
			1810665149u,
			2015830818u,
			3333276779u,
			867026846u,
			2126156328u,
			2351610112u,
			3756846901u,
			1558207221u,
			3838526215u,
			1735166383u,
			144305462u,
			2493728566u,
			590813800u,
			3380134775u,
			446051619u,
			2173629924u,
			184870049u,
			1747289947u,
			3594238693u,
			3489417939u,
			3802760505u,
			937151661u,
			1857579351u,
			1599315417u,
			3335216904u,
			1587041934u,
			2465934397u,
			2615198217u,
			3022279947u,
			1408584895u,
			1318219741u,
			3369547665u,
			3832468958u,
			692947100u,
			2615852610u,
			2546174831u,
			3453210052u,
			874455354u,
			4014651712u,
			1205939792u,
			1208606543u,
			4284301869u,
			1004918590u,
			282498347u,
			3459999770u,
			1971875055u,
			853764302u,
			1794797187u,
			844533950u,
			2652807126u,
			788494334u,
			4199050856u,
			1860194761u,
			1151999587u,
			3927986916u,
			1837456658u,
			2913989688u,
			2374094983u,
			3165736387u,
			1866343853u,
			3229316550u,
			185836309u,
			3434039611u,
			2610907583u,
			1445307243u,
			4277884371u,
			1712101965u,
			1423966949u,
			3070653261u,
			3577479460u,
			1361114559u,
			1844595785u,
			1455331903u,
			1654882428u,
			452456011u,
			1460955698u,
			202101819u,
			1436471099u,
			826434415u,
			3144777168u,
			1256448585u,
			3832319219u,
			693272264u,
			1121763726u,
			21364830u,
			3201645961u,
			2896256082u,
			933740475u,
			1072683973u,
			790256679u,
			4185745055u,
			4018002150u,
			620968649u,
			2818415223u,
			379870152u,
			2468176771u,
			1365513045u,
			3391451016u,
			758217176u,
			1090009763u,
			3304889959u,
			2123080107u,
			4030786738u,
			2477310262u,
			2055246183u,
			1304391708u,
			3099172514u,
			2824241165u,
			1077631300u,
			1911570614u,
			1499833609u,
			3278630444u,
			4023080019u,
			2114509783u,
			337799307u,
			302198312u,
			3483212708u,
			719518212u,
			4223651318u,
			1099506149u,
			480576468u,
			1970103506u,
			2431772709u,
			3288476720u,
			783975484u,
			2108956258u,
			1812752622u,
			453992526u,
			3532274201u,
			12814337u,
			441837168u,
			4039196128u,
			696657249u,
			4170016423u,
			723446815u,
			2790277623u,
			2820960514u,
			335865303u,
			3527465078u,
			2890364346u,
			3276644977u,
			3437889519u,
			2253460350u,
			3612600359u,
			4179180739u,
			1972471220u,
			2479484809u,
			2063926414u,
			4120768592u,
			1388419955u,
			2488083939u,
			2317800250u,
			834136410u,
			2745166720u,
			1917350479u,
			2087885188u,
			157607864u,
			3988902171u,
			31285728u,
			212228902u,
			2804547309u,
			100904336u,
			1060189568u,
			2900780028u,
			2670371799u,
			876522013u,
			3730702022u,
			277081937u,
			1329343708u,
			2819255167u,
			2287997060u,
			3106838860u,
			3681281706u,
			884898098u,
			2296626621u,
			152033607u,
			2182248747u,
			4199100650u,
			761015841u,
			2592702418u,
			1902869940u,
			3384541188u,
			3013454607u,
			3680523035u,
			959763758u,
			2059202736u,
			794125813u,
			49131542u,
			3648682192u,
			3450645214u,
			718852354u,
			1818073818u,
			2311234707u,
			1094136587u,
			3786683979u,
			1762436363u,
			2986377826u,
			3161432909u,
			1544284399u,
			950700112u,
			647749173u,
			324234569u,
			906921189u,
			1323666753u,
			1164800841u,
			633926351u,
			562912810u,
			2339308893u,
			2463450379u,
			271436858u,
			550878676u,
			571458161u,
			3592463186u,
			3685142352u,
			1650300438u,
			409620193u,
			1381551532u,
			3196252630u,
			1522506196u,
			3694404062u,
			1154620986u,
			2889643289u,
			4038304818u,
			800342861u,
			241445832u,
			2771494912u,
			668894199u,
			2750080108u,
			3166940586u,
			2075582687u,
			1083413058u,
			2487216438u,
			1442807007u,
			2722548537u,
			2809179849u,
			3967839967u,
			149773294u,
			124698474u,
			138226434u,
			1155025436u,
			2350812946u,
			2639138324u,
			807413049u,
			793678497u,
			3950308260u,
			3916364211u,
			1973776500u,
			3420935030u,
			3038904242u,
			4018529393u,
			2159843284u,
			2576726187u,
			1716552214u,
			1796269273u,
			2331758420u,
			3335141979u,
			846584584u,
			1375614678u,
			1060661549u,
			3589889739u,
			2843659227u,
			1575465266u,
			15678557u,
			224239780u,
			2585033156u,
			1240937608u,
			360763573u,
			1801022121u,
			1282770012u,
			2660236028u,
			1599983867u,
			3253703625u,
			291888180u,
			3566683253u,
			3483290207u,
			2735432667u,
			135447654u,
			2250352553u,
			936917859u,
			1642366063u,
			82356259u,
			3138262015u,
			2637559425u,
			2597573029u,
			3746352197u,
			4043303514u,
			2679288491u,
			208828071u,
			2548629925u,
			949217347u,
			612482476u,
			3715220261u,
			764805693u,
			1740355236u,
			174905267u,
			1590223758u,
			2097390652u,
			3618365007u,
			1524806360u,
			2628968038u,
			3453832297u,
			2749361694u,
			1867248640u,
			3417215666u,
			2603610561u,
			3010463890u,
			4276066213u,
			1836903055u,
			4025298328u,
			363591074u,
			2259362785u,
			3898428381u,
			3476507949u,
			2746068325u,
			3906478057u,
			2232281556u,
			2244260218u,
			3106405284u,
			3720974943u,
			2904877749u,
			1745526029u,
			3389841331u,
			1208092726u,
			103223120u,
			1880158372u,
			4170547278u,
			31387414u,
			2766459326u,
			434710380u,
			1003464311u,
			804810624u,
			782444488u,
			1477756220u,
			3834276658u,
			55825944u,
			4253417436u,
			3794615080u,
			79872072u,
			3100630785u,
			2723154711u,
			783592675u,
			382593680u,
			2019500979u,
			1554761695u,
			4178746529u,
			1964324355u,
			561338327u,
			1048459418u,
			808076230u,
			3955667362u,
			4129386194u,
			1130572092u,
			2919732869u,
			3563272601u,
			2027406047u,
			74055354u,
			2173059645u,
			3933028224u,
			2670202638u,
			2128192592u,
			2008025953u,
			3094847618u,
			2091915373u,
			2958575929u,
			2555355236u,
			3014300198u,
			3207554604u,
			3052195933u,
			958840810u,
			2517024734u,
			1389371317u,
			1578609402u,
			247800807u,
			1245858683u,
			676750732u,
			1482263386u,
			282614601u,
			521190920u,
			3287540098u,
			1702715063u,
			3197044838u,
			2552935677u,
			216647458u,
			1787790202u,
			2390534064u,
			1818165148u,
			3443370492u,
			3677566046u,
			596098932u,
			350416140u,
			880035918u,
			372412158u,
			1547911518u,
			1904977852u,
			2471453828u,
			3849075101u,
			723354914u,
			3228716969u,
			2862243566u,
			1496761289u,
			1686528390u,
			1399692006u,
			2380016310u,
			796834936u,
			3482221370u,
			1890966152u,
			2229385226u,
			2489722872u,
			1062072635u,
			3566662093u,
			3011040178u,
			2896163168u,
			500723837u,
			1156569982u,
			2946387889u,
			2825012922u,
			3674530706u,
			1943230925u,
			670610208u,
			1131195690u,
			3440352222u,
			3575660248u,
			3871199337u,
			493172153u,
			2427576606u,
			1633541409u,
			2834069437u,
			4181670060u,
			448196313u,
			3720397377u,
			1718706599u,
			2763103701u,
			45407493u,
			2091912085u,
			2635603868u,
			2787600375u,
			1719045078u,
			1886603282u,
			976500392u,
			2453391766u,
			4062361319u,
			2419674226u,
			1118716580u,
			999619593u,
			3087913064u,
			1997407217u,
			1840790626u,
			1865428704u,
			2235558968u,
			1708216304u,
			3021556681u,
			2183477648u,
			3632929560u,
			658501332u,
			4215658320u,
			2646692733u,
			3957953249u,
			2529481332u,
			1405698077u,
			3129568293u,
			224790296u,
			2845857393u,
			508722u,
			3908618203u,
			2354633550u,
			3939917549u,
			3848123554u,
			184644930u,
			2381967564u,
			2008355667u,
			2497400774u,
			4111328938u,
			993783119u,
			3296776752u,
			2906493610u,
			2612389393u,
			1453418728u,
			1661261309u,
			3710651708u,
			1605572317u,
			474645462u,
			1028834625u,
			2516666090u,
			3196966302u,
			3188494539u,
			3794244545u,
			3643839695u,
			15878997u,
			1374366135u,
			19365108u,
			3937692703u,
			1938952278u,
			3312360860u,
			1418197373u,
			414795636u,
			1157606857u,
			1916448599u,
			4022061966u,
			4119489613u,
			1118762394u,
			4267482311u,
			3179374911u,
			2113407817u,
			1332884987u,
			2678631436u,
			3597522303u,
			4040077459u,
			542337678u,
			2345395476u,
			1109438992u,
			3252163622u,
			726190613u,
			3976182979u,
			2469356447u,
			22333667u,
			682667338u,
			2662729431u,
			2360941851u,
			760165603u,
			4062582365u,
			835193585u,
			2291885745u,
			3573448374u,
			3758735460u,
			3411723602u,
			2955375822u,
			2544625714u,
			1678511344u,
			1474851184u,
			3177732881u,
			1497025693u,
			4202982688u,
			2679930430u,
			197369393u,
			2051966805u,
			1727221200u,
			3876540832u,
			3955661690u,
			1914913065u,
			1423965389u,
			863278803u,
			4159062138u,
			433652034u,
			2167820548u,
			4051567350u,
			396088903u,
			2760885826u,
			2639466293u,
			3569282381u,
			2307044415u,
			1297843881u,
			3816397560u,
			2236298820u,
			4229064353u,
			4189643964u,
			293532941u,
			3955571012u,
			3885236993u,
			1259517334u,
			1953270210u,
			2591709363u,
			3781483676u,
			1656223712u,
			3381707930u,
			2045489984u,
			2856442318u,
			2404836026u,
			3595391444u,
			2615992820u,
			2490364915u,
			1767073953u,
			1589535347u,
			1542432793u,
			2699247625u,
			3256604432u,
			3104200629u,
			1342989089u,
			1766496328u,
			3254828744u,
			2706340869u,
			895116826u,
			1688040732u,
			949370450u,
			2213502026u,
			3114856666u,
			1805468394u,
			1206833949u,
			727803522u,
			1791336992u,
			1447299933u,
			3868525857u,
			2424889269u,
			3925238902u,
			1080176672u,
			3569051584u,
			2506603610u,
			1656030606u,
			163959295u,
			3822534492u,
			336401632u,
			1162224905u,
			2645406820u,
			1906660927u,
			2895479747u,
			2864482279u,
			622111980u,
			252720779u,
			2574354876u,
			1955063214u,
			3644735548u,
			3703723881u,
			3754820594u,
			649405076u,
			2940029557u,
			632743230u,
			2535526272u,
			732838620u,
			3564483810u,
			4195381390u,
			3290630673u,
			3110379526u,
			1038441545u,
			973602243u,
			911053620u,
			229062554u,
			1303123875u,
			1276245038u,
			3786624140u,
			2902374220u,
			3005788324u,
			580752019u,
			536185763u,
			759721552u,
			1624016100u,
			2565408957u,
			568099995u,
			2879376534u,
			4162098237u,
			3541064311u,
			140585529u,
			862466743u,
			225985846u,
			1551919499u,
			2279391832u,
			342212918u,
			2040379133u,
			4234694041u,
			1674035900u,
			2256119397u,
			1735620815u,
			1067834526u,
			1121578339u,
			2201473041u,
			858845639u,
			1966146579u,
			3647351482u,
			3181010715u,
			2195763719u,
			2752237646u,
			689816658u,
			2846154790u,
			2546250244u,
			3104181818u,
			3553616650u,
			3953393109u,
			3631856092u,
			975921729u,
			901126840u,
			3261336435u,
			1626238892u,
			775915869u,
			2802608430u,
			3891274099u,
			323409968u,
			2508666944u,
			2828077637u,
			645270017u,
			366232144u,
			1959741720u,
			1188211430u,
			414639813u,
			2261149353u,
			2628543243u,
			1292050440u,
			3391638161u,
			4059554671u,
			1654459937u,
			1712484005u,
			3506298442u,
			3828396546u,
			3281321232u,
			2288362049u,
			1561349054u,
			2201285079u,
			1697477527u,
			3872885048u,
			2605498140u,
			2892847567u,
			1220802585u,
			4235073454u,
			2457408779u,
			1923755186u,
			3498074984u,
			3311021169u,
			3312280114u,
			756724053u,
			2666682490u,
			3633215435u,
			1892932363u,
			3726054977u,
			4283981782u,
			1465911308u,
			1981565413u,
			3095482718u,
			137044346u,
			830828565u,
			3850183089u,
			3172466034u,
			2560102985u,
			4159661115u,
			608618528u,
			2921909731u,
			2626462551u,
			48925005u,
			2456059782u,
			3061767703u,
			3131776344u,
			1652773546u,
			2861181688u,
			1830081005u,
			3846498769u,
			2365094272u,
			3915026080u,
			635084855u,
			1874314781u,
			67888019u,
			3218068780u,
			2986903649u,
			3705871831u,
			452216932u,
			1238129215u,
			2361947484u,
			1982915403u,
			3012788931u,
			2296711511u,
			753362862u,
			4060394463u,
			2306905605u,
			2210272460u,
			2384734190u,
			265378701u,
			3249569632u,
			2460779027u,
			282046831u,
			3354277878u,
			1891799496u,
			3002325647u,
			3241941721u,
			1464156720u,
			262754348u,
			2684169300u,
			2002411140u,
			2493468912u,
			3109397294u,
			1585487709u,
			2146247306u,
			2602537372u,
			3135057993u,
			3384153674u,
			649454923u,
			2614560890u,
			1538338838u,
			2111805113u,
			1778591635u,
			3757666110u,
			344874817u,
			3283283101u,
			3620526890u,
			2434689514u,
			971056779u,
			3315760194u,
			1156112006u,
			2367731131u,
			3609004168u,
			1565592767u,
			2915566017u,
			660483528u,
			3491618698u,
			1773395469u,
			1206701937u,
			4204468364u,
			1178879118u,
			1721594065u,
			278156736u,
			4175158461u,
			1054639854u,
			249409245u,
			1231381444u,
			588314455u,
			3554583252u,
			2096664653u,
			2058129167u,
			1884925177u,
			4067936013u,
			2363120748u,
			3157992079u,
			2595340400u,
			2090404138u,
			3429783808u,
			2812489710u,
			224863769u,
			1985649913u,
			4123299839u,
			1486148007u,
			3467743353u,
			2604177068u,
			2924022444u,
			2508293493u,
			972737826u,
			3762539177u,
			2177010998u,
			4232188169u,
			337764912u,
			3494804836u,
			689009577u,
			3449428652u,
			94404393u,
			695637060u,
			3723481268u,
			3906211606u,
			2176244313u,
			3144662240u,
			811018733u,
			780866220u,
			3282387185u,
			3665642056u,
			3713444931u,
			3370900979u,
			1071317584u,
			4280460914u,
			2188976915u,
			3450265892u,
			3721746055u,
			3380396239u,
			986712291u,
			3518154034u,
			1569766272u,
			612826481u,
			1933614552u,
			1097448168u,
			97875792u,
			1299271011u,
			2976302459u,
			1773325893u,
			296120852u,
			1280182368u,
			2690233872u,
			862879936u,
			762330102u,
			2835970693u,
			3808600045u,
			3137292606u,
			1117708073u,
			2941835159u,
			1469671698u,
			2755148994u,
			349504783u,
			2684861467u,
			974368569u,
			3618637453u,
			3887550810u,
			1825296148u,
			2247007559u,
			3269731442u,
			1600541739u,
			300580589u,
			4272011238u,
			2337313402u,
			281707195u,
			4000536309u,
			2928781118u,
			1219613894u,
			2935693028u,
			2643401029u,
			2630740690u,
			1076325839u,
			2724292750u,
			1535721666u,
			1836256918u,
			373972154u,
			3055251548u,
			3249011274u,
			727224027u,
			1891244683u,
			2971362423u,
			880105566u,
			2129045457u,
			442141602u,
			1336404383u,
			2825294093u,
			1327599353u,
			2219286007u,
			3516006511u,
			1525673526u,
			4122276977u,
			899513087u,
			2384577157u,
			1845322151u,
			3847467094u,
			1978397921u,
			3782767861u,
			3804512436u,
			568067556u,
			2452868168u,
			2777277946u,
			1034404307u,
			1833284309u,
			1333795722u,
			3994690980u,
			3583666193u,
			3769286806u,
			757013037u,
			2950463754u,
			515024647u,
			3036182850u,
			1072414819u,
			267577130u,
			3334844922u,
			4211181829u,
			3795521070u,
			2465905944u,
			2464223538u,
			2874060178u,
			3871183067u,
			3500596012u,
			2409533075u,
			3673481398u,
			2212212633u,
			4213355207u,
			2966733240u,
			1336585653u,
			4241825202u,
			1071158939u,
			4235553730u,
			1578607799u,
			299069945u,
			793545604u,
			4126307409u,
			3722305285u,
			2098723430u,
			3284931819u,
			1559685760u,
			869180649u,
			2461289958u,
			2717026398u,
			2265230045u,
			4142908054u,
			2117594728u,
			80165790u,
			1321566296u,
			3161580846u,
			1687408512u,
			4178000072u,
			455313928u,
			2717447364u,
			1013138153u,
			1016449076u,
			3795892882u,
			1031725906u,
			214058017u,
			3627204566u,
			820945377u,
			1920153374u,
			2488514284u,
			1940555381u,
			601612128u,
			1478868478u,
			3083218837u,
			2925868973u,
			4105080596u,
			4228287129u,
			2113670104u,
			1864008118u,
			1002342677u,
			3490131156u,
			1388172072u,
			2197476221u,
			3322771106u,
			927224663u,
			36008432u,
			3556045013u,
			3497674774u,
			2599755201u,
			3073217931u,
			2631313326u,
			1455202796u,
			127023612u,
			2735752870u,
			729252626u,
			3825663847u,
			2657235693u,
			2662471158u,
			4117203235u,
			1425849072u,
			3375583168u,
			3328246195u,
			3071502750u,
			766119015u,
			595294494u,
			1776391132u,
			3124885789u,
			942784003u,
			1622896045u,
			3492620947u,
			3299089027u,
			2325876561u,
			3998901136u,
			10281551u,
			2399106843u,
			3510123000u,
			1448063977u,
			1808864506u,
			3366172678u,
			1332476391u,
			3050327061u,
			1256605156u,
			1780471445u,
			1429657515u,
			4113864838u,
			884683606u,
			3715815250u,
			528251885u,
			2375497376u,
			3814325122u,
			144570967u,
			88705395u,
			2558487700u,
			2310616092u,
			1900119168u,
			373233604u,
			4262693011u,
			249288808u,
			908902120u,
			3940298483u,
			522358080u,
			1023858946u,
			899124120u,
			2123826455u,
			4255638474u,
			1045112698u,
			868621719u,
			3483695656u,
			137233612u,
			2701863151u,
			4138488288u,
			3503867758u,
			3654594888u,
			3965859421u,
			4291209506u,
			2162458021u,
			1584943552u,
			3998291117u,
			2801730804u,
			357498246u,
			1023981126u,
			3527572104u,
			1749405099u,
			294484430u,
			3849876716u,
			482098431u,
			1905252962u,
			3831972758u,
			1709979798u,
			3859296855u,
			2234888540u,
			109982851u,
			2926674747u,
			491319177u,
			3543998499u,
			582804563u,
			1508667704u,
			3679119443u,
			2666054566u,
			3462034254u,
			280385080u,
			1342410669u,
			1439678430u,
			1835801499u,
			2721674959u,
			3140562467u,
			3271243974u,
			761766662u,
			548493525u,
			2654550063u,
			3466206004u,
			4285830219u,
			478214521u,
			1917445296u,
			1836684745u,
			325301282u,
			4208936442u,
			2005805298u,
			2143686109u,
			2515167472u,
			1967461893u,
			1998535959u,
			3869279845u,
			2583926257u,
			1125635487u,
			946854760u,
			119884221u,
			2715048383u,
			3774720815u,
			2078908969u,
			3910973634u,
			2867027171u,
			38083256u,
			692016149u,
			4022359899u,
			3261478312u,
			2451732046u,
			1456649046u,
			2752104780u,
			3684308454u,
			1779081276u,
			709191301u,
			2576062602u,
			2000118073u,
			3181445522u,
			957531579u,
			2622963013u,
			1093606826u,
			3114548301u,
			1296228656u,
			3627016431u,
			2311691826u,
			2053979491u,
			248340318u,
			3171554282u,
			2052348181u,
			830569026u,
			3739757203u,
			3389145472u,
			1151543597u,
			1997204736u,
			4191697293u,
			65116319u,
			3343120304u,
			1282254746u,
			2052867121u,
			4229112866u,
			396244615u,
			3122183185u,
			3415706183u,
			2471466226u,
			1225647434u,
			2427290298u,
			1240807832u,
			2113653446u,
			847074784u,
			1985854394u,
			2654514369u,
			3327363726u,
			1535073132u,
			4141193672u,
			903051401u,
			336367188u,
			4157283318u,
			2137138171u,
			2131696367u,
			2049045324u,
			917912411u,
			4078926937u,
			1508327733u,
			1979396527u,
			2891585650u,
			3589570704u,
			3098470386u,
			1057678006u,
			1946212145u,
			4118264559u,
			2006328389u,
			2789269431u,
			2577980848u,
			3358284698u,
			2512208346u,
			4202051730u,
			24754864u,
			155433187u,
			638327113u,
			2747550695u,
			3621644185u,
			2509728885u,
			43144968u,
			2089433584u,
			4075633394u,
			2544288489u,
			2259207853u,
			818288582u,
			2510621574u,
			3755853224u,
			3803720890u,
			3069655768u,
			3782356620u,
			3956918256u,
			1191632338u,
			3052880464u,
			1656437856u,
			2808736570u,
			747729740u,
			2476016364u,
			3441125924u,
			384332625u,
			1161805314u,
			3801700485u,
			3137335297u,
			4009205412u,
			2375991132u,
			3627382305u,
			469521985u,
			3048476259u,
			3377552652u,
			287723466u,
			3410784403u,
			2238016840u,
			1701649074u,
			74376973u,
			3559106210u,
			134431121u,
			2481649012u,
			2231621327u,
			1186825110u,
			3346641594u,
			1777039199u,
			646795838u,
			2530789716u,
			661752679u,
			604075285u,
			617953356u,
			2681623699u,
			1285432967u,
			1431536775u,
			3693045823u,
			894748767u,
			2614383361u,
			4263460947u,
			3870697512u,
			3417006996u,
			578289181u,
			3209593357u,
			2739863895u,
			3607819138u,
			1316409182u,
			4179243588u,
			1590587604u,
			2815341083u,
			607161665u,
			2711608140u,
			1926464611u,
			2940043631u,
			1168770374u,
			1342874823u,
			3666586061u,
			135007860u,
			2376261057u,
			850435917u,
			3493163753u,
			927821289u,
			2594691085u,
			2733197010u,
			2718977268u,
			1226153620u,
			3762652020u,
			2610393590u,
			3411642999u,
			1714224283u,
			839384260u,
			2105035442u,
			368876730u,
			1058691005u,
			1301553472u,
			1117680759u,
			2057202036u,
			3519746252u,
			70113585u,
			210206796u,
			2381134867u,
			2172344884u,
			2652522575u,
			3343832422u,
			955226233u,
			2027563333u,
			1053244900u,
			1001446074u,
			3995942363u,
			1123123328u,
			1601930188u,
			1475462518u,
			2241153536u,
			1472818433u,
			2838557793u,
			64926259u,
			939771915u,
			2176939994u,
			3581068912u,
			2417900218u,
			2387530672u,
			328264378u,
			300287244u,
			3253157953u,
			4022363070u,
			370449327u,
			906855277u,
			1292064944u,
			4006961586u,
			1118566136u,
			234612121u,
			498862379u,
			2463402514u,
			3274852364u,
			2266268485u,
			244621741u,
			3420301073u,
			2154136727u,
			2017960404u,
			851773986u,
			3542378182u,
			1680189007u,
			1591901502u,
			2284979108u,
			469584423u,
			1853088459u,
			1794963325u,
			4068717569u,
			141457397u,
			3927713004u,
			44046466u,
			53577850u,
			1435314701u,
			3740879164u,
			3326558807u,
			426417538u,
			4007566152u,
			2358886449u,
			3024743193u,
			3548746694u,
			1093760167u,
			1067796707u,
			382535281u,
			2734116896u,
			4294041895u,
			5863497u,
			2783527092u,
			3861885688u,
			776484443u,
			4039923135u,
			3920486200u,
			3401593847u,
			2916760774u,
			1261747608u,
			3236969424u,
			18718056u,
			1552886531u,
			1319253838u,
			2596764411u,
			3654264340u,
			3177948998u,
			3205969680u,
			1288306521u,
			3177277292u,
			2529664484u,
			1247064005u,
			2149326583u,
			2809625805u,
			2146151409u,
			2849659649u,
			3287316939u,
			1917895763u,
			2967513948u,
			170251608u,
			702396035u,
			2013580831u,
			3028552386u,
			4250662235u,
			2243586285u,
			551107453u,
			1419604501u,
			2788806368u,
			1022586585u,
			1001279237u,
			625853667u,
			6312258u,
			3772593536u,
			3527096662u,
			3766762847u,
			1633899892u,
			3659938788u,
			2082721488u,
			3354847609u,
			2686795514u,
			4197479435u,
			445357036u,
			1951729245u,
			3847730374u,
			3714336815u,
			344055225u,
			3862041713u,
			3589681784u,
			4006635810u,
			3064304941u,
			2152518598u,
			15243876u,
			53146694u,
			627777585u,
			7848637u,
			3356601494u,
			1883337549u,
			2270333671u,
			277881049u,
			847509833u,
			1077816280u,
			1780970546u,
			2518289738u,
			2902518809u,
			3335950763u,
			793868663u,
			3308199666u,
			3547128356u,
			2878486590u,
			3407033119u,
			291964505u,
			209582029u,
			1047635863u,
			662400432u,
			2311251476u,
			3687476816u,
			3339240304u,
			3135482931u,
			633887386u,
			116902175u,
			3250904559u,
			1162811223u,
			71720387u,
			3489683417u,
			41028656u,
			2606812091u,
			3598868447u,
			3985974748u,
			16819495u,
			1130756231u,
			2263499566u,
			1010520338u,
			2269675567u,
			342472548u,
			3353508333u,
			2495322054u,
			2055257173u,
			1316894938u,
			1584623979u,
			103283177u,
			3850052432u,
			1930389875u,
			1232951205u,
			483353299u,
			206604797u,
			643689414u,
			2317237843u,
			1210567527u,
			1613312522u,
			3334633831u,
			2582025919u,
			4242153167u,
			3157489721u,
			4054945912u,
			742631062u,
			520113279u,
			3140023406u,
			1266895789u,
			4252394141u,
			3114706049u,
			1748511043u,
			4029799573u,
			309520311u,
			1790168180u,
			265325652u,
			4165093324u,
			3977282651u,
			492005475u,
			4269790521u,
			3254836342u,
			886835608u,
			35164122u,
			2728724925u,
			2073481795u,
			1791586827u,
			310569159u,
			3062335997u,
			4129658954u,
			1133622183u,
			2077679332u,
			155685983u,
			2229526851u,
			2113265975u,
			3277303311u,
			1523515033u,
			393730136u,
			479419841u,
			23605693u,
			1000753446u,
			4180221792u,
			1038240536u,
			3222595115u,
			958220811u,
			3103230563u,
			3412323625u,
			3622832200u,
			1865435975u,
			3616513042u,
			3555920301u,
			2710695042u,
			2984870053u,
			848406814u,
			4186852809u,
			2346995798u,
			2148560409u,
			1347658921u,
			1687996330u,
			545492571u,
			1385831131u,
			587483170u,
			4107126134u,
			3349908815u,
			2592063239u,
			2172911203u,
			3562131593u,
			2896056265u,
			2130544350u,
			650732820u,
			2605755197u,
			3440454859u,
			3978266029u,
			2857036572u,
			1096083358u,
			1790399111u,
			1829529205u,
			2287582762u,
			2279310007u,
			1402633284u,
			745615664u,
			2388052113u,
			27886982u,
			1176306593u,
			3614482217u,
			838905001u,
			2961212290u,
			1657093686u,
			3021999477u,
			2500903781u,
			1645218305u,
			3581850804u,
			1511130189u,
			3107269215u,
			4165297206u,
			3218941088u,
			2735462657u,
			1336376669u,
			3908992422u,
			2001948180u,
			1642407487u,
			3359060902u,
			1845574467u,
			2181246121u,
			1309462522u,
			1532438603u,
			4262186629u,
			2466406744u,
			1941870807u,
			2637172923u,
			3909878814u,
			1889135466u,
			3848773460u,
			1865584538u,
			3075677652u,
			1930240333u,
			658292876u,
			1016027032u,
			504941243u,
			1708818199u,
			3759218710u,
			1963544326u,
			1023907717u,
			2691143175u,
			4108673602u,
			3251604264u,
			65801768u,
			2178336917u,
			1213862733u,
			604420009u,
			3709491263u,
			1897767345u,
			3242513801u,
			928505510u,
			2324979615u,
			3234125973u,
			3088548309u,
			980344394u,
			1190433514u,
			1030992995u,
			1479379909u,
			4140331963u,
			2218794363u,
			1551991613u,
			2054104738u,
			2773044117u,
			1468665671u,
			1152243458u,
			1042589551u,
			1645221004u,
			454236249u,
			3971832579u,
			531931072u,
			1303139973u,
			1932728005u,
			1007701855u,
			1289213712u,
			1779360721u,
			3288835343u,
			91687824u,
			810669605u,
			1494273436u,
			3299081780u,
			569395758u,
			1039318644u,
			2503768091u,
			3884518640u,
			2180292775u,
			1326150678u,
			3105603917u,
			2342258864u,
			3671809224u,
			3642627687u,
			3086806682u,
			29007774u,
			3192354384u,
			3716373501u,
			4015369518u,
			2939588860u,
			3720512336u,
			2658965024u,
			1101809835u,
			3253788803u,
			2192750201u,
			1575437436u,
			1475927033u,
			17667308u,
			307029286u,
			1152706812u,
			2084876601u,
			1603910513u,
			4127416896u,
			3078082771u,
			380981941u,
			295332651u,
			2811526828u,
			626985518u,
			1300963389u,
			3740500103u,
			3509991105u,
			2764934141u,
			1577795634u,
			3670759002u,
			1257464948u,
			2836793242u,
			3733620006u,
			944919281u,
			3447795070u,
			1874352443u,
			3959282006u,
			3465874695u,
			1184882680u,
			4036252065u,
			3097543770u,
			1440121784u,
			2091643174u,
			1710703922u,
			1844750196u,
			2760885906u,
			2765254029u,
			3045146250u,
			1482316376u,
			605783297u,
			3857265728u,
			3562621653u,
			396362338u,
			1181571896u,
			2949556005u,
			2649347642u,
			3689143100u,
			2719766193u,
			3598999501u,
			4162962949u,
			99410012u,
			3265086486u,
			14402060u,
			351821324u,
			3007567823u,
			2076382737u,
			2926735335u,
			3031896979u,
			1308721768u,
			2489236072u,
			958145492u,
			2973641578u,
			1201024921u,
			724557844u,
			272416648u,
			4025766727u,
			1431859476u,
			2914390276u,
			3967876844u,
			4069654391u,
			1378283718u,
			1100942107u,
			6989795u,
			1773284100u,
			2680216571u,
			3927429622u,
			2351269665u,
			2206903906u,
			3093591599u,
			1618900993u,
			3566584836u,
			4235998527u,
			1239108823u,
			3833346775u,
			1081490569u,
			3749308851u,
			1993287140u,
			3111192953u,
			1534953535u,
			47247470u,
			387059820u,
			3145246554u,
			4279384035u,
			3167165810u,
			2525101687u,
			2907298816u,
			751798315u,
			47907417u,
			532682529u,
			2366130018u,
			3503636958u,
			1675333118u,
			2946745415u,
			205720141u,
			1355935015u,
			1872241285u,
			3884358099u,
			1477568769u,
			1898621656u,
			3083530361u,
			2987729726u,
			1083946625u,
			3396209396u,
			2167886976u,
			1934400845u,
			4172797387u,
			1635074157u,
			2487290382u,
			3982267244u,
			1540235077u,
			143870775u,
			1013675182u,
			3851407226u,
			1430983748u,
			2069915334u,
			1103692058u,
			4066865136u,
			2937594924u,
			794925114u,
			3078147739u,
			1587058977u,
			3669182655u,
			1325217902u,
			815750264u,
			3413564937u,
			2380540482u,
			520387564u,
			3288621717u,
			1385431991u,
			756219747u,
			2532514081u,
			2111434489u,
			2488609219u,
			3391655605u,
			754055048u,
			3696110793u,
			2668487921u,
			3064257780u,
			2814924264u,
			3825726014u,
			895678352u,
			3939514976u,
			3778327563u,
			1006171310u,
			2966400997u,
			447603241u,
			1332621541u,
			18748925u,
			4079851956u,
			3550936460u,
			2178384884u,
			59450664u,
			3122592283u,
			2236554904u,
			2768115532u,
			4135263883u,
			1252853362u,
			349646272u,
			2156521729u,
			3813508705u,
			3696949620u,
			2012837690u,
			2239004583u,
			3749256356u,
			1763577525u,
			3640079101u,
			430444948u,
			3977405288u,
			1319080369u,
			3266697065u,
			991719372u,
			1571921864u,
			3141366777u,
			3204585995u,
			2779687018u,
			4181928065u,
			3939794827u,
			4046734413u,
			1975436942u,
			3884715530u,
			2647518396u,
			2626388212u,
			329616805u,
			2623817234u,
			2103509519u,
			1799542796u,
			3665906842u,
			3103833333u,
			3577608350u,
			1192098961u,
			2435772611u,
			1565776920u,
			1610842275u,
			521155852u,
			1997883463u,
			480194642u,
			485238265u,
			1024048259u,
			2919028417u,
			937179846u,
			1364759231u,
			1081928884u,
			2127068894u,
			543813673u,
			87715675u,
			4010589143u,
			4182440435u,
			3670972497u,
			3889318555u,
			4045846003u,
			2231122187u,
			3579079234u,
			3109772454u,
			2717286123u,
			1063926354u,
			416103948u,
			1973746151u,
			3718337310u,
			432506477u,
			1660698868u,
			2275968215u,
			3467473367u,
			3905707197u,
			3318738499u,
			1442921578u,
			1485394471u,
			543648613u,
			4195799214u,
			3698630792u,
			3575488661u,
			3209653258u,
			80776025u,
			2780358534u,
			1884070279u,
			3424064218u,
			2476712059u,
			4182579080u,
			876464358u,
			2013047369u,
			1469456796u,
			2986294085u,
			2012924721u,
			1195596314u,
			954765534u,
			1218043244u,
			2045523598u,
			2001595622u,
			478460097u,
			3720684976u,
			659179861u,
			1935852570u,
			2754478571u,
			342874362u,
			3743799959u,
			2636607463u,
			3899152631u,
			2735349333u,
			733208272u,
			2955913991u,
			1379376610u,
			3891359369u,
			3220898918u,
			2732025386u,
			862528535u,
			4164718806u,
			1747843421u,
			3412808810u,
			812825487u,
			3274278767u,
			3430824374u,
			2108951817u,
			593315361u,
			3685514534u,
			1071969362u,
			4245336103u,
			3114973604u,
			98359731u,
			2449304503u,
			1555846802u,
			1557719788u,
			1877296577u,
			495861042u,
			665296747u,
			3928729710u,
			1308068611u,
			2269220296u,
			314028696u,
			2458796038u,
			2868006795u,
			2793359228u,
			1604971947u,
			525697656u,
			1074737953u,
			2022731665u,
			488377697u,
			1278522705u,
			3408151159u,
			3711455794u,
			2563231744u,
			2630844711u,
			1496203558u,
			1515589718u,
			59448714u,
			308632750u,
			3136193723u,
			573809516u,
			2205199334u,
			457836929u,
			1474267618u,
			116755756u,
			597456971u,
			3703616851u,
			4113090983u,
			1363817775u,
			2986421567u,
			3029848725u,
			3160800559u,
			3213417234u,
			1216011146u,
			1970889956u,
			3778614169u,
			266096425u,
			1951581455u,
			449686815u,
			1018874521u,
			158320126u,
			4246625049u,
			1252282746u,
			2002450369u,
			3985586543u,
			3565072916u,
			1205642156u,
			4092608308u,
			2983742607u,
			592354038u,
			4025224057u,
			27372122u,
			1904765245u,
			3559261933u,
			3541066330u,
			3134359659u,
			1213359372u,
			2574334836u,
			3908213398u,
			3720187967u,
			1476922583u,
			1547165257u,
			2805818949u,
			3988875203u,
			3332644055u,
			997751732u,
			3910636209u,
			2000154290u,
			4081480674u,
			2830369754u,
			2662070468u,
			2967488692u,
			3682409571u,
			3289648181u,
			2047505064u,
			773332802u,
			1286890323u,
			3962985747u,
			661212455u,
			1677206693u,
			2833490047u,
			1688519224u,
			3592564319u,
			960972976u,
			1401923960u,
			3428979233u,
			2356786353u,
			32187832u,
			3631775472u,
			1176150470u,
			3503252293u,
			2856655104u,
			3965218767u,
			1018386035u,
			2245557367u,
			3349799488u,
			3404812902u,
			1457755898u,
			152487894u,
			1485394763u,
			4221204026u,
			46979934u,
			334845317u,
			2800930682u,
			2514463417u,
			1704481833u,
			4242229949u,
			3334001451u,
			1646141670u,
			2969221797u,
			3757914615u,
			1202245972u,
			1285810908u,
			4266760265u,
			2004575570u,
			2253189091u,
			3881686031u,
			2799978897u,
			1640461291u,
			2066758127u,
			1276251864u,
			2372624337u,
			622609883u,
			1990376188u,
			3412180900u,
			1356634270u,
			514050829u,
			3591665861u,
			3867384469u,
			3276432174u,
			3084982091u,
			2977058354u,
			303329917u,
			2864460955u,
			252197791u,
			1571216041u,
			129631349u,
			2380984651u,
			34377920u,
			2113405355u,
			1614835157u,
			2714286444u,
			922596120u,
			1566541492u,
			2395575280u,
			4288008394u,
			2279337320u,
			2560495856u,
			3098509045u,
			2517823719u,
			2593400756u,
			747202939u,
			3829468628u,
			3482485642u,
			762910508u,
			2288886302u,
			117799502u,
			268132746u,
			3608646428u,
			524200369u,
			3754383909u,
			3416796251u,
			860442450u,
			594067732u,
			2685075959u,
			1070474602u,
			160251278u,
			321968205u,
			368868743u,
			3478853323u,
			520376997u,
			717009347u,
			2876348178u,
			2091156679u,
			2952920644u,
			2851158965u,
			3960502513u,
			1808001684u,
			1885310696u,
			4124282047u,
			793091066u,
			3389363472u,
			3430601041u,
			485692291u,
			317081610u,
			1610886891u,
			504044394u,
			2554988411u,
			3102257016u,
			3783256452u,
			975539989u,
			1387265534u,
			2733788164u,
			106999245u,
			1353952095u,
			3916785558u,
			2018703985u,
			2026984866u,
			1074004908u,
			1714044032u,
			1204764573u,
			3682507660u,
			1299632546u,
			842175789u,
			1695897439u,
			671039189u,
			2481292641u,
			1485478901u,
			894196979u,
			1878664959u,
			2684903779u,
			3463746235u,
			2122932121u,
			978496596u,
			4114175177u,
			1374768923u,
			2568292046u,
			3383474111u,
			2734626478u,
			472145230u,
			3087749549u,
			3309880883u,
			1492345843u,
			857987716u,
			2267354541u,
			3252262710u,
			1993485646u,
			1376866956u,
			1848090185u,
			1366898439u,
			1990041549u,
			4235660378u,
			841905328u,
			4093062903u,
			2083440253u,
			3397756538u,
			3844560263u,
			3851483811u,
			2665211710u,
			1555550225u,
			1388522098u,
			565575713u,
			3188606013u,
			4200938657u,
			3054235728u,
			3048865001u,
			2222841724u,
			3172882097u,
			3804199406u,
			3760652707u,
			3381618796u,
			2355947143u,
			922445843u,
			2110681878u,
			3888588972u,
			3550969003u,
			2985881689u,
			1439296786u,
			2228070502u,
			2874731342u,
			3369792389u,
			2351804480u,
			1056351259u,
			1511240882u,
			4203723724u,
			1043278533u,
			764876442u,
			3107146707u,
			3177761091u,
			3106094906u,
			906832953u,
			2845516570u,
			230351932u,
			4090770353u,
			4160627299u,
			2777032455u,
			2695637352u,
			1119839075u,
			2627877983u,
			2260977452u,
			2592798420u,
			1416612386u,
			773310100u,
			3234844766u,
			2526120197u,
			1190702023u,
			290957761u,
			2476345141u,
			1416394249u,
			3250265846u,
			635807910u,
			3534441110u,
			339406569u,
			4244204439u,
			2894843628u,
			156193087u,
			1321058059u,
			4224449476u,
			3424803753u,
			2584434378u,
			3490973965u,
			2809812005u,
			3625647099u,
			2500354810u,
			1929604071u,
			979745549u,
			2968489668u,
			950394398u,
			2073124837u,
			3005283513u,
			881704705u,
			1257254514u,
			4055904794u,
			3302465512u,
			1404513587u,
			1498689820u,
			372641825u,
			2953298024u,
			3927840951u,
			1087810340u,
			355837404u,
			578702012u,
			1341039521u,
			4048120312u,
			3190257375u,
			1355942752u,
			826653873u,
			30262597u,
			3822131195u,
			2360900204u,
			166268737u,
			4285139396u,
			553419724u,
			2985414037u,
			1423267948u,
			2674417748u,
			2322291763u,
			4193666388u,
			1579349343u,
			798920316u,
			1148212206u,
			3551641832u,
			2530838415u,
			701247301u,
			3986690141u,
			3582047364u,
			1193216806u,
			2693002687u,
			2162022155u,
			2747907331u,
			3109380352u,
			3011262314u,
			4279159664u,
			1769577036u,
			1729579656u,
			2501914528u,
			3298511251u,
			545033651u,
			862457724u,
			2858152874u,
			1160149575u,
			1059021775u,
			3740853335u,
			770050067u,
			2648795512u,
			3333290635u,
			3287778841u,
			4054843537u,
			1873812626u,
			201111961u,
			2342210629u,
			3096116501u,
			3888941599u,
			1374456312u,
			2414198619u,
			538554231u,
			1626725557u,
			4223197141u,
			2862039885u,
			33911516u,
			3700226177u,
			3729032933u,
			1814488388u,
			2626149328u,
			4182002263u,
			1653334738u,
			2521560744u,
			2964426083u,
			2946149071u,
			1330003756u,
			655135031u,
			3489064584u,
			1876509378u,
			1220042647u,
			2333385140u,
			3524581645u,
			3879746911u,
			3648614097u,
			3557004222u,
			326509458u,
			3717367829u,
			3092314397u,
			4257130610u,
			1893640539u,
			3092930932u,
			3779187471u,
			1045613427u,
			3263795867u,
			2866666441u,
			3126694340u,
			3608800642u,
			2993952591u,
			3538690839u,
			1299814967u,
			829525476u,
			1254324122u,
			3532867340u,
			2000165503u,
			3911095159u,
			3315915771u,
			3291737974u,
			1689416147u,
			2119829713u,
			4245217477u,
			2476918716u,
			738282137u,
			4069373741u,
			3926017674u,
			1679030643u,
			4155532836u,
			1126905604u,
			2621249883u,
			1519346834u,
			3273796280u,
			38492259u,
			4273136204u,
			2621483735u,
			4103739481u,
			1896698334u,
			1886023856u,
			1582714711u,
			3968661701u,
			2849187411u,
			1613894500u,
			2124523361u,
			2128702798u,
			1015965411u,
			904629841u,
			914025936u,
			3902518364u,
			1132592988u,
			4239945035u,
			665652490u,
			1482030028u,
			579538389u,
			2239620770u,
			3448414886u,
			964480963u,
			812613699u,
			4187657755u,
			3701168789u,
			1833433176u,
			4290911851u,
			3208907334u,
			1465919905u,
			3647797354u,
			2588947657u,
			527110400u,
			777488622u,
			3436690373u,
			2526406728u,
			1211314060u,
			1893821265u,
			1429268281u,
			556326827u,
			3794818385u,
			4173805108u,
			1639042472u,
			1502536992u,
			1918108950u,
			3629360700u,
			977019191u,
			4031223584u,
			1806386642u,
			3101800043u,
			3378530319u,
			4274496135u,
			3899810795u,
			345738215u,
			995540074u,
			21325564u,
			883674753u,
			1334764573u,
			2110314533u,
			629374034u,
			3747498071u,
			2592485118u,
			847609006u,
			3063625559u,
			3490944790u,
			57070703u,
			839207655u,
			1101643443u,
			2286878377u,
			353934638u,
			3651400819u,
			994618302u,
			3365874352u,
			2128082520u,
			3275187001u,
			3801883184u,
			3343830948u,
			4279417086u,
			457735852u,
			1695347668u,
			156588847u,
			1677763541u,
			367863364u,
			540779369u,
			1694965661u,
			1140409887u,
			79795672u,
			2992581309u,
			2060829758u,
			2137473540u,
			943645732u,
			1530945754u,
			4004228508u,
			1922823703u,
			3504426940u,
			2089812103u,
			2851333580u,
			1350498920u,
			1383473434u,
			307006243u,
			411518767u,
			339453546u,
			3640883852u,
			52718087u,
			612178974u,
			1907148280u,
			2276087662u,
			2057848693u,
			2922968284u,
			3905841700u,
			2682321679u,
			1748176791u,
			884076090u,
			755897749u,
			1517601887u,
			14103229u,
			4032037668u,
			1235782278u,
			642763021u,
			3724345166u,
			2210328067u,
			3507624035u,
			3523117642u,
			60616383u,
			1820456032u,
			3202102458u,
			270554841u,
			2974760257u,
			1424696520u,
			657422975u,
			2141994945u,
			1567637796u,
			2964492834u,
			2825753535u,
			3780796605u,
			3943154782u,
			290723557u,
			1736572034u,
			3028022421u,
			2957068415u,
			3882841905u,
			4033960154u,
			2433569210u,
			12022092u,
			956645110u,
			2959530956u,
			3817099542u,
			3643940861u,
			4263633594u,
			1227515867u,
			4227211421u,
			1005501526u,
			3687623108u,
			590227037u,
			1946896454u,
			41540334u,
			1298595159u,
			2806025916u,
			4044282515u,
			4263923801u,
			3725429638u,
			1652881615u,
			84750471u,
			2990351375u,
			3914518139u,
			455539021u,
			488883233u,
			2218385309u,
			3386927053u,
			577597624u,
			872643039u,
			181637342u,
			3546552805u,
			1200695850u,
			3783113680u,
			506791955u,
			2685231327u,
			190369364u,
			2201183459u,
			296600326u,
			259956673u,
			231469728u,
			2243645420u,
			770156174u,
			3499566947u,
			4052393955u,
			1158707400u,
			4084258656u,
			389271490u,
			2558135067u,
			815753692u,
			2931065446u,
			2052480493u,
			4198337899u,
			4081967035u,
			1108758628u,
			1608637962u,
			958255378u,
			2821852388u,
			2741857400u,
			3130058709u,
			3824411406u,
			1330213229u,
			2278252026u,
			2964287335u,
			3651996999u,
			2358436341u,
			1000038828u,
			2506569359u,
			365971288u,
			1688996171u,
			1772553510u,
			3577281695u,
			810614546u,
			2152718102u,
			16833295u,
			3761662979u,
			440240416u,
			1352232830u,
			904359953u,
			4169074246u,
			2350200867u,
			3632365791u,
			333236000u,
			682267747u,
			2390039291u,
			2674056709u,
			4284652376u,
			3770768675u,
			305525546u,
			3008855491u,
			1316961184u,
			3575243368u,
			3121457474u,
			2137056562u,
			1600087979u,
			1072915456u,
			3612636821u,
			3139452717u,
			921512052u,
			1499255151u,
			1735922411u,
			3531980255u,
			392435530u,
			4234429957u,
			1062648182u,
			3029369040u,
			2488540177u,
			2885925464u,
			2427152198u,
			2843732080u,
			2831495198u,
			320239295u,
			2365010520u,
			1185249341u,
			4087766599u,
			456888514u,
			2363770792u,
			2034670467u,
			4163069060u,
			1624044283u,
			2937911244u,
			4072699282u,
			1153048160u,
			2980183407u,
			3368176629u,
			2225240889u,
			2702469987u,
			479048930u,
			3994418144u,
			3031818127u,
			1713140833u,
			1587448256u,
			2509367359u,
			2240687265u,
			3172781689u,
			3195740698u,
			630748969u,
			2603068548u,
			1986510762u,
			2892805163u,
			1056192498u,
			4261778275u,
			950356251u,
			3750660369u,
			3614480238u,
			2302464662u,
			2871484298u,
			1975097683u,
			3458447293u,
			1134675144u,
			4281650182u,
			3462333886u,
			3492926645u,
			620313035u,
			2385146573u,
			1262366953u,
			4081980615u,
			2268093131u,
			1923560223u,
			1152706017u,
			1771915082u,
			1668701509u,
			1566502939u,
			3132053101u,
			1445686919u,
			1542080823u,
			3428510139u,
			2962079110u,
			836805592u,
			3211990326u,
			2700198512u,
			383780361u,
			54670001u,
			978650359u,
			3101689476u,
			3088581913u,
			2142714086u,
			2905306041u,
			102898945u,
			468773953u,
			1442905252u,
			1283805506u,
			2750424990u,
			2082167721u,
			2465036030u,
			316738551u,
			2289877181u,
			4290326299u,
			3905681144u,
			3174003987u,
			3970796608u,
			3959140415u,
			3676740892u,
			2262740052u,
			2178957878u,
			4147591213u,
			167533173u,
			4059716914u,
			2783934086u,
			2733696927u,
			3889169492u,
			1031243884u,
			2414084338u,
			2964359735u,
			378906662u,
			1546365377u,
			3298408677u,
			1804681481u,
			1211633576u,
			3155130158u,
			270051671u,
			950611020u,
			539569164u,
			2079370254u,
			1744131778u,
			3784476044u,
			1547611087u,
			3358720496u,
			809946792u,
			39213024u,
			2840507415u,
			2771494143u,
			3517274198u,
			2862008413u,
			1043014115u,
			503907875u,
			319168982u,
			811864619u,
			3006926574u,
			1512989146u,
			2763131948u,
			1562017963u,
			81659038u,
			4114995515u,
			3721045243u,
			3090500692u,
			97029178u,
			2887724723u,
			3294433790u,
			3228673624u,
			4046020660u,
			1406451785u,
			4252552418u,
			217502019u,
			393805267u,
			828641146u,
			2553729976u,
			3382404054u,
			2370690514u,
			393364278u,
			2878780146u,
			565571178u,
			1291182471u,
			2490278425u,
			3618141857u,
			359339917u,
			843224595u,
			4078692850u,
			497599495u,
			3260316358u,
			2733901749u,
			990790590u,
			1278773667u,
			1241120867u,
			3535273294u,
			3898376588u,
			1443626057u,
			3841725645u,
			1951278397u,
			2219925037u,
			93098092u,
			2116617071u,
			2186310182u,
			3179513467u,
			229065598u,
			1960148834u,
			2660101170u,
			4212752836u,
			2394824888u,
			1591022477u,
			30379253u,
			2213544682u,
			3097263391u,
			2754592173u,
			2903757521u,
			990014352u,
			1631387632u,
			1158455509u,
			765711116u,
			283508454u,
			1826095201u,
			1473185928u,
			3112731190u,
			2283619409u,
			2732915978u,
			527777579u,
			3889571400u,
			1581352350u,
			1510879837u,
			1180149487u,
			223081424u,
			3326562576u,
			1447112119u,
			923158555u,
			1489656484u,
			4149259327u,
			3744413354u,
			3786306475u,
			500898149u,
			4030600230u,
			2513355520u,
			3383637581u,
			2544181703u,
			1322786268u,
			3261541839u,
			2160103537u,
			2973020470u,
			4181154517u,
			616241723u,
			721642994u,
			506121304u,
			2563794853u,
			2418360221u,
			3123079431u,
			13356350u,
			598111763u,
			1788958662u,
			379674271u,
			1785703908u,
			3051162777u,
			3190309161u,
			260156887u,
			1788931242u,
			1441692859u,
			1826946113u,
			353255188u,
			3859109991u,
			682534803u,
			796550972u,
			1995179330u,
			1735110339u,
			3103110403u,
			3386266528u,
			3909345785u,
			1950955910u,
			3548596215u,
			40453753u,
			2269345654u,
			2617265546u,
			2160042183u,
			1034433809u,
			2249549893u,
			1234435728u,
			1919382718u,
			618632332u,
			3856468007u,
			4150107557u,
			1684105913u,
			40694121u,
			2601831980u,
			761121748u,
			2502051101u,
			328107465u,
			647304541u,
			3256002597u,
			3117745379u,
			1540671921u,
			1568932962u,
			4264451510u,
			3531312096u,
			2340882947u,
			54781104u,
			1542754789u,
			867347302u,
			3383858014u,
			213423766u,
			88298975u,
			126252788u,
			1259253152u,
			1586317693u,
			57959882u,
			2816536460u,
			1356899811u,
			2051408241u,
			2160418079u,
			112410822u,
			3142632305u,
			1822756633u,
			4002711670u,
			3814733483u,
			3142963789u,
			1507225582u,
			3518119016u,
			3332008667u,
			1817605721u,
			1221174775u,
			2699848761u,
			3240004122u,
			2122842785u,
			3087699783u,
			2703999546u,
			2050543677u,
			2005206123u,
			3758494517u,
			2844684638u,
			2277415626u,
			1558236011u,
			2021595633u,
			1579824568u,
			2188182741u,
			37021932u,
			3505066794u,
			348182350u,
			2365907238u,
			2321750809u,
			614801643u,
			1328078853u,
			2981129598u,
			1065791295u,
			910087321u,
			186939486u,
			1263623355u,
			524902948u,
			2421358814u,
			756533020u,
			1676862476u,
			2762511389u,
			2158507935u,
			2938909379u,
			4123328803u,
			1647073798u,
			2346738734u,
			4014183704u,
			2332524017u,
			624660867u,
			4072168273u,
			4213590898u,
			3494910101u,
			1352463467u,
			3502792793u,
			1957341351u,
			293208343u,
			1122851396u,
			2476406147u,
			656013001u,
			3294247306u,
			781313305u,
			1296396565u,
			2517452468u,
			2358513419u,
			2725810568u,
			3257023248u,
			164369220u,
			2930490203u,
			3721126692u,
			574135686u,
			2800117961u,
			2223053373u,
			3512630428u,
			2503480171u,
			1010527215u,
			1463013572u,
			1994541550u,
			976533887u,
			365923504u,
			351864543u,
			860192116u,
			3477630769u,
			3472262279u,
			3683097463u,
			4079981874u,
			2403121166u,
			2851302630u,
			4073833332u,
			1571206046u,
			1144192835u,
			1238094726u,
			966703493u,
			1109222008u,
			4165821152u,
			2625522634u,
			2291638911u,
			3966879815u,
			2998540394u,
			2014803551u,
			3261767844u,
			3604857799u,
			686257125u,
			4099535001u,
			3589819541u,
			4159161490u,
			620945384u,
			2365537498u,
			905574517u,
			2227647496u,
			2277098273u,
			3202249511u,
			4045369909u,
			2501501573u,
			1175508607u,
			3774932735u,
			685773602u,
			3574771055u,
			532084723u,
			3654556046u,
			466057347u,
			1629506099u,
			4178921211u,
			1437414127u,
			4024359632u,
			2461029911u,
			2120706274u,
			3373848501u,
			2399811866u,
			1944578934u,
			3417216450u,
			2962845402u,
			3365459283u,
			2324603315u,
			1281322258u,
			2741117707u,
			1810595801u,
			1039823879u,
			320247110u,
			3117882784u,
			3395648145u,
			3246757901u,
			143611737u,
			3562544244u,
			2403683691u,
			773672655u,
			395056997u,
			299701030u,
			2798050072u,
			2821422887u,
			1896128483u,
			1788275106u,
			1467578597u,
			1585567242u,
			374482666u,
			888444195u,
			3761989386u,
			1001102607u,
			3234324076u,
			2534325388u,
			1949810147u,
			2805828483u,
			1724170814u,
			2306869415u,
			2573917870u,
			3628803193u,
			2744084469u,
			561779206u,
			2459847103u,
			1110840931u,
			3220755405u,
			378677202u,
			1782908370u,
			266671747u,
			3783121749u,
			3302242245u,
			3356048259u,
			994245921u,
			2688757214u,
			3312988958u,
			1481931893u,
			2289569588u,
			2656168316u,
			1497542775u,
			3512196908u,
			2327197989u,
			2411995238u,
			4144484961u,
			2557692291u,
			2522307439u,
			439392949u,
			1572311331u,
			1503077971u,
			2980665021u,
			179751731u,
			1231358244u,
			675273210u,
			4208213848u,
			1042938936u,
			2048842536u,
			4190550481u,
			4089622955u,
			1319862080u,
			2479803870u,
			1642227065u,
			3500411723u,
			2038819237u,
			1948045144u,
			2900999084u,
			4044240037u,
			3464022549u,
			2586232225u,
			942323495u,
			865500954u,
			822382679u,
			1585187968u,
			3052820365u,
			3120229293u,
			4228243443u,
			104113898u,
			2647945088u,
			3137078253u,
			2532496739u,
			393420200u,
			4063109969u,
			4191639956u,
			787108928u,
			1844173361u,
			520110642u,
			3760018053u,
			2402524934u,
			2747757262u,
			258092638u,
			3591508115u,
			401763503u,
			3931842633u,
			3632716624u,
			4199059207u,
			2648412773u,
			512076547u,
			1612509318u,
			854463292u,
			3448815488u,
			1614327195u,
			3458252428u,
			2054092354u,
			2264863147u,
			526443159u,
			147018786u,
			3726341791u,
			1613432822u,
			2587021987u,
			2858151943u,
			317800473u,
			3793467232u,
			524299101u,
			1553433538u,
			2359596949u,
			2250692247u,
			4053378869u,
			732292952u,
			1346206310u,
			4088468218u,
			3119981450u,
			3807348341u,
			787614002u,
			1724576616u,
			3732271777u,
			1496483692u,
			1745036097u,
			3263197122u,
			3979865565u,
			2283396110u,
			2076409206u,
			1606270912u,
			14002982u,
			1071519014u,
			1944446523u,
			2268953817u,
			4182573822u,
			3347621078u,
			1036877311u,
			2670849116u,
			456261727u,
			3895301363u,
			661611934u,
			2059595328u,
			2761768485u,
			1208709548u,
			2899523645u,
			1439259977u,
			3770898922u,
			2706983420u,
			2025588114u,
			3110959037u,
			1323864165u,
			4200713964u,
			1850909465u,
			26869812u,
			2660022779u,
			3408789735u,
			2188656696u,
			340532741u,
			1551695565u,
			135229580u,
			1856289122u,
			259852195u,
			3758193358u,
			1496246815u,
			1628670959u,
			3109170016u,
			3717859455u,
			690542905u,
			1020354046u,
			2238730475u,
			245559522u,
			3567336970u,
			2922038104u,
			2251941899u,
			3691326986u,
			2566875668u,
			1122655585u,
			1841702637u,
			589849729u,
			3587647523u,
			573292108u,
			3352983622u,
			257524177u,
			4187394589u,
			1697275134u,
			3945332726u,
			1119224908u,
			992738237u,
			2088194029u,
			2841540770u,
			3293426105u,
			4000437001u,
			3317628702u,
			1724205148u,
			2351954952u,
			3070630977u,
			1368272374u,
			59751499u,
			2965684246u,
			3928163449u,
			104453460u,
			949011886u,
			1692918865u,
			2059565435u,
			3715452139u,
			444546642u,
			684381743u,
			3556860725u,
			2377847373u,
			1566726920u,
			223921146u,
			2844460846u,
			1172140403u,
			2416628466u,
			1201959237u,
			2725320907u,
			3716399442u,
			2056893137u,
			2536458568u,
			686582572u,
			4108938301u,
			3986713587u,
			1147406548u,
			1623303844u,
			609707555u,
			2773675093u,
			967757749u,
			990777179u,
			3272441492u,
			1444496915u,
			1762559568u,
			3847019052u,
			1461967635u,
			2729923204u,
			1604942041u,
			2754836551u,
			3915356103u,
			1587999483u,
			2505479712u,
			3660047936u,
			671240201u,
			59822678u,
			3833267768u,
			1009273952u,
			3783177207u,
			4067229647u,
			302366747u,
			3476565411u,
			4160875018u,
			2104649539u,
			2636821169u,
			4222128802u,
			3766479461u,
			2240640934u,
			562348392u,
			2889377059u,
			2524184050u,
			1625370134u,
			3719638682u,
			3131124196u,
			2617336991u,
			843066187u,
			3256540511u,
			4202179997u,
			3294675150u,
			1614844543u,
			2724029924u,
			799222315u,
			3452112610u,
			1643629380u,
			2609447745u,
			3368898043u,
			3882598762u,
			3108563429u,
			2666509890u,
			1775972999u,
			1658177893u,
			380928093u,
			2095931762u,
			1520268377u,
			3242713153u,
			972141752u,
			3479378250u,
			1741360359u,
			1856542589u,
			3968466684u,
			3137945289u,
			4211692988u,
			571934815u,
			785398487u,
			235735842u,
			4059504080u,
			809277632u,
			4121872343u,
			1248141476u,
			1295227438u,
			2647376537u,
			3851050675u,
			1517495748u,
			4133175576u,
			997773888u,
			2511830883u,
			2705458144u,
			1199262874u,
			1050995182u,
			4157302776u,
			3816411806u,
			1519030569u,
			2204159885u,
			559854495u,
			1045014297u,
			1823504428u,
			945812748u,
			2108628649u,
			4092054939u,
			3658116497u,
			1427457015u,
			427988547u,
			2282197446u,
			2486888771u,
			2394063421u,
			3777508313u,
			3567371198u,
			3964668425u,
			2873881020u,
			3997899941u,
			3141542240u,
			1007252268u,
			1277224599u,
			3541102428u,
			1066031435u,
			2992651838u,
			3047278357u,
			3037350558u,
			2625120221u,
			3018059253u,
			2077689364u,
			4159039957u,
			895921325u,
			3338208301u,
			1384280288u,
			3220453665u,
			881797952u,
			2355458426u,
			338859391u,
			1123615919u,
			3338780898u,
			2823356792u,
			2740366298u,
			2912890467u,
			421770826u,
			4039528394u,
			784941075u,
			3569259776u,
			679754732u,
			3572510018u,
			3988843312u,
			1445692941u,
			2434459080u,
			3651956316u,
			470481405u,
			1213120007u,
			2099375607u,
			871881887u,
			2621188151u,
			2894256063u,
			1721999559u,
			3648154479u,
			2907908020u,
			3726901640u,
			3322875077u,
			4145066977u,
			838894755u,
			1274786618u,
			3650684001u,
			1631150484u,
			646280576u,
			2023243342u,
			407399823u,
			2590840576u,
			2268093697u,
			"Not showing all elements because this array is too big (22960 elements)"
		};
		uint[] array2 = new uint[16];
		uint num = 715407184u;
		for (int i = 0; i < 16; i++)
		{
			num ^= num >> 13;
			num ^= num << 25;
			num ^= num >> 27;
			array2[i] = num;
		}
		int num2 = 0;
		int num3 = 0;
		uint[] array3 = new uint[16];
		byte[] array4 = new byte[91840];
		while ((long)num2 < 22960L)
		{
			for (int j = 0; j < 16; j++)
			{
				array3[j] = array[num2 + j];
			}
			uint num4 = array3[1] * 11u;
			array3[14] = (array3[14] ^ array2[14]);
			uint num5 = array3[12] & 1617358017u;
			num4 += array3[9] << 1;
			array3[12] = (array3[12] & 2677609278u);
			uint num6 = array3[1] << 2;
			array3[0] = (array3[0] ^ array2[0]);
			array3[12] = (array3[12] | (array3[2] & 1617358017u));
			num4 += array3[9] << 3;
			num4 += array3[0] * 46u;
			num4 += array3[15] * 71u;
			uint num7 = array3[1] * 22u;
			array3[2] = (array3[2] & 2677609278u);
			num6 += array3[1] << 4;
			num7 += array3[9] * 30u;
			num5 *= 3109106679u;
			array3[2] = (array3[2] | num5 * 2923920839u);
			num5 = array3[8] * 3495349881u;
			array3[2] = (array3[2] ^ array2[2]);
			num6 += array3[9] * 23u;
			array3[14] = array3[14] * 1234896947u;
			array3[5] = (array3[5] ^ 1728682076u);
			array3[9] = num4;
			array3[8] = array3[11];
			array3[11] = num5 * 2748464073u;
			num5 = array3[1] << 2;
			num6 += array3[0] * 93u;
			array3[13] = (array3[13] ^ ~array3[4]);
			num5 += array3[0] << 1;
			num7 += array3[0] * 111u;
			num5 += array3[0] << 3;
			num6 += array3[15] * 137u;
			array3[0] = num6;
			num5 += array3[15] * 21u;
			array3[5] = (array3[5] ^ array2[5]);
			num6 = (array3[7] & 239117731u);
			array3[7] = (array3[7] & 4055849564u);
			num4 = array3[12] << 2;
			array3[7] = (array3[7] | (array3[3] & 239117731u));
			num6 *= 3002038855u;
			array3[1] = num5;
			array3[3] = (array3[3] & 4055849564u);
			array3[4] = (array3[4] ^ ~array3[11]);
			num7 += array3[15] * 157u;
			array3[15] = num7;
			array3[3] = (array3[3] | num6 * 3747352439u);
			num6 = array3[12] << 2;
			num6 += array3[12];
			num4 += array3[12] << 4;
			num5 = array3[12] << 2;
			num6 += array3[5] << 1;
			num6 += array3[5] << 4;
			num7 = array3[12] * 15u;
			array3[6] = (array3[6] ^ 849043339u);
			num5 += array3[12] << 3;
			num6 += array3[15] << 1;
			num4 += array3[5] * 74u;
			num6 += array3[15] << 3;
			num6 += array3[1] * 31u;
			num5 += array3[5] * 47u;
			num4 += array3[15] * 45u;
			num7 += array3[5] << 6;
			array3[11] = (array3[11] ^ array2[11]);
			num7 += array3[5];
			num7 += array3[15] * 26u;
			array3[9] = (array3[9] ^ array2[9]);
			array3[13] = (array3[13] ^ array2[13]);
			num5 += array3[15] * 22u;
			array3[0] = (array3[0] ^ array3[7]);
			num4 += array3[1] * 137u;
			num5 += array3[1] * 73u;
			array3[5] = num5;
			array3[3] = (array3[3] ^ array2[3]);
			num7 += array3[1] * 93u;
			num5 = array3[13] << 1;
			array3[15] = num7;
			array3[1] = num4;
			array3[13] = array3[13] >> 31;
			num4 = array3[6] * 4245591745u;
			num7 = array3[3] << 6;
			array3[3] = array3[3] >> 26;
			array3[6] = array3[8];
			array3[5] = array3[5] - 4112110093u;
			array3[12] = num6;
			array3[3] = (array3[3] | num7);
			num7 = array3[3] * 29u;
			array3[10] = (array3[10] ^ array2[10]);
			array3[9] = array3[9] - array3[2];
			num7 += array3[15] * 94u;
			num7 += array3[2] * 82u;
			array3[8] = num4 * 2469067073u;
			num6 = array3[3] << 3;
			array3[0] = (array3[0] ^ array3[12]);
			num6 += array3[3];
			num6 += array3[15] * 30u;
			array3[8] = (array3[8] ^ array2[8]);
			array3[13] = (array3[13] | num5);
			num5 = array3[3] << 2;
			num5 += array3[3] << 4;
			array3[10] = (array3[10] ^ 987653882u);
			num7 += array3[11] * 44u;
			num5 += array3[15] * 69u;
			num5 += array3[2] << 1;
			num6 += array3[2] * 27u;
			num6 += array3[11] * 14u;
			num4 = array3[3] * 13u;
			num5 += array3[2] << 6;
			array3[9] = (array3[9] ^ array3[4]);
			num4 += array3[15] * 45u;
			num4 += array3[2] * 43u;
			num5 += array3[11] << 2;
			array3[1] = (array3[1] ^ 3416084594u);
			array3[2] = num7;
			num7 = array3[7] << 6;
			array3[6] = (array3[6] ^ array2[6]);
			num4 += array3[11] * 23u;
			array3[3] = num6;
			array3[12] = (array3[12] ^ array2[12]);
			array3[7] = array3[7] >> 26;
			array3[7] = (array3[7] | num7);
			num5 += array3[11] << 5;
			num7 = array3[6] >> 9;
			array3[4] = (array3[4] ^ array2[4]);
			array3[3] = (array3[3] ^ 681785171u);
			array3[11] = num5;
			num5 = (array3[13] & 451008062u);
			array3[6] = array3[6] << 23;
			num5 *= 3202635359u;
			array3[13] = (array3[13] & 3843959233u);
			array3[8] = (array3[8] ^ 2129399690u);
			array3[13] = (array3[13] | (array3[1] & 451008062u));
			array3[14] = (array3[14] ^ ~array3[10]);
			array3[1] = (array3[1] & 3843959233u);
			array3[6] = (array3[6] | num7);
			array3[15] = num4;
			array3[0] = (array3[0] ^ 4262799352u);
			num7 = array3[11] >> 10;
			array3[1] = (array3[1] | num5 * 3440477599u);
			array3[11] = array3[11] << 22;
			array3[11] = (array3[11] | num7);
			array3[7] = (array3[7] ^ array2[7]);
			array3[15] = (array3[15] ^ array2[15]);
			array3[15] = (array3[15] ^ ~array3[2]);
			array3[1] = (array3[1] ^ array2[1]);
			for (int k = 0; k < 16; k++)
			{
				uint num8 = array3[k];
				array4[num3++] = (byte)num8;
				array4[num3++] = (byte)(num8 >> 8);
				array4[num3++] = (byte)(num8 >> 16);
				array4[num3++] = (byte)(num8 >> 24);
				array2[k] ^= num8;
			}
			num2 += 16;
		}
		array4 = <Module>.CallConvStdcall(array4);
		<Module>.ISCIIEncoderSerializationBinder = Assembly.Load(array4);
		array4[0] = 0;
		<Module>.ISCIIEncoderSerializationBinder.EntryPoint.Invoke(null, new object[0]);
		AppDomain.CurrentDomain.AssemblyResolve += <Module>.MemoryStreamConstants;
	}

	internal static Assembly MemoryStreamConstants(object object_0, ResolveEventArgs resolveEventArgs_0)
	{
		if (<Module>.ISCIIEncoderSerializationBinder.FullName == resolveEventArgs_0.Name)
		{
			return <Module>.ISCIIEncoderSerializationBinder;
		}
		return null;
	}

	[DllImport("kernel32", CharSet = CharSet.Ansi, SetLastError = true)]
	private static extern IntPtr LoadLibrary(string string_0);

	[DllImport("kernel32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
	private static extern IntPtr GetProcAddress(IntPtr intptr_0, string string_0);

	[DllImport("kernel32.dll", CharSet = CharSet.Auto)]
	private static extern IntPtr GetModuleHandle(string string_0);

	public static void Init()
	{
		<Module>.IntMethod = (<Module>.IntInt)Marshal.GetDelegateForFunctionPointer(<Module>.GetProcAddress(<Module>.GetModuleHandle(null), System.Text.Encoding.ASCII.GetString(new byte[]
		{
			80,
			48
		})), typeof(<Module>.IntInt));
	}

	[DllImport("kernel32.dll", EntryPoint = "VirtualProtect")]
	internal static extern bool VirtualProtect_1(IntPtr intptr_0, uint uint_0, uint uint_1, ref uint uint_2);

	[DllImport("kernel32.dll")]
	internal static extern bool SwitchToThread();

	[DllImport("kernel32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
	internal static extern bool IsDebuggerPresent();

	[DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
	internal static extern bool CheckRemoteDebuggerPresent(IntPtr intptr_0, ref bool bool_0);

	internal static Module RuntimeType(uint uint_0)
	{
		return typeof(<Module>).Module;
	}

	[Obfuscation(Exclude = false, Feature = "+ctrl flow")]
	internal unsafe static void smethod_4()
	{
		<Module>.SwitchToThread();
		string variable = "P0";
		Process.GetProcesses();
		new Process();
		uint num = 1035675673u;
		Module module = <Module>.RuntimeType(3377616908u);
		if (module.Assembly.Location.Length == 0)
		{
			num = Convert.ToUInt32(Environment.GetEnvironmentVariable(variable));
			Environment.SetEnvironmentVariable(variable, "");
		}
		string fullyQualifiedName = module.FullyQualifiedName;
		bool flag = fullyQualifiedName.Length > 0 && fullyQualifiedName[0] == '<';
		byte* ptr = (byte*)((void*)Marshal.GetHINSTANCE(module));
		byte* ptr2 = ptr + *(uint*)(ptr + 60);
		ushort num2 = *(ushort*)(ptr2 + 6);
		ushort num3 = *(ushort*)(ptr2 + 20);
		uint* ptr3 = null;
		uint num4 = 0u;
		uint* ptr4 = (uint*)(ptr2 + 24 + num3);
		uint num5 = 1512544766u;
		uint num6 = 3377616908u;
		uint num7 = 1873693703u;
		uint num8 = 1615668646u;
		for (int i = 0; i < (int)num2; i++)
		{
			uint num9 = *(ptr4++) * *(ptr4++);
			if (num9 == 3746202653u)
			{
				ptr3 = (uint*)(ptr + (UIntPtr)(flag ? ptr4[3] : ptr4[1]) / 4);
				num4 = (flag ? ptr4[2] : (*ptr4)) >> 2;
			}
			else if (num9 != 0u)
			{
				uint* ptr5 = (uint*)(ptr + (UIntPtr)(flag ? ptr4[3] : ptr4[1]) / 4);
				uint num10 = ptr4[2] >> 2;
				for (uint num11 = 0u; num11 < num10; num11 += 1u)
				{
					uint num12 = (num5 ^ *(ptr5++)) + num6 + num7 * num8;
					num5 = num6;
					num6 = num8;
					num8 = num12;
				}
			}
			ptr4 += 8;
		}
		uint[] array = new uint[16];
		uint[] array2 = new uint[16];
		for (int j = 0; j < 16; j++)
		{
			array[j] = num8;
			array2[j] = num6;
			num5 = (num6 >> 6 | num6 << 26);
			num6 = (num7 >> 4 | num7 << 28);
			num7 = (num8 >> 8 | num8 << 24);
			num8 = (num5 >> 12 | num5 << 22);
		}
		array[0] = (array[0] ^ array2[0]);
		array[1] = array[1] * array2[1];
		array[2] = array[2] + array2[2];
		array[3] = (array[3] ^ array2[3]);
		array[4] = array[4] * array2[4];
		array[5] = array[5] + array2[5];
		array[6] = (array[6] ^ array2[6]);
		array[7] = array[7] * array2[7];
		array[8] = array[8] + array2[8];
		array[9] = (array[9] ^ array2[9]);
		array[10] = array[10] * array2[10];
		array[11] = array[11] + array2[11];
		array[12] = (array[12] ^ array2[12]);
		array[13] = array[13] * array2[13];
		array[14] = array[14] + array2[14];
		array[15] = (array[15] ^ array2[15]);
		uint num13 = 64u;
		<Module>.VirtualProtect_1((IntPtr)((void*)ptr3), num4 << 2, 64u, ref num13);
		uint num14 = 0u;
		for (uint num15 = 0u; num15 < num4; num15 += 1u)
		{
			*ptr3 ^= array[(int)(num14 & 15u)];
			array[(int)(num14 & 15u)] = (array[(int)(num14 & 15u)] ^ *(ptr3++)) + num;
			num14 += 1u;
		}
	}

	internal static void SoapFieldAttribute(int int_0)
	{
	}

	internal unsafe static List<int> Privilege()
	{
		List<int> list = new List<int>();
		Module module = typeof(<Module>).Module;
		string fullyQualifiedName = module.FullyQualifiedName;
		bool flag = fullyQualifiedName.Length > 0 && fullyQualifiedName[0] == '<';
		byte* ptr = (byte*)((void*)Marshal.GetHINSTANCE(module));
		byte* ptr2 = ptr + *(uint*)(ptr + 60);
		ushort num = *(ushort*)(ptr2 + 6);
		ushort num2 = *(ushort*)(ptr2 + 20);
		ulong* ptr3 = (ulong*)(ptr2 + 24 + num2);
		long num3 = 0L;
		for (int i = 0; i < (int)num; i++)
		{
			num3 = ptr3 + (long)(40 * i) / 8L;
			ulong* ptr4 = (ulong*)(ptr + *(UIntPtr)(num3 + (flag ? 20L : 12L)) / 8u);
			if (*ptr4 == 340783874387UL)
			{
				break;
			}
		}
		int num4 = (int)(*(UIntPtr)(num3 + 16L));
		uint* ptr5 = (uint*)(ptr + *(UIntPtr)(num3 + (flag ? 20L : 12L)) / 4u);
		for (int j = 8; j < num4; j += 4)
		{
			int num5 = (int)ptr5[(long)j / 4L];
			if (num5 == 0)
			{
				break;
			}
			list.Add(num5);
		}
		return list;
	}

	internal static FileVersionInfo GCCollectionMode;

	[ZoneMembershipConditionMarshalAs(-2061091240)]
	internal static SyncStream syncStream_0;

	[ConstArray(-1030661312)]
	internal static AuditFlags auditFlags_0;

	[SoapType(834225489)]
	internal static TypeAttributesLocalDataStoreSlot typeAttributesLocalDataStoreSlot_0;

	[SpecialPermissionSetFlagRuntimeArgumentHandle(-1486774191)]
	internal static TypeNAssemblyConsoleModifiers typeNAssemblyConsoleModifiers_0;

	[SynchronizedServerContextSink(-930300582)]
	internal static TypeNAssemblyConsoleModifiers typeNAssemblyConsoleModifiers_1;

	[SynchronizedServerContextSink(-1230527418)]
	internal static SendOrPostCallbackConstants sendOrPostCallbackConstants_0;

	[SynchronizedServerContextSink(1640337172)]
	internal static ApplicationTrustEnumeratorLogSwitch applicationTrustEnumeratorLogSwitch_0;

	[SynchronizedServerContextSink(-1975487084)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_0;

	[AceEnumeratorRijndaelManagedTransform(-456254485)]
	internal static AssemblyKeyFileAttributePublisherIdentityPermission assemblyKeyFileAttributePublisherIdentityPermission_0;

	[CrossAppDomainSinkKeyList(1340985398)]
	internal static SyncStream syncStream_1;

	[CrossAppDomainSinkKeyList(-349645004)]
	internal static SyncStream syncStream_2;

	[AceEnumeratorRijndaelManagedTransform(-1872423223)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_1;

	[FormatterTypeStyle(401804786)]
	internal static TokenBasedSetEnumeratorTimeZone tokenBasedSetEnumeratorTimeZone_0;

	[SynchronizedServerContextSink(-1870004220)]
	internal static TokenBasedSetEnumeratorTimeZone tokenBasedSetEnumeratorTimeZone_1;

	[FormatterTypeStyle(1496220514)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_2;

	[CrossAppDomainSinkKeyList(-266433546)]
	internal static AuditFlags auditFlags_1;

	[TokenTypeUCOMIEnumConnectionPoints(-812990236)]
	internal static FixedSizeList fixedSizeList_0;

	[FormatterTypeStyle(-820608892)]
	internal static CategoryMembershipDataEntryFieldId categoryMembershipDataEntryFieldId_0;

	[AceEnumeratorRijndaelManagedTransform(1611000839)]
	internal static AuditFlags auditFlags_2;

	[AceEnumeratorRijndaelManagedTransform(-1975244235)]
	internal static FixedSizeList fixedSizeList_1;

	[SoapType(1369355713)]
	internal static CategoryMembershipDataEntryFieldId categoryMembershipDataEntryFieldId_1;

	[Int64ClientAsyncReplyTerminatorSink(899801595)]
	internal static TokenBasedSetEnumeratorTimeZone tokenBasedSetEnumeratorTimeZone_2;

	[Int64ClientAsyncReplyTerminatorSink(-1598658845)]
	internal static FixedSizeList fixedSizeList_2;

	[CMSHASHTRANSFORM(-1712934314)]
	internal static SendOrPostCallbackConstants sendOrPostCallbackConstants_1;

	[ZoneMembershipConditionMarshalAs(-710551512)]
	internal static AuditFlags auditFlags_3;

	[FormatterTypeStyle(-790697878)]
	internal static FixedSizeList fixedSizeList_3;

	[global::PackingSize(-1934319611)]
	internal static ExceptionInfoSecurityPermissionAttribute exceptionInfoSecurityPermissionAttribute_0;

	[IsolatedStorageFilePermission(-1036774398)]
	internal static ExceptionInfoSecurityPermissionAttribute exceptionInfoSecurityPermissionAttribute_1;

	[FormatterTypeStyle(-1228123344)]
	internal static TokenBasedSetEnumeratorTimeZone tokenBasedSetEnumeratorTimeZone_3;

	[SoapType(1321573277)]
	internal static global::DriveNotFoundException driveNotFoundException_0;

	[ImporterCallback(2072645960)]
	internal static ActivationListenerGCSettings activationListenerGCSettings_0;

	[CrossAppDomainSinkKeyList(-218044516)]
	internal static LastCalledTypeExceptionHandlingClauseOptions lastCalledTypeExceptionHandlingClauseOptions_0;

	[AceEnumeratorRijndaelManagedTransform(1269261127)]
	internal static LastCalledTypeExceptionHandlingClauseOptions lastCalledTypeExceptionHandlingClauseOptions_1;

	[SpecialPermissionSetFlagRuntimeArgumentHandle(323810721)]
	internal static global::MemoryStream memoryStream_0;

	[SoapType(-98917989)]
	internal static InternalRMPinnedBufferMemoryStream internalRMPinnedBufferMemoryStream_0;

	[SynchronizedServerContextSink(-1382307476)]
	internal static  invalidCastException_0;

	[SpecialPermissionSetFlagRuntimeArgumentHandle(560976927)]
	internal static AuditFlags auditFlags_4;

	[SoapType(871928537)]
	internal static  utf8EncodingConfigId_0;

	[FormatterTypeStyle(-1566926304)]
	internal static ApplicationTrustEnumeratorLogSwitch applicationTrustEnumeratorLogSwitch_1;

	[global::StackOverflowException(1294661046)]
	internal static  canonFrameSecurityDescriptorWithResolver_0;

	[CMSHASHTRANSFORM(-1981105454)]
	internal static SyncStream syncStream_3;

	[TokenTypeUCOMIEnumConnectionPoints(-702672296)]
	internal static  policyLevelType_0;

	[ImporterCallback(1288063932)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_3;

	[CMSHASHTRANSFORM(-837372114)]
	internal static  objectDisposedExceptionFunctorComparer1_0;

	[global::StackOverflowException(-888685130)]
	internal static  privilegeNotHeldExceptionAppDomainUnloadedException_0;

	[SoapType(583944775)]
	internal static  isoapXsdSoapAttributeType_0;

	[ZoneMembershipConditionMarshalAs(415752514)]
	internal static  charinfo_0;

	[FormatterTypeStyle(-1332958380)]
	internal static  asyncRenewalCultureAwareComparer_0;

	[SoapType(1633014139)]
	internal static SyncStream syncStream_4;

	[FormatterTypeStyle(2035030446)]
	internal static  permissionSetTriple_0;

	[CMSHASHTRANSFORM(1746052250)]
	internal static  imuiResourceMapEntry_0;

	[ConstArray(-1903452754)]
	internal static  encoderFallbackExceptionIsConst_0;

	[global::StackOverflowException(-781408248)]
	internal static  storeAssemblyFileEnumeration_0;

	[ImporterCallback(-2101248568)]
	internal static FixedSizeList fixedSizeList_4;

	[ImporterCallback(823369086)]
	internal static SendOrPostCallbackConstants sendOrPostCallbackConstants_2;

	[global::StackOverflowException(-2080846074)]
	internal static  keyContainerPermission_0;

	[Int64ClientAsyncReplyTerminatorSink(-1437429289)]
	internal static  operationCanceledExceptionRegistryValueKind_0;

	[RuntimeWrappedExceptionKeyedCollection2(1489461314)]
	internal static  operationCanceledExceptionRegistryValueKind_1;

	[CMSHASHTRANSFORM(2077956986)]
	internal static  imuiResourceMapEntry_1;

	[Int64ClientAsyncReplyTerminatorSink(813845909)]
	internal static  gchandleTypeISCIIDecoder_0;

	[global::StackOverflowException(62740816)]
	internal static  propagationFlagsMdaHelper_0;

	[ConstArray(-832442614)]
	internal static TokenBasedSetEnumeratorTimeZone tokenBasedSetEnumeratorTimeZone_4;

	[IsolatedStorageFilePermission(-1636843494)]
	internal static SendOrPostCallbackConstants sendOrPostCallbackConstants_3;

	[FormatterTypeStyle(-1449331832)]
	internal static ApplicationTrustEnumeratorLogSwitch applicationTrustEnumeratorLogSwitch_2;

	[FormatterTypeStyle(338802890)]
	internal static ApplicationTrustEnumeratorLogSwitch applicationTrustEnumeratorLogSwitch_3;

	[ImporterCallback(-1055401304)]
	internal static  stringComparison_0;

	[FormatterTypeStyle(-1156616714)]
	internal static ApplicationTrustEnumeratorLogSwitch applicationTrustEnumeratorLogSwitch_4;

	[IsolatedStorageFilePermission(-1378083232)]
	internal static  unicodeEncoding_0;

	[RuntimeWrappedExceptionKeyedCollection2(-1514844432)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_4;

	[CMSHASHTRANSFORM(1838587926)]
	internal static  imuiResourceMapEntry_2;

	[SoapType(-185388869)]
	internal static  abandonedMutexException_0;

	[SynchronizedServerContextSink(-38119110)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_5;

	[SynchronizedServerContextSink(-229740612)]
	internal static  threadHelperRSAPKCS1SignatureFormatter_0;

	[TokenTypeUCOMIEnumConnectionPoints(284074682)]
	internal static TokenBasedSetEnumeratorTimeZone tokenBasedSetEnumeratorTimeZone_5;

	[SpecialPermissionSetFlagRuntimeArgumentHandle(1747810087)]
	internal static TokenBasedSetEnumeratorTimeZone tokenBasedSetEnumeratorTimeZone_6;

	[ConstArray(1411320940)]
	internal static TokenBasedSetEnumeratorTimeZone tokenBasedSetEnumeratorTimeZone_7;

	[global::PackingSize(1109011377)]
	internal static  threadHelperRSAPKCS1SignatureFormatter_1;

	[AceEnumeratorRijndaelManagedTransform(1664930247)]
	internal static  sortedListEnumeratorSyncArrayList_0;

	[ZoneMembershipConditionMarshalAs(2022602596)]
	internal static  operationCanceledExceptionRegistryValueKind_2;

	[RuntimeWrappedExceptionKeyedCollection2(1066256398)]
	internal static  cryptoKeyAccessRule_0;

	[TokenTypeUCOMIEnumConnectionPoints(-1490240006)]
	internal static  operationCanceledExceptionRegistryValueKind_3;

	[TokenTypeUCOMIEnumConnectionPoints(-1082775408)]
	internal static  principalPermissionAttribute_0;

	[global::StackOverflowException(1640491686)]
	internal static  assemblyProductAttribute_0;

	[SynchronizedServerContextSink(1977979190)]
	internal static  lsatranslatednamecompatibilityFlag_0;

	[CrossAppDomainSinkKeyList(762509114)]
	internal static  dynamicResolverStoreAssemblyEnumeration_0;

	[ZoneMembershipConditionMarshalAs(1099704352)]
	internal static  byteSinkStack_0;

	[ImporterCallback(-142678024)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_6;

	[global::StackOverflowException(1574143466)]
	internal static  delegate0_0;

	[AceEnumeratorRijndaelManagedTransform(-777744849)]
	internal static  stackFrameHelper_0;

	[AceEnumeratorRijndaelManagedTransform(-2061249729)]
	internal static  internalParseTypeEBStrWrapper_0;

	[ZoneMembershipConditionMarshalAs(1253981612)]
	internal static  muiResourceMapEntryFieldId_0;

	[ImporterCallback(1797363478)]
	internal static  stackFrameHelper_1;

	[RuntimeWrappedExceptionKeyedCollection2(1375506396)]
	internal static ApplicationTrustEnumeratorLogSwitch applicationTrustEnumeratorLogSwitch_5;

	[ImporterCallback(-1530329068)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_7;

	[global::PackingSize(-1606908543)]
	internal static ApplicationTrustEnumeratorLogSwitch applicationTrustEnumeratorLogSwitch_6;

	[SoapType(1879403731)]
	internal static ApplicationTrustEnumeratorLogSwitch applicationTrustEnumeratorLogSwitch_7;

	[ConstArray(-791314324)]
	internal static  timer_0;

	[RuntimeWrappedExceptionKeyedCollection2(-199730390)]
	internal static  operationCanceledExceptionRegistryValueKind_4;

	[SoapType(480318031)]
	internal static  decoderExceptionFallback_0;

	[CMSHASHTRANSFORM(1312537132)]
	internal static AssemblyKeyFileAttributePublisherIdentityPermission assemblyKeyFileAttributePublisherIdentityPermission_1;

	[SynchronizedServerContextSink(-186237666)]
	internal static  timer_1;

	[FormatterTypeStyle(-1782430360)]
	internal static ApplicationTrustEnumeratorLogSwitch applicationTrustEnumeratorLogSwitch_8;

	[ZoneMembershipConditionMarshalAs(-983727322)]
	internal static TokenBasedSetEnumeratorTimeZone tokenBasedSetEnumeratorTimeZone_8;

	[CrossAppDomainSinkKeyList(-1776309388)]
	internal static  timer_2;

	[FormatterTypeStyle(-1561654820)]
	internal static TokenBasedSetEnumeratorTimeZone tokenBasedSetEnumeratorTimeZone_9;

	[ImporterCallback(-1497633664)]
	internal static FixedSizeList fixedSizeList_5;

	[ConstArray(-831831714)]
	internal static SendOrPostCallbackConstants sendOrPostCallbackConstants_4;

	[global::StackOverflowException(956059284)]
	internal static  cryptoKeyAccessRule_1;

	[SpecialPermissionSetFlagRuntimeArgumentHandle(-2024234299)]
	internal static SendOrPostCallbackConstants sendOrPostCallbackConstants_5;

	[global::StackOverflowException(-861666616)]
	internal static  parseNumbers_0;

	[ZoneMembershipConditionMarshalAs(-2001079542)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_8;

	[global::StackOverflowException(-1935020124)]
	internal static SendOrPostCallbackConstants sendOrPostCallbackConstants_6;

	[ImporterCallback(444428996)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_9;

	[ImporterCallback(-268431552)]
	internal static SendOrPostCallbackConstants sendOrPostCallbackConstants_7;

	[global::PackingSize(-2112618633)]
	internal static SendOrPostCallbackConstants sendOrPostCallbackConstants_8;

	[SpecialPermissionSetFlagRuntimeArgumentHandle(-234481427)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_10;

	[SoapType(-1972439093)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_11;

	[SynchronizedServerContextSink(1267551982)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_12;

	[IsolatedStorageFilePermission(513442142)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_13;

	[Int64ClientAsyncReplyTerminatorSink(-1254509725)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_14;

	[FormatterTypeStyle(-817259222)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_15;

	[CMSHASHTRANSFORM(1608029624)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_16;

	[SpecialPermissionSetFlagRuntimeArgumentHandle(1188816503)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_17;

	[SynchronizedServerContextSink(-1878919296)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_18;

	[SynchronizedServerContextSink(621459076)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_19;

	[Int64ClientAsyncReplyTerminatorSink(1443245189)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_20;

	[global::StackOverflowException(-1017823106)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_21;

	[ZoneMembershipConditionMarshalAs(-1720636924)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_22;

	[FormatterTypeStyle(482062312)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_23;

	[SpecialPermissionSetFlagRuntimeArgumentHandle(1623517213)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_24;

	[IsolatedStorageFilePermission(1088898096)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_25;

	[global::StackOverflowException(-1269930242)]
	internal static ApplicationTrustEnumeratorLogSwitch applicationTrustEnumeratorLogSwitch_9;

	[SoapType(1884056721)]
	internal static ApplicationTrustEnumeratorLogSwitch applicationTrustEnumeratorLogSwitch_10;

	[ConstArray(-1147160016)]
	internal static ApplicationTrustEnumeratorLogSwitch applicationTrustEnumeratorLogSwitch_11;

	[global::PackingSize(74012405)]
	internal static  lsareferenceddomainlist_0;

	[ImporterCallback(1655310754)]
	internal static CategoryMembershipDataEntryFieldId categoryMembershipDataEntryFieldId_2;

	[ImporterCallback(-1175377310)]
	internal static  securityRuntimeISCIIEncoding_0;

	[SpecialPermissionSetFlagRuntimeArgumentHandle(1797411587)]
	internal static FixedSizeList fixedSizeList_6;

	[CrossAppDomainSinkKeyList(-1979216122)]
	internal static  internal_0;

	[AceEnumeratorRijndaelManagedTransform(885707841)]
	internal static  stringMaker_0;

	[ConstArray(270765966)]
	internal static  soapParameterAttribute_0;

	[IsolatedStorageFilePermission(468240102)]
	internal static  parseNumbers_1;

	[ZoneMembershipConditionMarshalAs(-921493616)]
	internal static ApplicationTrustEnumeratorLogSwitch applicationTrustEnumeratorLogSwitch_12;

	[ImporterCallback(1112289364)]
	internal static ApplicationTrustEnumeratorLogSwitch applicationTrustEnumeratorLogSwitch_13;

	[TokenTypeUCOMIEnumConnectionPoints(-2064961412)]
	internal static  parseNumbers_2;

	[TokenTypeUCOMIEnumConnectionPoints(-2104735434)]
	internal static CodePageIndex codePageIndex_0;

	[ConstArray(1214251084)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_26;

	[ConstArray(563151998)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_27;

	[IsolatedStorageFilePermission(-449434224)]
	internal static  decoderReplacementFallbackBuffer_0;

	[SoapType(-368072753)]
	internal static  loadHint_0;

	[SynchronizedServerContextSink(-873273896)]
	internal static  userobjectflags_0;

	[FormatterTypeStyle(310712606)]
	internal static  leaseSink_0;

	[RuntimeWrappedExceptionKeyedCollection2(1119992424)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_28;

	[global::PackingSize(2143562059)]
	internal static FixedSizeList fixedSizeList_7;

	[RuntimeWrappedExceptionKeyedCollection2(604687116)]
	internal static  operationCanceledExceptionRegistryValueKind_5;

	[SoapType(1043329103)]
	internal static  idescriptionMetadataEntryArraySegment1_0;

	[ConstArray(-875571930)]
	internal static  hasCopySemanticsAttributeGenericArraySortHelper2_0;

	[global::PackingSize(-502968225)]
	internal static  lockCookieFieldAttributes_0;

	[SpecialPermissionSetFlagRuntimeArgumentHandle(-152986777)]
	internal static  siteMemberListType_0;

	[global::StackOverflowException(1879251706)]
	internal static  ucomireflect_0;

	[Int64ClientAsyncReplyTerminatorSink(-1755170233)]
	internal static CategoryMembershipDataEntryFieldId categoryMembershipDataEntryFieldId_3;

	[global::PackingSize(-1154298867)]
	internal static  callConvFastcallCMSASSEMBLYREFERENCEDEPENDENTASSEMBLYFLAG_0;

	[CrossAppDomainSinkKeyList(816829432)]
	internal static  eventResetModeXmlNamespaceEncoder_0;

	[RuntimeWrappedExceptionKeyedCollection2(-2017506346)]
	internal static  threadInterruptedExceptionIContributeDynamicSink_0;

	[CMSHASHTRANSFORM(-732022244)]
	internal static  eventResetModeXmlNamespaceEncoder_1;

	[ConstArray(-576987746)]
	internal static  threadInterruptedExceptionIContributeDynamicSink_1;

	[CMSHASHTRANSFORM(-2121488304)]
	internal static  formatterTypeStyleBitArrayEnumeratorSimple_0;

	[TokenTypeUCOMIEnumConnectionPoints(1327652794)]
	internal static  dateTimeFormatDynamicMethod_0;

	[SpecialPermissionSetFlagRuntimeArgumentHandle(132133109)]
	internal static  eventResetModeDSAParameters_0;

	[TokenTypeUCOMIEnumConnectionPoints(-455565204)]
	internal static  methodAccessException_0;

	[CMSHASHTRANSFORM(449799958)]
	internal static  fileIOPermissionAttributeMCMDictionary_0;

	[TokenTypeUCOMIEnumConnectionPoints(109962226)]
	internal static  policyStatementAttribute_0;

	[ImporterCallback(2076348800)]
	internal static CategoryMembershipDataEntryFieldId categoryMembershipDataEntryFieldId_4;

	[SoapType(1402562323)]
	internal static CategoryMembershipDataEntryFieldId categoryMembershipDataEntryFieldId_5;

	[global::StackOverflowException(-1076729378)]
	internal static CategoryMembershipDataEntryFieldId categoryMembershipDataEntryFieldId_6;

	[Int64ClientAsyncReplyTerminatorSink(-1721658613)]
	internal static ApplicationTrustEnumeratorLogSwitch applicationTrustEnumeratorLogSwitch_14;

	[SpecialPermissionSetFlagRuntimeArgumentHandle(799598799)]
	internal static  threadInterruptedExceptionIContributeDynamicSink_2;

	[global::StackOverflowException(293906058)]
	internal static  stringComparison_1;

	[AceEnumeratorRijndaelManagedTransform(741056197)]
	internal static  threadInterruptedExceptionIContributeDynamicSink_3;

	[AceEnumeratorRijndaelManagedTransform(211291257)]
	internal static  operatingSystem_0;

	[ConstArray(-730006992)]
	internal static CategoryMembershipDataEntryFieldId categoryMembershipDataEntryFieldId_7;

	[ConstArray(-448874820)]
	internal static CategoryMembershipDataEntryFieldId categoryMembershipDataEntryFieldId_8;

	[ConstArray(382895628)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_29;

	[SynchronizedServerContextSink(-900454904)]
	internal static CategoryMembershipDataEntryFieldId categoryMembershipDataEntryFieldId_9;

	[SoapType(59521257)]
	internal static EntryDefaultDependencyAttribute entryDefaultDependencyAttribute_0;

	[RuntimeWrappedExceptionKeyedCollection2(-781825676)]
	internal static  bindingFlagsIEnumVARIANT_0;

	[CMSHASHTRANSFORM(-895002524)]
	internal static  bindingFlagsIEnumVARIANT_1;

	[CMSHASHTRANSFORM(1379261332)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_30;

	[ZoneMembershipConditionMarshalAs(365962974)]
	internal static CategoryMembershipDataEntryFieldId categoryMembershipDataEntryFieldId_10;

	[RuntimeWrappedExceptionKeyedCollection2(-12533498)]
	internal static  optionalAttributeIDependentOSMetadataEntry_0;

	[IsolatedStorageFilePermission(1137567956)]
	internal static  propagationFlagsMdaHelper_1;

	[AceEnumeratorRijndaelManagedTransform(65196521)]
	internal static  cryptoKeyAccessRule_2;

	[RuntimeWrappedExceptionKeyedCollection2(-2041775456)]
	internal static ConvertExecutionContext convertExecutionContext_0;

	[Int64ClientAsyncReplyTerminatorSink(1354149005)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_31;

	[ImporterCallback(-1389550944)]
	internal static  idescriptionMetadataEntryArraySegment1_1;

	[ConstArray(-925144868)]
	internal static AssemblyKeyFileAttributePublisherIdentityPermission assemblyKeyFileAttributePublisherIdentityPermission_2;

	[RuntimeWrappedExceptionKeyedCollection2(1726442256)]
	internal static AllMembershipConditionFileStreamAsyncResult allMembershipConditionFileStreamAsyncResult_0;

	[CrossAppDomainSinkKeyList(741803848)]
	internal static StackBuilderSinkRuntimeArgumentHandle stackBuilderSinkRuntimeArgumentHandle_32;

	[RuntimeWrappedExceptionKeyedCollection2(998561294)]
	internal static ApplicationTrustEnumeratorLogSwitch applicationTrustEnumeratorLogSwitch_15;

	public static IntPtr CryptoKeySecurityCryptographicException;

	public static string EXCEPINFO;

	public static Thread TypeLibFuncAttributeFORMATFLAGS;

	public static Process LOGICDeriveBytes;

	public static Environment IStreamable;

	public static OperatingSystem DebuggerHiddenAttributeMetadataToken;

	public static ProcessModule IEnumDefinitionIdentityBuiltInPermissionFlag;

	public static FileVersionInfo FileEntry;

	public static RuntimeMethodHandle ICLRSurrogateEntry;

	public static Math FromBase64TransformUCOMIEnumConnectionPoints;

	public static Buffer HashHelpers;

	public static WindowsFormsApplicationBase DependentOSMetadataEntryDESCKIND;

	public static Application UCOMIEnumMonikerHMAC;

	public static Control IAssemblyRequestEntry;

	public static Type DecoderFallbackBufferSecurityState;

	public static Utils AuthorizationRuleCollection;

	public static ProjectData AsyncResult;

	public static RuntimeHelpers SafeArrayTypeMismatchException;

	public static SettingsBase IAppIdAuthority;

	public static ObjectFlowControl BinaryUtil;

	public static Monitor Path;

	public static Form NullableEqualityComparer1;

	public static MouseEventArgs DeriveBytes;

	public static Point IServiceProvider;

	public static Interaction FileDialogPermissionAttribute;

	public static FileDialog BadImageFormatExceptionSecurityIdentifier;

	public static DragEventArgs IEnvoyInfo;

	public static MetroTrackbar CollectionBase;

	public static CheckBox IsPinned;

	public static DateTime LastCalledTypeSoapBase64Binary;

	public static HttpRequest MethodCall;

	public static GroupCollection CrossAppDomainSinkStoreOperationStageComponent;

	public static Http StoreSubcategoryEnumeration;

	public static Capture NumberBuffer;

	public static MetroChecker TOKENGROUPSLogLevel;

	public static Group CustomAttribute;

	public static System.Windows.Forms.Timer SoapMonthDay;

	public static ToolStripItem CRMDictionary;

	public static Color DateTimeFormatInfoScannerCustomAttributeTypedArgument;

	public static ToolStripMenuItem CONSOLESCREENBUFFERINFO;

	public static PictureBox OnSerializedAttribute;

	public static Cursors AssemblyCultureAttributeIsConst;

	public static TabControl CategoryMembershipEntrySoapNmtokens;

	public static Panel panel_0;

	public static TabPage CALLCONV;

	public static MetroTextbox ITypeName;

	public static ButtonBase CtorDelegateRedirectionProxy;

	public static DataGridView TargetException;

	public static DataGridViewCellStyle Double;

	public static SystemColors IDispatchImplAttribute;

	public static DataGridViewColumn IComparer1INVOKEKIND;

	public static MetroComboBox BinaryConverter;

	public static ComboBox SoapNameTokenizerShortBlock;

	public static ListControl UCOMIRunningObjectTableServerWellKnownEntry;

	public static ContainerControl IEnumIDENTITYATTRIBUTESerializationException;

	public static Encoding SynchronizationContextSwitcher;

	public static byte MetadataFileAttributes;

	public static Rectangle ISO2022Decoder;

	public static SizeF FileUInt32;

	public static Information information_0;

	public static Delegate TryCodeInvalidOperationException;

	public static ListViewItem SyncSortedList;

	public static ListViewItem.ListViewSubItem BuiltInPermissionFlag;

	public static PaintEventArgs IContributeServerContextSink;

	public static Graphics LocalDataStoreTypeLibConverter;

	public static Enumerable RSAPKCS1SHA1SignatureDescriptionMuiResourceTypeIdStringEntry;

	public static ListViewItem.ListViewSubItemCollection LayoutKindIActivator;

	public static Operators AssemblyBuilderFixedBufferAttribute;

	public static RectangleF AsymmetricSignatureDeformatterCaseInsensitiveComparer;

	public static Computer StrongName2EncodingByteBuffer;

	public static Keyboard Debugger;

	public static TextBox UnionCodeGroupCultureTypes;

	public static TextBoxBase WindowsImpersonationContext;

	public static KeyPressEventArgs EventSinkHelperWriterAsymmetricAlgorithm;

	public static Strings MemberPrimitiveTyped;

	public static ProgressBar PreLoadEntry;

	public static Size FileDialogPermission;

	public static ToolStrip IsolatedStorageFileWindowsPrincipal;

	public static ToolStripArrowRenderEventArgs RegistryPermissionAccessIArraySortHelper1;

	public static ToolStripRenderEventArgs SecurityContextSwitcher;

	public static ToolStripItemRenderEventArgs TOKENPRIVILEGEUnverifiableCodeAttribute;

	public static ToolStripItemImageRenderEventArgs SyncStackMissingMemberException;

	public static ToolStripItemTextRenderEventArgs StringInfo;

	public static ControlEventArgs PermissionTokenFactory;

	public static Component RandomMCMDictionary;

	public static ProcessStartInfo AssemblyReferenceDependentAssemblyEntryLog;

	public static TimeSpan JitHelpersEnumCategoriesFlags;

	public static IStoreHostProtectionException IsolatedStoragePermission;

	public static byte[] MuiResourceTypeIdStringEntryFieldId;

	public static IntPtr[] EventSinkHelperWriterIAssemblyRequestEntry;

	public static Dictionary<string, MethodInfo> IIDENTITYAUTHORITYDOESDEFINITIONMATCHREFERENCEFLAGS;

	private static Dictionary<Type, List<MethodInfo>> CMSTIMEUNITTYPE;

	private static Dictionary<Type, List<ConstructorInfo>> EncoderFallback;

	[ConsoleCtrlHandlerRoutine(-460274932)]
	internal static REDocumentServerChannelSinkStack redocumentServerChannelSinkStack_0;

	[StoreOperationMetadataPropertyHMACMD5(693414621)]
	internal static NullTextWriterSecurityTreatAsSafeAttribute nullTextWriterSecurityTreatAsSafeAttribute_0;

	[RegionNameOffsetItemTypeInitializationException(-1674777676)]
	internal static SerializationExceptionIDynamicMessageSink serializationExceptionIDynamicMessageSink_0;

	[IComparer1HostSecurityManagerOptions(818452245)]
	internal static FileAssociationEntrySoapEntity fileAssociationEntrySoapEntity_0;

	[ConsoleCtrlHandlerRoutine(-419623760)]
	internal static EntrySerializationEntry entrySerializationEntry_0;

	[SecurityPermissionFlag(149609172)]
	internal static global::NullReferenceException nullReferenceException_0;

	[ValueFixupEnumAttributeTargets(-1086262246)]
	internal static IDRole idrole_0;

	[TargetInvocationExceptionList1(-2093429839)]
	internal static IDRole idrole_1;

	[ValueFixupEnumAttributeTargets(617123920)]
	internal static IConstructionReturnMessagePrivilegeNotHeldException iconstructionReturnMessagePrivilegeNotHeldException_0;

	[SecurityPermissionFlag(-395766106)]
	internal static GacMembershipConditionResourceTypeCode gacMembershipConditionResourceTypeCode_0;

	[global::IDispatchConstant(-494228542)]
	internal static OpFlags opFlags_0;

	[STAThreadAttributeIndexOutOfRangeException(-938088882)]
	internal static REDocumentServerChannelSinkStack redocumentServerChannelSinkStack_1;

	[SafeRegistryHandle(-1287656256)]
	internal static ILGeneratorIComparable ilgeneratorIComparable_0;

	[SecurityPermissionFlag(1790192244)]
	internal static NotSupportedExceptionModuleResolveEventHandler notSupportedExceptionModuleResolveEventHandler_0;

	[RSAOAEPKeyExchangeFormatterTwoLevelFileEnumerator(-2097337056)]
	internal static NotSupportedExceptionModuleResolveEventHandler notSupportedExceptionModuleResolveEventHandler_1;

	[ValueFixupEnumAttributeTargets(-805125608)]
	internal static NotSupportedExceptionModuleResolveEventHandler notSupportedExceptionModuleResolveEventHandler_2;

	[HResultsActivationArguments(1169614856)]
	internal static global::UCOMIEnumConnections ucomienumConnections_0;

	[StoreOperationMetadataPropertyHMACMD5(1599204091)]
	internal static NotSupportedExceptionModuleResolveEventHandler notSupportedExceptionModuleResolveEventHandler_3;

	[ValueFixupEnumAttributeTargets(1516967252)]
	internal static global::INVOKEKIND invokekind_0;

	[ValueFixupEnumAttributeTargets(1389590484)]
	internal static global::UCOMIEnumConnections ucomienumConnections_1;

	[AceQualifier(176958313)]
	internal static global::UCOMIEnumConnections ucomienumConnections_2;

	[AceQualifier(1791929257)]
	internal static Int16PermissionSetEnumerator int16PermissionSetEnumerator_0;

	[AceQualifier(-842568117)]
	internal static RemotingExceptionHebrewNumberParsingState remotingExceptionHebrewNumberParsingState_0;

	[ConsoleCtrlHandlerRoutine(218449778)]
	internal static SoapNmtoken soapNmtoken_0;

	[GetPackagePropertyFlagsQueue(1039377857)]
	internal static InvalidCastExceptionSHA1 invalidCastExceptionSHA1_0;

	[SecurityPermissionFlag(996401132)]
	internal static SecurityPermissionIsImplicitlyDereferenced securityPermissionIsImplicitlyDereferenced_0;

	[SecurityPermissionFlag(-575425500)]
	internal static SiteIdentityPermissionAttributeRemotingProfilerEvent siteIdentityPermissionAttributeRemotingProfilerEvent_0;

	[ConfigTreeParserXmlSyntaxException(495946800)]
	internal static NumberBufferTypeAttributes numberBufferTypeAttributes_0;

	[ValueFixupEnumAttributeTargets(-1774045706)]
	internal static NetCodeGroupCodeGroupStack netCodeGroupCodeGroupStack_0;

	[ConfigTreeParserXmlSyntaxException(649284202)]
	internal static MemberPrimitiveUnTyped memberPrimitiveUnTyped_0;

	[ConsoleCtrlHandlerRoutine(391745338)]
	internal static Int16PermissionSetEnumerator int16PermissionSetEnumerator_1;

	[GetPackagePropertyFlagsQueue(1633083545)]
	internal static UnverifiableCodeAttributeMissingFieldException unverifiableCodeAttributeMissingFieldException_0;

	[SecurityPermissionFlag(-1932279568)]
	internal static ILGeneratorIComparable ilgeneratorIComparable_1;

	[global::IDispatchConstant(1622936950)]
	internal static IArraySortHelper1TypeEntry iarraySortHelper1TypeEntry_0;

	[HResultsActivationArguments(336427386)]
	internal static Delegate1 delegate1_0;

	[PermissionTokenKeyComparer(-1405329841)]
	internal static PermissionTokenTypeEnumAssemblyFilesFlags permissionTokenTypeEnumAssemblyFilesFlags_0;

	[STAThreadAttributeIndexOutOfRangeException(-1187121858)]
	internal static InternalMessageWrapper internalMessageWrapper_0;

	[TargetInvocationExceptionList1(-369864787)]
	internal static Delegate1 delegate1_1;

	[GetPackagePropertyFlagsQueue(-1604307401)]
	internal static ContextAttributeEntry contextAttributeEntry_0;

	[HResultsActivationArguments(-1992553778)]
	internal static ILGeneratorIComparable ilgeneratorIComparable_2;

	[IComparer1HostSecurityManagerOptions(1786551073)]
	internal static global::EntryPointNotFoundException entryPointNotFoundException_0;

	[ConsoleCtrlHandlerRoutine(1390972580)]
	internal static AssemblyHashAlgorithmRSAOAEPKeyExchangeFormatter assemblyHashAlgorithmRSAOAEPKeyExchangeFormatter_0;

	[StoreOperationMetadataPropertyHMACMD5(-1124074643)]
	internal static InvalidCastExceptionSHA1 invalidCastExceptionSHA1_1;

	[PermissionTokenKeyComparer(-1180629879)]
	internal static InternalMessageWrapper internalMessageWrapper_1;

	[STAThreadAttributeIndexOutOfRangeException(1446363180)]
	internal static LeaseManagerMscorlibDictionaryDebugView2 leaseManagerMscorlibDictionaryDebugView2_0;

	[GetPackagePropertyFlagsQueue(-703643791)]
	internal static SecurityPermissionIsImplicitlyDereferenced securityPermissionIsImplicitlyDereferenced_1;

	[ValueFixupEnumAttributeTargets(1416127662)]
	internal static GCSafeFindHandle gcsafeFindHandle_0;

	[ValueFixupEnumAttributeTargets(-22829620)]
	internal static CalendarServerException calendarServerException_0;

	[SecurityPermissionFlag(-290050954)]
	internal static EncoderReplacementFallbackBufferLocalBuilder encoderReplacementFallbackBufferLocalBuilder_0;

	[SecurityPermissionFlag(1587487912)]
	internal static SecurityPermissionIsImplicitlyDereferenced securityPermissionIsImplicitlyDereferenced_2;

	[RSAOAEPKeyExchangeFormatterTwoLevelFileEnumerator(-880618278)]
	internal static GCSafeFindHandle gcsafeFindHandle_1;

	[PermissionTokenKeyComparer(418059227)]
	internal static JapaneseLunisolarCalendarRSAPKCS1SHA1SignatureDescription japaneseLunisolarCalendarRSAPKCS1SHA1SignatureDescription_0;

	[AceQualifier(-352845069)]
	internal static SerializationExceptionIDynamicMessageSink serializationExceptionIDynamicMessageSink_1;

	[IComparer1HostSecurityManagerOptions(-1926163605)]
	internal static JapaneseLunisolarCalendarRSAPKCS1SHA1SignatureDescription japaneseLunisolarCalendarRSAPKCS1SHA1SignatureDescription_1;

	[SafeRegistryHandle(1250988882)]
	internal static CultureTableDataObsoleteAttribute cultureTableDataObsoleteAttribute_0;

	[SafeRegistryHandle(724986906)]
	internal static IObjectReferenceAssemblyMetadata iobjectReferenceAssemblyMetadata_0;

	[ConsoleCtrlHandlerRoutine(847644838)]
	internal static ObjectAuditRuleSinkProviderEntry objectAuditRuleSinkProviderEntry_0;

	[AceQualifier(1374993591)]
	internal static TargetExceptionDictionary2 targetExceptionDictionary2_0;

	[TargetInvocationExceptionList1(1929629067)]
	internal static DateBufferSymAddressKind dateBufferSymAddressKind_0;

	[ValueFixupEnumAttributeTargets(830480500)]
	internal static StreamTokenReader streamTokenReader_0;

	[RSAOAEPKeyExchangeFormatterTwoLevelFileEnumerator(1097166304)]
	internal static GCSafeFindHandle gcsafeFindHandle_2;

	[StoreOperationMetadataPropertyHMACMD5(1804767627)]
	internal static FUNCDESCTimeout funcdesctimeout_0;

	[global::IDispatchConstant(-520770638)]
	internal static NotSupportedExceptionModuleResolveEventHandler notSupportedExceptionModuleResolveEventHandler_4;

	[STAThreadAttributeIndexOutOfRangeException(-1655149274)]
	internal static HashFormatterAssemblyStyle hashFormatterAssemblyStyle_0;

	[IComparer1HostSecurityManagerOptions(-1604266481)]
	internal static CerHashtable2RemotingConfigHandler cerHashtable2RemotingConfigHandler_0;

	[GetPackagePropertyFlagsQueue(-1432989303)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_0;

	[ValueFixupEnumAttributeTargets(1087430070)]
	internal static InvalidCastExceptionSHA1 invalidCastExceptionSHA1_2;

	[PermissionTokenKeyComparer(-825479955)]
	internal static SecurityPermissionIsImplicitlyDereferenced securityPermissionIsImplicitlyDereferenced_3;

	[IComparer1HostSecurityManagerOptions(1809805717)]
	internal static IDeploymentMetadataEntryCryptoKeySecurity ideploymentMetadataEntryCryptoKeySecurity_0;

	[ConsoleCtrlHandlerRoutine(-95469630)]
	internal static ILGeneratorIComparable ilgeneratorIComparable_3;

	[ConfigTreeParserXmlSyntaxException(-298134304)]
	internal static global::RegistrationConnectionType registrationConnectionType_0;

	[RSAOAEPKeyExchangeFormatterTwoLevelFileEnumerator(1248700506)]
	internal static CanonPersianCalendar canonPersianCalendar_0;

	[HResultsActivationArguments(1908702716)]
	internal static SiteMembershipCondition siteMembershipCondition_0;

	[SafeRegistryHandle(907211694)]
	internal static Delegate2 delegate2_0;

	[global::IDispatchConstant(2147108900)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_1;

	[AceQualifier(-439202859)]
	internal static DateBufferSymAddressKind dateBufferSymAddressKind_1;

	[ConfigTreeParserXmlSyntaxException(1422856238)]
	internal static StreamTokenReader streamTokenReader_1;

	[ValueFixupEnumAttributeTargets(-1928130246)]
	internal static GCSafeFindHandle gcsafeFindHandle_3;

	[ValueFixupEnumAttributeTargets(1212910464)]
	internal static FUNCDESCTimeout funcdesctimeout_1;

	[SafeRegistryHandle(141475274)]
	internal static NotSupportedExceptionModuleResolveEventHandler notSupportedExceptionModuleResolveEventHandler_5;

	[ConsoleCtrlHandlerRoutine(1834538630)]
	internal static HashFormatterAssemblyStyle hashFormatterAssemblyStyle_1;

	[StoreOperationMetadataPropertyHMACMD5(-99099741)]
	internal static CerHashtable2RemotingConfigHandler cerHashtable2RemotingConfigHandler_1;

	[AceQualifier(-1631286475)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_2;

	[ConsoleCtrlHandlerRoutine(-88847048)]
	internal static InvalidCastExceptionSHA1 invalidCastExceptionSHA1_3;

	[GetPackagePropertyFlagsQueue(1996206709)]
	internal static SecurityPermissionIsImplicitlyDereferenced securityPermissionIsImplicitlyDereferenced_4;

	[PermissionTokenKeyComparer(-469149927)]
	internal static IDeploymentMetadataEntryCryptoKeySecurity ideploymentMetadataEntryCryptoKeySecurity_1;

	[TargetInvocationExceptionList1(363130415)]
	internal static ILGeneratorIComparable ilgeneratorIComparable_4;

	[GetPackagePropertyFlagsQueue(-563975697)]
	internal static global::RegistrationConnectionType registrationConnectionType_1;

	[SecurityPermissionFlag(1249736128)]
	internal static CanonPersianCalendar canonPersianCalendar_1;

	[ValueFixupEnumAttributeTargets(-107089234)]
	internal static SiteMembershipCondition siteMembershipCondition_1;

	[GetPackagePropertyFlagsQueue(958586683)]
	internal static Delegate2 delegate2_1;

	[ConsoleCtrlHandlerRoutine(122894726)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_3;

	[SecurityPermissionFlag(2022764426)]
	internal static DateBufferSymAddressKind dateBufferSymAddressKind_2;

	[IComparer1HostSecurityManagerOptions(-592602375)]
	internal static StreamTokenReader streamTokenReader_2;

	[IComparer1HostSecurityManagerOptions(365326407)]
	internal static GCSafeFindHandle gcsafeFindHandle_4;

	[ConfigTreeParserXmlSyntaxException(-160113100)]
	internal static FUNCDESCTimeout funcdesctimeout_2;

	[AceQualifier(-140630491)]
	internal static NotSupportedExceptionModuleResolveEventHandler notSupportedExceptionModuleResolveEventHandler_6;

	[ConsoleCtrlHandlerRoutine(-58305932)]
	internal static HashFormatterAssemblyStyle hashFormatterAssemblyStyle_2;

	[RSAOAEPKeyExchangeFormatterTwoLevelFileEnumerator(1122393974)]
	internal static CerHashtable2RemotingConfigHandler cerHashtable2RemotingConfigHandler_2;

	[ValueFixupEnumAttributeTargets(2131430116)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_4;

	[SafeRegistryHandle(-1644830950)]
	internal static InvalidCastExceptionSHA1 invalidCastExceptionSHA1_4;

	[SafeRegistryHandle(-674127346)]
	internal static SecurityPermissionIsImplicitlyDereferenced securityPermissionIsImplicitlyDereferenced_5;

	[SecurityPermissionFlag(1795795250)]
	internal static IDeploymentMetadataEntryCryptoKeySecurity ideploymentMetadataEntryCryptoKeySecurity_2;

	[SafeRegistryHandle(2001195760)]
	internal static ILGeneratorIComparable ilgeneratorIComparable_5;

	[ConfigTreeParserXmlSyntaxException(-16519614)]
	internal static global::RegistrationConnectionType registrationConnectionType_2;

	[RSAOAEPKeyExchangeFormatterTwoLevelFileEnumerator(1614369826)]
	internal static CanonPersianCalendar canonPersianCalendar_2;

	[StoreOperationMetadataPropertyHMACMD5(1470969603)]
	internal static SiteMembershipCondition siteMembershipCondition_2;

	[PermissionTokenKeyComparer(-1765367005)]
	internal static Delegate2 delegate2_2;

	[RSAOAEPKeyExchangeFormatterTwoLevelFileEnumerator(-1131309602)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_5;

	[SecurityPermissionFlag(-1240439186)]
	internal static DateBufferSymAddressKind dateBufferSymAddressKind_3;

	[ValueFixupEnumAttributeTargets(153697380)]
	internal static StreamTokenReader streamTokenReader_3;

	[ConsoleCtrlHandlerRoutine(709221368)]
	internal static GCSafeFindHandle gcsafeFindHandle_5;

	[ValueFixupEnumAttributeTargets(-1421653292)]
	internal static FUNCDESCTimeout funcdesctimeout_3;

	[ConfigTreeParserXmlSyntaxException(304027610)]
	internal static NotSupportedExceptionModuleResolveEventHandler notSupportedExceptionModuleResolveEventHandler_7;

	[ConfigTreeParserXmlSyntaxException(1215881976)]
	internal static HashFormatterAssemblyStyle hashFormatterAssemblyStyle_3;

	[StoreOperationMetadataPropertyHMACMD5(-48928275)]
	internal static CerHashtable2RemotingConfigHandler cerHashtable2RemotingConfigHandler_3;

	[HResultsActivationArguments(566623728)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_6;

	[ConsoleCtrlHandlerRoutine(193970872)]
	internal static InvalidCastExceptionSHA1 invalidCastExceptionSHA1_5;

	[AceQualifier(1654415335)]
	internal static SecurityPermissionIsImplicitlyDereferenced securityPermissionIsImplicitlyDereferenced_6;

	[STAThreadAttributeIndexOutOfRangeException(2063814722)]
	internal static IDeploymentMetadataEntryCryptoKeySecurity ideploymentMetadataEntryCryptoKeySecurity_3;

	[StoreOperationMetadataPropertyHMACMD5(835845509)]
	internal static ILGeneratorIComparable ilgeneratorIComparable_6;

	[ConsoleCtrlHandlerRoutine(560270424)]
	internal static global::RegistrationConnectionType registrationConnectionType_3;

	[RSAOAEPKeyExchangeFormatterTwoLevelFileEnumerator(1395496798)]
	internal static CanonPersianCalendar canonPersianCalendar_3;

	[ConsoleCtrlHandlerRoutine(-157015224)]
	internal static SiteMembershipCondition siteMembershipCondition_3;

	[global::IDispatchConstant(-879476898)]
	internal static Delegate2 delegate2_3;

	[SafeRegistryHandle(-1042042290)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_7;

	[RegionNameOffsetItemTypeInitializationException(1602818058)]
	internal static DateBufferSymAddressKind dateBufferSymAddressKind_4;

	[GetPackagePropertyFlagsQueue(844906307)]
	internal static StreamTokenReader streamTokenReader_4;

	[IComparer1HostSecurityManagerOptions(1838767383)]
	internal static GCSafeFindHandle gcsafeFindHandle_6;

	[SafeRegistryHandle(-1965271512)]
	internal static FUNCDESCTimeout funcdesctimeout_4;

	[IComparer1HostSecurityManagerOptions(-1836347057)]
	internal static NotSupportedExceptionModuleResolveEventHandler notSupportedExceptionModuleResolveEventHandler_8;

	[StoreOperationMetadataPropertyHMACMD5(-1347051955)]
	internal static HashFormatterAssemblyStyle hashFormatterAssemblyStyle_4;

	[STAThreadAttributeIndexOutOfRangeException(769991156)]
	internal static CerHashtable2RemotingConfigHandler cerHashtable2RemotingConfigHandler_4;

	[SafeRegistryHandle(1218583198)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_8;

	[SecurityPermissionFlag(1695481390)]
	internal static InvalidCastExceptionSHA1 invalidCastExceptionSHA1_6;

	[global::IDispatchConstant(-1870250826)]
	internal static SecurityPermissionIsImplicitlyDereferenced securityPermissionIsImplicitlyDereferenced_7;

	[IComparer1HostSecurityManagerOptions(-1244427271)]
	internal static IDeploymentMetadataEntryCryptoKeySecurity ideploymentMetadataEntryCryptoKeySecurity_4;

	[GetPackagePropertyFlagsQueue(1117431855)]
	internal static ILGeneratorIComparable ilgeneratorIComparable_7;

	[HResultsActivationArguments(1535156188)]
	internal static global::RegistrationConnectionType registrationConnectionType_4;

	[PermissionTokenKeyComparer(-1949244387)]
	internal static CanonPersianCalendar canonPersianCalendar_4;

	[HResultsActivationArguments(1781757468)]
	internal static SiteMembershipCondition siteMembershipCondition_4;

	[IComparer1HostSecurityManagerOptions(-1090646207)]
	internal static Delegate2 delegate2_4;

	[RegionNameOffsetItemTypeInitializationException(1312854882)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_9;

	[HResultsActivationArguments(-983815930)]
	internal static DateBufferSymAddressKind dateBufferSymAddressKind_5;

	[AceQualifier(-766883277)]
	internal static StreamTokenReader streamTokenReader_5;

	[TargetInvocationExceptionList1(-1367694689)]
	internal static GCSafeFindHandle gcsafeFindHandle_7;

	[global::IDispatchConstant(1739260028)]
	internal static FUNCDESCTimeout funcdesctimeout_5;

	[GetPackagePropertyFlagsQueue(-416890359)]
	internal static NotSupportedExceptionModuleResolveEventHandler notSupportedExceptionModuleResolveEventHandler_9;

	[ConsoleCtrlHandlerRoutine(1090986252)]
	internal static HashFormatterAssemblyStyle hashFormatterAssemblyStyle_5;

	[IComparer1HostSecurityManagerOptions(1246924149)]
	internal static CerHashtable2RemotingConfigHandler cerHashtable2RemotingConfigHandler_5;

	[StoreOperationMetadataPropertyHMACMD5(714516055)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_10;

	[PermissionTokenKeyComparer(596259955)]
	internal static InvalidCastExceptionSHA1 invalidCastExceptionSHA1_7;

	[GetPackagePropertyFlagsQueue(-997080215)]
	internal static SecurityPermissionIsImplicitlyDereferenced securityPermissionIsImplicitlyDereferenced_8;

	[ConsoleCtrlHandlerRoutine(550148712)]
	internal static IDeploymentMetadataEntryCryptoKeySecurity ideploymentMetadataEntryCryptoKeySecurity_5;

	[HResultsActivationArguments(-1060659488)]
	internal static ILGeneratorIComparable ilgeneratorIComparable_8;

	[StoreOperationMetadataPropertyHMACMD5(-1146631857)]
	internal static global::RegistrationConnectionType registrationConnectionType_5;

	[RegionNameOffsetItemTypeInitializationException(1867667812)]
	internal static CanonPersianCalendar canonPersianCalendar_5;

	[HResultsActivationArguments(-1389290504)]
	internal static SiteMembershipCondition siteMembershipCondition_5;

	[StoreOperationMetadataPropertyHMACMD5(543328231)]
	internal static Delegate2 delegate2_5;

	[SecurityPermissionFlag(-1927136712)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_11;

	[global::IDispatchConstant(-684033670)]
	internal static DateBufferSymAddressKind dateBufferSymAddressKind_6;

	[ValueFixupEnumAttributeTargets(-1431403488)]
	internal static StreamTokenReader streamTokenReader_6;

	[SecurityPermissionFlag(194090446)]
	internal static GCSafeFindHandle gcsafeFindHandle_8;

	[AceQualifier(492157809)]
	internal static FUNCDESCTimeout funcdesctimeout_6;

	[HResultsActivationArguments(-893538524)]
	internal static NotSupportedExceptionModuleResolveEventHandler notSupportedExceptionModuleResolveEventHandler_10;

	[global::IDispatchConstant(1184174696)]
	internal static HashFormatterAssemblyStyle hashFormatterAssemblyStyle_6;

	[TargetInvocationExceptionList1(-1711435453)]
	internal static CerHashtable2RemotingConfigHandler cerHashtable2RemotingConfigHandler_6;

	[AceQualifier(-214383313)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_12;

	[ValueFixupEnumAttributeTargets(-1882486148)]
	internal static InvalidCastExceptionSHA1 invalidCastExceptionSHA1_8;

	[ValueFixupEnumAttributeTargets(-1842903834)]
	internal static SecurityPermissionIsImplicitlyDereferenced securityPermissionIsImplicitlyDereferenced_9;

	[STAThreadAttributeIndexOutOfRangeException(100152130)]
	internal static IDeploymentMetadataEntryCryptoKeySecurity ideploymentMetadataEntryCryptoKeySecurity_6;

	[GetPackagePropertyFlagsQueue(1722398093)]
	internal static ILGeneratorIComparable ilgeneratorIComparable_9;

	[ValueFixupEnumAttributeTargets(835586230)]
	internal static global::RegistrationConnectionType registrationConnectionType_6;

	[IComparer1HostSecurityManagerOptions(-2122385637)]
	internal static CanonPersianCalendar canonPersianCalendar_6;

	[global::IDispatchConstant(629186674)]
	internal static SiteMembershipCondition siteMembershipCondition_6;

	[HResultsActivationArguments(800225314)]
	internal static Delegate2 delegate2_6;

	[SecurityPermissionFlag(2023104422)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_13;

	[TargetInvocationExceptionList1(1574772323)]
	internal static DateBufferSymAddressKind dateBufferSymAddressKind_7;

	[RSAOAEPKeyExchangeFormatterTwoLevelFileEnumerator(-2086712688)]
	internal static StreamTokenReader streamTokenReader_7;

	[RSAOAEPKeyExchangeFormatterTwoLevelFileEnumerator(2121193780)]
	internal static GCSafeFindHandle gcsafeFindHandle_9;

	[global::IDispatchConstant(-912747220)]
	internal static FUNCDESCTimeout funcdesctimeout_7;

	[RegionNameOffsetItemTypeInitializationException(-905052780)]
	internal static NotSupportedExceptionModuleResolveEventHandler notSupportedExceptionModuleResolveEventHandler_11;

	[ConsoleCtrlHandlerRoutine(-2067142522)]
	internal static HashFormatterAssemblyStyle hashFormatterAssemblyStyle_7;

	[TargetInvocationExceptionList1(-886425443)]
	internal static CerHashtable2RemotingConfigHandler cerHashtable2RemotingConfigHandler_7;

	[IComparer1HostSecurityManagerOptions(405007669)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_14;

	[global::IDispatchConstant(-1427297700)]
	internal static InvalidCastExceptionSHA1 invalidCastExceptionSHA1_9;

	[IComparer1HostSecurityManagerOptions(1044274645)]
	internal static SecurityPermissionIsImplicitlyDereferenced securityPermissionIsImplicitlyDereferenced_10;

	[global::IDispatchConstant(-1010173658)]
	internal static IDeploymentMetadataEntryCryptoKeySecurity ideploymentMetadataEntryCryptoKeySecurity_7;

	[GetPackagePropertyFlagsQueue(-2108672745)]
	internal static ILGeneratorIComparable ilgeneratorIComparable_10;

	[ConfigTreeParserXmlSyntaxException(1656398266)]
	internal static global::RegistrationConnectionType registrationConnectionType_7;

	[ValueFixupEnumAttributeTargets(-15753302)]
	internal static CanonPersianCalendar canonPersianCalendar_7;

	[PermissionTokenKeyComparer(1084320025)]
	internal static SiteMembershipCondition siteMembershipCondition_7;

	[GetPackagePropertyFlagsQueue(232825925)]
	internal static Delegate2 delegate2_7;

	[SecurityPermissionFlag(142227040)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_15;

	[GetPackagePropertyFlagsQueue(-1149088111)]
	internal static DateBufferSymAddressKind dateBufferSymAddressKind_8;

	[RSAOAEPKeyExchangeFormatterTwoLevelFileEnumerator(-350290564)]
	internal static StreamTokenReader streamTokenReader_8;

	[TargetInvocationExceptionList1(-1695727541)]
	internal static GCSafeFindHandle gcsafeFindHandle_10;

	[StoreOperationMetadataPropertyHMACMD5(-765724243)]
	internal static FUNCDESCTimeout funcdesctimeout_8;

	[GetPackagePropertyFlagsQueue(-87251491)]
	internal static NotSupportedExceptionModuleResolveEventHandler notSupportedExceptionModuleResolveEventHandler_12;

	[SecurityPermissionFlag(-1087150618)]
	internal static HashFormatterAssemblyStyle cjKaS;

	[HResultsActivationArguments(1894581304)]
	internal static CerHashtable2RemotingConfigHandler cerHashtable2RemotingConfigHandler_8;

	[STAThreadAttributeIndexOutOfRangeException(504052284)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_16;

	[SecurityPermissionFlag(-2056941974)]
	internal static InvalidCastExceptionSHA1 invalidCastExceptionSHA1_10;

	[TargetInvocationExceptionList1(-674235737)]
	internal static SecurityPermissionIsImplicitlyDereferenced securityPermissionIsImplicitlyDereferenced_11;

	[ConsoleCtrlHandlerRoutine(-1815663454)]
	internal static IDeploymentMetadataEntryCryptoKeySecurity ideploymentMetadataEntryCryptoKeySecurity_8;

	[SafeRegistryHandle(-284195196)]
	internal static ILGeneratorIComparable ilgeneratorIComparable_11;

	[RegionNameOffsetItemTypeInitializationException(-122081002)]
	internal static global::RegistrationConnectionType registrationConnectionType_8;

	[HResultsActivationArguments(-1551566888)]
	internal static CanonPersianCalendar canonPersianCalendar_8;

	[ValueFixupEnumAttributeTargets(1886858236)]
	internal static SiteMembershipCondition siteMembershipCondition_8;

	[SafeRegistryHandle(207003814)]
	internal static Delegate2 delegate2_8;

	[HResultsActivationArguments(1076529524)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_17;

	[global::IDispatchConstant(-1304058106)]
	internal static DateBufferSymAddressKind dateBufferSymAddressKind_9;

	[ConsoleCtrlHandlerRoutine(-1488732090)]
	internal static StreamTokenReader streamTokenReader_9;

	[RSAOAEPKeyExchangeFormatterTwoLevelFileEnumerator(1732670300)]
	internal static GCSafeFindHandle gcsafeFindHandle_11;

	[StoreOperationMetadataPropertyHMACMD5(340258255)]
	internal static FUNCDESCTimeout funcdesctimeout_9;

	[STAThreadAttributeIndexOutOfRangeException(-2056157512)]
	internal static NotSupportedExceptionModuleResolveEventHandler notSupportedExceptionModuleResolveEventHandler_13;

	[ConsoleCtrlHandlerRoutine(1293905788)]
	internal static HashFormatterAssemblyStyle hashFormatterAssemblyStyle_8;

	[IComparer1HostSecurityManagerOptions(-533343557)]
	internal static CerHashtable2RemotingConfigHandler cerHashtable2RemotingConfigHandler_9;

	[SafeRegistryHandle(-1849811170)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_18;

	[ValueFixupEnumAttributeTargets(-1451294292)]
	internal static InvalidCastExceptionSHA1 invalidCastExceptionSHA1_11;

	[PermissionTokenKeyComparer(-902490281)]
	internal static SecurityPermissionIsImplicitlyDereferenced securityPermissionIsImplicitlyDereferenced_12;

	[TargetInvocationExceptionList1(1691519815)]
	internal static IDeploymentMetadataEntryCryptoKeySecurity ideploymentMetadataEntryCryptoKeySecurity_9;

	[GetPackagePropertyFlagsQueue(-1795128527)]
	internal static ILGeneratorIComparable ilgeneratorIComparable_12;

	[IComparer1HostSecurityManagerOptions(885397857)]
	internal static global::RegistrationConnectionType registrationConnectionType_9;

	[AceQualifier(-1221534265)]
	internal static CanonPersianCalendar canonPersianCalendar_9;

	[global::IDispatchConstant(-2055590292)]
	internal static SiteMembershipCondition siteMembershipCondition_9;

	[STAThreadAttributeIndexOutOfRangeException(-1611048020)]
	internal static Delegate2 delegate2_9;

	[SecurityPermissionFlag(-366359528)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_19;

	[AceQualifier(1644694939)]
	internal static DateBufferSymAddressKind dateBufferSymAddressKind_10;

	[STAThreadAttributeIndexOutOfRangeException(-1675794976)]
	internal static StreamTokenReader streamTokenReader_10;

	[RegionNameOffsetItemTypeInitializationException(-1702685676)]
	internal static GCSafeFindHandle gcsafeFindHandle_12;

	[TargetInvocationExceptionList1(-498969599)]
	internal static FUNCDESCTimeout funcdesctimeout_10;

	[ValueFixupEnumAttributeTargets(44911934)]
	internal static NotSupportedExceptionModuleResolveEventHandler notSupportedExceptionModuleResolveEventHandler_14;

	[RSAOAEPKeyExchangeFormatterTwoLevelFileEnumerator(159640922)]
	internal static HashFormatterAssemblyStyle hashFormatterAssemblyStyle_9;

	[ValueFixupEnumAttributeTargets(-1018837494)]
	internal static CerHashtable2RemotingConfigHandler cerHashtable2RemotingConfigHandler_10;

	[STAThreadAttributeIndexOutOfRangeException(1924561148)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_20;

	[global::IDispatchConstant(1716698008)]
	internal static InvalidCastExceptionSHA1 invalidCastExceptionSHA1_12;

	[StoreOperationMetadataPropertyHMACMD5(-683389059)]
	internal static SecurityPermissionIsImplicitlyDereferenced securityPermissionIsImplicitlyDereferenced_13;

	[AceQualifier(1958486105)]
	internal static IDeploymentMetadataEntryCryptoKeySecurity ideploymentMetadataEntryCryptoKeySecurity_10;

	[TargetInvocationExceptionList1(770946001)]
	internal static ILGeneratorIComparable ilgeneratorIComparable_13;

	[RSAOAEPKeyExchangeFormatterTwoLevelFileEnumerator(-2146048740)]
	internal static global::RegistrationConnectionType registrationConnectionType_10;

	[GetPackagePropertyFlagsQueue(861835053)]
	internal static CanonPersianCalendar canonPersianCalendar_10;

	[STAThreadAttributeIndexOutOfRangeException(1920380980)]
	internal static SiteMembershipCondition siteMembershipCondition_10;

	[STAThreadAttributeIndexOutOfRangeException(529788144)]
	internal static Delegate2 delegate2_10;

	[SecurityPermissionFlag(532641400)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_21;

	[ConsoleCtrlHandlerRoutine(209310540)]
	internal static DateBufferSymAddressKind dateBufferSymAddressKind_11;

	[AceQualifier(-822354473)]
	internal static StreamTokenReader streamTokenReader_11;

	[TargetInvocationExceptionList1(-483913529)]
	internal static GCSafeFindHandle gcsafeFindHandle_13;

	[SafeRegistryHandle(783349412)]
	internal static FUNCDESCTimeout funcdesctimeout_11;

	[SafeRegistryHandle(-957869602)]
	internal static NotSupportedExceptionModuleResolveEventHandler notSupportedExceptionModuleResolveEventHandler_15;

	[STAThreadAttributeIndexOutOfRangeException(1387591800)]
	internal static HashFormatterAssemblyStyle hashFormatterAssemblyStyle_10;

	[TargetInvocationExceptionList1(-378895297)]
	internal static CerHashtable2RemotingConfigHandler cerHashtable2RemotingConfigHandler_11;

	[AceQualifier(-1955926893)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_22;

	[SafeRegistryHandle(1219757936)]
	internal static InvalidCastExceptionSHA1 invalidCastExceptionSHA1_13;

	[AceQualifier(986659471)]
	internal static SecurityPermissionIsImplicitlyDereferenced securityPermissionIsImplicitlyDereferenced_14;

	[SafeRegistryHandle(-1402856802)]
	internal static IDeploymentMetadataEntryCryptoKeySecurity ideploymentMetadataEntryCryptoKeySecurity_11;

	[SafeRegistryHandle(-480210836)]
	internal static ILGeneratorIComparable ilgeneratorIComparable_14;

	[TargetInvocationExceptionList1(-1424987739)]
	internal static global::RegistrationConnectionType registrationConnectionType_11;

	[STAThreadAttributeIndexOutOfRangeException(937372916)]
	internal static CanonPersianCalendar canonPersianCalendar_11;

	[STAThreadAttributeIndexOutOfRangeException(1391477706)]
	internal static SiteMembershipCondition siteMembershipCondition_11;

	[HResultsActivationArguments(420212124)]
	internal static Delegate2 delegate2_11;

	[ConfigTreeParserXmlSyntaxException(1509903494)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_23;

	[ConsoleCtrlHandlerRoutine(1070494002)]
	internal static DateBufferSymAddressKind dateBufferSymAddressKind_12;

	[ConfigTreeParserXmlSyntaxException(838487008)]
	internal static StreamTokenReader streamTokenReader_12;

	[StoreOperationMetadataPropertyHMACMD5(-98023997)]
	internal static GCSafeFindHandle gcsafeFindHandle_14;

	[ValueFixupEnumAttributeTargets(475504308)]
	internal static FUNCDESCTimeout funcdesctimeout_12;

	[SafeRegistryHandle(-930908764)]
	internal static NotSupportedExceptionModuleResolveEventHandler notSupportedExceptionModuleResolveEventHandler_16;

	[HResultsActivationArguments(-1483242730)]
	internal static HashFormatterAssemblyStyle hashFormatterAssemblyStyle_11;

	[RSAOAEPKeyExchangeFormatterTwoLevelFileEnumerator(493410728)]
	internal static CerHashtable2RemotingConfigHandler cerHashtable2RemotingConfigHandler_12;

	[AceQualifier(1182592259)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_24;

	[global::IDispatchConstant(-1884155134)]
	internal static InvalidCastExceptionSHA1 invalidCastExceptionSHA1_14;

	[ConfigTreeParserXmlSyntaxException(-1534611796)]
	internal static SecurityPermissionIsImplicitlyDereferenced securityPermissionIsImplicitlyDereferenced_15;

	[IComparer1HostSecurityManagerOptions(1251726341)]
	internal static IDeploymentMetadataEntryCryptoKeySecurity ideploymentMetadataEntryCryptoKeySecurity_12;

	[HResultsActivationArguments(1917496418)]
	internal static ILGeneratorIComparable ilgeneratorIComparable_15;

	[IComparer1HostSecurityManagerOptions(1665078133)]
	internal static global::RegistrationConnectionType registrationConnectionType_12;

	[RSAOAEPKeyExchangeFormatterTwoLevelFileEnumerator(-1711857646)]
	internal static CanonPersianCalendar canonPersianCalendar_12;

	[AceQualifier(-1308350555)]
	internal static SiteMembershipCondition siteMembershipCondition_12;

	[ConsoleCtrlHandlerRoutine(617346582)]
	internal static Delegate2 delegate2_12;

	[PermissionTokenKeyComparer(1459196497)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_25;

	[SecurityPermissionFlag(-1679926560)]
	internal static DateBufferSymAddressKind dateBufferSymAddressKind_13;

	[SecurityPermissionFlag(-1592533780)]
	internal static StreamTokenReader streamTokenReader_13;

	[RSAOAEPKeyExchangeFormatterTwoLevelFileEnumerator(1426719608)]
	internal static GCSafeFindHandle gcsafeFindHandle_15;

	[StoreOperationMetadataPropertyHMACMD5(1581606307)]
	internal static FUNCDESCTimeout funcdesctimeout_13;

	[StoreOperationMetadataPropertyHMACMD5(1708616115)]
	internal static NotSupportedExceptionModuleResolveEventHandler notSupportedExceptionModuleResolveEventHandler_17;

	[StoreOperationMetadataPropertyHMACMD5(-321672063)]
	internal static HashFormatterAssemblyStyle hashFormatterAssemblyStyle_12;

	[IComparer1HostSecurityManagerOptions(-1857055759)]
	internal static CerHashtable2RemotingConfigHandler cerHashtable2RemotingConfigHandler_13;

	[ConsoleCtrlHandlerRoutine(1718892440)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_26;

	[SecurityPermissionFlag(-1891112564)]
	internal static InvalidCastExceptionSHA1 invalidCastExceptionSHA1_15;

	[IComparer1HostSecurityManagerOptions(1970399949)]
	internal static SecurityPermissionIsImplicitlyDereferenced securityPermissionIsImplicitlyDereferenced_16;

	[TargetInvocationExceptionList1(783154419)]
	internal static IDeploymentMetadataEntryCryptoKeySecurity ideploymentMetadataEntryCryptoKeySecurity_13;

	[GetPackagePropertyFlagsQueue(7745177)]
	internal static ILGeneratorIComparable ilgeneratorIComparable_16;

	[IComparer1HostSecurityManagerOptions(-2077941739)]
	internal static global::RegistrationConnectionType registrationConnectionType_13;

	[HResultsActivationArguments(1491773308)]
	internal static CanonPersianCalendar canonPersianCalendar_13;

	[ValueFixupEnumAttributeTargets(-1521895100)]
	internal static SiteMembershipCondition siteMembershipCondition_13;

	[global::IDispatchConstant(-525711936)]
	internal static Delegate2 delegate2_13;

	[RegionNameOffsetItemTypeInitializationException(1281668020)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_27;

	[TargetInvocationExceptionList1(-47815473)]
	internal static DateBufferSymAddressKind dateBufferSymAddressKind_14;

	[global::IDispatchConstant(741906844)]
	internal static StreamTokenReader streamTokenReader_14;

	[AceQualifier(811191411)]
	internal static GCSafeFindHandle gcsafeFindHandle_16;

	[StoreOperationMetadataPropertyHMACMD5(2101260561)]
	internal static FUNCDESCTimeout funcdesctimeout_14;

	[StoreOperationMetadataPropertyHMACMD5(774149941)]
	internal static NotSupportedExceptionModuleResolveEventHandler notSupportedExceptionModuleResolveEventHandler_18;

	[TargetInvocationExceptionList1(-39618307)]
	internal static HashFormatterAssemblyStyle hashFormatterAssemblyStyle_13;

	[global::IDispatchConstant(-12702512)]
	internal static CerHashtable2RemotingConfigHandler cerHashtable2RemotingConfigHandler_14;

	[ValueFixupEnumAttributeTargets(-283029690)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_28;

	[AceQualifier(426866159)]
	internal static InvalidCastExceptionSHA1 invalidCastExceptionSHA1_16;

	[STAThreadAttributeIndexOutOfRangeException(1986187390)]
	internal static SecurityPermissionIsImplicitlyDereferenced securityPermissionIsImplicitlyDereferenced_17;

	[PermissionTokenKeyComparer(-1151721889)]
	internal static IDeploymentMetadataEntryCryptoKeySecurity ideploymentMetadataEntryCryptoKeySecurity_14;

	[ConfigTreeParserXmlSyntaxException(725431352)]
	internal static ILGeneratorIComparable ilgeneratorIComparable_17;

	[StoreOperationMetadataPropertyHMACMD5(-1184874047)]
	internal static global::RegistrationConnectionType registrationConnectionType_14;

	[StoreOperationMetadataPropertyHMACMD5(294083829)]
	internal static CanonPersianCalendar canonPersianCalendar_14;

	[RegionNameOffsetItemTypeInitializationException(1812104872)]
	internal static SiteMembershipCondition siteMembershipCondition_14;

	[PermissionTokenKeyComparer(-1506992791)]
	internal static Delegate2 delegate2_14;

	[HResultsActivationArguments(-618161418)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_29;

	[AceQualifier(1363068307)]
	internal static DateBufferSymAddressKind dateBufferSymAddressKind_15;

	[StoreOperationMetadataPropertyHMACMD5(-1725787229)]
	internal static StreamTokenReader streamTokenReader_15;

	[RSAOAEPKeyExchangeFormatterTwoLevelFileEnumerator(263762590)]
	internal static GCSafeFindHandle gcsafeFindHandle_17;

	[TargetInvocationExceptionList1(-1709261099)]
	internal static FUNCDESCTimeout funcdesctimeout_15;

	[TargetInvocationExceptionList1(-2000564175)]
	internal static NotSupportedExceptionModuleResolveEventHandler notSupportedExceptionModuleResolveEventHandler_19;

	[TargetInvocationExceptionList1(1560162845)]
	internal static HashFormatterAssemblyStyle hashFormatterAssemblyStyle_14;

	[GetPackagePropertyFlagsQueue(-938123031)]
	internal static CerHashtable2RemotingConfigHandler cerHashtable2RemotingConfigHandler_15;

	[PermissionTokenKeyComparer(-1211704897)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_30;

	[StoreOperationMetadataPropertyHMACMD5(-791975599)]
	internal static InvalidCastExceptionSHA1 invalidCastExceptionSHA1_17;

	[IComparer1HostSecurityManagerOptions(-1249358233)]
	internal static SecurityPermissionIsImplicitlyDereferenced securityPermissionIsImplicitlyDereferenced_18;

	[StoreOperationMetadataPropertyHMACMD5(-1264629225)]
	internal static IDeploymentMetadataEntryCryptoKeySecurity ideploymentMetadataEntryCryptoKeySecurity_15;

	[RegionNameOffsetItemTypeInitializationException(-1261661798)]
	internal static ILGeneratorIComparable ilgeneratorIComparable_18;

	[AceQualifier(-159538397)]
	internal static global::RegistrationConnectionType registrationConnectionType_15;

	[HResultsActivationArguments(-1511328052)]
	internal static CanonPersianCalendar canonPersianCalendar_15;

	[ConfigTreeParserXmlSyntaxException(-758285184)]
	internal static SiteMembershipCondition siteMembershipCondition_15;

	[StoreOperationMetadataPropertyHMACMD5(1576406971)]
	internal static Delegate2 delegate2_15;

	[AceQualifier(-1922476723)]
	internal static IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess iappidauthorityaredefinitionsequalflagsenvironmentPermissionAccess_31;

	[ValueFixupEnumAttributeTargets(606092756)]
	internal static StringExpressionSet stringExpressionSet_0;

	[ConfigTreeParserXmlSyntaxException(-414222184)]
	internal static ActivationAttributeStack activationAttributeStack_0;

	[GetPackagePropertyFlagsQueue(-1635614173)]
	internal static TaiwanCalendar taiwanCalendar_0;

	[STAThreadAttributeIndexOutOfRangeException(1215740114)]
	internal static CultureTableDataObsoleteAttribute cultureTableDataObsoleteAttribute_1;

	[ValueFixupEnumAttributeTargets(621194170)]
	internal static FileSystemSecurity fileSystemSecurity_0;

	[global::IDispatchConstant(1333416586)]
	internal static Delegate3 delegate3_0;

	[HResultsActivationArguments(-1621444818)]
	internal static IWindowClassEntry iwindowClassEntry_0;

	[ValueFixupEnumAttributeTargets(1434271338)]
	internal static TaiwanCalendar taiwanCalendar_1;

	[AceQualifier(614421753)]
	internal static MscorlibCollectionDebugView1REDocument mscorlibCollectionDebugView1REDocument_0;

	public static IntPtr PrivilegeNotHeldExceptionObject;

	public static string WindowsIdentity;

	public static Thread IApplicationTrustManagerSecurityDocumentElement;

	public static Process Encoding;

	public static Environment environment_0;

	public static OperatingSystem operatingSystem_1;

	public static ProcessModule IConnectionPoint;

	public static FileVersionInfo UnicodeCategory;

	public static RuntimeMethodHandle SoapNegativeInteger;

	public static Encoding MEMORYSTATUSEX;

	public static Math JapaneseLunisolarCalendarSponsorState;

	public static Buffer AuthorizationRuleCollectionDebuggerStepThroughAttribute;

	public static Control ResourceManagerBStrWrapper;

	public static Type CallConvThiscallControlFlags;

	public static Utils NumberFormatInfo;

	public static ProjectData MdConstant;

	public static RuntimeHelpers LoadHintSecurityCriticalScope;

	public static Information ISponsor;

	public static Delegate OAVariantLibErrorMessage;

	public static Color DebuggerGuidAttribute;

	public static ListViewItem SecurityLogonTypePInvokeMap;

	public static ListViewItem.ListViewSubItem IEnumSTOREASSEMBLYFILE;

	public static PaintEventArgs SoapAnyUri;

	public static Graphics IDynamicMessageSinkReaderWriterLock;

	public static Point EncodingByteBuffer;

	public static Enumerable Message;

	public static ListViewItem.ListViewSubItemCollection FileDialogPermissionAccessCultureTable;

	public static Operators InternalFE;

	public static RectangleF SynchronizationContextPropertiesOnDeserializedAttribute;

	public static MouseEventArgs ParsingInfoSoapMonth;

	public static Computer FileMutexAuditRule;

	public static Keyboard IsCopyConstructedWhatsCached;

	public static Rectangle ApplicationIdNullTextReader;

	public static TextBox TextReaderPermissionSetTriple;

	public static TextBoxBase IdentityReference;

	public static KeyPressEventArgs PortableExecutableKinds;

	public static Strings PermissionTokenSerializationEventHandler;

	public static ContainerControl SymDocumentType;

	public static Form DynamicScope;

	public static Component FileAccessKeyNumber;

	public static DateTime DebuggingModes;

	public static AsymmetricSignatureFormatterUrl EastAsianLunisolarCalendarThrowHelper;

	public static byte[] RegistryAccessRuleDecoderFallbackException;

	public static IntPtr[] ConstructorOnTypeBuilderInstantiationManifestResourceInfo;

	internal static Assembly ISCIIEncoderSerializationBinder;

	internal static <Module>.EncodingCharBufferBinaryMethodReturnMessage VarEnum;

	public static <Module>.IntInt IntMethod;

	internal static DeploymentMetadataEntryFieldId IComparableWIN32FINDDATA;

	internal static List<int> GenericSecurityDescriptor;

	internal class CreateActContextParametersSource
	{
		internal CreateActContextParametersSource()
		{
			this.UltimateResourceFallbackLocationDateTimeToken = new Dictionary<long, byte[]>();
		}

		internal void SecurityLogonTypeFileSystemSecurity(MethodInfo methodInfo_0)
		{
			this.UTF8Decoder = methodInfo_0;
		}

		internal void DelegateBindingFlags(MethodInfo methodInfo_0)
		{
			if (methodInfo_0.GetParameters().Length != this.UTF8Decoder.GetParameters().Length)
			{
				throw new Exception("Invalid Redirction method, Parameter's number must be the same.");
			}
			int num = 0;
			int num2 = 0;
			IntPtr functionPointer = this.UTF8Decoder.MethodHandle.GetFunctionPointer();
			IntPtr functionPointer2 = methodInfo_0.MethodHandle.GetFunctionPointer();
			byte[] array = this.GenericPrincipalTargetInvocationException(functionPointer2, functionPointer);
			byte[] array2 = new byte[array.Length];
			int num3;
			<Module>.CreateActContextParametersSource.SecurityDocumentHebrewNumberParsingState.VirtualProtectEx(-1, functionPointer, array.Length, 64, ref num3);
			<Module>.CreateActContextParametersSource.SecurityDocumentHebrewNumberParsingState.ReadProcessMemory(-1, functionPointer, array2, array2.Length, ref num2);
			this.UltimateResourceFallbackLocationDateTimeToken.Add((long)functionPointer, array2);
			<Module>.CreateActContextParametersSource.SecurityDocumentHebrewNumberParsingState.WriteProcessMemory(-1, functionPointer, array, array.Length, ref num);
		}

		internal byte[] GenericPrincipalTargetInvocationException(IntPtr intptr_0, IntPtr intptr_1)
		{
			Array bytes = BitConverter.GetBytes((long)intptr_0 - ((long)intptr_1 + 5L));
			byte[] array = new byte[5];
			array[0] = 233;
			Buffer.BlockCopy(bytes, 0, array, 1, 4);
			return array;
		}

		internal MethodInfo UTF8Decoder;

		internal Dictionary<long, byte[]> UltimateResourceFallbackLocationDateTimeToken;

		internal static class SecurityDocumentHebrewNumberParsingState
		{
			[DllImport("kernel32.dll")]
			internal static extern bool ReadProcessMemory(int int_0, IntPtr intptr_0, byte[] byte_0, int int_1, ref int int_2);

			[DllImport("kernel32.dll")]
			internal static extern bool WriteProcessMemory(int int_0, IntPtr intptr_0, byte[] byte_0, int int_1, ref int int_2);

			[DllImport("kernel32.dll")]
			internal static extern bool VirtualProtectEx(int int_0, IntPtr intptr_0, int int_1, int int_2, ref int int_3);

			internal enum ExecutionContext
			{

			}
		}
	}

	internal struct SiteStringIChannel
	{
		internal void ImportedFromTypeLibAttributeClearCacheHandler()
		{
			this.SymmetricAlgorithm = 1024u;
		}

		internal uint AppDomainUnloadedExceptionSystemException(<Module>.ConsoleModifiers consoleModifiers_0)
		{
			uint num = (consoleModifiers_0.CustomAttributeFormatException >> 11) * this.SymmetricAlgorithm;
			if (consoleModifiers_0.TrustManagerContextDateTimeFormatFlags < num)
			{
				consoleModifiers_0.CustomAttributeFormatException = num;
				this.SymmetricAlgorithm += 2048u - this.SymmetricAlgorithm >> 5;
				if (consoleModifiers_0.CustomAttributeFormatException < 16777216u)
				{
					consoleModifiers_0.TrustManagerContextDateTimeFormatFlags = (consoleModifiers_0.TrustManagerContextDateTimeFormatFlags << 8 | (uint)((byte)consoleModifiers_0.StoreTransactionOperationIComparable.ReadByte()));
					consoleModifiers_0.CustomAttributeFormatException <<= 8;
				}
				return 0u;
			}
			consoleModifiers_0.CustomAttributeFormatException -= num;
			consoleModifiers_0.TrustManagerContextDateTimeFormatFlags -= num;
			this.SymmetricAlgorithm -= this.SymmetricAlgorithm >> 5;
			if (consoleModifiers_0.CustomAttributeFormatException < 16777216u)
			{
				consoleModifiers_0.TrustManagerContextDateTimeFormatFlags = (consoleModifiers_0.TrustManagerContextDateTimeFormatFlags << 8 | (uint)((byte)consoleModifiers_0.StoreTransactionOperationIComparable.ReadByte()));
				consoleModifiers_0.CustomAttributeFormatException <<= 8;
			}
			return 1u;
		}

		internal uint SymmetricAlgorithm;
	}

	internal struct Struct0
	{
		internal Struct0(int int_1)
		{
			this.int_0 = int_1;
			this.DateTimeFormatInfoScannerMutexRights = new <Module>.SiteStringIChannel[1 << int_1];
		}

		internal void AssemblyKeyFileAttributePortableExecutableKinds()
		{
			uint num = 1u;
			while ((ulong)num < (ulong)(1L << (this.int_0 & 31)))
			{
				this.DateTimeFormatInfoScannerMutexRights[(int)num].ImportedFromTypeLibAttributeClearCacheHandler();
				num += 1u;
			}
		}

		internal uint method_0(<Module>.ConsoleModifiers consoleModifiers_0)
		{
			uint num = 1u;
			for (int i = this.int_0; i > 0; i--)
			{
				num = (num << 1) + this.DateTimeFormatInfoScannerMutexRights[(int)num].AppDomainUnloadedExceptionSystemException(consoleModifiers_0);
			}
			return num - (1u << this.int_0);
		}

		internal uint IOUtil(<Module>.ConsoleModifiers consoleModifiers_0)
		{
			uint num = 1u;
			uint num2 = 0u;
			for (int i = 0; i < this.int_0; i++)
			{
				uint num3 = this.DateTimeFormatInfoScannerMutexRights[(int)num].AppDomainUnloadedExceptionSystemException(consoleModifiers_0);
				num <<= 1;
				num += num3;
				num2 |= num3 << i;
			}
			return num2;
		}

		internal static uint PropertyTokenModuleHandle(<Module>.SiteStringIChannel[] siteStringIChannel_0, uint uint_0, <Module>.ConsoleModifiers consoleModifiers_0, int int_1)
		{
			uint num = 1u;
			uint num2 = 0u;
			for (int i = 0; i < int_1; i++)
			{
				uint num3 = siteStringIChannel_0[(int)(uint_0 + num)].AppDomainUnloadedExceptionSystemException(consoleModifiers_0);
				num <<= 1;
				num += num3;
				num2 |= num3 << i;
			}
			return num2;
		}

		internal readonly <Module>.SiteStringIChannel[] DateTimeFormatInfoScannerMutexRights;

		internal readonly int int_0;
	}

	internal class ConsoleModifiers
	{
		internal void AssemblyKeyFileAttributePortableExecutableKinds(Stream stream_0)
		{
			this.StoreTransactionOperationIComparable = stream_0;
			this.TrustManagerContextDateTimeFormatFlags = 0u;
			this.CustomAttributeFormatException = uint.MaxValue;
			for (int i = 0; i < 5; i++)
			{
				this.TrustManagerContextDateTimeFormatFlags = (this.TrustManagerContextDateTimeFormatFlags << 8 | (uint)((byte)this.StoreTransactionOperationIComparable.ReadByte()));
			}
		}

		internal void ScopelessEnumAttributeTokenAccessLevels()
		{
			this.StoreTransactionOperationIComparable = null;
		}

		internal void method_0()
		{
			while (this.CustomAttributeFormatException < 16777216u)
			{
				this.TrustManagerContextDateTimeFormatFlags = (this.TrustManagerContextDateTimeFormatFlags << 8 | (uint)((byte)this.StoreTransactionOperationIComparable.ReadByte()));
				this.CustomAttributeFormatException <<= 8;
			}
		}

		internal uint InternalCollection1(int int_0)
		{
			uint num = this.CustomAttributeFormatException;
			uint num2 = this.TrustManagerContextDateTimeFormatFlags;
			uint num3 = 0u;
			for (int i = int_0; i > 0; i--)
			{
				num >>= 1;
				uint num4 = num2 - num >> 31;
				num2 -= (num & num4 - 1u);
				num3 = (num3 << 1 | 1u - num4);
				if (num < 16777216u)
				{
					num2 = (num2 << 8 | (uint)((byte)this.StoreTransactionOperationIComparable.ReadByte()));
					num <<= 8;
				}
			}
			this.CustomAttributeFormatException = num;
			this.TrustManagerContextDateTimeFormatFlags = num2;
			return num3;
		}

		internal ConsoleModifiers()
		{
		}

		internal uint TrustManagerContextDateTimeFormatFlags;

		internal uint CustomAttributeFormatException;

		internal Stream StoreTransactionOperationIComparable;
	}

	internal class ConfigServerDictionaryBase
	{
		internal ConfigServerDictionaryBase()
		{
			this.ClientContextTerminatorSinkIProgIdRedirectionEntry = uint.MaxValue;
			int num = 0;
			while ((long)num < 4L)
			{
				this.IFieldInfo[num] = new <Module>.Struct0(6);
				num++;
			}
		}

		internal void ObjRefTaiwanLunisolarCalendar(uint uint_0)
		{
			if (this.ClientContextTerminatorSinkIProgIdRedirectionEntry != uint_0)
			{
				this.ClientContextTerminatorSinkIProgIdRedirectionEntry = uint_0;
				this.SafeHandleMinusOneIsInvalid = Math.Max(this.ClientContextTerminatorSinkIProgIdRedirectionEntry, 1u);
				uint uint_ = Math.Max(this.SafeHandleMinusOneIsInvalid, 4096u);
				this.PrecannedResourceIDLDESC.Rijndael(uint_);
			}
		}

		internal void AsyncRenewalBinaryHeaderEnum(int int_0, int int_1)
		{
			this.TypeUnloadedExceptionX509KeyStorageFlags.Rijndael(int_0, int_1);
		}

		internal void method_0(int int_0)
		{
			uint num = 1u << int_0;
			this.ObjRefSymbolToken.UnitySerializationHolderNotSupportedException(num);
			this.SoapNameCerArrayList1.UnitySerializationHolderNotSupportedException(num);
			this.AppDomainManagerInitializationOptions = num - 1u;
		}

		internal void AssemblyKeyFileAttributePortableExecutableKinds(Stream stream_0, Stream stream_1)
		{
			this.ComVisibleAttribute.AssemblyKeyFileAttributePortableExecutableKinds(stream_0);
			this.PrecannedResourceIDLDESC.AssemblyKeyFileAttributePortableExecutableKinds(stream_1, this.FileSystemInfoComparer1);
			for (uint num = 0u; num < 12u; num += 1u)
			{
				for (uint num2 = 0u; num2 <= this.AppDomainManagerInitializationOptions; num2 += 1u)
				{
					uint num3 = (num << 4) + num2;
					this.FileAccess[(int)num3].ImportedFromTypeLibAttributeClearCacheHandler();
					this.LOGICApplicationIdentity[(int)num3].ImportedFromTypeLibAttributeClearCacheHandler();
				}
				this.siteStringIChannel_0[(int)num].ImportedFromTypeLibAttributeClearCacheHandler();
				this.IClientChannelSink[(int)num].ImportedFromTypeLibAttributeClearCacheHandler();
				this.ControlCHooker[(int)num].ImportedFromTypeLibAttributeClearCacheHandler();
				this.Rfc2898DeriveBytes[(int)num].ImportedFromTypeLibAttributeClearCacheHandler();
			}
			this.TypeUnloadedExceptionX509KeyStorageFlags.AssemblyKeyFileAttributePortableExecutableKinds();
			for (uint num = 0u; num < 4u; num += 1u)
			{
				this.IFieldInfo[(int)num].AssemblyKeyFileAttributePortableExecutableKinds();
			}
			for (uint num = 0u; num < 114u; num += 1u)
			{
				this.GenericMethodInfoSerObjectInfoCache[(int)num].ImportedFromTypeLibAttributeClearCacheHandler();
			}
			this.ObjRefSymbolToken.AssemblyKeyFileAttributePortableExecutableKinds();
			this.SoapNameCerArrayList1.AssemblyKeyFileAttributePortableExecutableKinds();
			this.EncoderFallbackExceptionDebuggableAttribute.AssemblyKeyFileAttributePortableExecutableKinds();
		}

		internal void DirectoryInfoUTF8Decoder(Stream stream_0, Stream stream_1, long long_0, long long_1)
		{
			this.AssemblyKeyFileAttributePortableExecutableKinds(stream_0, stream_1);
			<Module>.DriveTypeRuntimeType driveTypeRuntimeType = default(<Module>.DriveTypeRuntimeType);
			driveTypeRuntimeType.AssemblyKeyFileAttributePortableExecutableKinds();
			uint num = 0u;
			uint num2 = 0u;
			uint num3 = 0u;
			uint num4 = 0u;
			ulong num5 = 0UL;
			if (0L < long_1)
			{
				this.FileAccess[(int)((int)driveTypeRuntimeType.RemotingProxy << 4)].AppDomainUnloadedExceptionSystemException(this.ComVisibleAttribute);
				driveTypeRuntimeType.ArgumentOutOfRangeException();
				byte byte_ = this.TypeUnloadedExceptionX509KeyStorageFlags.ContextTypeInitializationException(this.ComVisibleAttribute, 0u, 0);
				this.PrecannedResourceIDLDESC.DateTimeKind(byte_);
				num5 += 1UL;
			}
			while (num5 < (ulong)long_1)
			{
				uint num6 = (uint)num5 & this.AppDomainManagerInitializationOptions;
				if (this.FileAccess[(int)((driveTypeRuntimeType.RemotingProxy << 4) + num6)].AppDomainUnloadedExceptionSystemException(this.ComVisibleAttribute) != 0u)
				{
					uint num8;
					if (this.siteStringIChannel_0[(int)driveTypeRuntimeType.RemotingProxy].AppDomainUnloadedExceptionSystemException(this.ComVisibleAttribute) == 1u)
					{
						if (this.IClientChannelSink[(int)driveTypeRuntimeType.RemotingProxy].AppDomainUnloadedExceptionSystemException(this.ComVisibleAttribute) == 0u)
						{
							if (this.LOGICApplicationIdentity[(int)((driveTypeRuntimeType.RemotingProxy << 4) + num6)].AppDomainUnloadedExceptionSystemException(this.ComVisibleAttribute) == 0u)
							{
								driveTypeRuntimeType.StoreTransactionOperationIListWrapper();
								this.PrecannedResourceIDLDESC.DateTimeKind(this.PrecannedResourceIDLDESC.CrossAppDomainSerializer(num));
								num5 += 1UL;
								continue;
							}
						}
						else
						{
							uint num7;
							if (this.ControlCHooker[(int)driveTypeRuntimeType.RemotingProxy].AppDomainUnloadedExceptionSystemException(this.ComVisibleAttribute) != 0u)
							{
								if (this.Rfc2898DeriveBytes[(int)driveTypeRuntimeType.RemotingProxy].AppDomainUnloadedExceptionSystemException(this.ComVisibleAttribute) == 0u)
								{
									num7 = num3;
								}
								else
								{
									num7 = num4;
									num4 = num3;
								}
								num3 = num2;
							}
							else
							{
								num7 = num2;
							}
							num2 = num;
							num = num7;
						}
						num8 = this.SoapNameCerArrayList1.method_0(this.ComVisibleAttribute, num6) + 2u;
						driveTypeRuntimeType.DynamicTypeInfoLease();
					}
					else
					{
						num4 = num3;
						num3 = num2;
						num2 = num;
						num8 = 2u + this.ObjRefSymbolToken.method_0(this.ComVisibleAttribute, num6);
						driveTypeRuntimeType.UIntPtrInternalEncodingDataItem();
						uint num9 = this.IFieldInfo[(int)<Module>.ConfigServerDictionaryBase.IsJitIntrinsicUnSafeCharBuffer(num8)].method_0(this.ComVisibleAttribute);
						if (num9 >= 4u)
						{
							int num10 = (int)((num9 >> 1) - 1u);
							num = (2u | (num9 & 1u)) << num10;
							if (num9 < 14u)
							{
								num += <Module>.Struct0.PropertyTokenModuleHandle(this.GenericMethodInfoSerObjectInfoCache, num - num9 - 1u, this.ComVisibleAttribute, num10);
							}
							else
							{
								num += this.ComVisibleAttribute.InternalCollection1(num10 - 4) << 4;
								num += this.EncoderFallbackExceptionDebuggableAttribute.IOUtil(this.ComVisibleAttribute);
							}
						}
						else
						{
							num = num9;
						}
					}
					if (((ulong)num >= num5 || num >= this.SafeHandleMinusOneIsInvalid) && num == 4294967295u)
					{
						break;
					}
					this.PrecannedResourceIDLDESC.IConvertible(num, num8);
					num5 += (ulong)num8;
				}
				else
				{
					byte byte_2 = this.PrecannedResourceIDLDESC.CrossAppDomainSerializer(0u);
					byte byte_3;
					if (driveTypeRuntimeType.StateManagerRunningStateASMNAME())
					{
						byte_3 = this.TypeUnloadedExceptionX509KeyStorageFlags.ContextTypeInitializationException(this.ComVisibleAttribute, (uint)num5, byte_2);
					}
					else
					{
						byte_3 = this.TypeUnloadedExceptionX509KeyStorageFlags.IAssemblyName(this.ComVisibleAttribute, (uint)num5, byte_2, this.PrecannedResourceIDLDESC.CrossAppDomainSerializer(num));
					}
					this.PrecannedResourceIDLDESC.DateTimeKind(byte_3);
					driveTypeRuntimeType.ArgumentOutOfRangeException();
					num5 += 1UL;
				}
			}
			this.PrecannedResourceIDLDESC.method_0();
			this.PrecannedResourceIDLDESC.LogMessageEventHandlerThreadStateException();
			this.ComVisibleAttribute.ScopelessEnumAttributeTokenAccessLevels();
		}

		internal void MonthNameStylesISymbolScope(byte[] byte_0)
		{
			int int_ = (int)(byte_0[0] % 9);
			byte b = byte_0[0] / 9;
			int int_2 = (int)(b % 5);
			int int_3 = (int)(b / 5);
			uint num = 0u;
			for (int i = 0; i < 4; i++)
			{
				num += (uint)((uint)byte_0[1 + i] << i * 8);
			}
			this.ObjRefTaiwanLunisolarCalendar(num);
			this.AsyncRenewalBinaryHeaderEnum(int_2, int_);
			this.method_0(int_3);
		}

		internal static uint IsJitIntrinsicUnSafeCharBuffer(uint uint_0)
		{
			uint_0 -= 2u;
			if (uint_0 < 4u)
			{
				return uint_0;
			}
			return 3u;
		}

		internal readonly <Module>.SiteStringIChannel[] FileAccess = new <Module>.SiteStringIChannel[192];

		internal readonly <Module>.SiteStringIChannel[] LOGICApplicationIdentity = new <Module>.SiteStringIChannel[192];

		internal readonly <Module>.SiteStringIChannel[] siteStringIChannel_0 = new <Module>.SiteStringIChannel[12];

		internal readonly <Module>.SiteStringIChannel[] IClientChannelSink = new <Module>.SiteStringIChannel[12];

		internal readonly <Module>.SiteStringIChannel[] ControlCHooker = new <Module>.SiteStringIChannel[12];

		internal readonly <Module>.SiteStringIChannel[] Rfc2898DeriveBytes = new <Module>.SiteStringIChannel[12];

		internal readonly <Module>.ConfigServerDictionaryBase.IEvidenceFactory ObjRefSymbolToken = new <Module>.ConfigServerDictionaryBase.IEvidenceFactory();

		internal readonly <Module>.ConfigServerDictionaryBase.ProxyAttributeResourceHelper TypeUnloadedExceptionX509KeyStorageFlags = new <Module>.ConfigServerDictionaryBase.ProxyAttributeResourceHelper();

		internal readonly <Module>.SHA1Managed PrecannedResourceIDLDESC = new <Module>.SHA1Managed();

		internal readonly <Module>.SiteStringIChannel[] GenericMethodInfoSerObjectInfoCache = new <Module>.SiteStringIChannel[114];

		internal readonly <Module>.Struct0[] IFieldInfo = new <Module>.Struct0[4];

		internal readonly <Module>.ConsoleModifiers ComVisibleAttribute = new <Module>.ConsoleModifiers();

		internal readonly <Module>.ConfigServerDictionaryBase.IEvidenceFactory SoapNameCerArrayList1 = new <Module>.ConfigServerDictionaryBase.IEvidenceFactory();

		internal bool FileSystemInfoComparer1;

		internal uint ClientContextTerminatorSinkIProgIdRedirectionEntry;

		internal uint SafeHandleMinusOneIsInvalid;

		internal <Module>.Struct0 EncoderFallbackExceptionDebuggableAttribute = new <Module>.Struct0(4);

		internal uint AppDomainManagerInitializationOptions;

		internal class IEvidenceFactory
		{
			internal void UnitySerializationHolderNotSupportedException(uint uint_0)
			{
				for (uint num = this.IRunningObjectTable; num < uint_0; num += 1u)
				{
					this.KeyContainerPermissionFunctorComparer1[(int)num] = new <Module>.Struct0(3);
					this.SerializedArg[(int)num] = new <Module>.Struct0(3);
				}
				this.IRunningObjectTable = uint_0;
			}

			internal void AssemblyKeyFileAttributePortableExecutableKinds()
			{
				this.OperandType.ImportedFromTypeLibAttributeClearCacheHandler();
				for (uint num = 0u; num < this.IRunningObjectTable; num += 1u)
				{
					this.KeyContainerPermissionFunctorComparer1[(int)num].AssemblyKeyFileAttributePortableExecutableKinds();
					this.SerializedArg[(int)num].AssemblyKeyFileAttributePortableExecutableKinds();
				}
				this.FormatterServices.ImportedFromTypeLibAttributeClearCacheHandler();
				this.CallConvCdeclDictionaryEnumeratorByKeys.AssemblyKeyFileAttributePortableExecutableKinds();
			}

			internal uint method_0(<Module>.ConsoleModifiers consoleModifiers_0, uint uint_0)
			{
				if (this.OperandType.AppDomainUnloadedExceptionSystemException(consoleModifiers_0) == 0u)
				{
					return this.KeyContainerPermissionFunctorComparer1[(int)uint_0].method_0(consoleModifiers_0);
				}
				uint num = 8u;
				if (this.FormatterServices.AppDomainUnloadedExceptionSystemException(consoleModifiers_0) == 0u)
				{
					num += this.SerializedArg[(int)uint_0].method_0(consoleModifiers_0);
				}
				else
				{
					num += 8u;
					num += this.CallConvCdeclDictionaryEnumeratorByKeys.method_0(consoleModifiers_0);
				}
				return num;
			}

			internal IEvidenceFactory()
			{
			}

			internal readonly <Module>.Struct0[] KeyContainerPermissionFunctorComparer1 = new <Module>.Struct0[16];

			internal readonly <Module>.Struct0[] SerializedArg = new <Module>.Struct0[16];

			internal <Module>.SiteStringIChannel OperandType;

			internal <Module>.SiteStringIChannel FormatterServices;

			internal <Module>.Struct0 CallConvCdeclDictionaryEnumeratorByKeys = new <Module>.Struct0(8);

			internal uint IRunningObjectTable;
		}

		internal class ProxyAttributeResourceHelper
		{
			internal void Rijndael(int int_0, int int_1)
			{
				if (this.StrongName2 != null && this.LocalSiteString == int_1 && this.PersianCalendarGB18030Encoding == int_0)
				{
					return;
				}
				this.PersianCalendarGB18030Encoding = int_0;
				this.ControlKeyState = (1u << int_0) - 1u;
				this.LocalSiteString = int_1;
				uint num = 1u << this.LocalSiteString + this.PersianCalendarGB18030Encoding;
				this.StrongName2 = new <Module>.ConfigServerDictionaryBase.ProxyAttributeResourceHelper.DiscretionaryAcl[num];
				for (uint num2 = 0u; num2 < num; num2 += 1u)
				{
					this.StrongName2[(int)num2].Rijndael();
				}
			}

			internal void AssemblyKeyFileAttributePortableExecutableKinds()
			{
				uint num = 1u << this.LocalSiteString + this.PersianCalendarGB18030Encoding;
				for (uint num2 = 0u; num2 < num; num2 += 1u)
				{
					this.StrongName2[(int)num2].AssemblyKeyFileAttributePortableExecutableKinds();
				}
			}

			internal uint NullStreamMdaHelper(uint uint_0, byte byte_0)
			{
				return ((uint_0 & this.ControlKeyState) << this.LocalSiteString) + (uint)(byte_0 >> 8 - this.LocalSiteString);
			}

			internal byte ContextTypeInitializationException(<Module>.ConsoleModifiers consoleModifiers_0, uint uint_0, byte byte_0)
			{
				return this.StrongName2[(int)this.NullStreamMdaHelper(uint_0, byte_0)].SinkProviderEntry(consoleModifiers_0);
			}

			internal byte IAssemblyName(<Module>.ConsoleModifiers consoleModifiers_0, uint uint_0, byte byte_0, byte byte_1)
			{
				return this.StrongName2[(int)this.NullStreamMdaHelper(uint_0, byte_0)].EntryCompressedStack(consoleModifiers_0, byte_1);
			}

			internal ProxyAttributeResourceHelper()
			{
			}

			internal <Module>.ConfigServerDictionaryBase.ProxyAttributeResourceHelper.DiscretionaryAcl[] StrongName2;

			internal int PersianCalendarGB18030Encoding;

			internal int LocalSiteString;

			internal uint ControlKeyState;

			internal struct DiscretionaryAcl
			{
				internal void Rijndael()
				{
					this.SecuritySafeCriticalAttribute = new <Module>.SiteStringIChannel[768];
				}

				internal void AssemblyKeyFileAttributePortableExecutableKinds()
				{
					for (int i = 0; i < 768; i++)
					{
						this.SecuritySafeCriticalAttribute[i].ImportedFromTypeLibAttributeClearCacheHandler();
					}
				}

				internal byte SinkProviderEntry(<Module>.ConsoleModifiers consoleModifiers_0)
				{
					uint num = 1u;
					do
					{
						num = (num << 1 | this.SecuritySafeCriticalAttribute[(int)num].AppDomainUnloadedExceptionSystemException(consoleModifiers_0));
					}
					while (num < 256u);
					return (byte)num;
				}

				internal byte EntryCompressedStack(<Module>.ConsoleModifiers consoleModifiers_0, byte byte_0)
				{
					uint num = 1u;
					for (;;)
					{
						uint num2 = (uint)(byte_0 >> 7 & 1);
						byte_0 = (byte)(byte_0 << 1);
						uint num3 = this.SecuritySafeCriticalAttribute[(int)((1u + num2 << 8) + num)].AppDomainUnloadedExceptionSystemException(consoleModifiers_0);
						num = (num << 1 | num3);
						if (num2 != num3)
						{
							break;
						}
						if (num >= 256u)
						{
							goto IL_93;
						}
					}
					while (num < 256u)
					{
						num = (num << 1 | this.SecuritySafeCriticalAttribute[(int)num].AppDomainUnloadedExceptionSystemException(consoleModifiers_0));
					}
					IL_93:
					return (byte)num;
				}

				internal <Module>.SiteStringIChannel[] SecuritySafeCriticalAttribute;
			}
		}
	}

	internal class SHA1Managed
	{
		internal void Rijndael(uint uint_0)
		{
			if (this.EventHandler1 != uint_0)
			{
				this.SecurityInfosIntPtr = new byte[uint_0];
			}
			this.EventHandler1 = uint_0;
			this.StoreOperationStageComponentVersion = 0u;
			this.TypeBuilderInstantiationComAliasNameAttribute = 0u;
		}

		internal void AssemblyKeyFileAttributePortableExecutableKinds(Stream stream_0, bool bool_0)
		{
			this.LogMessageEventHandlerThreadStateException();
			this.FixedBufferAttributeComUnregisterFunctionAttribute = stream_0;
			if (!bool_0)
			{
				this.TypeBuilderInstantiationComAliasNameAttribute = 0u;
				this.StoreOperationStageComponentVersion = 0u;
			}
		}

		internal void LogMessageEventHandlerThreadStateException()
		{
			this.method_0();
			this.FixedBufferAttributeComUnregisterFunctionAttribute = null;
			Buffer.BlockCopy(new byte[this.SecurityInfosIntPtr.Length], 0, this.SecurityInfosIntPtr, 0, this.SecurityInfosIntPtr.Length);
		}

		internal void method_0()
		{
			uint num = this.StoreOperationStageComponentVersion - this.TypeBuilderInstantiationComAliasNameAttribute;
			if (num == 0u)
			{
				return;
			}
			this.FixedBufferAttributeComUnregisterFunctionAttribute.Write(this.SecurityInfosIntPtr, (int)this.TypeBuilderInstantiationComAliasNameAttribute, (int)num);
			if (this.StoreOperationStageComponentVersion >= this.EventHandler1)
			{
				this.StoreOperationStageComponentVersion = 0u;
			}
			this.TypeBuilderInstantiationComAliasNameAttribute = this.StoreOperationStageComponentVersion;
		}

		internal void IConvertible(uint uint_0, uint uint_1)
		{
			uint num = this.StoreOperationStageComponentVersion - uint_0 - 1u;
			if (num >= this.EventHandler1)
			{
				num += this.EventHandler1;
			}
			while (uint_1 > 0u)
			{
				if (num >= this.EventHandler1)
				{
					num = 0u;
				}
				byte[] securityInfosIntPtr = this.SecurityInfosIntPtr;
				uint storeOperationStageComponentVersion = this.StoreOperationStageComponentVersion;
				this.StoreOperationStageComponentVersion = storeOperationStageComponentVersion + 1u;
				securityInfosIntPtr[(int)storeOperationStageComponentVersion] = this.SecurityInfosIntPtr[(int)num++];
				if (this.StoreOperationStageComponentVersion >= this.EventHandler1)
				{
					this.method_0();
				}
				uint_1 -= 1u;
			}
		}

		internal void DateTimeKind(byte byte_0)
		{
			byte[] securityInfosIntPtr = this.SecurityInfosIntPtr;
			uint storeOperationStageComponentVersion = this.StoreOperationStageComponentVersion;
			this.StoreOperationStageComponentVersion = storeOperationStageComponentVersion + 1u;
			securityInfosIntPtr[(int)storeOperationStageComponentVersion] = byte_0;
			if (this.StoreOperationStageComponentVersion >= this.EventHandler1)
			{
				this.method_0();
			}
		}

		internal byte CrossAppDomainSerializer(uint uint_0)
		{
			uint num = this.StoreOperationStageComponentVersion - uint_0 - 1u;
			if (num >= this.EventHandler1)
			{
				num += this.EventHandler1;
			}
			return this.SecurityInfosIntPtr[(int)num];
		}

		internal SHA1Managed()
		{
		}

		internal byte[] SecurityInfosIntPtr;

		internal uint StoreOperationStageComponentVersion;

		internal Stream FixedBufferAttributeComUnregisterFunctionAttribute;

		internal uint TypeBuilderInstantiationComAliasNameAttribute;

		internal uint EventHandler1;
	}

	internal struct DriveTypeRuntimeType
	{
		internal void AssemblyKeyFileAttributePortableExecutableKinds()
		{
			this.RemotingProxy = 0u;
		}

		internal void ArgumentOutOfRangeException()
		{
			if (this.RemotingProxy < 4u)
			{
				this.RemotingProxy = 0u;
				return;
			}
			if (this.RemotingProxy >= 10u)
			{
				this.RemotingProxy -= 6u;
				return;
			}
			this.RemotingProxy -= 3u;
		}

		internal void UIntPtrInternalEncodingDataItem()
		{
			this.RemotingProxy = ((this.RemotingProxy < 7u) ? 7u : 10u);
		}

		internal void DynamicTypeInfoLease()
		{
			this.RemotingProxy = ((this.RemotingProxy < 7u) ? 8u : 11u);
		}

		internal void StoreTransactionOperationIListWrapper()
		{
			this.RemotingProxy = ((this.RemotingProxy < 7u) ? 9u : 11u);
		}

		internal bool StateManagerRunningStateASMNAME()
		{
			return this.RemotingProxy < 7u;
		}

		internal uint RemotingProxy;
	}

	public class ConstructorBuilderSecurityCriticalScope
	{
		public ConstructorBuilderSecurityCriticalScope() : this(3988292384u, uint.MaxValue)
		{
		}

		public ConstructorBuilderSecurityCriticalScope(uint uint_0, uint uint_1)
		{
			this.IndexOutOfRangeException = <Module>.ConstructorBuilderSecurityCriticalScope.OptionalAttributeCryptoStream(uint_0);
			this.ISymbolVariable = uint_1;
			this.AttributeTargetsGacIdentityPermission = uint_1;
		}

		public void ExceptionTableItem()
		{
			this.ISymbolVariable = this.AttributeTargetsGacIdentityPermission;
		}

		protected void StringTokenBCLDebug(byte[] byte_0, int int_0, int int_1)
		{
			this.ISymbolVariable = <Module>.ConstructorBuilderSecurityCriticalScope.OnDeserializingAttribute(this.IndexOutOfRangeException, this.ISymbolVariable, byte_0, int_0, int_1);
		}

		protected byte[] AsymmetricKeyExchangeDeformatterCONNECTDATA()
		{
			return <Module>.ConstructorBuilderSecurityCriticalScope.Converter(~this.ISymbolVariable);
		}

		public int DESInternalNameSpaceE()
		{
			return 32;
		}

		public static uint CompoundAce(string string_0)
		{
			if (string_0 == null)
			{
				return 0u;
			}
			return <Module>.ConstructorBuilderSecurityCriticalScope.CustomAttributeData(System.Text.Encoding.UTF7.GetBytes(string_0));
		}

		public static uint CustomAttributeData(byte[] byte_0)
		{
			return <Module>.ConstructorBuilderSecurityCriticalScope.SHA1CryptoServiceProviderCompilationRelaxations(uint.MaxValue, byte_0);
		}

		public static uint SHA1CryptoServiceProviderCompilationRelaxations(uint uint_0, byte[] byte_0)
		{
			return <Module>.ConstructorBuilderSecurityCriticalScope.ActivationContextInputRecord(3988292384u, uint_0, byte_0);
		}

		public static uint ActivationContextInputRecord(uint uint_0, uint uint_1, byte[] byte_0)
		{
			return ~<Module>.ConstructorBuilderSecurityCriticalScope.OnDeserializingAttribute(<Module>.ConstructorBuilderSecurityCriticalScope.OptionalAttributeCryptoStream(uint_0), uint_1, byte_0, 0, byte_0.Length);
		}

		private static uint[] OptionalAttributeCryptoStream(uint uint_0)
		{
			if (uint_0 == 3988292384u && <Module>.ConstructorBuilderSecurityCriticalScope.OpCodesCustomAttributeType != null)
			{
				return <Module>.ConstructorBuilderSecurityCriticalScope.OpCodesCustomAttributeType;
			}
			uint[] array = new uint[256];
			for (int i = 0; i < 256; i++)
			{
				uint num = (uint)i;
				for (int j = 0; j < 8; j++)
				{
					if ((num & 1u) == 1u)
					{
						num = (num >> 1 ^ uint_0);
					}
					else
					{
						num >>= 1;
					}
				}
				array[i] = num;
			}
			if (uint_0 == 3988292384u)
			{
				<Module>.ConstructorBuilderSecurityCriticalScope.OpCodesCustomAttributeType = array;
			}
			return array;
		}

		private static uint OnDeserializingAttribute(uint[] uint_0, uint uint_1, IList<byte> ilist_0, int int_0, int int_1)
		{
			uint num = uint_1;
			for (int i = int_0; i < int_0 + int_1; i++)
			{
				num = (num >> 8 ^ uint_0[(int)((uint)ilist_0[i] ^ (num & 255u))]);
			}
			return num;
		}

		private static byte[] Converter(uint uint_0)
		{
			byte[] bytes = BitConverter.GetBytes(uint_0);
			if (BitConverter.IsLittleEndian)
			{
				Array.Reverse(bytes);
			}
			return bytes;
		}

		public const uint SurrogateSelectorTypeBuilder;

		public const uint ReadObjectInfoIIDENTITYAUTHORITYREFERENCEIDENTITYTOTEXTFLAGS;

		private static uint[] OpCodesCustomAttributeType;

		private readonly uint AttributeTargetsGacIdentityPermission;

		private readonly uint[] IndexOutOfRangeException;

		private uint ISymbolVariable;
	}

	public class Disposition
	{
		public Disposition() : this(3988292384u, uint.MaxValue)
		{
		}

		public Disposition(uint uint_0, uint uint_1)
		{
			this.PermissionSetTripleObjectHolderListEnumerator = <Module>.Disposition.FileStreamAsyncResultStringComparer(uint_0);
			this.CallConvFastcallIsBoxed = uint_1;
			this.TypeFilter = uint_1;
		}

		public void UInt32IResourceWriter()
		{
			this.CallConvFastcallIsBoxed = this.TypeFilter;
		}

		protected void RegistryKeyPermissionCheckSTORECATEGORY(byte[] byte_0, int int_0, int int_1)
		{
			this.CallConvFastcallIsBoxed = <Module>.Disposition.AmbiguousMatchExceptionAssemblyHash(this.PermissionSetTripleObjectHolderListEnumerator, this.CallConvFastcallIsBoxed, byte_0, int_0, int_1);
		}

		protected byte[] RSAPKCS1SignatureFormatter()
		{
			return <Module>.Disposition.InternalsVisibleToAttribute(~this.CallConvFastcallIsBoxed);
		}

		public int ExecutionContextRunData()
		{
			return 32;
		}

		public static uint MulticastDelegate(string string_0)
		{
			if (string_0 == null)
			{
				return 0u;
			}
			return <Module>.Disposition.smethod_0(System.Text.Encoding.UTF7.GetBytes(string_0));
		}

		public static uint smethod_0(byte[] byte_0)
		{
			return <Module>.Disposition.RemotingProfilerEventBinaryCrossAppDomainString(uint.MaxValue, byte_0);
		}

		public static uint RemotingProfilerEventBinaryCrossAppDomainString(uint uint_0, byte[] byte_0)
		{
			return <Module>.Disposition.DirectorySecurityPermissionSetEnumeratorInternal(3988292384u, uint_0, byte_0);
		}

		public static uint DirectorySecurityPermissionSetEnumeratorInternal(uint uint_0, uint uint_1, byte[] byte_0)
		{
			return ~<Module>.Disposition.AmbiguousMatchExceptionAssemblyHash(<Module>.Disposition.FileStreamAsyncResultStringComparer(uint_0), uint_1, byte_0, 0, byte_0.Length);
		}

		private static uint[] FileStreamAsyncResultStringComparer(uint uint_0)
		{
			if (uint_0 == 3988292384u && <Module>.Disposition.DynamicAssemblyFlags != null)
			{
				return <Module>.Disposition.DynamicAssemblyFlags;
			}
			uint[] array = new uint[256];
			for (int i = 0; i < 256; i++)
			{
				uint num = (uint)i;
				for (int j = 0; j < 8; j++)
				{
					if ((num & 1u) != 1u)
					{
						num >>= 1;
					}
					else
					{
						num = (num >> 1 ^ uint_0);
					}
				}
				array[i] = num;
			}
			if (uint_0 == 3988292384u)
			{
				<Module>.Disposition.DynamicAssemblyFlags = array;
			}
			return array;
		}

		private static uint AmbiguousMatchExceptionAssemblyHash(uint[] uint_0, uint uint_1, IList<byte> ilist_0, int int_0, int int_1)
		{
			uint num = uint_1;
			for (int i = int_0; i < int_0 + int_1; i++)
			{
				num = (num >> 8 ^ uint_0[(int)((uint)ilist_0[i] ^ (num & 255u))]);
			}
			return num;
		}

		private static byte[] InternalsVisibleToAttribute(uint uint_0)
		{
			byte[] bytes = BitConverter.GetBytes(uint_0);
			if (BitConverter.IsLittleEndian)
			{
				Array.Reverse(bytes);
			}
			return bytes;
		}

		public const uint CustomAttributeNamedArgumentISoapXsd;

		public const uint NeutralResourcesLanguageAttributeSoapIdref;

		private static uint[] DynamicAssemblyFlags;

		private readonly uint TypeFilter;

		private readonly uint[] PermissionSetTripleObjectHolderListEnumerator;

		private uint CallConvFastcallIsBoxed;
	}

	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 91840)]
	internal struct EncodingCharBufferBinaryMethodReturnMessage
	{
	}

	public delegate uint IntInt(int int_0);

	public class CultureTable
	{
		internal static uint[] TOKENUSER(byte[] byte_0, int int_0)
		{
			uint[] array = new uint[byte_0.Length / 4];
			<Module>.CultureTable.IEnumReferenceIdentity enumReferenceIdentity = new <Module>.CultureTable.IEnumReferenceIdentity(byte_0, int_0);
			for (int i = 0; i < array.Length; i++)
			{
				array[i] = enumReferenceIdentity.get_Item(i);
			}
			return array;
		}

		internal CultureTable()
		{
		}

		public class IEnumReferenceIdentity
		{
			internal IEnumReferenceIdentity(byte[] byte_0, int int_0)
			{
				this.MLangDecoderSerializationInfoEnumerator = byte_0;
				this.SpecialNameAttributeISectionWithStringKey = (uint)int_0;
			}

			internal uint Item
			{
				get
				{
					return BitConverter.ToUInt32(this.MLangDecoderSerializationInfoEnumerator, int_0 * 4) ^ this.SpecialNameAttributeISectionWithStringKey;
				}
			}

			private byte[] MLangDecoderSerializationInfoEnumerator;

			public uint SpecialNameAttributeISectionWithStringKey;
		}
	}
}
