﻿using System;

internal delegate object SendOrPostCallbackConstants(object object_0);
