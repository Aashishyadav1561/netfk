﻿using System;

internal delegate string NetCodeGroupCodeGroupStack(string string_0, string[] string_1);
