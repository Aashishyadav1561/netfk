﻿using System;

internal delegate object EntryPointNotFoundException(object object_0, object object_1, object[] object_2);
