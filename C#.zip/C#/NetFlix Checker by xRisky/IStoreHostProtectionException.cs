﻿using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 4065)]
internal struct IStoreHostProtectionException
{
}
