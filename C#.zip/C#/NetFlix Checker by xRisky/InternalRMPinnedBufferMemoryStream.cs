﻿using System;

internal delegate void InternalRMPinnedBufferMemoryStream(Array array_0, int int_0, Array array_1, int int_1, int int_2);
