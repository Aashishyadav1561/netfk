﻿using System;

internal delegate object IDeploymentMetadataEntryCryptoKeySecurity(string string_0, object object_0, Type[] type_0, object object_1, bool bool_0);
