﻿using System;

internal delegate uint[] StringExpressionSet(uint uint_0);
