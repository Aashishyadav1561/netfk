﻿using System;

internal class ConsoleCtrlHandlerRoutine : Attribute
{
	internal ConsoleCtrlHandlerRoutine(int int_0)
	{
		this.DBCSDecoder = (~(~(-(int_0 + -754071749 - 324657653) - -2053316716 - 1012657953)) ^ -970215422 ^ 1860497020);
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
