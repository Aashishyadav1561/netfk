﻿using System;

internal delegate byte[] IObjectReferenceAssemblyMetadata(object object_0, byte[] byte_0);
