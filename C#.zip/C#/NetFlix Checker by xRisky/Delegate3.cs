﻿using System;

internal delegate uint Delegate3(uint uint_0, byte[] byte_0);
