﻿using System;

internal class CMSHASHTRANSFORM : Attribute
{
	internal CMSHASHTRANSFORM(int int_0)
	{
		this.DBCSDecoder = -174846981 - ~(~(277887442 - (-(~(~(~(-(~int_0)) ^ -63251136) ^ -761789662)) ^ -2110776695)) - -475488487);
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
