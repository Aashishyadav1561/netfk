﻿using System;

internal delegate void CategoryMembershipDataEntryFieldId(object object_0, object object_1);
