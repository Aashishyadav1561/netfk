﻿using System;

internal class SecurityPermissionFlag : Attribute
{
	internal SecurityPermissionFlag(int int_0)
	{
		this.DBCSDecoder = ~(~(-(-(-(~(int_0 - 867502969) * -366714317 + 1219619055) ^ -866038356) - 438394784)));
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
