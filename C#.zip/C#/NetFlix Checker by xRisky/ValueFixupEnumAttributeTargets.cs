﻿using System;

internal class ValueFixupEnumAttributeTargets : Attribute
{
	internal ValueFixupEnumAttributeTargets(int int_0)
	{
		this.DBCSDecoder = -(~(~(~((-(~(~(1924776048 - (int_0 + -1715915561)))) * 2009610197 * 1748866179 - -252268515) * 2076250621) ^ -224332260) ^ -1976830011) + 955163365);
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
