﻿using System;
using System.Reflection;

internal delegate object CerHashtable2RemotingConfigHandler(Type type_0, MethodInfo methodInfo_0);
