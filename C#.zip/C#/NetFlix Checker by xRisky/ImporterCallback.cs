﻿using System;

internal class ImporterCallback : Attribute
{
	internal ImporterCallback(int int_0)
	{
		this.DBCSDecoder = (~(~(-(-92240522 - -(914618924 - int_0 - -1298596718)))) ^ -24170025);
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
