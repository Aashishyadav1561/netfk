﻿using System;

internal delegate int FileAssociationEntrySoapEntity(object object_0, byte[] byte_0, int int_0, int int_1);
