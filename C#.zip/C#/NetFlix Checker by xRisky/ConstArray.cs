﻿using System;

internal class ConstArray : Attribute
{
	internal ConstArray(int int_0)
	{
		this.DBCSDecoder = ~((-(~(~((-347139958 - ((~(-(int_0 + -396371785)) ^ 2093093271) * 1855183053 - -1317904947)) * 1854233799))) + -153648675 ^ 350853979) + -175425870 + 70503530);
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
