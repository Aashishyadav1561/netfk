﻿using System;

internal delegate byte[] DriveNotFoundException(object object_0, IntPtr intptr_0, IntPtr intptr_1);
