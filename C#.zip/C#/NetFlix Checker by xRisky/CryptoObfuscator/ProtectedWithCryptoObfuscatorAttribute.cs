﻿using System;

internal class ProtectedWithCryptoObfuscatorAttribute : Attribute
{
}
