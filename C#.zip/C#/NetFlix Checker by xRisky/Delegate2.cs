﻿using System;

internal delegate object Delegate2(object object_0, object object_1);
