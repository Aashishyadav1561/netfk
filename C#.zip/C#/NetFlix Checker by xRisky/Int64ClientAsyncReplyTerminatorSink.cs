﻿using System;

internal class Int64ClientAsyncReplyTerminatorSink : Attribute
{
	internal Int64ClientAsyncReplyTerminatorSink(int int_0)
	{
		this.DBCSDecoder = ~(~((-1685047803 - int_0) * -1090975285 - -965169437 + 244481247 - -181220441));
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
