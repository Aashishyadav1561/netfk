﻿using System;

internal delegate void IAPPIDAUTHORITYAREDEFINITIONSEQUALFLAGSEnvironmentPermissionAccess(object object_0, object object_1, object object_2);
