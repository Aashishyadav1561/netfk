﻿using System;

internal class IDispatchConstantAttribute : Attribute
{
	internal IDispatchConstantAttribute(int int_0)
	{
		this.DBCSDecoder = -(-263945614 - -((-(int_0 + -2134811140 ^ -239832431) - 1915087737 + 2126930386) * -260855261 - 623326682) * -955575153 * 52755903 ^ 1181911502 ^ 1683957867);
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
