﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

namespace WindowsApp45
{
	[Obfuscation(Exclude = true)]
	[Obfuscation(Exclude = true)]
	public class AnimaStatusBar : Control
	{
		public AnimaStatusBar.RuntimeFieldInfo LogMessageEventHandler { [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] get; [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] set; }

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		public AnimaStatusBar()
		{
			this.WhatsCachedPermissionSetTriple = Color.FromArgb(0, 122, 204);
			this.Buffer = Color.FromArgb(0, 126, 204);
			this.DoubleBuffered = true;
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		protected override void OnPaint(PaintEventArgs e)
		{
			<Module>.SoapFieldAttribute(213);
			this.SearchDataRealProxyFlags = e.Graphics;
			switch (this.LogMessageEventHandler)
			{
			case AnimaStatusBar.RuntimeFieldInfo.Basic:
				this.WhatsCachedPermissionSetTriple = Color.FromArgb(0, 122, 204);
				this.Buffer = Color.FromArgb(0, 126, 204);
				break;
			case AnimaStatusBar.RuntimeFieldInfo.Warning:
				this.WhatsCachedPermissionSetTriple = Color.FromArgb(210, 143, 75);
				this.Buffer = Color.FromArgb(214, 147, 75);
				break;
			case AnimaStatusBar.RuntimeFieldInfo.Wrong:
				this.WhatsCachedPermissionSetTriple = Color.FromArgb(212, 110, 110);
				this.Buffer = Color.FromArgb(216, 114, 114);
				break;
			default:
				this.WhatsCachedPermissionSetTriple = Color.FromArgb(45, 193, 90);
				this.Buffer = Color.FromArgb(45, 197, 90);
				break;
			}
			checked
			{
				using (SolidBrush solidBrush = new SolidBrush(this.WhatsCachedPermissionSetTriple))
				{
					using (Pen pen = new Pen(this.Buffer))
					{
						this.SearchDataRealProxyFlags.FillRectangle(solidBrush, new Rectangle(0, 0, base.Width - 1, base.Height - 1));
						this.SearchDataRealProxyFlags.DrawLine(pen, 0, 0, base.Width - 2, 0);
					}
				}
				using (SolidBrush solidBrush2 = new SolidBrush(Color.FromArgb(255, 255, 255)))
				{
					using (Font font = new Font("Segoe UI semibold", 8f))
					{
						this.SearchDataRealProxyFlags.DrawString(this.Text, font, solidBrush2, new Point(4, 2));
					}
				}
				base.OnPaint(e);
			}
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		protected override void OnTextChanged(EventArgs e)
		{
			base.Invalidate();
			base.OnTextChanged(e);
		}

		private Graphics SearchDataRealProxyFlags;

		private Color WhatsCachedPermissionSetTriple;

		private Color Buffer;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private AnimaStatusBar.RuntimeFieldInfo CacheAction;

		public enum RuntimeFieldInfo : byte
		{
			Basic,
			Warning,
			Wrong,
			Success
		}
	}
}
