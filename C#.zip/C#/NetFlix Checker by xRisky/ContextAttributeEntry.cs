﻿using System;
using System.Reflection.Emit;

internal delegate void ContextAttributeEntry(object object_0, OpCode opCode_0, object object_1, Type[] type_0);
