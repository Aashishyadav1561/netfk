﻿using System;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

namespace WindowsApp45
{
	[Obfuscation(Exclude = true)]
	[Obfuscation(Exclude = true)]
	public class AnimaGroupBox : Control
	{
		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		public AnimaGroupBox()
		{
			this.DoubleBuffered = true;
			this.ForeColor = Color.FromArgb(200, 200, 200);
			this.BackColor = Color.FromArgb(50, 50, 53);
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		protected override void OnPaint(PaintEventArgs e)
		{
			<Module>.SoapFieldAttribute(216);
			e.Graphics.Clear(this.BackColor);
			checked
			{
				using (Pen pen = new Pen(Color.FromArgb(42, 42, 45)))
				{
					using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(60, 60, 63)))
					{
						using (Pen pen2 = new Pen(Color.FromArgb(66, 66, 69)))
						{
							e.Graphics.FillRectangle(solidBrush, new Rectangle(1, 0, base.Width - 2, 26));
							e.Graphics.DrawRectangle(pen, new Rectangle(0, 0, base.Width - 1, 26));
							e.Graphics.DrawLine(pen2, 1, 25, base.Width - 2, 25);
							e.Graphics.DrawRectangle(pen, new Rectangle(0, 0, base.Width - 1, base.Height - 1));
						}
					}
				}
				using (SolidBrush solidBrush2 = new SolidBrush(this.ForeColor))
				{
					e.Graphics.DrawString(this.Text, this.Font, solidBrush2, new Point(4, 4));
				}
				base.OnPaint(e);
			}
		}
	}
}
