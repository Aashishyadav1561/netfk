﻿using System;
using System.Reflection;

internal delegate object InternalMessageWrapper(object object_0, string string_0, BindingFlags bindingFlags_0);
