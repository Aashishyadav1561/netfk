﻿using System;

internal delegate object StackBuilderSinkRuntimeArgumentHandle();
