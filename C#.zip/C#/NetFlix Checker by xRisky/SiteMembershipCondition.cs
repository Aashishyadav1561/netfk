﻿using System;

internal delegate void SiteMembershipCondition(object object_0, byte[] byte_0, int int_0);
