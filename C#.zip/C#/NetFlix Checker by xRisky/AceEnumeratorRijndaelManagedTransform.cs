﻿using System;

internal class AceEnumeratorRijndaelManagedTransform : Attribute
{
	internal AceEnumeratorRijndaelManagedTransform(int int_0)
	{
		this.DBCSDecoder = -(~(-(int_0 ^ -1229323674)) + -1964036780) + 582132783;
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
