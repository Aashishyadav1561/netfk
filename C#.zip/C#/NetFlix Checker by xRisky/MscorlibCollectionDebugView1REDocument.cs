﻿using System;

internal delegate void MscorlibCollectionDebugView1REDocument(Array array_0);
