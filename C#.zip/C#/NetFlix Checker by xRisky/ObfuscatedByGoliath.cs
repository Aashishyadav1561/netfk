﻿using System;

internal class ObfuscatedByGoliath : Attribute
{
}
