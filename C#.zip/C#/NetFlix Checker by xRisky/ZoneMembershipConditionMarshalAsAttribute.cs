﻿using System;

internal class ZoneMembershipConditionMarshalAsAttribute : Attribute
{
	internal ZoneMembershipConditionMarshalAsAttribute(int int_0)
	{
		this.Resolver = ~(~(~(~((~(-int_0) * -1269174203 - 1364512827 - -372050643 ^ -2078730794 ^ -1257714461 ^ 1897099295) * 2095834425 * 2060978295) * 1431530827)) * 363994751);
	}

	public virtual int BinaryArray()
	{
		return this.Resolver;
	}

	internal readonly int Resolver;
}
