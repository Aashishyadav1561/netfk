﻿using System;

internal class SafeRegistryHandle : Attribute
{
	internal SafeRegistryHandle(int int_0)
	{
		this.DBCSDecoder = ~(((int_0 + 731437541 ^ -786899032 ^ -969558759) - -477164297 ^ -1594043971) - 924242559 ^ 1763468340) + 916746355;
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
