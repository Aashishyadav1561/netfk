﻿using System;

internal delegate object HashFormatterAssemblyStyle(object object_0, int int_0);
