﻿using System;

internal delegate bool SiteIdentityPermissionAttributeRemotingProfilerEvent(object object_0, string string_0);
