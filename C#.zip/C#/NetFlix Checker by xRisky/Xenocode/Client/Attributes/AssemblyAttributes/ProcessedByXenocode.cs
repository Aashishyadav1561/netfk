﻿using System;

internal class ProcessedByXenocode : Attribute
{
}
