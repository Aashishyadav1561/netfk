﻿using System;

internal delegate uint UCOMIEnumConnections(object object_0);
