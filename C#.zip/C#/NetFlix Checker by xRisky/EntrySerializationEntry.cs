﻿using System;

internal delegate void EntrySerializationEntry(object object_0, byte[] byte_0, int int_0, int int_1);
