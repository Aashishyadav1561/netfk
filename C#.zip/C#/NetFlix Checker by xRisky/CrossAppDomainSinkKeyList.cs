﻿using System;

internal class CrossAppDomainSinkKeyList : Attribute
{
	internal CrossAppDomainSinkKeyList(int int_0)
	{
		this.DBCSDecoder = ((~((int_0 - 1806822344 ^ -98538310) * 315120169 * -1283717785) ^ 1450654714 ^ -1204110995) + -706090610 ^ 903491031) * -141150179;
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
