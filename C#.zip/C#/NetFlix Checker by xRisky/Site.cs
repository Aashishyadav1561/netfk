﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsApp45
{
	public class Site : TabControl
	{
		protected virtual void TypeFilterLevel(ControlEventArgs e)
		{
			<Module>.SoapFieldAttribute(214);
			e.Control.BackColor = Color.FromArgb(45, 45, 48);
			e.Control.ForeColor = Color.FromArgb(200, 200, 200);
			e.Control.Font = new Font("Segoe UI", 9f);
			base.OnControlAdded(e);
		}

		public Site()
		{
			this.DoubleBuffered = true;
			this.Font = new Font("Segoe UI", 9f);
			this.ForeColor = Color.FromArgb(200, 200, 200);
			base.ItemSize = new Size(18, 18);
			base.SizeMode = TabSizeMode.Fixed;
			base.Alignment = TabAlignment.Top;
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.Opaque | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
		}

		protected virtual void IConstructionCallMessage(PaintEventArgs e)
		{
			<Module>.SoapFieldAttribute(215);
			this.SearchDataRealProxyFlags = e.Graphics;
			this.SearchDataRealProxyFlags.Clear(base.Parent.BackColor);
			checked
			{
				int num = base.TabPages.Count - 1;
				int i = 0;
				while (i <= num)
				{
					this.ResourceHelper = base.GetTabRect(i);
					if (base.SelectedIndex == i)
					{
						using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(41, 130, 232)))
						{
							using (Pen pen = new Pen(Color.FromArgb(38, 127, 229)))
							{
								this.SearchDataRealProxyFlags.FillRectangle(solidBrush, new Rectangle(this.ResourceHelper.X + 5, this.ResourceHelper.Y + 2, 12, 12));
								this.SearchDataRealProxyFlags.DrawRectangle(pen, new Rectangle(this.ResourceHelper.X + 5, this.ResourceHelper.Y + 2, 12, 12));
							}
							goto IL_239;
						}
						goto IL_159;
					}
					goto IL_159;
					IL_239:
					i++;
					continue;
					IL_159:
					using (SolidBrush solidBrush2 = new SolidBrush(Color.FromArgb(70, 70, 73)))
					{
						using (Pen pen2 = new Pen(Color.FromArgb(42, 42, 45)))
						{
							this.SearchDataRealProxyFlags.FillRectangle(solidBrush2, new Rectangle(this.ResourceHelper.X + 5, this.ResourceHelper.Y + 2, 12, 12));
							this.SearchDataRealProxyFlags.DrawRectangle(pen2, new Rectangle(this.ResourceHelper.X + 5, this.ResourceHelper.Y + 2, 12, 12));
						}
					}
					goto IL_239;
				}
				base.OnPaint(e);
			}
		}

		private Graphics SearchDataRealProxyFlags;

		private Rectangle ResourceHelper;
	}
}
