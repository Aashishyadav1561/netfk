﻿using System;

internal delegate string ObjectAuditRuleSinkProviderEntry(byte[] byte_0);
