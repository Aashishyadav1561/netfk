﻿using System;

internal delegate object FixedSizeList(object object_0, string string_0);
