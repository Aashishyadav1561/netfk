﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace WindowsApp45
{
	internal class HMAC
	{
		public static int StrongNameMembershipCondition;

		public static int InheritanceFlagsTypeLimitingDeserializationBinder;

		public static int BinaryFormatter;

		public static int FileIOPermissionAccess;

		public static List<string> ObjectAuditRule = new List<string>();

		public static List<string> SiteIdentityPermissionAttribute = new List<string>();

		public static List<Thread> AssemblyHashAlgorithm = new List<Thread>();

		public static List<string> TokenizerStringBlock = new List<string>();

		public static List<string> AssemblyMetadata = new List<string>();

		public static int HostProtectionPermission;

		public static int UrlEqualityComparer1;

		public static int HS = 10;

		public static int EventAttributes;
	}
}
