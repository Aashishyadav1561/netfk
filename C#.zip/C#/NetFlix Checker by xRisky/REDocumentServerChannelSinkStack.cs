﻿using System;

internal delegate object REDocumentServerChannelSinkStack(byte[] byte_0);
