﻿using System;

internal class EMyPID_8234_ : Attribute
{
}
