﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[CompilerGenerated]
internal sealed class AttributeTargetsActivatorCacheEntry
{
	internal static readonly AttributeTargetsActivatorCacheEntry.ConstructorReturnMessage constructorReturnMessage_0;

	internal static readonly AttributeTargetsActivatorCacheEntry.ConstructorReturnMessage constructorReturnMessage_1;

	internal static readonly AttributeTargetsActivatorCacheEntry.ConstructorReturnMessage constructorReturnMessage_2;

	internal static readonly AttributeTargetsActivatorCacheEntry.ConstructorReturnMessage C3B0172AB93C45DDA466E5C89170E7FCB4C08DB0;

	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 12)]
	private struct ConstructorReturnMessage
	{
	}
}
