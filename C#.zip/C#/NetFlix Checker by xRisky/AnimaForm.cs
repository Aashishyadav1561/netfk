﻿using System;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

namespace WindowsApp45
{
	[Obfuscation(Exclude = true)]
	public class AnimaForm : ContainerControl
	{
		[Obfuscation(Exclude = true)]
		public AnimaForm()
		{
			this.CCMDictionary = default(Point);
			this.TrustManagerContext = default(Point);
			this.BackColor = Color.FromArgb(45, 45, 48);
			this.DoubleBuffered = true;
			this.Font = new Font("Segoe UI", 9f);
			this.Dock = DockStyle.Fill;
			this.ForeColor = Color.FromArgb(200, 200, 200);
		}

		[Obfuscation(Exclude = true)]
		protected override void OnCreateControl()
		{
			<Module>.SoapFieldAttribute(168);
			base.ParentForm.FormBorderStyle = FormBorderStyle.None;
			base.OnCreateControl();
		}

		[Obfuscation(Exclude = true)]
		protected override void OnPaint(PaintEventArgs e)
		{
			<Module>.SoapFieldAttribute(169);
			this.SearchDataRealProxyFlags = e.Graphics;
			checked
			{
				using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(55, 55, 58)))
				{
					this.SearchDataRealProxyFlags.FillRectangle(solidBrush, new Rectangle(0, 0, base.Width - 1, 36));
				}
				using (Pen pen = new Pen(Color.FromArgb(43, 43, 46)))
				{
					this.SearchDataRealProxyFlags.DrawLine(pen, 0, 36, base.Width - 1, 36);
				}
				using (SolidBrush solidBrush2 = new SolidBrush(this.ForeColor))
				{
					this.SearchDataRealProxyFlags.DrawString(this.Text, this.Font, solidBrush2, new Point(10, 10));
				}
				using (Pen pen2 = new Pen(Color.FromArgb(35, 35, 38)))
				{
					e.Graphics.DrawRectangle(pen2, new Rectangle(0, 0, base.Width - 1, base.Height - 1));
				}
				base.OnPaint(e);
			}
		}

		[Obfuscation(Exclude = true)]
		protected override void OnMouseDown(MouseEventArgs e)
		{
			<Module>.SoapFieldAttribute(170);
			if (e.Button == MouseButtons.Left && e.Y < 36)
			{
				this.CacheType = true;
				this.CCMDictionary.X = e.X;
				this.CCMDictionary.Y = e.Y;
			}
			base.OnMouseDown(e);
		}

		[Obfuscation(Exclude = true)]
		protected override void OnMouseUp(MouseEventArgs e)
		{
			<Module>.SoapFieldAttribute(171);
			if (e.Button == MouseButtons.Left)
			{
				this.CacheType = false;
			}
			base.OnMouseUp(e);
		}

		[Obfuscation(Exclude = true)]
		protected override void OnMouseMove(MouseEventArgs e)
		{
			<Module>.SoapFieldAttribute(172);
			checked
			{
				if (this.CacheType)
				{
					this.TrustManagerContext.X = base.Parent.Location.X + (e.X - this.CCMDictionary.X);
					this.TrustManagerContext.Y = base.Parent.Location.Y + (e.Y - this.CCMDictionary.Y);
					base.Parent.Location = this.TrustManagerContext;
					this.TrustManagerContext = default(Point);
				}
				base.OnMouseMove(e);
			}
		}

		private Graphics SearchDataRealProxyFlags;

		private bool CacheType;

		private Point CCMDictionary;

		private Point TrustManagerContext;
	}
}
