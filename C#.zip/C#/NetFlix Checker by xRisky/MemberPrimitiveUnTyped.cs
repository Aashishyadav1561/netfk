﻿using System;

internal delegate void MemberPrimitiveUnTyped(Array array_0, int int_0, int int_1);
