﻿using System;

internal delegate void IDRole(object object_0);
