﻿using System;

internal delegate uint SoapNmtoken(string string_0);
