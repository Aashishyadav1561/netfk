﻿using System;

internal class BabelObfuscatorAttribute : Attribute
{
}
