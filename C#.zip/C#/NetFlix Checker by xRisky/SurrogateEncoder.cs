﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsApp45
{
	public class SurrogateEncoder : ContextMenuStrip
	{
		public SurrogateEncoder()
		{
			this.Font = new Font("Segoe UI", 9f);
			base.ForeColor = Color.FromArgb(200, 200, 200);
			NameCachePrincipalPolicy nameCachePrincipalPolicy = new NameCachePrincipalPolicy();
			nameCachePrincipalPolicy.MutexCleanupInfo += this.IEnumerable1;
			nameCachePrincipalPolicy.UCOMIBindCtxAF += this.ModuleHandle;
			nameCachePrincipalPolicy.EncoderFallbackBufferAccessControlActions += this.ActivationServices;
			nameCachePrincipalPolicy.TypeUnloadedExceptionBINDPTR += this.TypeKindExceptionHandlingClauseOptions;
			nameCachePrincipalPolicy.AssemblyNamePermissionListSet += this.SiteString;
			nameCachePrincipalPolicy.StateManagerRunningStateWellKnownClientTypeEntry += this.IRegistrationServicesExceptionInfo;
			base.Renderer = nameCachePrincipalPolicy;
		}

		private void IRegistrationServicesExceptionInfo(object sender, ToolStripArrowRenderEventArgs e)
		{
			<Module>.SoapFieldAttribute(207);
			this.SearchDataRealProxyFlags = e.Graphics;
			using (Font font = new Font("Marlett", 10f))
			{
				using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(130, 130, 130)))
				{
					this.SearchDataRealProxyFlags.DrawString("4", font, solidBrush, new Point(e.ArrowRectangle.X, checked(e.ArrowRectangle.Y + 2)));
				}
			}
		}

		private void IEnumerable1(object sender, ToolStripRenderEventArgs e)
		{
			<Module>.SoapFieldAttribute(208);
			this.SearchDataRealProxyFlags = e.Graphics;
			this.SearchDataRealProxyFlags.Clear(Color.FromArgb(55, 55, 58));
		}

		private void ModuleHandle(object sender, ToolStripRenderEventArgs e)
		{
			<Module>.SoapFieldAttribute(209);
			this.SearchDataRealProxyFlags = e.Graphics;
			using (Pen pen = new Pen(Color.FromArgb(35, 35, 38)))
			{
				this.SearchDataRealProxyFlags.DrawRectangle(pen, checked(new Rectangle(e.AffectedBounds.X, e.AffectedBounds.Y, e.AffectedBounds.Width - 1, e.AffectedBounds.Height - 1)));
			}
		}

		private void ActivationServices(object sender, ToolStripItemImageRenderEventArgs e)
		{
			<Module>.SoapFieldAttribute(210);
			this.SearchDataRealProxyFlags = e.Graphics;
			this.SearchDataRealProxyFlags.DrawImage(e.Image, new Point(10, 1));
		}

		private void TypeKindExceptionHandlingClauseOptions(object sender, ToolStripItemTextRenderEventArgs e)
		{
			<Module>.SoapFieldAttribute(211);
			this.SearchDataRealProxyFlags = e.Graphics;
			using (SolidBrush solidBrush = new SolidBrush(e.TextColor))
			{
				this.SearchDataRealProxyFlags.DrawString(e.Text, this.Font, solidBrush, new Point(e.TextRectangle.X, checked(e.TextRectangle.Y - 1)));
			}
		}

		private void SiteString(object sender, ToolStripItemRenderEventArgs e)
		{
			<Module>.SoapFieldAttribute(212);
			this.SearchDataRealProxyFlags = e.Graphics;
			this.SoapNameCalendarWeekRule = e.Item.ContentRectangle;
			if (e.Item.Selected)
			{
				using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(85, 85, 85)))
				{
					this.SearchDataRealProxyFlags.FillRectangle(solidBrush, checked(new Rectangle(this.SoapNameCalendarWeekRule.X - 4, this.SoapNameCalendarWeekRule.Y - 1, this.SoapNameCalendarWeekRule.Width + 4, this.SoapNameCalendarWeekRule.Height - 1)));
				}
			}
		}

		private Graphics SearchDataRealProxyFlags;

		private Rectangle SoapNameCalendarWeekRule;
	}
}
