﻿using System;

internal delegate string AssemblyHashAlgorithmRSAOAEPKeyExchangeFormatter(string string_0, object object_0);
