﻿using System;
using System.Reflection;

internal delegate FieldInfo[] RemotingExceptionHebrewNumberParsingState(object object_0);
