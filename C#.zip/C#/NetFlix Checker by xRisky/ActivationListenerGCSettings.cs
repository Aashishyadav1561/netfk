﻿using System;

internal delegate bool ActivationListenerGCSettings(int int_0, IntPtr intptr_0, int int_1, int int_2, ref int int_3);
