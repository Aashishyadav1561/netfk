﻿using System;

internal delegate byte[] StreamTokenReader(object object_0, int int_0);
