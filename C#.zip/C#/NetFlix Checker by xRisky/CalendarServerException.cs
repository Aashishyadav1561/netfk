﻿using System;

internal delegate object CalendarServerException(object object_0, Type[] type_0);
