﻿using System;

internal class ConfigTreeParserXmlSyntaxException : Attribute
{
	internal ConfigTreeParserXmlSyntaxException(int int_0)
	{
		this.DBCSDecoder = (-(-(-1716351468 - -(~(1834275935 - (int_0 * 1738170143 ^ -335800354))))) * -1579991149 ^ -2077741780) * 1068451937 - -1526339429;
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
