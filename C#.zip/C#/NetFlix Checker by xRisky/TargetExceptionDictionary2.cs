﻿using System;

internal delegate string TargetExceptionDictionary2(object object_0, string string_0, string string_1);
