﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;

internal static class UInt16
{
	internal static int CompressedStack(string string_0, int int_0)
	{
		return global::UInt16.Overlapped(string_0, int_0);
	}

	internal static int Overlapped(string string_0, int int_0)
	{
		List<double> list = new List<double>();
		foreach (string s in string_0.Split(new char[]
		{
			','
		}))
		{
			list.Add(double.Parse(s, CultureInfo.InvariantCulture));
		}
		if (global::UInt16.ScopeTreeAssociateRecord == null)
		{
			global::UInt16.OnDeserializedAttributeStrongNameKeyPair();
		}
		global::UInt16.BinaryCrossAppDomainStringICryptoTransform binaryCrossAppDomainStringICryptoTransform = global::UInt16.IMessageCtrlIEnumConnections(global::UInt16.ScopeTreeAssociateRecord, list, -1.0, 0.0);
		binaryCrossAppDomainStringICryptoTransform.IList1.Add((double)int_0);
		return (int)global::UInt16.CalendarWeekRuleChineseLunisolarCalendar(binaryCrossAppDomainStringICryptoTransform).FileSystemInfoTypeLibTypeAttribute;
	}

	internal static void OnDeserializedAttributeStrongNameKeyPair()
	{
		List<double> list = new List<double>();
		foreach (string s in new StreamReader(Assembly.GetExecutingAssembly().GetManifestResourceStream("vmkeyz")).ReadToEnd().Split(new char[]
		{
			','
		}))
		{
			list.Add(double.Parse(s, CultureInfo.InvariantCulture));
		}
		global::UInt16.ScopeTreeAssociateRecord = new global::UInt16.AuthorizationRuleCollectionThrowHelper(list);
	}

	internal static double TypeLibImportClassAttribute(global::UInt16.BinaryCrossAppDomainStringICryptoTransform binaryCrossAppDomainStringICryptoTransform_0)
	{
		double result = binaryCrossAppDomainStringICryptoTransform_0.SkipAddresses[binaryCrossAppDomainStringICryptoTransform_0.SkipAddresses.Count - 1];
		binaryCrossAppDomainStringICryptoTransform_0.SkipAddresses.Remove(binaryCrossAppDomainStringICryptoTransform_0.SkipAddresses[binaryCrossAppDomainStringICryptoTransform_0.SkipAddresses.Count - 1]);
		return result;
	}

	internal static void InternalActivationContextHelper(global::UInt16.BinaryCrossAppDomainStringICryptoTransform binaryCrossAppDomainStringICryptoTransform_0, double double_0)
	{
		binaryCrossAppDomainStringICryptoTransform_0.SkipAddresses.Add(double_0);
	}

	internal static double IPermission(global::UInt16.BinaryCrossAppDomainStringICryptoTransform binaryCrossAppDomainStringICryptoTransform_0)
	{
		List<double> serverWellKnownEntrySoapDate = binaryCrossAppDomainStringICryptoTransform_0.ServerWellKnownEntrySoapDate;
		double num = binaryCrossAppDomainStringICryptoTransform_0.ReadDelegateICryptoTransform + 1.0;
		binaryCrossAppDomainStringICryptoTransform_0.ReadDelegateICryptoTransform = num;
		return serverWellKnownEntrySoapDate[(int)num];
	}

	internal static global::UInt16.BinaryCrossAppDomainStringICryptoTransform IMessageCtrlIEnumConnections(global::UInt16.AuthorizationRuleCollectionThrowHelper authorizationRuleCollectionThrowHelper_0, List<double> list_0, double double_0, double double_1)
	{
		return new global::UInt16.BinaryCrossAppDomainStringICryptoTransform
		{
			DefaultBinderThreadInterruptedException = authorizationRuleCollectionThrowHelper_0,
			ServerWellKnownEntrySoapDate = list_0,
			ReadDelegateICryptoTransform = double_0,
			CORINFOEHCLAUSEGenericAce = 0.0,
			ISymbolVariableInternalMemberValueE = -1.0,
			IList1 = new List<double>((int)double_1),
			SkipAddresses = new List<double>(global::UInt16.ScopeTreeUInt64)
		};
	}

	internal static global::UInt16.BinaryCrossAppDomainStringICryptoTransform CalendarWeekRuleChineseLunisolarCalendar(global::UInt16.BinaryCrossAppDomainStringICryptoTransform binaryCrossAppDomainStringICryptoTransform_0)
	{
		int num = 0;
		for (;;)
		{
			double num2;
			if (num == 11)
			{
				num2 = global::UInt16.TypeLibImportClassAttribute(binaryCrossAppDomainStringICryptoTransform_0);
				num = 12;
			}
			if (num == 9)
			{
				goto IL_914;
			}
			goto IL_9B7;
			IL_84C:
			if (num == 8)
			{
				goto IL_986;
			}
			double num3;
			if (num == 17)
			{
				num3 = global::UInt16.TypeLibImportClassAttribute(binaryCrossAppDomainStringICryptoTransform_0);
				num = 18;
			}
			if (num == 12)
			{
				num3 = global::UInt16.TypeLibImportClassAttribute(binaryCrossAppDomainStringICryptoTransform_0);
				num = 13;
			}
			if (num == 26)
			{
				num2 = global::UInt16.IPermission(binaryCrossAppDomainStringICryptoTransform_0);
				num = 27;
			}
			if (num == 5)
			{
				num2 = global::UInt16.TypeLibImportClassAttribute(binaryCrossAppDomainStringICryptoTransform_0);
				num = 6;
			}
			double num4;
			if (num == 4)
			{
				if (num4 != binaryCrossAppDomainStringICryptoTransform_0.DefaultBinderThreadInterruptedException.ICollectionMetadataColumn)
				{
					goto IL_914;
				}
				num = 5;
			}
			if (num == 0)
			{
				num = 1;
			}
			if (num == 28)
			{
				global::UInt16.InternalActivationContextHelper(binaryCrossAppDomainStringICryptoTransform_0, (double)((num3 < num2) ? 1 : 0));
				binaryCrossAppDomainStringICryptoTransform_0.ReadDelegateICryptoTransform += 1.0;
				goto IL_986;
			}
			continue;
			IL_287:
			if (num == 24)
			{
				goto IL_986;
			}
			if (num == 25)
			{
				goto IL_2A7;
			}
			goto IL_84C;
			IL_229:
			if (num == 27)
			{
				num3 = global::UInt16.TypeLibImportClassAttribute(binaryCrossAppDomainStringICryptoTransform_0);
				num = 28;
			}
			if (num == 6)
			{
				num3 = global::UInt16.TypeLibImportClassAttribute(binaryCrossAppDomainStringICryptoTransform_0);
				num = 7;
			}
			if (num == 16)
			{
				num2 = global::UInt16.TypeLibImportClassAttribute(binaryCrossAppDomainStringICryptoTransform_0);
				num = 17;
			}
			if (num == 15)
			{
				goto IL_1C4;
			}
			goto IL_287;
			IL_1FD:
			bool flag;
			if (num == 1)
			{
				flag = false;
				num = 2;
			}
			if (num != 3)
			{
				goto IL_229;
			}
			goto IL_23E;
			IL_9B7:
			if (num == 22)
			{
				num3 = global::UInt16.TypeLibImportClassAttribute(binaryCrossAppDomainStringICryptoTransform_0);
				num = 23;
			}
			if (num == 23)
			{
				global::UInt16.InternalActivationContextHelper(binaryCrossAppDomainStringICryptoTransform_0, num3 / num2);
				num = 24;
			}
			if (num == 21)
			{
				num2 = global::UInt16.TypeLibImportClassAttribute(binaryCrossAppDomainStringICryptoTransform_0);
				num = 22;
			}
			if (num == 7)
			{
				global::UInt16.InternalActivationContextHelper(binaryCrossAppDomainStringICryptoTransform_0, num3 + num2);
				num = 8;
			}
			if (num == 14 || num == 19)
			{
				goto IL_986;
			}
			if (num == 18)
			{
				global::UInt16.InternalActivationContextHelper(binaryCrossAppDomainStringICryptoTransform_0, num3 + num2);
				num = 19;
			}
			if (num == 13)
			{
				global::UInt16.InternalActivationContextHelper(binaryCrossAppDomainStringICryptoTransform_0, num3 - num2);
				num = 14;
			}
			if (num == 2)
			{
				goto IL_986;
			}
			if (num == 10)
			{
				if (num4 != binaryCrossAppDomainStringICryptoTransform_0.DefaultBinderThreadInterruptedException.ComAliasNameAttribute)
				{
					goto IL_1C4;
				}
				num = 11;
			}
			if (num != 20)
			{
				goto IL_1FD;
			}
			goto IL_1DD;
			IL_2A7:
			if (num4 == binaryCrossAppDomainStringICryptoTransform_0.DefaultBinderThreadInterruptedException.DSAParametersMidpointRounding)
			{
				num = 26;
				goto IL_84C;
			}
			if (num4 == binaryCrossAppDomainStringICryptoTransform_0.DefaultBinderThreadInterruptedException.RemotingTypeCachedData)
			{
				num2 = global::UInt16.IPermission(binaryCrossAppDomainStringICryptoTransform_0);
				num3 = global::UInt16.TypeLibImportClassAttribute(binaryCrossAppDomainStringICryptoTransform_0);
				global::UInt16.InternalActivationContextHelper(binaryCrossAppDomainStringICryptoTransform_0, (double)((num3 > num2) ? 1 : 0));
				binaryCrossAppDomainStringICryptoTransform_0.ReadDelegateICryptoTransform += 1.0;
				goto IL_986;
			}
			if (num4 == binaryCrossAppDomainStringICryptoTransform_0.DefaultBinderThreadInterruptedException.CharEnumeratorIComparable)
			{
				num2 = global::UInt16.IPermission(binaryCrossAppDomainStringICryptoTransform_0);
				if (num2 == binaryCrossAppDomainStringICryptoTransform_0.DefaultBinderThreadInterruptedException.HebrewTokenTypeLibImporterFlags)
				{
					num2 = binaryCrossAppDomainStringICryptoTransform_0.IList1[0];
				}
				num3 = global::UInt16.TypeLibImportClassAttribute(binaryCrossAppDomainStringICryptoTransform_0);
				global::UInt16.InternalActivationContextHelper(binaryCrossAppDomainStringICryptoTransform_0, (double)(num3.Equals(num2) ? 1 : 0));
				binaryCrossAppDomainStringICryptoTransform_0.ReadDelegateICryptoTransform += 1.0;
				goto IL_986;
			}
			if (num4 == binaryCrossAppDomainStringICryptoTransform_0.DefaultBinderThreadInterruptedException.TypeNAssemblyLSATRANSLATEDSID2)
			{
				binaryCrossAppDomainStringICryptoTransform_0.ReadDelegateICryptoTransform = global::UInt16.IPermission(binaryCrossAppDomainStringICryptoTransform_0);
				goto IL_986;
			}
			if (num4 == binaryCrossAppDomainStringICryptoTransform_0.DefaultBinderThreadInterruptedException.FixupHolderReadOnlyArrayList)
			{
				double readDelegateICryptoTransform = global::UInt16.IPermission(binaryCrossAppDomainStringICryptoTransform_0);
				if (global::UInt16.TypeLibImportClassAttribute(binaryCrossAppDomainStringICryptoTransform_0) == 1.0)
				{
					binaryCrossAppDomainStringICryptoTransform_0.ReadDelegateICryptoTransform = readDelegateICryptoTransform;
				}
				binaryCrossAppDomainStringICryptoTransform_0.ReadDelegateICryptoTransform += 1.0;
				goto IL_986;
			}
			if (num4 == binaryCrossAppDomainStringICryptoTransform_0.DefaultBinderThreadInterruptedException.Rfc2898DeriveBytesSoapYearMonth)
			{
				double readDelegateICryptoTransform = global::UInt16.IPermission(binaryCrossAppDomainStringICryptoTransform_0);
				if (global::UInt16.TypeLibImportClassAttribute(binaryCrossAppDomainStringICryptoTransform_0) == 0.0)
				{
					binaryCrossAppDomainStringICryptoTransform_0.ReadDelegateICryptoTransform = readDelegateICryptoTransform;
					goto IL_986;
				}
				binaryCrossAppDomainStringICryptoTransform_0.ReadDelegateICryptoTransform += 1.0;
				goto IL_986;
			}
			else
			{
				if (num4 == binaryCrossAppDomainStringICryptoTransform_0.DefaultBinderThreadInterruptedException.PublisherIdentityPermission)
				{
					double num5 = global::UInt16.IPermission(binaryCrossAppDomainStringICryptoTransform_0);
					if (num5 == binaryCrossAppDomainStringICryptoTransform_0.DefaultBinderThreadInterruptedException.HebrewTokenTypeLibImporterFlags)
					{
						num5 = binaryCrossAppDomainStringICryptoTransform_0.IList1[0];
					}
					global::UInt16.InternalActivationContextHelper(binaryCrossAppDomainStringICryptoTransform_0, num5);
					binaryCrossAppDomainStringICryptoTransform_0.ReadDelegateICryptoTransform += 1.0;
					goto IL_986;
				}
				if (num4 == binaryCrossAppDomainStringICryptoTransform_0.DefaultBinderThreadInterruptedException.DuplicateWaitObjectExceptionIBuiltInEvidence)
				{
					binaryCrossAppDomainStringICryptoTransform_0.SkipAddresses.Remove(binaryCrossAppDomainStringICryptoTransform_0.SkipAddresses[binaryCrossAppDomainStringICryptoTransform_0.SkipAddresses.Count - 1]);
					goto IL_986;
				}
				if (num4 == binaryCrossAppDomainStringICryptoTransform_0.DefaultBinderThreadInterruptedException.SizedArray)
				{
					binaryCrossAppDomainStringICryptoTransform_0.FileSystemInfoTypeLibTypeAttribute = global::UInt16.TypeLibImportClassAttribute(binaryCrossAppDomainStringICryptoTransform_0);
					flag = true;
					goto IL_986;
				}
				if (num4 == binaryCrossAppDomainStringICryptoTransform_0.DefaultBinderThreadInterruptedException.OpFlagsEnvironment)
				{
					double num5 = binaryCrossAppDomainStringICryptoTransform_0.SkipAddresses[binaryCrossAppDomainStringICryptoTransform_0.SkipAddresses.Count - 1];
					binaryCrossAppDomainStringICryptoTransform_0.IList1.Insert(0, num5);
					goto IL_986;
				}
				if (num4 == binaryCrossAppDomainStringICryptoTransform_0.DefaultBinderThreadInterruptedException.InternalParseTypeEObjectCloneHelper)
				{
					double num5 = global::UInt16.IPermission(binaryCrossAppDomainStringICryptoTransform_0);
					binaryCrossAppDomainStringICryptoTransform_0.IList1.Insert(1, num5);
					goto IL_986;
				}
				if (num4 == binaryCrossAppDomainStringICryptoTransform_0.DefaultBinderThreadInterruptedException.double_1)
				{
					double num5 = global::UInt16.IPermission(binaryCrossAppDomainStringICryptoTransform_0);
					binaryCrossAppDomainStringICryptoTransform_0.IList1.Insert(2, num5);
					goto IL_986;
				}
				if (num4 == binaryCrossAppDomainStringICryptoTransform_0.DefaultBinderThreadInterruptedException.KerbLogonSubmitTypeInternalElementTypeE)
				{
					double num5 = global::UInt16.IPermission(binaryCrossAppDomainStringICryptoTransform_0);
					binaryCrossAppDomainStringICryptoTransform_0.IList1.Insert(3, num5);
					goto IL_986;
				}
				if (num4 == binaryCrossAppDomainStringICryptoTransform_0.DefaultBinderThreadInterruptedException.HebrewTokenTypeLibImporterFlags)
				{
					double num5 = binaryCrossAppDomainStringICryptoTransform_0.IList1[0];
					global::UInt16.InternalActivationContextHelper(binaryCrossAppDomainStringICryptoTransform_0, num5);
					goto IL_986;
				}
				if (num4 == binaryCrossAppDomainStringICryptoTransform_0.DefaultBinderThreadInterruptedException.SecurityContextRunDataFieldOnTypeBuilderInstantiation)
				{
					double num5 = binaryCrossAppDomainStringICryptoTransform_0.IList1[1];
					global::UInt16.InternalActivationContextHelper(binaryCrossAppDomainStringICryptoTransform_0, num5);
					goto IL_986;
				}
				if (num4 == binaryCrossAppDomainStringICryptoTransform_0.DefaultBinderThreadInterruptedException.SoapAttributeSignatureToken)
				{
					double num5 = binaryCrossAppDomainStringICryptoTransform_0.IList1[2];
					global::UInt16.InternalActivationContextHelper(binaryCrossAppDomainStringICryptoTransform_0, num5);
					goto IL_986;
				}
				if (num4 == binaryCrossAppDomainStringICryptoTransform_0.DefaultBinderThreadInterruptedException.CmsUtils)
				{
					double num5 = binaryCrossAppDomainStringICryptoTransform_0.IList1[3];
					global::UInt16.InternalActivationContextHelper(binaryCrossAppDomainStringICryptoTransform_0, num5);
					goto IL_986;
				}
				if (num4 == binaryCrossAppDomainStringICryptoTransform_0.DefaultBinderThreadInterruptedException.UnknownWrapperGacIdentityPermission)
				{
					num2 = global::UInt16.TypeLibImportClassAttribute(binaryCrossAppDomainStringICryptoTransform_0);
					num3 = global::UInt16.TypeLibImportClassAttribute(binaryCrossAppDomainStringICryptoTransform_0);
					global::UInt16.InternalActivationContextHelper(binaryCrossAppDomainStringICryptoTransform_0, (double)((int)num3 << (int)num2));
					goto IL_986;
				}
				if (num4 == binaryCrossAppDomainStringICryptoTransform_0.DefaultBinderThreadInterruptedException.OverflowException)
				{
					num2 = global::UInt16.TypeLibImportClassAttribute(binaryCrossAppDomainStringICryptoTransform_0);
					num3 = global::UInt16.TypeLibImportClassAttribute(binaryCrossAppDomainStringICryptoTransform_0);
					global::UInt16.InternalActivationContextHelper(binaryCrossAppDomainStringICryptoTransform_0, (double)((int)num3 >> (int)num2));
					goto IL_986;
				}
				goto IL_986;
			}
			IL_1DD:
			if (num4 == binaryCrossAppDomainStringICryptoTransform_0.DefaultBinderThreadInterruptedException.double_0)
			{
				num = 21;
				goto IL_1FD;
			}
			goto IL_2A7;
			IL_1C4:
			if (num4 == binaryCrossAppDomainStringICryptoTransform_0.DefaultBinderThreadInterruptedException.DateTimeResultIMethodCallMessage)
			{
				num = 16;
				goto IL_287;
			}
			goto IL_1DD;
			IL_23E:
			List<double> serverWellKnownEntrySoapDate = binaryCrossAppDomainStringICryptoTransform_0.ServerWellKnownEntrySoapDate;
			double num6 = binaryCrossAppDomainStringICryptoTransform_0.ReadDelegateICryptoTransform + 1.0;
			binaryCrossAppDomainStringICryptoTransform_0.ReadDelegateICryptoTransform = num6;
			num4 = serverWellKnownEntrySoapDate[(int)num6];
			num = 4;
			goto IL_229;
			IL_986:
			if (flag)
			{
				break;
			}
			goto IL_23E;
			IL_914:
			if (num4 != binaryCrossAppDomainStringICryptoTransform_0.DefaultBinderThreadInterruptedException.Binder)
			{
				num = 10;
				goto IL_9B7;
			}
			goto IL_986;
		}
		return binaryCrossAppDomainStringICryptoTransform_0;
	}

	internal static global::UInt16.AuthorizationRuleCollectionThrowHelper ScopeTreeAssociateRecord;

	internal static int ScopeTreeUInt64 = 100;

	internal class AuthorizationRuleCollectionThrowHelper
	{
		internal AuthorizationRuleCollectionThrowHelper(List<double> list_0)
		{
			this.ICollectionMetadataColumn = list_0[1];
			this.ComAliasNameAttribute = list_0[2];
			this.DateTimeResultIMethodCallMessage = list_0[3];
			this.double_0 = list_0[4];
			this.DSAParametersMidpointRounding = list_0[5];
			this.RemotingTypeCachedData = list_0[6];
			this.CharEnumeratorIComparable = list_0[7];
			this.TypeNAssemblyLSATRANSLATEDSID2 = list_0[8];
			this.FixupHolderReadOnlyArrayList = list_0[9];
			this.Rfc2898DeriveBytesSoapYearMonth = list_0[10];
			this.PublisherIdentityPermission = list_0[11];
			this.DuplicateWaitObjectExceptionIBuiltInEvidence = list_0[12];
			this.SizedArray = list_0[13];
			this.OpFlagsEnvironment = list_0[14];
			this.InternalParseTypeEObjectCloneHelper = list_0[15];
			this.double_1 = list_0[16];
			this.KerbLogonSubmitTypeInternalElementTypeE = list_0[17];
			this.HebrewTokenTypeLibImporterFlags = list_0[18];
			this.SecurityContextRunDataFieldOnTypeBuilderInstantiation = list_0[19];
			this.SoapAttributeSignatureToken = list_0[20];
			this.CmsUtils = list_0[21];
			this.UnknownWrapperGacIdentityPermission = list_0[22];
			this.OverflowException = list_0[23];
			this.Binder = list_0[24];
		}

		internal double ICollectionMetadataColumn = 1.0;

		internal double ComAliasNameAttribute = 2.0;

		internal double DateTimeResultIMethodCallMessage = 3.0;

		internal double double_0 = 4.0;

		internal double DSAParametersMidpointRounding = 5.0;

		internal double RemotingTypeCachedData = 6.0;

		internal double CharEnumeratorIComparable = 7.0;

		internal double TypeNAssemblyLSATRANSLATEDSID2 = 8.0;

		internal double FixupHolderReadOnlyArrayList = 9.0;

		internal double Rfc2898DeriveBytesSoapYearMonth = 10.0;

		internal double PublisherIdentityPermission = 11.0;

		internal double DuplicateWaitObjectExceptionIBuiltInEvidence = 12.0;

		internal double SizedArray = 13.0;

		internal double OpFlagsEnvironment = 14.0;

		internal double InternalParseTypeEObjectCloneHelper = 15.0;

		internal double double_1 = 16.0;

		internal double KerbLogonSubmitTypeInternalElementTypeE = 17.0;

		internal double HebrewTokenTypeLibImporterFlags = 18.0;

		internal double SecurityContextRunDataFieldOnTypeBuilderInstantiation = 19.0;

		internal double SoapAttributeSignatureToken = 20.0;

		internal double CmsUtils = 21.0;

		internal double UnknownWrapperGacIdentityPermission = 22.0;

		internal double OverflowException = 23.0;

		internal double Binder = 24.0;
	}

	internal struct BinaryCrossAppDomainStringICryptoTransform
	{
		internal List<double> IList1;

		internal List<double> ServerWellKnownEntrySoapDate;

		internal List<double> SkipAddresses;

		internal double ReadDelegateICryptoTransform;

		internal double ISymbolVariableInternalMemberValueE;

		internal double CORINFOEHCLAUSEGenericAce;

		internal double FileSystemInfoTypeLibTypeAttribute;

		internal global::UInt16.AuthorizationRuleCollectionThrowHelper DefaultBinderThreadInterruptedException;
	}
}
