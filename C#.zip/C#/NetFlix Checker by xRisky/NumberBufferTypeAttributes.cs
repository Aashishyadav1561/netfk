﻿using System;

internal delegate object NumberBufferTypeAttributes(char[] char_0);
