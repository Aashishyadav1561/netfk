﻿using System;

internal delegate byte[] NullReferenceException(object object_0);
