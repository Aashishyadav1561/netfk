﻿using System;
using System.Drawing;

internal delegate void EntryDefaultDependencyAttribute(object object_0, Point point_0);
