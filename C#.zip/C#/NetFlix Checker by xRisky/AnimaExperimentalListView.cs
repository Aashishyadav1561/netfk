﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using WindowsApp45.My;

namespace WindowsApp45
{
	[Obfuscation(Exclude = true)]
	[Obfuscation(Exclude = true)]
	public class AnimaExperimentalListView : Control
	{
		public string[] ObjectCreationDelegateCleanupCode { [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] get; [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] set; }

		public ListViewItem[] InterlockedThreadAbortException { [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] get; [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] set; }

		public int Int32_0 { [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] get; [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] set; }

		public int SurrogateHashtable { [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] get; [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] set; }

		public List<int> CodePageEncodingManifestResourceAttributes { [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] get; [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] set; }

		public bool RegistryPermissionAccess { [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] get; [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] set; }

		public int TextInfo { [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] get; [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] set; }

		public bool CustomErrorsModes { [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] get; [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] set; }

		public bool CodePageDataItemStringReader { [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] get; [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] set; }

		public int EventWaitHandleAuditRule { [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] get; [Obfuscation(Exclude = true)] [Obfuscation(Exclude = true)] set; }

		public int FileIOPermissionAttributeIdnMapping
		{
			[Obfuscation(Exclude = true)]
			[Obfuscation(Exclude = true)]
			get
			{
				return this.CodePageEncodingManifestResourceAttributes.Count;
			}
		}

		public ListViewItem ILGenerator
		{
			[Obfuscation(Exclude = true)]
			[Obfuscation(Exclude = true)]
			get
			{
				ListViewItem result;
				if (Information.IsNothing(this.CodePageEncodingManifestResourceAttributes))
				{
					result = new ListViewItem();
				}
				else
				{
					result = this.InterlockedThreadAbortException[this.CodePageEncodingManifestResourceAttributes[0]];
				}
				return result;
			}
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		public void Add(ListViewItem Item)
		{
			<Module>.SoapFieldAttribute(140);
			List<ListViewItem> list = this.InterlockedThreadAbortException.ToList<ListViewItem>();
			list.Add(Item);
			this.InterlockedThreadAbortException = list.ToArray();
			base.Invalidate();
		}

		public event AnimaExperimentalListView.StringToken SponsorInfoTokenizer
		{
			[Obfuscation(Exclude = true)]
			[Obfuscation(Exclude = true)]
			[CompilerGenerated]
			add
			{
				<Module>.SoapFieldAttribute(141);
				AnimaExperimentalListView.StringToken stringToken = this.SortedListEnumeratorIFormatter;
				AnimaExperimentalListView.StringToken stringToken2;
				do
				{
					stringToken2 = stringToken;
					AnimaExperimentalListView.StringToken value2 = (AnimaExperimentalListView.StringToken)Delegate.Combine(stringToken2, value);
					stringToken = Interlocked.CompareExchange<AnimaExperimentalListView.StringToken>(ref this.SortedListEnumeratorIFormatter, value2, stringToken2);
				}
				while (stringToken != stringToken2);
			}
			[CompilerGenerated]
			[Obfuscation(Exclude = true)]
			[Obfuscation(Exclude = true)]
			remove
			{
				<Module>.SoapFieldAttribute(142);
				AnimaExperimentalListView.StringToken stringToken = this.SortedListEnumeratorIFormatter;
				AnimaExperimentalListView.StringToken stringToken2;
				do
				{
					stringToken2 = stringToken;
					AnimaExperimentalListView.StringToken value2 = (AnimaExperimentalListView.StringToken)Delegate.Remove(stringToken2, value);
					stringToken = Interlocked.CompareExchange<AnimaExperimentalListView.StringToken>(ref this.SortedListEnumeratorIFormatter, value2, stringToken2);
				}
				while (stringToken != stringToken2);
			}
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		public AnimaExperimentalListView()
		{
			this.Int32_0 = 120;
			this.SurrogateHashtable = -1;
			this.CodePageEncodingManifestResourceAttributes = new List<int>();
			this.TextInfo = -1;
			this.EventWaitHandleAuditRule = 16;
			this.SerializationInfoEnumerator = -1;
			this.DoubleBuffered = true;
			this.ForeColor = Color.FromArgb(200, 200, 200);
			this.Font = new Font("Segoe UI", 9f);
			base.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		private SolidBrush ReturnForeFromItem(int I, ListViewItem Item)
		{
			SolidBrush result;
			if (this.CodePageEncodingManifestResourceAttributes.Contains(I))
			{
				result = new SolidBrush(Color.FromArgb(10, 10, 10));
			}
			else if (this.CustomErrorsModes)
			{
				result = new SolidBrush(Item.ForeColor);
			}
			else
			{
				result = new SolidBrush(this.ForeColor);
			}
			return result;
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		private SolidBrush ReturnForeFromSubItem(int I, ListViewItem.ListViewSubItem Item)
		{
			SolidBrush result;
			if (this.CodePageEncodingManifestResourceAttributes.Contains(I))
			{
				result = new SolidBrush(Color.FromArgb(10, 10, 10));
			}
			else if (this.CustomErrorsModes)
			{
				result = new SolidBrush(Item.ForeColor);
			}
			else
			{
				result = new SolidBrush(this.ForeColor);
			}
			return result;
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		protected override void OnPaint(PaintEventArgs e)
		{
			<Module>.SoapFieldAttribute(143);
			e.Graphics.Clear(Color.FromArgb(50, 50, 53));
			checked
			{
				using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(55, 55, 58)))
				{
					e.Graphics.FillRectangle(solidBrush, new Rectangle(1, 1, base.Width - 2, 26));
				}
				using (Pen pen = new Pen(Color.FromArgb(42, 42, 45)))
				{
					using (Pen pen2 = new Pen(Color.FromArgb(65, 65, 68)))
					{
						e.Graphics.DrawRectangle(pen, new Rectangle(0, 0, base.Width - 1, base.Height - 1));
						e.Graphics.DrawRectangle(pen, new Rectangle(0, 0, base.Width - 1, 26));
						e.Graphics.DrawLine(pen2, 1, 1, base.Width - 2, 1);
					}
				}
				if (!Information.IsNothing(this.ObjectCreationDelegateCleanupCode))
				{
					int num = this.ObjectCreationDelegateCleanupCode.Count<string>() - 1;
					for (int i = 0; i <= num; i++)
					{
						if (i != 0)
						{
							using (SolidBrush solidBrush2 = new SolidBrush(Color.FromArgb(42, 42, 45)))
							{
								using (SolidBrush solidBrush3 = new SolidBrush(Color.FromArgb(65, 65, 68)))
								{
									e.Graphics.FillRectangle(solidBrush2, new Rectangle(this.Int32_0 * i, 1, 1, 26));
									e.Graphics.FillRectangle(solidBrush3, new Rectangle(this.Int32_0 * i - 1, 1, 1, 25));
									if (this.CodePageDataItemStringReader && !Information.IsNothing(this.InterlockedThreadAbortException))
									{
										e.Graphics.FillRectangle(solidBrush2, new Rectangle(this.Int32_0 * i, 1, 1, 26 + this.InterlockedThreadAbortException.Count<ListViewItem>() * this.EventWaitHandleAuditRule));
										e.Graphics.FillRectangle(solidBrush3, new Rectangle(this.Int32_0 * i - 1, 1, 1, 25 + this.InterlockedThreadAbortException.Count<ListViewItem>() * this.EventWaitHandleAuditRule));
									}
								}
							}
						}
						using (SolidBrush solidBrush4 = new SolidBrush(this.ForeColor))
						{
							e.Graphics.DrawString(this.ObjectCreationDelegateCleanupCode[i], this.Font, solidBrush4, new Point(this.Int32_0 * i + 6, 4));
						}
					}
				}
				if (!Information.IsNothing(this.InterlockedThreadAbortException))
				{
					if (this.TextInfo != -1)
					{
						using (SolidBrush solidBrush5 = new SolidBrush(Color.FromArgb(66, 66, 69)))
						{
							using (Pen pen3 = new Pen(Color.FromArgb(45, 45, 48)))
							{
								e.Graphics.FillRectangle(solidBrush5, new Rectangle(1, 26 + this.TextInfo * this.EventWaitHandleAuditRule, base.Width - 2, this.EventWaitHandleAuditRule));
								e.Graphics.DrawRectangle(pen3, new Rectangle(1, 26 + this.TextInfo * this.EventWaitHandleAuditRule, base.Width - 2, this.EventWaitHandleAuditRule));
							}
						}
					}
					using (SolidBrush solidBrush6 = new SolidBrush(Color.FromArgb(41, 130, 232)))
					{
						using (Pen pen4 = new Pen(Color.FromArgb(40, 40, 40)))
						{
							if (this.RegistryPermissionAccess && this.CodePageEncodingManifestResourceAttributes.Count != 0)
							{
								try
								{
									foreach (int num2 in this.CodePageEncodingManifestResourceAttributes)
									{
										e.Graphics.FillRectangle(solidBrush6, new Rectangle(1, 26 + num2 * this.EventWaitHandleAuditRule, base.Width - 2, this.EventWaitHandleAuditRule));
										if (num2 == 0 && this.CodePageEncodingManifestResourceAttributes.Count == 1)
										{
											e.Graphics.DrawLine(pen4, 1, 26 + this.EventWaitHandleAuditRule, base.Width - 2, 26 + this.EventWaitHandleAuditRule);
										}
										else if (this.CodePageEncodingManifestResourceAttributes.Count == 1)
										{
											e.Graphics.DrawLine(pen4, 1, 26 + this.EventWaitHandleAuditRule + num2 * this.EventWaitHandleAuditRule, base.Width - 2, 26 + this.EventWaitHandleAuditRule + num2 * this.EventWaitHandleAuditRule);
										}
									}
									goto IL_6DF;
								}
								finally
								{
									List<int>.Enumerator enumerator;
									((IDisposable)enumerator).Dispose();
								}
							}
							if (this.CodePageEncodingManifestResourceAttributes.Count != 0)
							{
								e.Graphics.FillRectangle(solidBrush6, new Rectangle(1, 26 + this.SurrogateHashtable * this.EventWaitHandleAuditRule, base.Width - 2, this.EventWaitHandleAuditRule));
							}
							IL_6DF:;
						}
					}
					if (this.CodePageEncodingManifestResourceAttributes.Count > 0)
					{
						this.SerializationInfoEnumerator = this.CodePageEncodingManifestResourceAttributes.Max();
					}
					int num3 = this.InterlockedThreadAbortException.Count<ListViewItem>() - 1;
					for (int j = 0; j <= num3; j++)
					{
						e.Graphics.DrawString(this.InterlockedThreadAbortException[j].Text, this.Font, this.ReturnForeFromItem(j, this.InterlockedThreadAbortException[j]), new Point(6, 26 + j * this.EventWaitHandleAuditRule + 2));
						if (!Information.IsNothing(this.InterlockedThreadAbortException[j].SubItems))
						{
							int num4 = this.InterlockedThreadAbortException[j].SubItems.Count - 1;
							for (int k = 0; k <= num4; k++)
							{
								if (Operators.CompareString(this.InterlockedThreadAbortException[j].SubItems[k].Text, this.InterlockedThreadAbortException[j].Text, false) != 0)
								{
									e.Graphics.DrawString(this.InterlockedThreadAbortException[j].SubItems[k].Text, this.Font, this.ReturnForeFromSubItem(j, this.InterlockedThreadAbortException[j].SubItems[k]), new Rectangle(this.Int32_0 * k + 6, 26 + j * this.EventWaitHandleAuditRule + 2, this.Int32_0 - 8, 16));
								}
							}
						}
					}
					if (this.CodePageEncodingManifestResourceAttributes.Contains(this.SerializationInfoEnumerator))
					{
						using (Pen pen5 = new Pen(Color.FromArgb(40, 40, 40)))
						{
							e.Graphics.DrawLine(pen5, 1, 26 + this.EventWaitHandleAuditRule + this.SerializationInfoEnumerator * this.EventWaitHandleAuditRule, base.Width - 2, 26 + this.EventWaitHandleAuditRule + this.SerializationInfoEnumerator * this.EventWaitHandleAuditRule);
						}
					}
				}
				base.OnPaint(e);
			}
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		protected override void OnMouseUp(MouseEventArgs e)
		{
			<Module>.SoapFieldAttribute(144);
			int selectedFromLocation = this.GetSelectedFromLocation(e.Location);
			if (selectedFromLocation != -1 && e.Button == MouseButtons.Left)
			{
				if (this.RegistryPermissionAccess && MyProject.BinderState.Keyboard.CtrlKeyDown)
				{
					if (!this.CodePageEncodingManifestResourceAttributes.Contains(selectedFromLocation))
					{
						this.CodePageEncodingManifestResourceAttributes.Add(selectedFromLocation);
					}
					else
					{
						this.CodePageEncodingManifestResourceAttributes.Remove(selectedFromLocation);
					}
				}
				else if (this.RegistryPermissionAccess && !MyProject.BinderState.Keyboard.CtrlKeyDown)
				{
					this.CodePageEncodingManifestResourceAttributes = new List<int>
					{
						selectedFromLocation
					};
				}
				else
				{
					this.CodePageEncodingManifestResourceAttributes = new List<int>
					{
						selectedFromLocation
					};
					this.SurrogateHashtable = selectedFromLocation;
				}
				if (selectedFromLocation == -1)
				{
					this.CodePageEncodingManifestResourceAttributes = new List<int>();
				}
				base.Invalidate();
				AnimaExperimentalListView.StringToken sortedListEnumeratorIFormatter = this.SortedListEnumeratorIFormatter;
				if (sortedListEnumeratorIFormatter != null)
				{
					sortedListEnumeratorIFormatter(this, selectedFromLocation);
				}
				base.OnMouseUp(e);
			}
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		private int GetSelectedFromLocation(Point P)
		{
			checked
			{
				if (!Information.IsNothing(this.InterlockedThreadAbortException))
				{
					int num = this.InterlockedThreadAbortException.Count<ListViewItem>() - 1;
					for (int i = 0; i <= num; i++)
					{
						if (new Rectangle(1, 26 + i * this.EventWaitHandleAuditRule, base.Width - 2, this.EventWaitHandleAuditRule).Contains(P))
						{
							return i;
						}
					}
				}
				return -1;
			}
		}

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private string[] DriveInfoValueTypeFixupInfo;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private ListViewItem[] Latin1Encoding;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int OpCode;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int IsLong;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private List<int> ISoapXsdSyncTextReader;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private bool AttributeTargetsISymbolScope;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int HebrewValue;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private bool StoreOperationPinDeployment;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private bool SatelliteContractVersionAttribute;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int InternalEncoderBestFitFallbackBufferAmbiguousMatchException;

		private int SerializationInfoEnumerator;

		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private AnimaExperimentalListView.StringToken SortedListEnumeratorIFormatter;

		public delegate void StringToken(object Sender, int Index);
	}
}
