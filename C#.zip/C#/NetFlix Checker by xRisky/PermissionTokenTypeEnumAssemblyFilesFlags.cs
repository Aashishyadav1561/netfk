﻿using System;
using System.Reflection.Emit;

internal delegate void PermissionTokenTypeEnumAssemblyFilesFlags(object object_0, OpCode opCode_0);
