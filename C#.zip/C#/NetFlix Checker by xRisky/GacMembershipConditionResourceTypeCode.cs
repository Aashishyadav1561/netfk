﻿using System;

internal delegate int GacMembershipConditionResourceTypeCode(object object_0, string string_0, int int_0);
