﻿using System;

internal delegate uint FileSystemSecurity(byte[] byte_0);
