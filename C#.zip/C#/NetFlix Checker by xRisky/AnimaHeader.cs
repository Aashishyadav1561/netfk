﻿using System;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

namespace WindowsApp45
{
	[Obfuscation(Exclude = true)]
	[Obfuscation(Exclude = true)]
	public class AnimaHeader : Control
	{
		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		public AnimaHeader()
		{
			this.DoubleBuffered = true;
			this.Font = new Font("Segoe UI", 9f);
			base.Location = new Point(1, 1);
			base.Size = new Size(checked(base.Width - 2), 36);
			this.ForeColor = Color.FromArgb(200, 200, 200);
		}

		[Obfuscation(Exclude = true)]
		[Obfuscation(Exclude = true)]
		protected override void OnPaint(PaintEventArgs e)
		{
			<Module>.SoapFieldAttribute(167);
			this.SearchDataRealProxyFlags = e.Graphics;
			checked
			{
				using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(55, 55, 58)))
				{
					this.SearchDataRealProxyFlags.FillRectangle(solidBrush, new Rectangle(0, 0, base.Width - 1, base.Height - 1));
				}
				using (Pen pen = new Pen(Color.FromArgb(43, 43, 46)))
				{
					this.SearchDataRealProxyFlags.DrawLine(pen, 0, base.Height - 1, base.Width - 1, base.Height - 1);
				}
				using (SolidBrush solidBrush2 = new SolidBrush(this.ForeColor))
				{
					this.SearchDataRealProxyFlags.DrawString(this.Text, this.Font, solidBrush2, new Point(6, 6));
				}
				base.OnPaint(e);
			}
		}

		private Graphics SearchDataRealProxyFlags;
	}
}
