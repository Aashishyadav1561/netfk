﻿using System;

internal class STAThreadAttributeIndexOutOfRangeException : Attribute
{
	internal STAThreadAttributeIndexOutOfRangeException(int int_0)
	{
		this.DBCSDecoder = (-617663839 - -int_0 * -2110681353 - -515444146 + 317032) * 976070433;
	}

	public virtual int BinaryMethodReturnMessage()
	{
		return this.DBCSDecoder;
	}

	internal readonly int DBCSDecoder;
}
