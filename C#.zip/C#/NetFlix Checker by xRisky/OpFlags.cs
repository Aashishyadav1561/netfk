﻿using System;

internal delegate string OpFlags(object object_0, int int_0, int int_1);
