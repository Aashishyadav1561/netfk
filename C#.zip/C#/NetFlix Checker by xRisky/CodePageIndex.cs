﻿using System;

internal delegate int CodePageIndex(object object_0, object[] object_1);
