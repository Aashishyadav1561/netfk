﻿using System;

internal class NETGuard : Attribute
{
	public NETGuard(string string_0)
	{
	}
}
